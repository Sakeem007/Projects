
$('.owl-carousel').owlCarousel({
	loop: true,
	margin: 10,
	nav: true,
	autoplayTimeout:2000,
	navText: ['<i class="fa fa-chevron-left"></i>', '<i class="fa fa-chevron-right"></i>'],
	responsiveClass: true,
	responsive: {
		0: {
			 items: 1
		},
		600: {
			items: 1
		},
		1000: {
			items: 2
		}
	 }
});


