<?php include 'header.php'; ?>

<div class="HomeBodyWrapper">
	<div class="BannerBox"><img src="images/homeBanner.png" /></div>
	<div class="container">
		<div class="SearchWrapper">
			<form action="property-listing.php">
				<ul>
					<li>
						<label>Localisation</label>
						<input class="form-control" type="text" placeholder="Ville un code postal" />
					</li>
					<li>
						<label>Type</label>
						<select class="form-control">
							<option>Appartement,...</option>
							<option>Ville</option>
						</select>
					</li>
					<li class="PrixBox">
						<label>Prix</label>
						<input class="form-control" type="text" placeholder="Prix max" /><span>€</span>
					</li>
					<li>
						<label>Nbr de Pièce(S)</label>
						<select class="form-control">
							<option hidden>4,...</option>
							<option>1</option>
							<option>2</option>
							<option>3</option>
							<option>4</option>
						</select>
					</li>
					<li>
						<label>&nbsp;</label>
						<button class="SubmitBrn" type="send">Rechercher</button>
					</li>
				</ul>
			</form>
		</div>
		<div class="Espaceolog"><a href="index.html"><img src="images/EspaceoLogo.png" /></a></div>
		<h1>"Le marché immobilier à porté de tous"</h1>
		<p class="AboutBtn"><a href="javascript:void(0)" data-toggle="modal" data-target="#Pricelist">À Propos</a></p>		
	</div>
	<div class="clearfix"></div>
</div>
	
	

<?php include 'footer.php'; ?>
