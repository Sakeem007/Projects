﻿<?php include 'header.php'; ?>
<div class="prod_listing_wp">	
	<div class="container">
		<div class="TopBtnBox"><span>Acheter | Louer</span> </div>
		<div class="top_srch_cection top_srch_cection1">
			<div class="row">
				<input type="hidden" name="searchType" id="searchType" value="Acheter">
				<input class="first_inpt" list="ville_list" name="q" value="" type="text" placeholder="Ville(s), CP ou dpt">
				<datalist id="ville_list">
					<option value=""></option>
					<option value="BONNEVILLE">BONNEVILLE</option>
					<option value="BONS EN CHABLAIS">BONS EN CHABLAIS</option>
					<option value="BOURGOIN JALLIEU">BOURGOIN JALLIEU</option>
					<option value="CHENS SUR LEMAN">CHENS SUR LEMAN</option>
					<option value="CHEVRY">CHEVRY</option>
					<option value="CHILLY">CHILLY</option>
					<option value="COLLONGES SOUS SALEVE">COLLONGES SOUS SALEVE</option>
					<option value="CRANVES SALES">CRANVES SALES</option>
					<option value="DIVONNE LES BAINS">DIVONNE LES BAINS</option>
					<option value="EVIAN LES BAINS">EVIAN LES BAINS</option>
					<option value="EVIRES">EVIRES</option>
					<option value="FAVERGES SEYTHENEX">FAVERGES SEYTHENEX</option>
					<option value="FILLINGES">FILLINGES</option>
					<option value="GAILLARD">GAILLARD</option>
					<option value="GORDES">GORDES</option>
					<option value="LA TOUR DU PIN">LA TOUR DU PIN</option>
					<option value="MEYTHET">MEYTHET</option>
					<option value="MONNETIER MORNEX">MONNETIER MORNEX</option>
					<option value="Nancy sur Cluses">Nancy sur Cluses</option>
					<option value="ORCIER">ORCIER</option>
					<option value="POISY">POISY</option>
					<option value="RUMILLY">RUMILLY</option>
					<option value="SAMOENS">SAMOENS</option>
					<option value="SCIONZIER">SCIONZIER</option>
					<option value="ST PIERRE EN FAUCIGNY">ST PIERRE EN FAUCIGNY</option>
					<option value="THONON LES BAINS">THONON LES BAINS</option>
					<option value="VETRAZ MONTHOUX">VETRAZ MONTHOUX</option>
				</datalist>
					
				<div class="select_box">				
					<div class="multiselect">
						<div id="Kindgood" class="selectBox" onclick="showCheckboxes()">
							<select>
								<option>Type de bien</option>
							</select>
							<div class="overSelect"></div>
						</div>
						<div id="checkboxes">
							<input type="text" placeholder="Type de bien" />
							<label for="appartement">
								<input type="checkbox" id="appartement" />Appartement
							</label>
							<label for="maison">
								<input type="checkbox" id="maison" />Maison
							</label>
							<label for="terrain">
								<input type="checkbox" id="terrain" />Terrain
							</label>
							<label for="demeure">
								<input type="checkbox" id="demeure" />Demeure
							</label>
							<label for="lcalcommercial">
								<input type="checkbox" id="lcalcommercial" />Local Commercial
							</label>
							<label for="immeuble">
								<input type="checkbox" id="immeuble" />Immeuble
							</label>
							<label for="parking">
								<input type="checkbox" id="parking" />Parking
							</label>
						</div>
					</div>
				</div>
					
				<div class="select_box">				
					<div class="multiselect">
						<div id="Nbpieces" class="selectBox" onclick="showCheckboxes2()">
							<select>
								<option>Nb de pieces</option>
							</select>
							<div class="overSelect"></div>
						</div>
						<div id="checkboxes2" style="display:none">
							<input type="text" placeholder="Nb de pieces" />
							<label for="one">
								<input type="checkbox" id="one" />1
							</label>
							<label for="two">
								<input type="checkbox" id="two" />2
							</label>
							<label for="three">
								<input type="checkbox" id="three" />3
							</label>
							<label for="four">
								<input type="checkbox" id="four" />4
							</label>
							<label for="five">
								<input type="checkbox" id="five" />5 et +
							</label>
						</div>
					</div>
				</div>
				<span class="second_inpt_wp">
					<input class="second_inpt" value="" name="budget_max" type="text" placeholder="Budget max">
				</span>
				<input class="nostop_srch_btn" name="adad" type="submit" value="Rechercher">
				<input class="nostop_srch_btn" data-target="#modalCreateQuery" data-toggle="modal" type="button" value="Créer requête">
				<div class="advance_search_bar">
					<div class="subcat-ansshow-btn"> 
						<a href="#sb3" data-toggle="collapse"> 
						<span class="second_icon"><img src="images/search_less_icon.png"></span> 
						<span class="first_icon"><img src="images/search_plus_icon.png"></span>

					</a> 
					</div>
					<div class="form_sections collapse" id="sb3">
						<div class="row">
							<div class="col-md-3 ad_one">
								<input name="surface_min" value="" placeholder="Surface Habitable min" type="text">
							</div>
							<div class="col-md-3 ad_one">
								<input name="surface_terrain" value="" placeholder="Superficie Terrain min" type="text">
							</div>

							<div class="col-md-3 last_inpt">
								<input name="mandat_pro" type="checkbox" value="1">
								Mandat Nulle part ailleurs 
							</div>
						</div>
						<div class="clr"></div>
					</div>
				</div>
			</div>
		</div>
		<div class="well well-sm affix-top1">
			<div class="row">
				<div class="col-lg-5 col-md-4 col-sm-12 col-xs-12">
					<strong>Afficher : </strong>
					<div class="listViewBtn">
						<a href="javascript:;" onclick="changeListType('grid')" id="grid" class="btn btn-default btn-sm active">
							<i class="fas fa-th"></i> Mosaic
						</a>
						<a href="javascript:;" onclick="changeListType('list')" id="list" class="btn btn-default btn-sm ">
							<i class="fas fa-list"></i> listing
						</a>	
					</div>
				</div>
				<div class="col-lg-7 col-md-8 col-sm-12 col-xs-12">
					<div class="right_srch" id="right_srch">
						<strong>Filter : </strong>
						<select name="order_price" onchange="$('#formList').submit();">
							<option value="">Prix</option>
							<option value="price_ascending">Prix   &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; ↓</option>
							<option value="price_descending">Prix   &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; ↑</option>
							</select>
						<select name="order_surface" onchange="$('#formList').submit();">
							<option value="">Surface</option>
							<option value="surface_ascending">Surface &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; ↓</option>
							<option value="surface_descending">Surface &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; ↑</option>
						</select>
						<a class="container-checkbox checked">
							<input name="NEUF_ANCIEN[]" value="Ancien" type="checkbox"> <span>Ancien</span>
						</a>
						<a class="container-checkbox checked">							
							<input name="NEUF_ANCIEN[]" value="Recent" type="checkbox"> <span>Neuf</span>
							<input style="display:none;" name="NEUF_ANCIEN[]" value="" checked="" type="checkbox">
						</a>
					</div>
				</div>
				<div class="clearfix"></div>
			</div>
		</div>
		<div id="propList">
			<div class="row">
				<div class="col-xs-4 col-sm-6 col-md-4 col-lg-4">
					<div class="example-1 card">
						<div class="wrapper" style="background-image:url(images/1.png)">
							<div class="data">
								<div class="content">
									<h3 class="title"><a href="property-details.php">APPARTEMENT - 4 pièces - 104 m²</a></h3>
									<p>THONON LES BAINS (74200)</p>
									<p class="price">502 000,00 € </p>
									<div class="text"> 
										<a href="property-details.php">Voir le bien</a> 
										<a href="javascript:(0);">Mandat Chassimo<span>Confiez moi votre recherche</span> </a> 
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-xs-4 col-sm-6 col-md-4 col-lg-4">
					<div class="example-1 card">
						<div class="wrapper" style="background-image:url(images/2.png)">
							<div class="data">
								<div class="content">
									<h3 class="title"><a href="property-details.php">APPARTEMENT - 4 pièces - 104 m²</a></h3>
									<p>THONON LES BAINS (74200)</p>
									<p class="price">502 000,00 € </p>
									<div class="text"> 
										<a href="property-details.php">Voir le bien</a> 
										<a href="javascript:(0);">Mandat Chassimo<span>Confiez moi votre recherche</span> </a> 
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-xs-4 col-sm-6 col-md-4 col-lg-4">
					<div class="example-1 card">
						<div class="wrapper" style="background-image:url(images/3.png)">
							<div class="data">
								<div class="content">
									<h3 class="title"><a href="property-details.php">APPARTEMENT - 4 pièces - 104 m²</a></h3>
									<p>THONON LES BAINS (74200)</p>
									<p class="price">502 000,00 € </p>
									<div class="text"> 
										<a href="property-details.php">Voir le bien</a> 
										<a href="javascript:(0);">Mandat Chassimo<span>Confiez moi votre recherche</span> </a> 
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-xs-4 col-sm-6 col-md-4 col-lg-4">
					<div class="example-1 card">
						<div class="wrapper" style="background-image:url(images/1.png)">
							<div class="data">
								<div class="content">
									<h3 class="title"><a href="property-details.php">APPARTEMENT - 4 pièces - 104 m²</a></h3>
									<p>THONON LES BAINS (74200)</p>
									<p class="price">502 000,00 € </p>
									<div class="text"> 
										<a href="property-details.php">Voir le bien</a> 
										<a href="javascript:(0);">Mandat Chassimo<span>Confiez moi votre recherche</span> </a> 
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-xs-4 col-sm-6 col-md-4 col-lg-4">
					<div class="example-1 card">
						<div class="wrapper" style="background-image:url(images/2.png)">
							<div class="data">
								<div class="content">
									<h3 class="title"><a href="property-details.php">APPARTEMENT - 4 pièces - 104 m²</a></h3>
									<p>THONON LES BAINS (74200)</p>
									<p class="price">502 000,00 € </p>
									<div class="text"> 
										<a href="property-details.php">Voir le bien</a> 
										<a href="javascript:(0);">Mandat Chassimo<span>Confiez moi votre recherche</span> </a> 
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-xs-4 col-sm-6 col-md-4 col-lg-4">
					<div class="example-1 card">
						<div class="wrapper" style="background-image:url(images/3.png)">
							<div class="data">
								<div class="content">
									<h3 class="title"><a href="property-details.php">APPARTEMENT - 4 pièces - 104 m²</a></h3>
									<p>THONON LES BAINS (74200)</p>
									<p class="price">502 000,00 € </p>
									<div class="text"> 
										<a href="property-details.php">Voir le bien</a> 
										<a href="javascript:(0);">Mandat Chassimo<span>Confiez moi votre recherche</span> </a> 
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-xs-4 col-sm-6 col-md-4 col-lg-4">
					<div class="example-1 card">
						<div class="wrapper" style="background-image:url(images/1.png)">
							<div class="data">
								<div class="content">
									<h3 class="title"><a href="property-details.php">APPARTEMENT - 4 pièces - 104 m²</a></h3>
									<p>THONON LES BAINS (74200)</p>
									<p class="price">502 000,00 € </p>
									<div class="text"> 
										<a href="property-details.php">Voir le bien</a> 
										<a href="javascript:(0);">Mandat Chassimo<span>Confiez moi votre recherche</span> </a> 
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-xs-4 col-sm-6 col-md-4 col-lg-4">
					<div class="example-1 card">
						<div class="wrapper" style="background-image:url(images/2.png)">
							<div class="data">
								<div class="content">
									<h3 class="title"><a href="property-details.php">APPARTEMENT - 4 pièces - 104 m²</a></h3>
									<p>THONON LES BAINS (74200)</p>
									<p class="price">502 000,00 € </p>
									<div class="text"> 
										<a href="property-details.php">Voir le bien</a> 
										<a href="javascript:(0);">Mandat Chassimo<span>Confiez moi votre recherche</span> </a> 
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="col-xs-4 col-sm-6 col-md-4 col-lg-4">
					<div class="example-1 card">
						<div class="wrapper" style="background-image:url(images/3.png)">
							<div class="data">
								<div class="content">
									<h3 class="title"><a href="property-details.php">APPARTEMENT - 4 pièces - 104 m²</a></h3>
									<p>THONON LES BAINS (74200)</p>
									<p class="price">502 000,00 € </p>
									<div class="text"> 
										<a href="property-details.php">Voir le bien</a> 
										<a href="javascript:(0);">Mandat Chassimo<span>Confiez moi votre recherche</span> </a> 
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="row" style="display:none;">
				<div id="MapBox" class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
					<div class="map_wp" id="mapContainer" style="height:100%;">
						<img src="images/map5.jpg" />
					</div>
				</div>
				<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6" id="listContainer">                    
                    <div class="project_list map-list">
						<div class="row">
							<div class="col-md-5 project_thumb">
								<div class="view_more "><a href="javascript:void(0)">Voir le bien</a></div>
								<div class="wrapper" style="background-image:url(images/1.png)"></div>
							</div>
							<div class="col-md-7 project_discription">
								<div class="price_section animated zoomIn delay-03s animated animated">
									<em>Donnez votre avis</em>
									<div class="price_wp">
										<p>502 000,00 €</p>
										<ul>
											<li><a onclick="savePrixRange('Pas cher','30438468','502000.00')" href="javascript:;">Pas cher</a></li>
											<li><a onclick="savePrixRange('Au prix','30438468','502000.00')" href="javascript:;">Au prix</a></li>
											<li><a onclick="savePrixRange('Trop cher','30438468','502000.00')" href="javascript:;">Trop cher</a></li>
											<div class="clearfix"></div>
										</ul>
									</div>
								</div>
								<h3><a href="#">4 Pièces 104 m² </a></h3>
								<p class="discription_part">THONON LES BAINS (74200)<br> APPARTEMENT</p>
								<p>Limmobilier met à la vente ce superbe T4 neuf , tout juste livré, orienté Sud, à Thonon-Les-Bains. Le programme est construit à flanc de coteau, dans un écrin de verdure.   L'appartement vous offre un ensemble à vivre de près de 47 mètres carrés</p>
								<div class="bottom_txt">
									<a href="javascript:;"><img src="images/cl_pic.png" alt="user">Votre home conseiller</a>
								</div>
							</div>
							<div class="bottom_button_bar animated fadeInLeft delay-03s animated animated">
								<ul>
									<li><a href="javascript:;"><i class="fa fa-star"></i> Suivre le prix</a></li>
									<li><a href="javascript:;" onclick="$('#project_aff_id30438468').hide(500)"><i class="fa fa-times"></i> Masquer Annonce</a></li>
									<div class="clearfix"></div>
								</ul>
							</div>
						</div>
						<div class="clearfix"></div>
                    </div>                    
                    <div class="project_list map-list">
						<div class="row">
							<div class="col-md-5 project_thumb">
								<div class="view_more "><a href="javascript:void(0)">Voir le bien</a></div>
								<div class="wrapper" style="background-image:url(images/1.png)"></div>
							</div>
							<div class="col-md-7 project_discription">
								<div class="price_section animated zoomIn delay-03s animated animated">
									<em>Donnez votre avis</em>
									<div class="price_wp">
										<p>502 000,00 €</p>
										<ul>
											<li><a onclick="savePrixRange('Pas cher','30438468','502000.00')" href="javascript:;">Pas cher</a></li>
											<li><a onclick="savePrixRange('Au prix','30438468','502000.00')" href="javascript:;">Au prix</a></li>
											<li><a onclick="savePrixRange('Trop cher','30438468','502000.00')" href="javascript:;">Trop cher</a></li>
											<div class="clearfix"></div>
										</ul>
									</div>
								</div>
								<h3><a href="#">4 Pièces 104 m² </a></h3>
								<p class="discription_part">THONON LES BAINS (74200)<br> APPARTEMENT</p>
								<p>Limmobilier met à la vente ce superbe T4 neuf , tout juste livré, orienté Sud, à Thonon-Les-Bains. Le programme est construit à flanc de coteau, dans un écrin de verdure.   L'appartement vous offre un ensemble à vivre de près de 47 mètres carrés</p>
								<div class="bottom_txt">
									<a href="javascript:;"><img src="images/cl_pic.png" alt="user">Votre home conseiller</a>
								</div>
							</div>
							<div class="bottom_button_bar animated fadeInLeft delay-03s animated animated">
								<ul>
									<li><a href="javascript:;"><i class="fa fa-star"></i> Suivre le prix</a></li>
									<li><a href="javascript:;" onclick="$('#project_aff_id30438468').hide(500)"><i class="fa fa-times"></i> Masquer Annonce</a></li>
									<div class="clearfix"></div>
								</ul>
							</div>
						</div>
						<div class="clearfix"></div>
                    </div>    
				</div>
			</div>
		</div>
	</div>	
	<div class="clearfix"></div>
</div>


<?php include 'footer.php'; ?>