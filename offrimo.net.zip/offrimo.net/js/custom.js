  $(window).on("scroll", function () {
         if ($(window).scrollTop() >= 70) {
             $("header").addClass("headerfixed");
         } else {
             $("header").removeClass("headerfixed");
         }
	});
  $(window).on("scroll", function () {
         if ($(window).scrollTop() >= 70) {
             $(".well").addClass("affix-topSearchbar");
         } else {
             $(".well").removeClass("affix-topSearchbar");
         }
	});
  $(window).on("scroll", function () {
         if ($(window).scrollTop() >= 70) {
             $(".map_wp").addClass("affixMap");
         } else {
             $(".map_wp").removeClass("affixMap");
         }
	});
	

jQuery('#Kindgood').click(function(){
	jQuery('#checkboxes2').hide();
	jQuery('#checkboxes').show();
});
jQuery('#Nbpieces').click(function(){
	jQuery('#checkboxes').hide();
	jQuery('#checkboxes2').show();
});
jQuery('.cacl_button').click(function(){
	jQuery('#claculatorLoanAmount').show();
});	


 $(document).ready(function () {
 $('.RecentViewedList').owlCarousel({
	loop: true,
    items: 1,    
	 margin:0,
    nav: true,
    navText: [
      '<i class="fas fa-chevron-left" aria-hidden="true"></i>',
      '<i class="fas fa-chevron-right" aria-hidden="true"></i>'
    ],
	responsiveClass: true,
    smartSpeed: 1000,
    slideSpeed: 900,
    slideBy: 1,
    responsiveRefreshRate: 900,
	 responsive: {		 
		 1000: {
			 items: 1,
		 }
	 }
  });
  
   
 }); 