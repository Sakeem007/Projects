﻿<?php include 'header.php'; ?>
<div class="details_wrapper">	
	<div class="row DtlTopbox">
		<div class="col-xs-12 col-sm-8 col-md-8 col-lg-8 prestigeDetail">
			<div class="details_banner"> 			
				<div class="owl-carousel owl-theme RecentViewedList">
					<div class="item" style="background: url(images/1.png);"></div>
					<div class="item" style="background: url(images/2.png);"></div>
				</div>
			</div>
		</div>	
		<div class="col-xs-4 col-sm-4 col-md-4 col-lg-4 prestigeDetail">
			<div class="project_detais">
				<div class="project_discription">                  
					<div class="row">
						<div class="maison col-md-12">
							<div class="detail-bx">
								 <h3>THONON LES BAINS (74200)</h3>
								 <div class="first-cl-detail">
									 <ul class="apartment-features">
										<li><img src="images/pieces.png" alt=""> 4 Pieces</li>
										<li><img src="images/area.png" alt=""> 104 m2</li>						
										<li><img src="images/bed.png" alt=""> 0 m2</li>	                                         
									</ul>
								</div>                    
								 <div class="second-cl-detail">                        
									  <div class="print_share">
										<ul>
											<li><a href="#">450</a></li>
											<li><a  href="javascript:void(0)" data-toggle="modal" data-target="#modalFollowPrice">Suivre le prix</a></li>
											<li><a  onclick="window.print();" href="javascript:void(0)">Imprimer</a></li>
											<li><a href="javascript:void(0)">Partager</a></li>
											<div class="clearfix"></div>
										</ul>
										<div id="shareIcons" style="display:none;">asdfs</div>
									</div>
								 </div>      
							</div>
						</div>
						<div class="donnez col-md-12">
							<div class="detail-bx"> 
								<h3 class="price">879879 €</h3>
								<h2 class="detail-propertyType"><img src="images/APPARTEMENT.png" /> APPARTEMENT</h2>
								
								<div class="first-cl-detail">
								<em>Selon vous?</em>
								</div>
								<div class="second-cl-detail">
									<div class="price_section">
										<div class="price_wp">
											<ul>
												<li><a href="javascript:void(0)" data-toggle="modal" data-target="#modalSelon">Pas cher</a></li>
												<li><a href="javascript:void(0)" data-toggle="modal" data-target="#modalSelon">Au prix</a></li>
												<li><a href="javascript:void(0)" data-toggle="modal" data-target="#modalSelon">Trop cher</a></li>
												<div class="clearfix"></div>
											</ul>
										</div>
									</div>
								</div>
							<div class="clearfix"></div>
							</div>
							<div class="dtl_address">                        
								<div class="sm_logo">
									<img src="images/smalllogo.png" />
									<div class="box-m3">
										<p>
											<a href="#"><img src="images/phone_icon.png" alt="image" />04.57.438.194</a><br>
											<a href="#Enviemodal"><img src="images/mail_icon.png" alt="image" />Contactez l'agence</a><br>
										</p>
									</div>
								</div>                                            
							</div>
						</div>
					</div>                                             
				</div>
				<div class="clearfix"></div>
			</div>
		</div>   
	</div>
	
	
	
    <div class="tabs_section">
        <input id="tab2" type="radio" name="tabs" checked>
        <label class="first_tab" for="tab2"><img src="images/home_icon.png" alt="icon"/> Le Quartier</label>            
        <input id="tab1" type="radio" name="tabs" >
        <label  for="tab1"><i class="fa fa-home"></i> Le bien</label>  
        <input id="tab3" type="radio" name="tabs">
        <label for="tab3"><img src="images/tab_calc_icon.png" alt="icon"/> Votre financement</label>    
        <input id="tab4" type="radio" name="tabs">
        <label for="tab4"><i class="fa fa-heart"></i> Vivez l'expèrience immobilière</label>
        <input id="tab5" type="radio" name="tabs">
        <label class="last_tab" for="tab5"><i class="fas fa-euro-sign"></i> Devenez apporteur d'affaires</label>
        <!-------- Tab section One ----------->  
        <section id="content1">
			<div class="tab_descriptions_wrapper">
				<div class="first_txt_sect">
					<h3>Texte publicitaire</h3>
					<p>Limmobilier met à la vente ce superbe T4 neuf , tout juste livré, orienté Sud, à Thonon-Les-Bains. Le programme est construit à flanc de coteau, dans un écrin de verdure.   L'appartement vous offre un ensemble à vivre de près de 47 mètres carrés muni de deux accès à la terrasse de 49 m², une suite parentale de 18 m² avec placard, salle d'eau, WC et accès terrasse, une première chambre de 12m² avec dressing et accès terrasse, une seconde chambre de 9,7m²,  une salle de bains, et un WC séparé. En extérieur, vous bénéficiez de 49m² de terrasse. Une place de parking souterrain accessible par télécommande, une place extérieure et une cave complètent ce bien.  Pour votre confort, l'ensemble des ouvrants s'occulte au moyen de volets électriques. Toutes les pièces sont équipées de prises réseau. Votre salle de bains est équipée d'un sèche-serviettes. Votre cuisine est prête à être équipée à votre goût. Votre salle de bains est prête à l'emploi, avec miroir et éclairage.  Pour votre sécurité, le promoteur a sélectionné des portes anti-effraction, visiophone, accès Vigik, ascenseur, portail électrique, et a équipé votre séjour d'un détecteur de fumée autonome.  Pour l'économie d'énergie, le promoteur a équipé votre appartement de double-vitrages isolants (phonique et calorifique), d'une chaudière collective à compteur individuel.  Votre immeuble est muni d'un local deux roues.  Vous serez à deux minutes d'un accès à la voie rapide. Vous accéderez en 15min à pied (ou 5 en voiture) à la gare de Thonon et aux facilités du centre-ville. Cette situation idéale vous garantit les atouts de la ville et le calme de la campagne.  Bénéficiez des avantages du neuf: prêt à taux zéro (sous conditions) et frais de notaire réduits.  Avec limmobilier.net, votre bien vous est proposé à prix direct promoteur. Et toujours nos services en plus: partenaires financement et assurance, aide au déménagement, à la décoration,...</p>					
				</div>
				<div class="tab_bottom_disc">
					<h3>Les diagnostics du bien</h3>
					<div class="row">
						<div class="col-md-6 left_progress_br">
							<p> Diagnostic de Performance Energétique</p>
							<ol class="progress progress--medium">
								<li class="is-complete" data-step="A">&nbsp;</li>
								<li class="is-active" data-step="D">194</li>
								<li data-step="G" class="progress__last">&nbsp;</li>
							</ol>
						</div>
						<div class="col-md-6 right_progress_br">
							<p>Indice d'émission de gaz à effet de serre</p>
							<ol class="progress progress--medium">
								<li class="is-complete" data-step="A"><span>4</span></li>
								<li class="last_active" >&nbsp;</li>
								<li data-step="G" class="progress__last">&nbsp;</li>
							</ol>
						</div>
					</div>
					<div class="clearfix"></div>
					<h3>Information sur le prix</h3>
					<p>Les honoraires d'agence sont intégralement à la charge du vendeur, c'est à dire que les prix indiqués sont honoraires d'agence compris.<br>
						Les prix sont nets, hors frais notariés et hors droits de mutation (droit d'enregistrement) 
					</p>                
				</div>               
				<div class="data_Douvaine">
					<div class="table_wrapper">                                                                           
						<h4>Caractéristiques du bien</h4>
						<ul class="columns">								
							<li title="Surface habitable de "><span>Surface habitable :</span> <span class="span-2">104 m²</span></li>
							<li title="Superficie terrain de   "><span>Nb de pièce(s) :</span> <span class="span-2">4</span></li>
						</ul>																					   
						<div class="clear-both"></div>                      
					</div>
				</div>                
			</div>			
		</section>
        <!-------- Tab section Two Start ----------->  
		<section id="content2">
			<div class="tab_descriptions_wrapper">
				<div class="first_txt_sect">
					<h6>Calculer votre temps de trajet depuis ce bien</h6>
					<form action="" method="get">
						<input class="search_location" id="map_start" name="start" type="text" />
						<input class="search_location" id="map_end" value="" name="end" type="hidden" />
						<button class="search_btn" onclick="initMap()"  type="button" >Calculer ce trajet</button>
					</form>
					<div class="distant_wrapper" id="right-panel">                                                       
					</div>
					<div class="del_map">
						<h3>Les informations locales </h3>
						<div class="panel panel-primary">
							<div class="panel-body">
								<iframe id="mapIframe" style="border:0; width: 100%;" src="https://www.limmobilier.net/lapi/poi/elegance.php?address=&amp;lat=46.364788&amp;lon=6.490081&amp;dataFrom=city_coordinates2&amp;dataID=24" allowfullscreen="" height="400" frameborder="0"></iframe>
							</div>                                                             
						</div>                                                       
						<div class="table_wrapper">
							<h3>Plus d'informations le ville de </h3>
							<div class="row">
								<div class="col-xs-12 col-sm-12 col-md-12 col-lg-6">
									<div class="discover-content" style="margin:0px;"> 
									  <div id="CityCarousel1" class="carousel slide" data-ride="carousel">
										<div class="carousel-inner"> 
											<div class="item  active " style=" background: url('https://www.limmobilier.net/html/images/kel quartier.png')"></div>
										</div>
										<a class="left carousel-control" href="#myCarousel1" data-slide="prev">
										  <span class="glyphicon glyphicon-chevron-left"></span>
										  <span class="sr-only">Previous</span>
										</a>
										<a class="right carousel-control" href="#myCarousel1" data-slide="next">
										  <span class="glyphicon glyphicon-chevron-right"></span>
										  <span class="sr-only">Next</span>
										</a>
									  </div>
									</div>
									<div class="TabWprapper">
										<div class="panel with-nav-tabs panel-default">
											<div class="panel-heading UnbanimotopBox">
												<ul class="nav nav-tabs">
													<li><a class="active" href="#Habitants" data-toggle="tab">HABITANTS</a></li>
													<li><a href="#Immobilier" data-toggle="tab">IMMOBILIER</a></li>
													<li><a href="#Education" data-toggle="tab">EDUCATION</a></li>
													<li><a href="#Environnement" data-toggle="tab">ENVIRONNEMENT</a></li>
													<div class="clearfix"></div>
												</ul>
											</div>
											<div class="panel-body">
												<div class="tab-content">
													<div class="tab-pane fade in active show" id="Habitants">
														<ul id="list-Habitants" class="columns" style="column-count:1;">
															<li><span>Revenu mensuel</span><span class="span-2">2 810 euros / mois</span></li>
															<li><span>Chômage</span><span class="span-2">14 %</span></li>
															<li><span>Type de population</span><span class="span-2">Salariés</span></li>
															<li><span>Age moyen</span><span class="span-2">41 ans</span></li>
															<li><span>Densité de population</span><span class="span-2">1 965 hab/km²</span></li>
															<li><span>Croissance démographique</span><span class="span-2">0 %</span></li>
															<li><span>Enfants et adolescents</span><span class="span-2">23 %</span></li>
															<li><span>Taille des ménages</span><span class="span-2">2,1 personnes/ménage</span></li>
															<li><span>Bacheliers</span><span class="span-2">45 %</span></li>
															<li><span>Lieu de travail</span><span class="span-2">52 %</span></li>
															<li><span>Transport vers lieu de travail</span><span class="span-2">71 %</span></li>
															<li><span>Rentes, retraites, etc.</span><span class="span-2">1 050 euros / mois</span></li>
															<li><span>Ménages imposés</span><span class="span-2">62 %</span></li>
															<li><span>Personnes âgées</span><span class="span-2">20 %</span></li>
															<li><span>Cadres</span><span class="span-2">41 %</span></li>
															<li><span>Employés et ouvriers</span><span class="span-2">59 %</span></li>
															<li><span>Retraités</span><span class="span-2">28 %</span></li>
															<li><span>Taux de fécondité</span><span class="span-2">22 %</span></li>
															<li><span>Adultes</span><span class="span-2">57 %</span></li>
															<li><span>Nombre d'habitants</span><span class="span-2">13 870 habitants</span></li>
															<li><span>Population</span><span class="span-2">13870</span></li>
															<li><span>Habitants de moins de 25 ans</span><span class="span-2">28 %</span></li>
															<li><span>Habitants de 25 à 55 ans</span><span class="span-2">41 %</span></li>
															<li><span>Habitants de plus de 55 ans</span><span class="span-2">30 %</span></li>
															<li><span>Nombre d'enfants par famille</span><span class="span-2">1,1 personne/ménage</span></li>
															<li><span>Familles sans enfant</span><span class="span-2">49 %</span></li>
															<li><span>Familles avec 1 ou 2 enfants</span><span class="span-2">43 %</span></li>
															<li><span>Familles avec 3 enfants ou plus</span><span class="span-2">8 %</span></li>
															<li><span>Familles avec 1 enfant</span><span class="span-2">22 %</span></li>
															<li><span>Familles avec 2 enfants</span><span class="span-2">21 %</span></li>
															<li><span>Familles avec 3 enfants</span><span class="span-2">7 %</span></li>
															<li><span>Familles avec 4 enfants ou plus</span><span class="span-2">1 %</span></li>
															<li><span>Pauvreté</span><span class="span-2">13 %</span></li>
															<li><span>Revenus issus du patrimoine</span><span class="span-2">11 %</span></li>
															<li><span>Prestations familiales</span><span class="span-2">2 %</span></li>
															<li><span>Minima sociaux</span><span class="span-2">1 %</span></li>
															<li><span>Impôts sur le revenu</span><span class="span-2">17 %</span></li>
															<li><span>Inégalités de revenus</span><span class="span-2">4</span></li>
															<li><span>Nombre de familles</span><span class="span-2">3 580 familles</span></li>
															<li><span>Gentrification</span><span class="span-2">2 %</span></li>
															<li><span>Arrivée de familles</span><span class="span-2">-2 %</span></li>
														</ul>

													</div>
													<div class="tab-pane fade" id="Immobilier">
														<ul id="list-Immobilier" class="columns" style="column-count:1;">
															<li><span>Taxe habitation</span><span class="span-2">21 %</span></li>
															<li><span>Taxe foncière</span><span class="span-2">21 %</span></li>
															<li><span>Logement social HLM</span><span class="span-2">12 %</span></li>
															<li><span>Propriétaires (vs. locataires)</span><span class="span-2">49 %</span></li>
															<li><span>Résidences secondaires</span><span class="span-2">19 %</span></li>
															<li><span>Ancienneté du logement</span><span class="span-2">1982</span></li>
															<li><span>Logements vacants</span><span class="span-2">8 %</span></li>
															<li><span>Absence de chauffage central</span><span class="span-2">26 %</span></li>
															<li><span>Petites surfaces (&lt;40 m2)</span><span class="span-2">14 %</span></li>
															<li><span>Cotisation Foncière des Entreprises</span><span class="span-2">0 %</span></li>
															<li><span>Densité de logements</span><span class="span-2">12 log/ha</span></li>
															<li><span>Type de maison</span><span class="span-2">Maisons de ville</span></li>
															<li><span>Taxe foncière sur le non bâti</span><span class="span-2">62 %</span></li>
															<li><span>Taxe enlèvt ordures ménagères</span><span class="span-2">Valeur non applicable</span></li>
															<li><span>Maisons</span><span class="span-2">24 %</span></li>
															<li><span>Appartements</span><span class="span-2">76 %</span></li>
														</ul>											
													</div>
													<div class="tab-pane fade" id="Education">
														<ul id="list-Education" class="columns" style="column-count:1;">
															<li><span>Ecoles et crèches</span><span class="span-2">2,6 étab/km²</span></li>
															<li><span>Résultats des lycées</span><span class="span-2">97 %</span></li>
															<li><span>Sélectivité des lycées</span><span class="span-2">-10</span></li>
															<li><span>Valeur ajoutée des lycées</span><span class="span-2">1</span></li>
															<li><span>Etudiants inscrits dans l'enseignement supérieur</span><span class="span-2">564</span></li>
															<li><span>Techniciens supérieurs</span><span class="span-2">336</span></li>
															<li><span>Ecoles paramédicales et sociales</span><span class="span-2">228</span></li>
														</ul>
													</div>
													<div class="tab-pane fade" id="Environnement">
														<ul id="list-Environnement" class="columns" style="column-count:1;">
															<li><span>Transports publics</span><span class="span-2">4,2 station/km²</span></li>
															<li><span>Pluie</span><span class="span-2">1001 mm par an</span></li>
															<li><span>Ensoleillement</span><span class="span-2">1859 heures par an</span></li>
															<li><span>Terrains et salles de sport</span><span class="span-2">4,2 équip/km²</span></li>
															<li><span>Distance à l'aéroport</span><span class="span-2">33 km</span></li>
															<li><span>Distance centrale nucléaire</span><span class="span-2">151 km</span></li>
															<li><span>Espaces verts et jardins</span><span class="span-2">34 %</span></li>
															<li><span>Ville et villages fleuris</span><span class="span-2">Aucune fleur</span></li>
															<li><span>Ne possède pas une voiture</span><span class="span-2">18 %</span></li>
															<li><span>Type de paysage</span><span class="span-2">Petite ville et périphérie</span></li>
															<li><span>Supermarché</span><span class="span-2">Hypermarché à proximité</span></li>
															<li><span>Restaurants</span><span class="span-2">Très nombreux</span></li>
															<li><span>Education</span><span class="span-2">Tout à proximité</span></li>
															<li><span>Commerces</span><span class="span-2">Très nombreux</span></li>
															<li><span>Vie nocturne</span><span class="span-2">Très animée</span></li>
															<li><span>Espaces verts</span><span class="span-2">Très nombreux</span></li>
															<li><span>Transports</span><span class="span-2">Desservi</span></li>
															<li><span>Tranquilité</span><span class="span-2">Vivant</span></li>
															<li><span>Aéroport le plus proche</span><span class="span-2">Annemasse</span></li>
															<li><span>Centrale nucléaire la plus proche</span><span class="span-2">Bugey</span></li>
															<li><span>Surface</span><span class="span-2">7,1 Km²</span></li>
															<li><span>Source de la carte</span><span class="span-2">Valeur non applicable</span></li>
														</ul>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
								<div class="col-xs-12 col-sm-12 col-md-12 col-lg-6 Thekeynumbers">
									<div class="les-chipper">
										<h3>Les chiffres clés</h3>
										<div class="row">
											<div class="col-xs-12 col-sm-6 col-md-3 col-lg-3">
												<h4>
													<span>13870</span>
													<img src="images/group-symbol.png" alt="Group Symbol">
													<span>Habitants</span>
												</h4>
											</div>
											<div class="col-xs-12 col-sm-6 col-md-3 col-lg-3">
												<h4>
													<span>2 810 euros / mois</span>
													<img src="images/coin.png" alt="Group Symbol">
													<span>Revenu moyen par foyer</span>
												</h4>
											</div>
											<div class="col-xs-12 col-sm-6 col-md-3 col-lg-3">
												<div class="chart11">
													<span>76%</span>
													<img src="images/chart.png" alt="Group Symbol">
													<p>des habitants résident en appartements</p>
												</div>
											</div>															
											<div class="col-xs-12 col-sm-6 col-md-3 col-lg-3">
												<div class="chart11">
													<span>24%</span>
													<img src="images/chart-up.png" alt="Group Symbol">
													<p>des habitants résident en maisons</p>
												</div>
											</div>
										</div>
									</div>
									<div class="les-chipper1">
										<div class="row">
											<div class="col-xs-12 col-lg-6 col-md-6 col-sm-12">
												<h3>Proriétaires ou locataires</h3>  
												<div id="parentDoughnutChart" style="height:100%; width:auto;">
												<img src="images/graph1.png" />
													<canvas id="doughnutChart" style="display:none"></canvas>
												</div>
												<div id='doughnutChartLegend'></div>
											</div>
											<div class="col-xs-12 col-lg-6 col-md-6 col-sm-12">
												<h3>Surfaces</h3>   
													<div style="height: 100%;width:100%;"><img src="images/graph2.png" />
														<canvas id="barChart" style="display:none"></canvas>
													</div>
												<div id='barChartLegend'></div>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="clearfix"></div>
						</div>
					</div>
				</div>
			</div>
		</section>
		<!-------- Tab section Three Start ----------->   
		<section id="content3">
			<div class="tab_descriptions_wrapper">
				<div class="first_txt_sect">
					<h3>Evaluez votre budget </h3>
				</div>
				<div class="data_Douvaine calculator_wp">
					<div class="panel panel-primary">
					  <div class="panel-heading calculator_wrapper">
							<ul>
							 <li class="active"><a href="javascript:void(0)" >Budget suivant une mensualité </a></li>
						   </ul>
					  </div>
					<div class="panel-body">
					  <div class="tab-content">
						<div class="tab-pane active" id="tab06">
					<div class="cacl_frst_tab">
					<label>Mensualité Souhaitée</label> 
					<input id="monthly_installment" name="monthly_installment" type="text" />
					<span>€</span>
					<div class="term_loan">
					<div class="row">
						<div class="col-md-5 cacl_right2"><label>Durée de l'emprunt</label></div>
						<div class="col-md-7 cacl_left">
						<div class="seo">
						  <div class="slider">
							<div class="slider-block">
							  <div id="slider-3"><img src="images/votreSlide1.png" /></div>
							</div>
						  </div>
						 </div>
							<input type="hidden" id="duration" name="duration"/>  
						</div>
					</div>
					<div class="row">
						<div class="col-md-5 cacl_right2"><label>Taux effectif global (TEG)</label></div>
						<div class="col-md-7 cacl_left">
						<div class="seo">
						  <div class="slider">
							<div class="slider-block">
							  <div id="slider-4"><img src="images/votreSlide2.png" /></div>
							</div>
						  </div>
						 </div>
						<input type="hidden" id="intrest_rate" name="intrest_rate"/> 
						</div>
					</div>

					<div class="clr"></div>

					<input class="cacl_button" name="" type="button" value="Calculer" />

					</div>

					</div>

							<div id="claculatorLoanAmount" style="display:none;">Avec une mensualité de  euros sur 5 ans,vous pouvez emprunter 0,00 €.</div>        

							</div>



							<div class="tab-pane" id="tab07">

									<div class="col-md-6 cacl_left">

									<form action="" method="get">

									<label>Vos revenus mensuels nets</label> 

									<input name="" type="text" />

									<span>€</span>

									<label>Coût mensuel de vos crédits en cours</label> 

									<input name="" type="text" />

									<span>€</span>

									</form>

									</div>

							<div class="col-md-6 cacl_right">

							<div class="term_loan">
							<div class="col-md-5 cacl_right2"><label>Durée souhaitée de votre prêt</label></div>

							<div class="col-md-7 cacl_left">
							<div class="seo">

					  <div class="slider">

						<div class="slider-block">

						  <div id="slider-1"></div>

						</div>

					  </div>

					 </div>
							</div>

							<div class="col-md-5 cacl_right2"><label>Taux effectif global (TEG)</label></div>

							<div class="col-md-7 cacl_left">

							<div class="seo">

					  <div class="slider">

						<div class="slider-block">

						  <div id="slider-2"></div>

						</div>

					  </div>

					 </div>



							</div>

							</div>

							</div>

							<div class="clr"></div>

							<h5>Vos investissements locatifs</h5>

									<div class="col-md-6 cacl_left">

							<form action="" method="get">

							<label>Echéance de prêt mensuelle</label> 

							<input name="" type="text" />

							<span>€</span>

							</form>

							</div>

							<div class="col-md-6 cacl_right">

							<label>Loyers mensuels perçus</label> 

							<input name="" type="text" />

							<span>€</span>

							</div>

							<div class="clr"></div>

					<div class="cacl_frst_tab"><input class="cacl_button" name="" type="button" value="Calculer" /></div>

							</div>

					</div>

					</div>  

					</div>

					<div class="clr"></div>

				</div>

				<div class="first_txt_sect">

				<h5>Determinez votre budget</h5>

				<div class="notre_service">

				<h4><span> Prêt immobilier et rachat de crédit</span>" Notre service de courtage délégué en 6 étapes "</h4>

				<ul>

				<li><img src="images/mail_bg_icon.png" alt="icon" /> <p>Envoyez nous votre contact</p> </li>

				<li><img src="images/clock_icon.png" alt="icon" /> <p> Prise de RDV simple et rapide</p> </li>

				<li><img src="images/user_bg_icon.png" alt="icon" /> <p>  Service personnalisé et de proximité</p></li>

				<li><img src="images/calc_bg_icon.png" alt="icon" /> <p>Simulation gratuite et sans engagement</p></li>

				<li><img src="images/dic_icon.png" alt="icon" /> <p>  Le meilleur taux du moment</p></li>

				<li><img src="images/euro_bg_icon.png" alt="icon" /> <p> Gagnez du temps et de l'argent</p></li>

				<div class="clr"></div>

				<ul>

				<p>"Nous travaillons en toute indépendance, avec toutes les banques, et négocions pour vous les meilleurs conditions, vous profiterez de nos taux négociés."</p>

				<div class="cont_me"><a href="#">Contactez nous !</a></div>

				</div>
				</div>
			</div>
		</section>
		<!-------- Tab section Four Start ----------->   
		<section id="content4">
			<div class="tab_descriptions_wrapper">
				<div class="mandat_hassimo_wrapper">
					<p>Vous êtes à la recherche de votre futur chez vous ?<br>
					Laissez-nous rechercher pour vous…</p>
					<h3 >Mandat <span class="chasimo">Chassimo</span><sup>©</sup></h3>
					<p>« Mandat de recherche »<br>
						" Embarquez avec nous, pour une belle expérience immobilière  "</p>
					<span style="width:60%;" class="limoblierSign"><em>By</em> L’Immobilier</span>
					<div class="clearfix"></div>
					<div class="seller_container">
						<ul id="properties_sell">
							<li class="wow animated fadeInLeft delay-06s animated animated animated">
								<h4><a href="#">DECOUVRIMO</a></h4>
								<div class="pro_thumb"><img alt="image" src="images/sell_pic1.jpg"></div>
								<p>Découvrons votre<br>
								projet d'achat, et<br>
								vos exigences</p>
							</li>
							<li class="wow animated fadeInLeft delay-05s animated animated animated">
								<h4><a href="#">FINANCEO</a></h4>
								<div class="pro_thumb"><img alt="image" src="images/sell_pic2.jpg"></div>
								<p>Déterminez votre budget<br>
								aux meilleurs conditions<br>
								financières</p>
							</li>
							<li class="wow animated fadeInLeft delay-04s animated animated animated">
								<h4><a href="#">OFFRIMO</a></h4>
								<div class="pro_thumb"><img alt="image" src="images/sell_pic3.jpg"></div>
								<p>Nous vous donnons<br>
								accès à toute l'offre<br>
								immobilière</p>
							</li>
							<li class="wow animated fadeInLeft delay-03s animated animated animated">
								<h4><a href="#">OBSERVIMO</a></h4>
								<div class="pro_thumb"><img alt="image" src="images/sell_pic4.jpg"></div>
								<p>360° sur une adresse<br>
								Connaître son<br>
								environnement</p>
							</li>
							<li class="wow animated fadeInLeft delay-02s animated animated animated">
								<h4><a href="#">OPTIMEO</a></h4>
								<div class="pro_thumb"><img alt="image" src="images/sell_pic5.jpg"></div>
								<p>Personnalisez votre futur<br>
								espace de vie</p>
							</li>
							<div class="clearfix"></div>
						</ul>
						<p>Choisissez le mandat de recherche Chassimo<sup>©</sup><br>
						" Des solutions à chaque étape de votre projet d'achat"</p>
						<div class="cont_me"><a href="#contactUs" data-toggle="modal">Contactez nous !</a></div>
						</div>
				</div>
			</div>
		</section>
<!-------- Tab section Five Start ----------->   
		<section id="content5">
			<div class="tab_descriptions_wrapper">
				<div class="mandat_hassimo_wrapper">
					<div class="mandat_banner_wp">
						<div class="banner_cont">
							<div class="banner_cont_txt">
								<h3> L'immobilier rémunère le bouche-à-oreille !</h3>
								<p>" Gagnez de l'argent en indiquant des biens de particuliers en vente dans votre entourage ou près de chez vous "</p>
							</div>
						</div>
						<img src="images/5th_banner.jpg" alt="image"/>
					</div>
					<p>Complétez vos revenus n'a jamais été aussi simple !<br>
						"Communiquez-nous l'information en 30 secondes et gagnez 10% du montant de la commission agence."</p>
					<div class="clearfix"></div>
				</div>
			</div>
			<div class="buy_sections"> 
				<div class="container">
					<h2 class="text-center">Compléter vos revenus n'a jamais été aussi simple?</h2>
					<div class="steps">
						<div class="row">
							<div class="col-XS-12 col-sm-4 col-md-4 col-lg-4">
								<div class="box">
									<span class="ixon-bx">
									<i class="fas fa-pencil-alt"></i>
									</span>
									<h3>Étape 1</h3>
									<p>Communiquez les informations des biens en vente autour de vous.</p>
								</div>
							</div>
							<div class="col-XS-12 col-sm-4 col-md-4 col-lg-4">
								<div class="box">
									<span class="ixon-bx">
									<i class="fa fa-users"></i>
									</span>
									<h3>Étape 2</h3>
									<p>Suivez la progression entre la signature du mandat et  la vente de votre indication.</p>
								</div>
							</div>
							<div class="col-XS-12 col-sm-4 col-md-4 col-lg-4">
								<div class="box">
									<span class="ixon-bx">
									<i class="far fa-money-bill-alt"></i>
									</span>
									<h3>Étape 3</h3>
									<p>Percevez la prime dès la signature de l'acte de vente.</p>
								</div>
							</div>


						</div>
					</div>
					<div class="row">
						<div class="col-sx-12 col-sm-5 col-md-5 col-lg-5 step-btn">
						<a href="#">Inscription gratuite</a>
						</div>
						<div class="col-xs-12 col-sm-7 col-md-7 col-lg-7 step-btn">
							<div class="dejamembre">
								<h5>Déjà membre</h5>
								<a href="#">Nom</a>
								<a href="#">Code</a>
								<a href="#">Valider</a>
							</div>
						</div>
					</div>
				</div>  
			</div>
		</section>
	</div>
</div>

<div id="propList" class="DetailsRelated">
	<div class="container">
		<h3>Des offres similaires que vous pourriez aimer...</h3>
		<div class="row">
			<div class="col-xs-4 col-sm-6 col-md-4 col-lg-4">
				<div class="example-1 card">
					<div class="wrapper" style="background-image:url(images/1.png)">
						<div class="data">
							<div class="content">
								<h3 class="title"><a href="property-details.php">APPARTEMENT - 4 pièces - 104 m²</a></h3>
								<p>THONON LES BAINS (74200)</p>
								<p class="price">502 000,00 € </p>
								<div class="text"> 
									<a href="property-details.php">Voir le bien</a> 
									<a href="javascript:(0);">Mandat Chassimo<span>Confiez moi votre recherche</span> </a> 
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-xs-4 col-sm-6 col-md-4 col-lg-4">
				<div class="example-1 card">
					<div class="wrapper" style="background-image:url(images/2.png)">
						<div class="data">
							<div class="content">
								<h3 class="title"><a href="property-details.php">APPARTEMENT - 4 pièces - 104 m²</a></h3>
								<p>THONON LES BAINS (74200)</p>
								<p class="price">502 000,00 € </p>
								<div class="text"> 
									<a href="property-details.php">Voir le bien</a> 
									<a href="javascript:(0);">Mandat Chassimo<span>Confiez moi votre recherche</span> </a> 
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-xs-4 col-sm-6 col-md-4 col-lg-4">
				<div class="example-1 card">
					<div class="wrapper" style="background-image:url(images/3.png)">
						<div class="data">
							<div class="content">
								<h3 class="title"><a href="property-details.php">APPARTEMENT - 4 pièces - 104 m²</a></h3>
								<p>THONON LES BAINS (74200)</p>
								<p class="price">502 000,00 € </p>
								<div class="text"> 
									<a href="property-details.php">Voir le bien</a> 
									<a href="javascript:(0);">Mandat Chassimo<span>Confiez moi votre recherche</span> </a> 
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<div class="modal fade in" id="modalFollowPrice" role="dialog">
    <div class="modal-dialog modal-sm">    
      <!-- Modal content-->
      <div class="modal-content">              
        <div class="modal-body">
            <button type="button" class="close" data-dismiss="modal">×</button> 
                <h6>Vous voulez être informé quand le prix change?</h6>
                <div class="topBox">
                    <label>Utilisez votre compte pour vous inscrire</label>  
                    <div class="fbButton">
						<a href="#" class="fb btn">
						<i class="fab fa-facebook-square"></i> Connexion</a>
                    </div> 
                    <span>ou</span>
                </div>
                <div class="">                    
                        <input id="" type="email" class="email" placeholder="Inscrivez votre mail">
                </div>
               <!-- <div class="">
                        <div id="FollowPrice_message" class=""></div>
                </div>-->
                <div class="text-center">                    
                    <button type="button" class="submit"><i class="fa fa-check-square"></i>  Envoyer</button>
                </div>
            
        </div>
      </div>      
    </div>
  </div>

<div class="modal fade in" id="modalSelon" role="dialog">
	<div class="modal-dialog modal-lg"> 
		<div class="modal-content"> 
			<div class="modal-header">
				<h3>Votre avis sur ce prix</h3>  
				<button type="button" class="close" data-dismiss="modal">×</button> 
			</div>
		<div class="modal-body">
		<p>Votre avis sera communique de maniere anonyme au proprietaire du bien et a l'agence qui le commercialise.</p>
		<h4 class="text-center">Prix de l'annonce <span id="ratingPrix">502000.00</span>€ </h4>	

		<div class="row">	
		<div class="col-md-6"><h5>Quel est votre avis sur ce prix?</h5></div>
		<div class="col-md-6"> <ul class="pop-Btnl">
		<li><a id="btnPasCher" onclick="savePrixRange('Pas cher',AFF_IF,PRIX)" href="javascript:;" class="btnPriceRating active">Pas cher</a></li>
		<li><a id="btnAuprix" onclick="savePrixRange('Au prix',AFF_IF,PRIX)" class="btnPriceRating" href="javascript:;">Au prix</a></li>
		<li><a id="btnTropcher" onclick="savePrixRange('Trop cher',AFF_IF,PRIX)" class="btnPriceRating" href="javascript:;">Trop cher</a></li>
		</ul>
		</div>
		</div>
		<div class="row">
		<div class="col-md-5">
		<h6>A Combien evaluez-vous ce bien?
		<small>deplacez le curseur pour choisir un prix</small></h6>
		</div>
		<div class="col-md-7">
		<div class="row">
		<input type="hidden" id="ratingAFF_IF">
		<input type="hidden" id="ratingPRIX">
		<div class="slidecontainer">
		<p>Environ: <span id="demo">401600</span> €</p>
		<input type="range" min="401600" max="602400" value="502000" step="500" class="slider" id="myRange">		
		<div class="row">
		<div class="col-md-4 text-left"><p>Moins de <br><b id="ratingLabelMinPrice">401600€</b></p></div>
		<div class="col-md-4 text-center"><p>Prix de l'annonce <br><b id="ratingLabelPrice">502000€</b></p></div>
		<div class="col-md-4 text-right"><p>Plus de <br><b id="ratingLabelMaxPrice">602400€</b></p></div>
		</div>
		</div>
		</div>
		<div class="col-md-12">
		<div id="PriceRating_message" class=""></div>
		</div>
		<div class="row  text-left">
		<div class="col-md-3 text-left">
		<label>Email</label>
		</div>
		<div class="col-md-9">
		<input type="email" placeholder="email" class="form-control" name="ratingEmail" id="ratingEmail">
		</div>
		</div>
		</div>
		<br>
		<div class="col-md-12 text-center">
		<button id="btnPrixRating" class="btn btn-primary" onclick="submitPriceRating()" type="button">Valider</button>
		</div>
		</div>

		</div>
		</div>      
	</div>
</div>

<?php include 'footer.php'; ?>