<!DOCTYPE HTML>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title>Welcome to Offrimo.net</title>
	<link rel="icon" href="images/favicon.png" type="image/png">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/all.css">
	<link rel="stylesheet" href="css/mdb.min.css">
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<!-- my style css -->
	<link rel="stylesheet" href="css/global.css">
	<link rel="stylesheet" href="css/responsive.css">
</head>
<body>
<header>
	<div class="LogoBox">
		<a href="index.php"><img src="images/offrimologo.png" /></a>
		<span><a href="http://espaceo.ch/" target="_blank">My Espaceo</a></span>
	</div>
</header>