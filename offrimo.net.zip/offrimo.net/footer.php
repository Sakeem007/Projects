
<!-- Modal -->
<div id="Pricelist" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <div class="modal-content">
      <!--<div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
      </div>-->
      <div class="modal-body">
        <button type="button" class="close" data-dismiss="modal">&times;</button>     
		<h2>Quel type de compte vous correspond?</h2>
		<div class="PriceListing">
			<ul>
				<li>
					<div class="ItmeList">
						<h3>Espaceo Pro</h3>
						<ul>
							<li>Disposez de l’offre immobilière de votre secteur, en temps réel ; <b>vous connaitrez l’offre de votre secteur.</b></li>
							<li>Réalisez facilement et rapidement une étude de marché comparative et une estimation ; <b>vous qualifierez vos mandats.</b></li>
							<li>Comparez et évaluez votre offre par rapport aux offres concurrentes, en temps réel ; <b>vous resterez compétitif.</b></li>
							<li>Profitez de Solusoft un logiciel transaction inédit ; <b>travaillez mieux et plus vite.</b></li>
							<li>Profitez de RDV mandats et de leads qualifiés ; <b>plus de mandats de vente et de recherches. </b></li>
							<li>Augmentez vos ventes grâce à Interimo ( réseau d’agences travaillant en inter agence), <b>vous augmenterez votre chiffre d’affaire.</b></li>
						</ul>
					</div>
				</li>
				<li>	
					<div class="ItmeList">
						<h3>Espaceo Acheteur</h3>
						<ul>
							<li>Simulez votre demande virtuelle qui matchera avec l’offre immobilière de votre secteur, en temps réel ; <b>vous rendrez le marché immobilier simple et transparent.</b></li>
							<li>Vérifiez la faisabilité de votre demande en fonction de l’offre immobilière, en temps réel ; <b>vous ajusterez au mieux votre budget.</b></li>
							<li>Modifiez votre demande en temps réel ; <b>vous ne raterez aucune opportunité.</b></li>
							<li>Comparez et évaluez vos résultats de recherche en temps réel ; <b>vous achèterez au meilleur prix. </b></li>
							<li>Profitez de biens pertinents, correspondant à votre recherche simulée, en temps réel ; <b>vous ne perdrez plus de temps en visites inutiles.</b></li>
							<li>Augmentez le choix de biens grâce à Interimo ( réseau d’agences travaillant en inter- agence), <b>vous augmenterez le choix de biens.</b></li>
						</ul>
					</div>			
				</li>
				<li>	
					<div class="ItmeList">
						<h3>Espaceo Vendeur</h3>
						<ul>
							<li>Simulez votre projet de vente qui sera comparé avec l’offre immobilière concurrente de votre secteur, en temps réel ; <b>vous rendrez le marché immobilier simple et transparent.</b></li>
							<li>Visualisez la faisabilité de votre projet de vente ( rapport critères/prix de vente), en temps réel ; <b>vous ajusterez au mieux votre prix de vente.</b></li>
							<li>Modifianz votre prix de vente, en temps réel ; <b>vous comprendrez mieux le marché de votre secteur.</b> </li>
							<li>Comparez et évaluez votre offre par rapport aux offres concurrentes, en temps réel ; <b>vous vendrez plus vite.</b></li>
							<li>Classez votre offre par rapport à l’offre des biens comparables, en temps réel ; <b>vous vendrez au meilleur prix.</b></li>
							<li>Augmentez vos contacts acheteurs grâce à Interimo ( réseau d’agences travaillant en inter agence), <b>vous augmenterez vos chances de vendre.</b></li>
						</ul>
					</div>		
				</li>
			</ul>
			<a class="CreateAccount" href="javascript:void(0)">Créer un compte</a>
		</div>
      </div>
    </div>
  </div>
</div>

<script src="js/jquery-3.3.1.slim.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/owl.carousel.js"></script>
<script src="js/custom.js"></script>


</body>
</html>