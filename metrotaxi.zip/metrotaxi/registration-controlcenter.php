<?php include 'header.php'; ?>

	<section class="BodyWrapper">
		<a class="Goback" href="registration.php" title="Go back"><i class="icon icon-arrow-left"></i></a>
		<div class="CustMemBox">
			<div class="DriverPhotoBox">
				<div class="DriverPhoto"><img src="images/face-image.png"></div>                            
				<div class="upload-btn-wrapper">
				  <button class="btn upload-icon">Upload a Picture</button>
					   <input type="file" class="custom-file-input">
				</div>
			</div>
			<div class="DriverDocumBox">
				<div class="DriverDocum"><img src="images/identity-image.png"></div>
				<div class="upload-btn-wrapper">
					<button class="btn upload-icon">Upload an ID</button>
					<input type="file" class="custom-file-input">
				</div>
			</div>
			<div class="row CustomerFmBox">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<h3>Registration Form - Company Control Centre And Administrator Details</h3>
				</div>                            
				<form action="" role="form" class="registration-form">
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Business Type (Taxi Company, Rental Car Company, Chauffeur Service Company, Transportation Service Company)</label>
							<div class="add_tags_secondry">
								<input class="tginput" type="text" data-role="tagsinput" placeholder='Write Business Type' value="Taxi Company Mission Center ">				
							</div>
						</div>
					</div>
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Company Name<span>*</span></label>
							<input type="text" class="form-control">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Given Name - Company Administrator<span>*</span></label>
							<input type="text" class="form-control">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Last Name - Company Administrator<span>*</span></label>
							<input type="text" class="form-control">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Nationality - Company Administrator<span>*</span></label>
							<input type="text" class="form-control">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>ID Card - Company Administrator<span>*</span></label>
							<input type="text" class="form-control">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Password</label>
							<input type="password" class="form-control">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Conform Password</label>
							<input type="password" class="form-control">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Country - Company Address<span>*</span></label>
							<select class="form-control">
								<option selected="selected">CN China</option>
								<option>DE Germany</option>
								<option>FR France</option>
								<option>IN India</option>
								<option>ES Spain</option>
								<option>UK United Kingdom</option>
							</select>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Province - Company Address<span>*</span></label>
							<input type="text" class="form-control">
						</div>
					</div>
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>City / Municipality- Company Address<span>*</span></label>
							<input type="password" class="form-control">
						</div>
					</div>
					<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>ZIP- Company Address<span>*</span></label>
							<input type="text" class="form-control">
						</div>
					</div>
					<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">                     
						<div class="form-group">
							<label>Street Number- Company Address<span>*</span></label>
							<input type="text" class="form-control">
						</div>
					</div>
					<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Company Address Street Name<span>*</span></label>
							<input type="text" class="form-control">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>House / Apartment No.- Company Address</label>
							<input type="text" class="form-control">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Address Company -Floor</label>
							<input type="text" class="form-control">
						</div>
					</div>
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Further Information</label>
							<input type="text" class="form-control">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Email -Company Administrator<span>*</span></label>
							<input type="email" class="form-control">
						</div>
					</div>
					<div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Dialing Code</label>
							<input type="text" value="+86" class="form-control">
						</div>
					</div>
					<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Mobile Number -Company Administrator<span>*</span></label>
							<input type="text" class="form-control">
						</div>
					</div>
					<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>VAT, Tax Number - Taxi Company<span>*</span></label>
							<input type="text" class="form-control">
						</div>
					</div>
					<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Business License - Taxi Company<span>*</span></label>
							<input type="text" class="form-control">
						</div>
					</div>
					<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Taxi License - Taxi Company</label>
							<input type="text" class="form-control">
						</div>
					</div>
					
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
						<div class="form-group">
							<label>Account Unlock Method</label>
							<div class=""> 
								<label class="checkbox-label">
									<input type="checkbox"> Email Verification Link 
								</label>
								<label class="checkbox-label">
									<input type="checkbox"> Mobile Verification Code
								</label>
							</div>
							<div class="clearfix"></div>
						</div>
					</div>				
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
						<button type="submit" class="btn btn-default signin-btn register-btn">Submit</button>
					</div>
				</form>
			</div>
		</div>
	</section>	

<?php include 'footer.php'; ?>
