<?php include 'header.php'; ?>

	<section class="BodyWrapper">
		<div class="RegistrationBtns">
			<h1>Registration with us</h1>
			<a href="customer-membership.php" class="CusMem">Customer Membership</a>
			<a href="registration-selfemployeedriver.php">Self Employed Driver is updated from the admin</a>
			<p>*(Car Courier, Bike Courier, Others (Food, Postal, Newspaper, Documents))</p>
			<a href="registration-lincensedrivercompany.php">Individual Company Licensed Driver</a>
			<p>*(Food, Postal, Newspaper, Others (Food, Postal, Newspaper, Documents))</p>
			<a href="registration-controlcenter.php">Company control center(Administrator/Driver/Vehicle)</a>
			<p>*(Food, Postal, Newspaper, Others (Food, Postal, Newspaper, Documents))</p>
		</div>
	</section>	

<?php include 'footer.php'; ?>
