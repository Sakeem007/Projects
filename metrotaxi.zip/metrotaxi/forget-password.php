<?php include 'header.php'; ?>

	<section class="BodyWrapper">
		<div class="PgContainer">
			<div class="ForgetPassBox">
            <h4> Enter Your Mail ID:</h4>           
            <form class="">
                <div class="form-group">
                    <label for="email">Type here:</label>
                    <input type="email" class="form-control" id="email">
                </div>
                <div class="text-center">                   
                    <button type="submit" data-toggle="modal" class="btn btn-default signin-btn proceed-btn">Submit</button>
                </div>
            </form>
        </div>
		</div>
	</section>	

<?php include 'footer.php'; ?>
