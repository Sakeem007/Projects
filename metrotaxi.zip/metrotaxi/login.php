<?php include 'header.php'; ?>

	<section class="BodyWrapper">
		<div class="PgContainer">
			<div class="ForgetPassBox">
				<h4>Login</h4>           
				<div class="login-form"> 
					<form action="user/index.php">
						<div class="form-group">
							<label for="email">Email address:</label>
							<input type="email" class="form-control" id="email">
						</div>
						<div class="form-group">
							<label for="pwd">Password:</label>
							<input type="password" class="form-control" id="pwd">
						</div>
						<div class="checkbox">
							<label>
							<input type="checkbox">
							I'm not a robot</label>
							<span class="capatche-code"><img src="images/capatche.png"></span> 
						</div>
						<div class="text-center"> 
							<button type="submit" class="btn btn-default signin-btn">Login</button>
						</div>
						<p class="signup-heading"> Create New Account</p>
					</form>
					<div class="btn-box"> 
						<a class="default-btn register-btns" href="registration.php">Register With Us</a> 
						<a class="default-btn register-btns" href="forget-password.php">Forget Password</a> 
					</div>
				</div>
				<div class="clearfix"></div>
			</div>
		</div>
	</section>	

<?php include 'footer.php'; ?>
