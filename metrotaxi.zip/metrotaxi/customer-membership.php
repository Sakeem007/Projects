<?php include 'header.php'; ?>

	<section class="BodyWrapper">
		<a class="Goback" href="registration.php" title="Go back"><i class="icon icon-arrow-left"></i></a>
		<div class="CustMemBox">
			<div class="DriverPhotoBox">
				<div class="DriverPhoto"><img src="images/face-image.png"></div>                            
				<div class="upload-btn-wrapper">
				  <button class="btn upload-icon">Upload a Picture</button>
					   <input type="file" class="custom-file-input">
				</div>
			</div>
			<div class="DriverDocumBox">
				<div class="DriverDocum"><img src="images/identity-image.png"></div>
				<div class="upload-btn-wrapper">
					<button class="btn upload-icon">Upload an ID</button>
					<input type="file" class="custom-file-input">
				</div>
			</div>
			<div class="row CustomerFmBox">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<h3>Registration Form Customer Membership / On Demand</h3>
				</div>                            
				<form action="" role="form" class="registration-form">
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Business ConnectionAdhoc</label>
							<select class="form-control">
								<option value="Adhoc" selected="selected">Customer (Adhoc)</option>
								<option value="Membership">Customer (Membership)</option>
							</select>
						</div>
					</div>
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Customer Number ( Automatic Generated)</label>
							<input type="text" class="form-control">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>First Name</label>
							<input type="text" class="form-control">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Last Name</label>
							<input type="text" class="form-control">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Nationality</label>
							<select class="form-control">
								<option selected="selected">Chinese</option>
								<option>German</option>
								<option>French</option>
								<option>Indian</option>
								<option>Spanish</option>
								<option>British</option>
							</select>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>ID Card</label>
							<input type="text" class="form-control">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Password</label>
							<input type="password" class="form-control" placeholder="******">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Password-Repeat</label>
							<input type="password" class="form-control" placeholder="******">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Country </label>
							<select class="form-control">
								<option selected="selected">CN China
								<option value="DE Germany">DE Germany</option>
								<option value="FR France">FR France</option>
								<option value="IN India">IN India</option>
								<option value="ES Spain">ES Spain</option>
								<option value="UK United Kingdom">UK United Kingdom</option>
							</select>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Province / Federal State</label>
							<input type="text" class="form-control">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>City / Municipality</label>
							<input type="text" class="form-control">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>ZIP</label>
							<input type="text" class="form-control">
						</div>
					</div>
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Street Number</label>
							<input type="text" class="form-control">
						</div>
					</div>
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Street Name</label>
							<input type="text" class="form-control">
						</div>
					</div>
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>House / Apartment No.</label>
							<input type="text" class="form-control">
						</div>
					</div>
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Floor</label>
							<input type="text" class="form-control">
						</div>
					</div>
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Further Information</label>
							<input type="text" class="form-control">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Email<em>*</em> </label>
							<input type="email" class="form-control">
						</div>
					</div>
					<div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Dialing Code</label>
							<input type="text" class="form-control">
						</div>
					</div>
					<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Mobile Number<em>*</em></label>
							<input type="text" class="form-control">
						</div>
					</div>
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Verification</label>
							<div class="">
								<label class="checkbox-label">
									<input type="checkbox">
									Email Verification Link
								</label>
								<label class="checkbox-label">
								<input type="checkbox"> Mobile Verification Code</label>
							</div>
						</div>
					</div>
					<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Date of Create</label>
							<input type="text" id="theDate" class="form-control">
						</div>
					</div>
					<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Time of Create</label>
							<input type="text" class="form-control">
						</div>
					</div>
					<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Location of Create</label>
							<input type="text" class="form-control">
						</div>
					</div>
					<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Date of Change</label>
							<input type="text" class="form-control">
						</div>
					</div>
					<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Time of Change</label>
							<input type="text" class="form-control">
						</div>
					</div>
					<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Location of Change</label>
							<input type="text" class="form-control">
						</div>
					</div>
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
						<button type="submit" class="btn btn-default signin-btn register-btn">Submit</button>
					</div>
				</form>
			</div>
		</div>
	</section>	

<?php include 'footer.php'; ?>
