<?php include 'header-home.php'; ?>
<div class="UserContentBox">
	<div class="google-location-form">
	  <div class="form-group">
		<label for="email"><i class="fa fa-map-marker green"></i> Pick Up From</label>
		<input type="text" class="form-control" placeholder="1705 H3 NW, Washington, DC 20006, United States">      
		</ul>
	  </div>
	  <div class="form-group">
		<label for="email"><i class="fa fa-map-marker red"></i> Destination</label>
		<input type="text" class="form-control" placeholder="0510 H1 NW, Washington, DC 20006, United States">     
		</ul>
	  </div>
	</div>		
	<section class="MapBox">&nbsp;</section>	
	<div class="ServiceProvide">
	    <h4>Provided Service</h4>
		<div class="SrvcBox">
			<ul>
			<li>
			  <label class="radio-inline">
				<input type="checkbox" class="chaufeur-image" name="service" value="proservices">
				<span class="checkmark">Autonom</span><img src="../images/toyota_pic.jpg" /></label>
			</li>
			<li>
			  <label class="radio-inline">
				<input type="checkbox" class="chaufeur-image" name="service" value="proservices">
				<span class="checkmark">ECO</span><img src="../images/ecotaxi.jpg" /></label>
			</li>
			<li>
			  <label class="radio-inline">
				<input type="checkbox" class="chaufeur-image" name="service" value="proservices">
				<span class="checkmark">TAXI</span><img src="../images/taxi-image.jpg" /></label>
			</li>
			<li>
			  <label class="radio-inline">
				<input type="checkbox" class="chaufeur-image" name="service" value="proservices">
				<span class="checkmark">CHAUFFEUR</span><img src="../images/Chauffeur-image.jpg" /></label>
			</li>
			<li>
			  <label class="radio-inline">
				<input type="checkbox" class="chaufeur-image" name="service" value="proservices">
				<span class="checkmark">RENTAL CAR</span><img src="../images/rentalcar-image.jpg" /></label>
			</li>
			<li>
			  <label class="radio-inline">
				<input type="checkbox" class="chaufeur-image" name="service" value="proservices">
				<span class="checkmark">SELF EMPLOYED</span><img src="../images/selfemployed-image.jpg" /></label>
			</li>
			<li>
			  <label class="radio-inline">
				<input type="checkbox" class="chaufeur-image" name="service" value="proservices">
				<span class="checkmark">TRANSPORT</span><img src="../images/transport-image.jpg" /></label>
			</li>
			</ul>
		</div>	
	</div>
	<div class="transform-section-column">
	  <h4>Taxi Platform</h4>
	  <p>TIP (in total currency equal on top the transport fare)</p>
	  <ul>
		<li><a href="#">5</a></li>    
		<li><a href="#">10</a></li>
		<li><a href="#">15</a></li>
	  </ul>
	</div>
</div>
<div id="TailSubscription" class="modal fade in" role="dialog" data-backdrop="static">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-body">
        <p style="margin:0 auto;font-family:arial;margin-bottom:20px;line-height:20px;color:#545454;text-align:center;">
		<span class="GoSubs"><img src="../images/runs.gif"></span>
		<p style="width:400px;margin:0 auto;font-family:arial;margin-bottom:20px;line-height:20px;color:#545454;text-align:center;" class="ng-binding">		
        Your Ad-Hoc service has been expired. Want to book more cabs?Subscribe now to enjoy the metro taxi services.         
        </p> 
		</p>
      </div>
    </div>
  </div>
</div>
<style>
#TailSubscription.modal{z-index: 1000;top: 52px;display:block;}
#TailSubscription.fade{opacity:1;background: rgba(0, 0, 0, 0.5);}
.dropdown .btn-group.fl.open .dropdown-menu{z-index: 99999;}
.NewWrapper .modal-backdrop.fade.in{top: 52px;z-index:99;}
.GoSubs{display:block;margin-bottom:40px;}
.GoSubs img{width:100%;}
</style>
<script>
$(document).ready(function(){
	$("#TailSubscription").modal('show');
	$('body').addClass('NewWrapper');    
    $('.MenuList li a').click(function(){
        $('.modal-backdrop').hide();
    });
	$(".MenuList li a").click(function(){
       $('body').removeClass('modal-open');
	});	
	$(".MenuList li a").click(function(){
       $('body').removeClass('NewWrapper');
	});	
});

</script>

<?php include 'footer.php'; ?>
