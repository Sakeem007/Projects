		<div class="FooterWrapper">
			<ul>
				<li><a href="index.php" class="fa fa-home"><span>Home</span></a></li>	
				<li><a href="bookings.php" class="icon icon-newspaper"><span>Booking</span></a></li>	
				<li><a href="profile.php" class="fa fa-user"><span>Profile</span></a></li>	
			</ul><i class="far fa-newspaper"></i>
		</div>
		<script src="../js/jquery-2.2.4.min.js"></script> 
		<script src="../js/bootstrap.min.js"></script> 
		<script src="../js/niceCountryInput.js"></script>
		<script src="../js/menu.js"></script> 
		<script src="../js/tagsinput.js"></script> 
		<script>
			function onChangeCallback(ctr){
				console.log("The country was changed: " + ctr);
				//$("#selectionSpan").text(ctr);
			}
			$(document).ready(function () {
				$(".niceCountryInputSelector").each(function(i,e){
					new NiceCountryInput(e).init();
				});
			});		
			 jQuery('.ShowDesk-display').click(function(){
				jQuery('.login-form').toggle();  
			  });
			  
			//Menu active js
				
				$(document).ready(function () {
					var url = window.location;
					$('.FooterWrapper ul li a[href="' + url + '"]').parent().addClass('active');
					$('.FooterWrapper ul li a').filter(function () {
						return this.href == url;
					}).parent().addClass('active');
				});

		</script>
	</body>
</html>