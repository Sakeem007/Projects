<?php include 'header.php'; ?>
	<section class="BodyWrapper">
		<a class="EditIcon">
			<i id="EdtBTn" class="icon icon-pencil" title="Edit"></i>
			<i id="EyeBTn" class="icon icon-eye" title="View"></i>
		</a>
		<div class="CustMemBox">
			<div class="row CustomerFmBox">
				<form action="" role="form" class="ProfileBox">		
					<div class="FaceWrapper">							
						<div class="DriverPhotoBox">
							<div class="DriverPhoto"><img src="images/driver-image.jpg"></div> 
						</div>
						<div class="DriverDocumBox">
							<div class="DriverDocum"><img src="images/identity-image.png"></div>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Business ConnectionAdhoc</label>
							<p>Customer (Adhoc)</p>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Customer Number ( Automatic Generated)</label>
							<p>G00000365</p>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>First Name</label>
							<p>Deepti</p>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Last Name</label>
							<p>Srivastava</p>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">               
						<div class="form-group">
							<label>Nationality</label>
							<p>india</p>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>ID Card</label>
							<p>DTIPOES39</p>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Country </label>
							<p>CN China</p>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Province / Federal State</label>
							<p>Uttar Pradesh</p>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>City / Municipality</label>
							<p>Noida</p>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Zip</label>
							<p>201301</p>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Street Number</label>
							<p>231</p>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                     
						<div class="form-group">
							<label>Street Name</label>
							<p>036</p>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>House / Apartment No.</label>
							<p>D-171</p>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Floor</label>
							<p>1st Floor</p>
						</div>
					</div>
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Further Information</label>
							<p>Further Information will be provided soon//.//</p>
						</div>
					</div>		
				</form>
				<form action="" role="form" class="RegistrationForm">	
					<div class="FaceWrapper">				
						<div class="DriverPhotoBox">
							<div class="DriverPhoto"><img src="images/driver-image.jpg"></div>                            
							<div class="upload-btn-wrapper">						
								<button class="btn upload-icon">Upload a Picture</button>
								<input type="file" class="custom-file-input">
							</div>
						</div>
						<div class="DriverDocumBox">
							<div class="DriverDocum"><img src="images/identity-image.png"></div>
							<div class="upload-btn-wrapper">
								<button class="btn upload-icon">Upload an ID</button>
								<input type="file" class="custom-file-input">
							</div>
						</div>
						<div class="clearfix"></div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Business ConnectionAdhoc</label>
							<select class="form-control">
								<option selected="selected">Customer (Adhoc)</option>
								<option>Customer (Membership)</option>
							</select>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Customer Number ( Automatic Generated)</label>
							<input type="text" class="form-control" value="G00000365">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>First Name</label>
							<input type="text" class="form-control" value="Deepti">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Last Name</label>
							<input type="text" class="form-control" value="Srivastava">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">               
						<div class="form-group">
							<label>Nationality</label>
							<select class="form-control">
								<option selected="selected">india</option>
								<option>Chinese</option>
								<option>German</option>
								<option>French</option>
								<option>Indian</option>
								<option>Spanish</option>
								<option>Britishs</option>
							</select>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>ID Card</label>
							<input type="text" class="form-control" value="DTIPOES39">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Country </label>
							<select class="form-control">
								<option selected="selected">CN China</option>
								<option>DE Germany</option>
								<option>FR France</option>
								<option>IN India</option>
								<option>ES Spain</option>
								<option>UK United Kingdom</option>
							</select>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Province / Federal State</label>
							<input type="text" class="form-control" value="Uttar Pradesh">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>City / Municipality</label>
							<input type="text" class="form-control" value="Noida">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Zip</label>
							<input type="text" class="form-control" value="201301">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Street Number</label>
							<input type="text" class="form-control" value="231">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                     
						<div class="form-group">
							<label>Street Name</label>
							<input type="text" class="form-control" value="036">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>House / Apartment No.</label>
							<input type="text" class="form-control" value="D-171">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Floor</label>
							<input type="text" class="form-control" value="1st Floor">
						</div>
					</div>
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Further Information</label>
							<input type="text" class="form-control" value="Further Information will be provided soon//.//">
						</div>
					</div>		
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
						<button type="submit" class="btn btn-default signin-btn register-btn">Submit</button>
					</div>
				</form>                          
				
			</div>
		</div>
	</section>	
<div id="TakePictur" class="modal fade" role="dialog">
  <div class="modal-dialog">
    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-body">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
        <p>Some text in the modal.</p>
      </div>
    </div>
	</div>
</div>

<?php include 'footer.php'; ?>
<script>
	 jQuery('#EdtBTn').click(function(){
		jQuery('.ProfileBox').css("display", "none");
		jQuery('#EdtBTn').css("display", "none");
		jQuery('#EyeBTn').css("display", "block");
		jQuery('.RegistrationForm').css("display", "block");
	  });
	 jQuery('#EyeBTn').click(function(){
		jQuery('.RegistrationForm').css("display", "none");
		jQuery('#EdtBTn').css("display", "block");
		jQuery('#EyeBTn').css("display", "none");
		jQuery('.ProfileBox').css("display", "block");
	  });
</script>
