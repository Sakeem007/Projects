<?php include 'header.php'; ?>
<style>
.SubPayment{cursor: inherit !important;}
</style>
	<section class="BodyWrapper BookingBox">
		<div class="subscription-column">
        <div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12"><h4 class="PgTitle">Select Payment Method</h4></div>
            <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                <div class="free-subscription monthly-subscription">
                    <h5><strong>Standard</strong>
                        <span class="FreeTxt">Free</span>
                    </h5>
                    <ul class="SelectSrvc">
                        <li>
							<label class="SubPayment"><span class="TxtBox">Autonom</span> <img src="../images/toyota_pic.jpg" />
							  <input type="checkbox" disabled="">
							  <span class="checkmark"></span>
							</label>
						</li>
                        <li>
							<label class="SubPayment"><span class="TxtBox">ECO</span> <img src="../images/ecotaxi.jpg" />
							  <input type="checkbox" disabled="">
							  <span class="checkmark"></span>
							</label>
						</li>
                        <li>
							<label class="SubPayment"><span class="TxtBox">TAXI</span> <img src="../images/taxi-image.jpg" />
							  <input type="checkbox" disabled="">
							  <span class="checkmark"></span>
							</label>
						</li>
                        <li>
							<label class="SubPayment"><span class="TxtBox">CHAUFFEUR</span> <img src="../images/Chauffeur-image.jpg" />
							  <input type="checkbox">
							  <span class="checkmark"></span>
							</label>
						</li>
                        <li>
							<label class="SubPayment"><span class="TxtBox">RENTAL CAR</span> <img src="../images/rentalcar-image.jpg" />
							  <input type="checkbox">
							  <span class="checkmark"></span>
							</label>
						</li>
                        <li>
							<label class="SubPayment"><span class="TxtBox">SELF EMPLOYED</span> <img src="../images/selfemployed-image.jpg" />
							  <input type="checkbox">
							  <span class="checkmark"></span>
							</label>
						</li>
                        <li>
							<label class="SubPayment"><span class="TxtBox">TRANSPORT</span> <img src="../images/transport-image.jpg" />
							  <input type="checkbox">
							  <span class="checkmark"></span>
							</label>
						</li>                        
                    </ul>
                    <a class="default-btn buy-now monthly-buy" href="https://www.chawtechsolutions.co.in/metrotaxi/user-bookings">Book</a>
					<p class="SlogTitle">&nbsp;<br>&nbsp;</p>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                <div class="free-subscription monthly-subscription">
                    <h5><strong>Exclusive</strong>
                        <span class="MonthPay">4.00 USD/mth</span>
						<label class="SubPayment YearlyBox"><span class="SltAll">Yearly Payment*</span>
						  <input type="checkbox">
						  <span class="checkmark"></span>
						</label>
						<div class="clearfix"></div>
                    </h5>
                    
                    <ul class="SelectSrvc">
                        <li>
							<label class="SubPayment"><span class="TxtBox">Autonom</span> <img src="../images/toyota_pic.jpg" />
							  <input type="checkbox">
							  <span class="checkmark"></span>
							</label>
						</li>
                        <li>
							<label class="SubPayment"><span class="TxtBox">ECO</span> <img src="../images/ecotaxi.jpg" />
							  <input type="checkbox">
							  <span class="checkmark"></span>
							</label>
						</li>
                        <li>
							<label class="SubPayment"><span class="TxtBox">TAXI</span> <img src="../images/taxi-image.jpg" />
							  <input type="checkbox">
							  <span class="checkmark"></span>
							</label>
						</li>
                        <li>
							<label class="SubPayment"><span class="TxtBox">CHAUFFEUR</span> <img src="../images/Chauffeur-image.jpg" />
							  <input type="checkbox">
							  <span class="checkmark"></span>
							</label>
						</li>
                        <li>
							<label class="SubPayment"><span class="TxtBox">RENTAL CAR</span> <img src="../images/rentalcar-image.jpg" />
							  <input type="checkbox">
							  <span class="checkmark"></span>
							</label>
						</li>
                        <li>
							<label class="SubPayment"><span class="TxtBox">SELF EMPLOYED</span> <img src="../images/selfemployed-image.jpg" />
							  <input type="checkbox">
							  <span class="checkmark"></span>
							</label>
						</li>
                        <li>
							<label class="SubPayment"><span class="TxtBox">TRANSPORT</span> <img src="../images/transport-image.jpg" />
							  <input type="checkbox">
							  <span class="checkmark"></span>
							</label>
						</li>                        
                    </ul>
                    <a class="default-btn buy-now monthly-buy" href="user-payment.php">Book</a>
					<p class="SlogTitle">20 days try *Yearly payment 10% discount </p>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                <div class="free-subscription  monthly-subscription">
                    <h5><strong>Premium</strong>
                        <span class="MonthPay">10.00 USD/mth</span>
						<label class="SubPayment YearlyBox"><span class="SltAll">Yearly Payment*</span>
						  <input type="checkbox">
						  <span class="checkmark"></span>
						</label>
						<div class="clearfix"></div>
                    </h5>
                   
                    <ul class="SelectSrvc">
                        <li>
							<label class="SubPayment"><span class="TxtBox">Autonom</span> <img src="../images/toyota_pic.jpg" />
							  <input type="checkbox">
							  <span class="checkmark"></span>
							</label>
						</li>
                        <li>
							<label class="SubPayment"><span class="TxtBox">ECO</span> <img src="../images/ecotaxi.jpg" />
							  <input type="checkbox">
							  <span class="checkmark"></span>
							</label>
						</li>
                        <li>
							<label class="SubPayment"><span class="TxtBox">TAXI</span> <img src="../images/taxi-image.jpg" />
							  <input type="checkbox">
							  <span class="checkmark"></span>
							</label>
						</li>
                        <li>
							<label class="SubPayment"><span class="TxtBox">CHAUFFEUR</span> <img src="../images/Chauffeur-image.jpg" />
							  <input type="checkbox">
							  <span class="checkmark"></span>
							</label>
						</li>
                        <li>
							<label class="SubPayment"><span class="TxtBox">RENTAL CAR</span> <img src="../images/rentalcar-image.jpg" />
							  <input type="checkbox">
							  <span class="checkmark"></span>
							</label>
						</li>
                        <li>
							<label class="SubPayment"><span class="TxtBox">SELF EMPLOYED</span> <img src="../images/selfemployed-image.jpg" />
							  <input type="checkbox">
							  <span class="checkmark"></span>
							</label>
						</li>
                        <li>
							<label class="SubPayment"><span class="TxtBox">TRANSPORT</span> <img src="../images/transport-image.jpg" />
							  <input type="checkbox">
							  <span class="checkmark"></span>
							</label>
						</li>                        
                    </ul>
                    <a class="default-btn buy-now monthly-buy" href="https://www.chawtechsolutions.co.in/metrotaxi/user-payment-page/abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_000X690979_200_21164968305007015906">Book</a>
					<p class="SlogTitle">15 days try *Yearly payment 10% discount </p>
                </div>
            </div>
        </div>
    </div>
	</section>	

<?php include 'footer.php'; ?>
<script>
<?php	/* $(function () {		
		$('.SubPayment>input:checkbox').change(function(){
            if($(this).is(":checked")) {
                $(this).parent('').addClass('active');
            } else {
                $(this).parent('').removeClass('active');
            }
        });
		//$(".SelectSrvc li").click(function () {
			//$("SelectSrvc li.active").removeClass("active");
			//$(this).addClass("active");
		//});
	}); */ ?>
</script>
