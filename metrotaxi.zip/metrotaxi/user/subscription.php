<?php include 'header.php'; ?>

	<section class="BodyWrapper BookingBox">
		<div class="subscription-column">
        <div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12"><h4 class="PgTitle">Select Payment Method</h4></div>
			<div class="mainwrapper">
				<div class="col-lg-4 col-md-6 col-sm-12 col-xs-12">
					<div class="free-subscription monthly-subscription Standard">
						<h5><strong>Standard</strong></h5>
						<button onclick="window.location.href='standard.php'" type="button" class="PayNow">Free</button>
						<ul class="SelectSrvc">
							<li>
								<label class="SubPayment"><span class="TxtBox">Autonom</span> <img src="../images/toyota_pic.jpg" />
								  <input type="checkbox">
								  <span class="checkmark"></span>
								</label>
							</li>
							<li>
								<label class="SubPayment"><span class="TxtBox">ECO</span> <img src="../images/ecotaxi.jpg" />
								  <input type="checkbox">
								  <span class="checkmark"></span>
								</label>
							</li>
							<li>
								<label class="SubPayment"><span class="TxtBox">TAXI</span> <img src="../images/taxi-image.jpg" />
								  <input type="checkbox">
								  <span class="checkmark"></span>
								</label>
							</li>
							<li>
								<label class="SubPayment"><span class="TxtBox">CHAUFFEUR</span> <img src="../images/Chauffeur-image.jpg" />
								  <input type="checkbox">
								  <span class="checkmark"></span>
								</label>
							</li>
							<li>
								<label class="SubPayment"><span class="TxtBox">RENTAL CAR</span> <img src="../images/rentalcar-image.jpg" />
								  <input type="checkbox">
								  <span class="checkmark"></span>
								</label>
							</li>
							<li>
								<label class="SubPayment"><span class="TxtBox">SELF EMPLOYED</span> <img src="../images/selfemployed-image.jpg" />
								  <input type="checkbox">
								  <span class="checkmark"></span>
								</label>
							</li>
							<li>
								<label class="SubPayment"><span class="TxtBox">TRANSPORT</span> <img src="../images/transport-image.jpg" />
								  <input type="checkbox">
								  <span class="checkmark"></span>
								</label>
							</li>                        
						</ul>                  
						<p class="SlogTitle fst">&nbsp;</p>
					</div>
				</div>
				<div class="col-lg-4 col-md-6 col-sm-12 col-xs-12">
                <div class="free-subscription monthly-subscription">
                    <h5><strong>Exclusive</strong></h5>
					<button onclick="window.location.href='user-payment.php'" type="button" class="PayNow" href="standard.php">4.00 USD/p.m.</button>
					<button onclick="window.location.href='user-payment.php'" type="button" class="PayNow" href="standard.php">40.00 USD/p.a.</button>
                    <div class="clearfix"></div>
                    <ul class="SelectSrvc">
                        <li>
							<label class="SubPayment"><span class="TxtBox">Autonom</span> <img src="../images/toyota_pic.jpg" />
							  <input type="checkbox">
							  <span class="checkmark"></span>
							</label>
						</li>
                        <li>
							<label class="SubPayment"><span class="TxtBox">ECO</span> <img src="../images/ecotaxi.jpg" />
							  <input type="checkbox">
							  <span class="checkmark"></span>
							</label>
						</li>
                        <li>
							<label class="SubPayment"><span class="TxtBox">TAXI</span> <img src="../images/taxi-image.jpg" />
							  <input type="checkbox">
							  <span class="checkmark"></span>
							</label>
						</li>
                        <li>
							<label class="SubPayment"><span class="TxtBox">CHAUFFEUR</span> <img src="../images/Chauffeur-image.jpg" />
							  <input type="checkbox">
							  <span class="checkmark"></span>
							</label>
						</li>
                        <li>
							<label class="SubPayment"><span class="TxtBox">RENTAL CAR</span> <img src="../images/rentalcar-image.jpg" />
							  <input type="checkbox">
							  <span class="checkmark"></span>
							</label>
						</li>
                        <li>
							<label class="SubPayment"><span class="TxtBox">SELF EMPLOYED</span> <img src="../images/selfemployed-image.jpg" />
							  <input type="checkbox">
							  <span class="checkmark"></span>
							</label>
						</li>
                        <li>
							<label class="SubPayment"><span class="TxtBox">TRANSPORT</span> <img src="../images/transport-image.jpg" />
							  <input type="checkbox">
							  <span class="checkmark"></span>
							</label>
						</li>                        
                    </ul>
					<p class="SlogTitle">20 days try *Yearly payment 10% discount </p>
                </div>
            </div>
			</div>
        </div>
    </div>
	</section>	

<?php include 'footer.php'; ?>
<script>
	$(function () {		
		$('.SubPayment>input:checkbox').change(function(){
            if($(this).is(":checked")) {
                $(this).parent('').addClass('active');
            } else {
                $(this).parent('').removeClass('active');
            }
        });
		//$(".SelectSrvc li").click(function () {
			//$("SelectSrvc li.active").removeClass("active");
			//$(this).addClass("active");
		//});
	});
</script>
