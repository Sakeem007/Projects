<?php include 'header.php'; ?>
<div class="UserContentBox">
	<div class="google-location-form">
	  <div class="form-group">
		<label for="email"><i class="fa fa-map-marker green"></i> Pick Up From</label>
		<input type="text" class="form-control" placeholder="1705 H3 NW, Washington, DC 20006, United States">      
		</ul>
	  </div>
	  <div class="form-group">
		<label for="email"><i class="fa fa-map-marker red"></i> Destination</label>
		<input type="text" class="form-control" placeholder="0510 H1 NW, Washington, DC 20006, United States">     
		</ul>
	  </div>
	  <div class="clr"></div>
	</div>		
	<section class="MapBox">&nbsp;</section>	
	<div class="ServiceProvide">
	    <h4>Provided Service</h4>
		<div class="SrvcBox">
			<ul>
			<li>
			  <label class="radio-inline">
				<input type="checkbox" class="chaufeur-image" name="service" value="proservices">
				<span class="checkmark">Autonom</span><img src="../images/toyota_pic.jpg" /></label>
			</li>
			<li>
			  <label class="radio-inline">
				<input type="checkbox" class="chaufeur-image" name="service" value="proservices">
				<span class="checkmark">ECO</span><img src="../images/ecotaxi.jpg" /></label>
			</li>
			<li>
			  <label class="radio-inline">
				<input type="checkbox" class="chaufeur-image" name="service" value="proservices">
				<span class="checkmark">TAXI</span><img src="../images/taxi-image.jpg" /></label>
			</li>
			<li>
			  <label class="radio-inline">
				<input type="checkbox" class="chaufeur-image" name="service" value="proservices">
				<span class="checkmark">CHAUFFEUR</span><img src="../images/Chauffeur-image.jpg" /></label>
			</li>
			<li>
			  <label class="radio-inline">
				<input type="checkbox" class="chaufeur-image" name="service" value="proservices">
				<span class="checkmark">RENTAL CAR</span><img src="../images/rentalcar-image.jpg" /></label>
			</li>
			<li>
			  <label class="radio-inline">
				<input type="checkbox" class="chaufeur-image" name="service" value="proservices">
				<span class="checkmark">SELF EMPLOYED</span><img src="../images/selfemployed-image.jpg" /></label>
			</li>
			<li>
			  <label class="radio-inline">
				<input type="checkbox" class="chaufeur-image" name="service" value="proservices">
				<span class="checkmark">TRANSPORT</span><img src="../images/transport-image.jpg" /></label>
			</li>
			</ul>
		</div>	
	</div>
	<!--<div class="transform-section-column">
	  <h4>TIP</h4>
	  <ul>
		<li><a href="#">5</a></li>    
		<li><a href="#">10</a></li>
		<li><a href="#">15</a></li>
	  </ul>
	</div>-->
</div>

<?php include 'footer.php'; ?>
