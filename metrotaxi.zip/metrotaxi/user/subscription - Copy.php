<?php include 'header.php'; ?>

	<section class="BodyWrapper BookingBox">
		<div class="subscription-column">
        <div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12"><h4 class="PgTitle">Select Payment Method</h4></div>
            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                <div class="free-subscription">
                    <h5 class="ng-binding">
                        <span>Free</span><br>
                        0
                    </h5>
                    <ul>
                        <li>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</li>
                        <li>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</li>
                        <li>when an unknown printer took a galley of type and scrambled it to make a type specimen book.</li>
                        <li>It has survived not only five centuries, but also the leap into electronic typesetting.</li>
                    </ul>
                    <a class="default-btn buy-now" href="https://www.chawtechsolutions.co.in/metrotaxi/user-bookings">Free Trial </a>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                <div class="free-subscription monthly-subscription">
                    <h5 class="ng-binding">
                        <span>Monthly</span><br>
                        100
                    </h5>
                    <ul>
                        <li>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</li>
                        <li>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</li>
                        <li>when an unknown printer took a galley of type and scrambled it to make a type specimen book.</li>
                        <li>It has survived not only five centuries, but also the leap into electronic typesetting.</li>
                    </ul>
                    <a class="default-btn buy-now monthly-buy" href="user-payment.php">Buy Now </a>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                <div class="free-subscription">
                    <h5 class="ng-binding">
                        <span>Yearly</span><br>
                        200
                    </h5>
                    <ul>
                        <li>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</li>
                        <li>Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</li>
                        <li> when an unknown printer took a galley of type and scrambled it to make a type specimen book.</li>
                        <li> It has survived not only five centuries, but also the leap into electronic typesetting.</li>
                    </ul>
                    <a class="default-btn buy-now" href="https://www.chawtechsolutions.co.in/metrotaxi/user-payment-page/abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_000X690979_200_21164968305007015906">Buy Now </a>
                </div>
            </div>
        </div>
    </div>
	</section>	

<?php include 'footer.php'; ?>
<script>

</script>
