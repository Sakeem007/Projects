<?php include 'header.php'; ?>

	<section class="BodyWrapper BookingBox">
		<div class="panel-group booking" id="accordion" role="tablist" aria-multiselectable="true"> 
		  <div class="panel panel-default">
			<div class="panel-heading" role="tab" id="headingOne0"> 
			  <h4 class="panel-title UserBookingTtl"> <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="javascript:void(0);" data-target="#collapseOne0" aria-expanded="false" aria-controls="collapseOne">
				<p><strong> Pickup Location :</strong> Chhajarsi Village, Sector 63, Noida 201307, India</p>
				<p><strong>Drop Location:</strong> India, Noida</p>
				<p><strong>Fare :</strong> EUR 115.7 </p>
				<p><strong>Booking Date &amp; Time :</strong> 2019-08-26 19:27:47 </p>
				</a> </h4>
			</div>
			<div id="collapseOne0" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne" aria-expanded="false" style="height: 0px;">
			  <div class="panel-body">
				<label class="RideDtls">Ride Detail</label>
				<div class="row UserBookingList">
				  <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
					<label> Customer's Name</label>
				  </div>
				  <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12"> Deepti Srivastava </div>
				  <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
					<label> Driver's Name</label>
				  </div>
				  <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12"> Test Driver driver </div>
				</div>
				<div class="row UserBookingList">
				  <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
					<label> Pickup Location</label>
				  </div>
				  <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12"> Chhajarsi Village, Sector 63, Noida 201307, India </div>
				  <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
					<label> Drop Location</label>
				  </div>
				  <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12"> India, Noida </div>
				</div>
				<div class="row UserBookingList">
				  <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
					<label> Car Number</label>
				  </div>
				  <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12"> dr gt utyuj hgvnghjfg </div>
				</div>
				<div class="row UserBookingList">
				  <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
					<label> Vehicle Type</label>
				  </div>
				  <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12"> Sedan </div>
				  <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
					<label> Series</label>
				  </div>
				  <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12"> 4Runner(Toyota) </div>
				</div>
				<div class="row UserBookingList">
				  <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
					<label> Booking Date &amp; Time</label>
				  </div>
				  <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12"> 2019-08-26 19:27:47 </div>
				  <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
					<label> Offered Tip</label>
				  </div>
				  <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12"> 10 </div>
				</div>
				<div class="row UserBookingList">
				  <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
					<label> Rating</label>
				  </div>
				  <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12"> 0 </div>
				  <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
					<label> Feedbacks</label>
				  </div>
				  <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12"> </div>
				</div>
			  </div>
			</div>
		  </div>
		  
		  <div class="panel panel-default">
			<div class="panel-heading" role="tab" id="headingOne1"> 
			  <h4 class="panel-title UserBookingTtl"> <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="javascript:void(0);" data-target="#collapseOne1" aria-expanded="false" aria-controls="collapseOne">
				<p><strong> Pickup Location :</strong> Chhajarsi Village, Sector 63, Noida 201307, India</p>
				<p><strong>Drop Location:</strong> India, Noida</p>
				<p><strong>Fare :</strong> EUR 115.7 </p>
				<p><strong>Booking Date &amp; Time :</strong> 2019-08-26 19:25:08 </p>
				</a> </h4>
			</div>
			<div id="collapseOne1" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne" aria-expanded="false" style="height: 0px;">
			  <div class="panel-body">
				<label class="RideDtls">Ride Detail</label>
				<div class="row UserBookingList">
				  <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
					<label> Customer's Name</label>
				  </div>
				  <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12"> Deepti Srivastava </div>
				  <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
					<label> Driver's Name</label>
				  </div>
				  <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12"> Test Driver driver </div>
				</div>
				<div class="row UserBookingList">
				  <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
					<label> Pickup Location</label>
				  </div>
				  <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12"> Chhajarsi Village, Sector 63, Noida 201307, India </div>
				  <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
					<label> Drop Location</label>
				  </div>
				  <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12"> India, Noida </div>
				</div>
				<div class="row UserBookingList">
				  <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
					<label> Car Number</label>
				  </div>
				  <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12"> dr gt utyuj hgvnghjfg </div>
				</div>
				<div class="row UserBookingList">
				  <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
					<label> Vehicle Type</label>
				  </div>
				  <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12"> Sedan </div>
				  <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
					<label> Series</label>
				  </div>
				  <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12"> 4Runner(Toyota) </div>
				</div>
				<div class="row UserBookingList">
				  <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
					<label> Booking Date &amp; Time</label>
				  </div>
				  <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12"> 2019-08-26 19:25:08 </div>
				  <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
					<label> Offered Tip</label>
				  </div>
				  <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12"> 10 </div>
				</div>
				<div class="row UserBookingList">
				  <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
					<label> Rating</label>
				  </div>
				  <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12"> 0 </div>
				  <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
					<label> Feedbacks</label>
				  </div>
				  <div class="col-lg-3 col-md-3 col-sm-3 col-xs-12"> </div>
				</div>
			  </div>
			</div>
		  </div>
			<div class="panel panel-default">
			  <div class="panel-heading" role="tab" id="headingOne2"> 
				<h4 class="panel-title UserBookingTtl"> <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="javascript:void(0);" data-target="#collapseOne2" aria-expanded="false" aria-controls="collapseOne">
				  <p><strong> Pickup Location :</strong> Chhajarsi Village, Sector 63, Noida 201307, India</p>
				  <p><strong>Drop Location:</strong> India, Noida</p>
				  <p><strong>Fare :</strong> EUR 105.7 </p>
				  <p><strong>Booking Date &amp; Time :</strong> 2019-08-19 20:06:05 </p>
				  </a> </h4>
			  </div>
			  <div id="collapseOne2" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne" aria-expanded="false" style="height: 0px;">
				<div class="panel-body">
				  <label class="RideDtls">Ride Detail</label>
				  <div class="row UserBookingList">
					<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
					  <label> Customer's Name</label>
					</div>
					<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12"> Deepti Srivastava </div>
					<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
					  <label> Driver's Name</label>
					</div>
					<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12"> Test Driver driver </div>
				  </div>
				  <div class="row UserBookingList">
					<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
					  <label> Pickup Location</label>
					</div>
					<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12"> Chhajarsi Village, Sector 63, Noida 201307, India </div>
					<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
					  <label> Drop Location</label>
					</div>
					<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12"> India, Noida </div>
				  </div>
				  <div class="row UserBookingList">
					<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
					  <label> Car Number</label>
					</div>
					<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12"> dr gt utyuj hgvnghjfg </div>
				  </div>
				  <div class="row UserBookingList">
					<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
					  <label> Vehicle Type</label>
					</div>
					<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12"> Sedan </div>
					<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
					  <label> Series</label>
					</div>
					<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12"> 4Runner(Toyota) </div>
				  </div>
				  <div class="row UserBookingList">
					<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
					  <label> Booking Date &amp; Time</label>
					</div>
					<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12"> 2019-08-19 20:06:05 </div>
					<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
					  <label> Offered Tip</label>
					</div>
					<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12"> 0 </div>
				  </div>
				  <div class="row UserBookingList">
					<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
					  <label> Rating</label>
					</div>
					<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12"> 0 </div>
					<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
					  <label> Feedbacks</label>
					</div>
					<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12"> </div>
				  </div>
				</div>
			  </div>
			</div>
			<div class="panel panel-default">
			  <div class="panel-heading" role="tab" id="headingOne2"> 
				<h4 class="panel-title UserBookingTtl"> <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="javascript:void(0);" data-target="#collapseOne3" aria-expanded="false" aria-controls="collapseOne">
				  <p><strong> Pickup Location :</strong> Chhajarsi Village, Sector 63, Noida 201307, India</p>
				  <p><strong>Drop Location:</strong> India, Noida</p>
				  <p><strong>Fare :</strong> EUR 105.7 </p>
				  <p><strong>Booking Date &amp; Time :</strong> 2019-08-19 20:06:05 </p>
				  </a> </h4>
			  </div>
			  <div id="collapseOne3" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingOne" aria-expanded="false" style="height: 0px;">
				<div class="panel-body">
				  <label class="RideDtls">Ride Detail</label>
				  <div class="row UserBookingList">
					<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
					  <label> Customer's Name</label>
					</div>
					<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12"> Deepti Srivastava </div>
					<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
					  <label> Driver's Name</label>
					</div>
					<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12"> Test Driver driver </div>
				  </div>
				  <div class="row UserBookingList">
					<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
					  <label> Pickup Location</label>
					</div>
					<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12"> Chhajarsi Village, Sector 63, Noida 201307, India </div>
					<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
					  <label> Drop Location</label>
					</div>
					<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12"> India, Noida </div>
				  </div>
				  <div class="row UserBookingList">
					<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
					  <label> Car Number</label>
					</div>
					<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12"> dr gt utyuj hgvnghjfg </div>
				  </div>
				  <div class="row UserBookingList">
					<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
					  <label> Vehicle Type</label>
					</div>
					<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12"> Sedan </div>
					<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
					  <label> Series</label>
					</div>
					<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12"> 4Runner(Toyota) </div>
				  </div>
				  <div class="row UserBookingList">
					<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
					  <label> Booking Date &amp; Time</label>
					</div>
					<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12"> 2019-08-19 20:06:05 </div>
					<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
					  <label> Offered Tip</label>
					</div>
					<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12"> 0 </div>
				  </div>
				  <div class="row UserBookingList">
					<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
					  <label> Rating</label>
					</div>
					<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12"> 0 </div>
					<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12">
					  <label> Feedbacks</label>
					</div>
					<div class="col-lg-3 col-md-3 col-sm-3 col-xs-12"> </div>
				  </div>
				</div>
			  </div>
			</div>
		  
		</div>
	</section>	

<?php include 'footer.php'; ?>
<script>

</script>
