<?php include 'header.php'; ?>

	<section class="BodyWrapper">
		<a class="Goback" href="registration.php" title="Go back"><i class="icon icon-arrow-left"></i></a>
		<div class="CustMemBox">
			<div class="DriverPhotoBox">
				<div class="DriverPhoto"><img src="images/face-image.png"></div>                            
				<div class="upload-btn-wrapper">
				  <button class="btn upload-icon">Upload a Picture</button>
					   <input type="file" class="custom-file-input">
				</div>
			</div>
			<div class="DriverDocumBox">
				<div class="DriverDocum"><img src="images/identity-image.png"></div>
				<div class="upload-btn-wrapper">
					<button class="btn upload-icon">Upload an ID</button>
					<input type="file" class="custom-file-input">
				</div>
			</div>
			<div class="row CustomerFmBox">
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					<h3>Registration Form Selfemployeed Drivers</h3>
				</div>                            
				<form action="" role="form" class="registration-form">				
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Business Connection (selfemployeed - Rental Car Driver, Counter/Service Provider)</label>
							<div class="add_tags_secondry">
								<input class="tginput" type="text" data-role="tagsinput" placeholder='Write Business Connection' value="Self Employed Chauffeur">				
							</div>
						</div>
					</div>
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Driver Number ( Automatic Generated)</label>
							<input type="text" class="form-control">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Password</label>
							<input type="password" class="form-control">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Conform Password</label>
							<input type="password" class="form-control">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Country</label>
							<select class="form-control">
								<option selected="selected">CN China</option>
								<option>DE Germany</option>
								<option>FR France</option>
								<option>IN India</option>
								<option>ES Spain</option>
								<option>UK United Kingdom</option>
							</select>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Province / Federal State<span>*</span></label>
							<input type="text" class="form-control">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>City / Municipality<span>*</span></label>
							<input type="password" class="form-control">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Driver Address - Street Number<span>*</span></label>
							<input type="text" class="form-control">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">                     
						<div class="form-group">
							<label>Driver Address - Street Name<span>*</span></label>
							<input type="text" class="form-control">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Address Driver - House / Apartment No.<span>*</span></label>
							<input type="text" class="form-control">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Address Driver -Floor</label>
							<input type="text" class="form-control">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Address Driver - Further Information</label>
							<input type="text" class="form-control">
						</div>
					</div>
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Driver-Email<span>*</span></label>
							<input type="text" class="form-control">
						</div>
					</div>
					<div class="col-lg-2 col-md-2 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Dialing Code</label>
							<input type="text" value="+86" class="form-control">
						</div>
					</div>
					<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Driver-Mobile Number<span>*</span></label>
							<input type="text" class="form-control">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Driver - Taxi License No.</label>
							<input type="text" class="form-control">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Driver Given Name</label>
							<input type="text" class="form-control">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Driver Family Name</label>
							<input type="text" class="form-control">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Driver ID Card Number</label>
							<input type="text" class="form-control">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Driver Employee Number</label>
							<input type="text" class="form-control">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Driver Social Insurance Number</label>
							<input type="text" class="form-control">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Driver Car - License Plate</label>
							<input type="text" class="form-control">
						</div>
					</div>
					<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Vehicle Type</label>
							<select class="form-control">
							  <option selected="selected">Sedan</option>
							  <option>SUV</option>
							  <option>Coupe</option>
							  <option>MiniVan</option>
							  <option>Van</option>
							  <option>Convertible</option>
							  <option>Commercial Van</option>
							  <option>Wagon</option>
							  <option>Bike</option>
							  <option>eScooter</option>
							  <option>TwoWheeler</option>
							  <option>TriCycle</option>
							  <option>Quad</option>
							  <option>Truck</option>
							  <option>Other</option>
							  <option>Sedan11</option>
							  <option>Sedan13</option>
							  <option>xsxsdxsxs</option>  
							</select>
						</div>
					</div>
					<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Vehicle Make</label>
							<select class="form-control">
							  <option selected="selected" style="">Toyota</option>
							  <option>Audi</option>
							  <option>BMW</option>
							  <option>Ford</option>
							  <option>Holden</option>
							  <option>Hyundai</option>
							  <option>Kia</option>
							  <option>Mazda</option>
							  <option>Mercedes</option>
							  <option>Nissan</option>
							  <option>Peugot</option>
							  <option>Volkswagen</option>
							  <option>Vinaxuki</option>
							  <option>Effa</option>
							  <option>LuAZ</option>
							  <option>ZAZ</option>
							  <option>LAZ</option>
							  <option>VinFast</option>
							  <option>Mekong Auto</option>
							  <option>World Auto</option>
							  <option>GM Uzbekistan</option>
							  <option>KrAZ</option>
							  <option>Etalon</option>
							  <option>Bohdan</option>
							  <option>SAZ</option>
							  <option>Western Star</option>
							  <option>Tesla</option>
							  <option>SSC</option>
							  <option>Saleen</option>
							  <option>Rossion</option>
							  <option>Other</option>
							</select>

						</div>
					</div>
					<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Vehicle Brand Type</label>
							<select class="form-control">  
							  <option selected="selected" style="">4Runner</option>
							  <option>86</option>
							  <option>Aurion</option>
							  <option>Avalon</option>
							  <option>Avensis</option>
							  <option>Blizzard</option>
							  <option>Bundera</option>
							  <option>Camry</option>
							  <option>Celica</option>
							  <option>Coaster</option>
							  <option>Corolla</option>
							  <option>Cressida</option>
							  <option>Crown</option>
							  <option>C-HR</option>
							  <option>Dyna</option>
							  <option>Echo</option>
							  <option>FJ Cruiser</option>
							  <option>Fortuner</option>
							  <option>HiAce</option>
							  <option>HiLux</option>
							  <option>Kluger</option>
							  <option>Land Cruiser</option>
							  <option>Land Cruiser Prado</option>
							  <option>Lexcen</option>
							  <option>LITEACE</option>
							  <option>Mirai</option>
							  <option>MR2</option>
							  <option>Paseo</option>
							  <option>Prius</option>
							  <option>Prius V</option>  
							</select>
						</div>
					</div>
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
						<div class="form-group">
							<label>Powertrain:</label>
							<div class="checkbox">
								<label class="checkbox-label">
									<input type="radio" name="powertrain" value="Combustion"> Combustion 
								</label>
								<label class="checkbox-label">
									<input type="radio" name="powertrain" value="Hybrid"> Hybrid 
								</label>
								<label class="checkbox-label">
									<input type="radio" name="powertrain" value="Full Employee"> Full Employee 
								</label>
								<label class="checkbox-label">
									<input type="radio" name="powertrain" value="Man Power"> Man Power 
								</label>
							<div class="clearfix"></div>
							</div>
						</div>
					</div>
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
						<div class="form-group">
							<label>Driving Mode</label>
							<div class="checkbox">
								<label class="checkbox-label">
									<input type="radio" name="driving_mode" value="Driver"> Driver 
								</label>
								<label class="checkbox-label">
									<input type="radio" name="driving_mode" value="Autonom"> Autonom 
								</label>
							</div>
							<div class="clearfix"></div>
						</div>
					</div>
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
						<div class="form-group">
							<label>Verification</label>
							<div class=""> 
								<label class="checkbox-label">
									<input type="checkbox"> Email Verification Link 
								</label>
								<label class="checkbox-label">
									<input type="checkbox"> Mobile Verification Code
								</label>
							</div>
							<div class="clearfix"></div>
						</div>
					</div>
					<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Date of Create</label>
							<input type="date" class="form-control">
						</div>
					</div>
					<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Time of Create</label>
							<input type="time" class="form-control">
						</div>
					</div>
					<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Location of Create</label>
							<input type="text" class="form-control">
						</div>
					</div>
					<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Date of Change 2019-08-23</label>
							<input type="date" class="form-control">
						</div>
					</div>
					<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Time of Create</label>
							<input type="time" class="form-control">
						</div>
					</div>
					<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Location of Change</label>
							<input type="text" class="form-control">
						</div>
					</div>
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
						<button type="submit" class="btn btn-default signin-btn register-btn">Submit</button>
					</div>
				</form>
			</div>
		</div>
	</section>	

<?php include 'footer.php'; ?>
