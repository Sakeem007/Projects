<?php include 'header.php'; ?>
<style>
.ForgetPassBox{width:30%;margin:0;float:left;height:55vh}
.LoginPic{width:70%;margin:0;float:left;height:55vh}
.PgContainer {width: 80%;margin: 0 auto;}
.LoginPic img {width: 100%;border-radius:5px 0 0 5px;height:55vh}
.ForgetPassBox {border-radius:0 5px 5px 0;}
@media only screen and (max-width:1024px){
.PgContainer {width: 96%;}
.ForgetPassBox{width:30%;margin:0;float:left;height:70vh}
.LoginPic{width:70%;margin:0;float:left;height:70vh}
.LoginPic img {height:70vh}
}
</style>
	<section class="BodyWrapper">
		<div class="PgContainer">
			<div class="LoginPic"><img src="images/login.gif"></div>
			<div class="ForgetPassBox">
				<h4>Login</h4>           
				<div class="login-form"> 
					<form action="user/index.php">
						<div class="form-group">
							<label for="email">Email address:</label>
							<input type="email" class="form-control" id="email">
						</div>
						<div class="form-group">
							<label for="pwd">Password:</label>
							<input type="password" class="form-control" id="pwd">
						</div>
						<div class="checkbox">
							<label>
							<input type="checkbox">
							I'm not a robot</label>
							<span class="capatche-code"><img src="images/capatche.png"></span> 
						</div>
						<div class="text-center"> 
							<button type="submit" class="btn btn-default signin-btn">Login</button>
						</div>
						<p class="signup-heading"> Create New Account</p>
					</form>
					<div class="btn-box"> 
						<a class="default-btn register-btns" href="registration.php">Register With Us</a> 
						<a class="default-btn register-btns" href="forget-password.php">Forget Password</a> 
					</div>
				</div>
				<div class="clearfix"></div>
			</div>
		</div>
	</section>	

<?php include 'footer.php'; ?>
