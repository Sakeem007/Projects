<?php include 'header.php'; ?>
	<section class="BodyWrapper BookingBox">
		<h4 class="PgTitle">LIST OF VEHICLES</h4>
		<div class="dataTables_wrapper">
			<div class="dataTables_length">
				<label>Show
				  <select name="DataTables_Table_0_length">
					<option value="10">10</option>
					<option value="25">25</option>
					<option value="50">50</option>
					<option value="100">100</option>
				  </select>
				  entries</label>
			</div>
			<div id="DataTables_Table_0_filter" class="dataTables_filter">
			<label>Search:
			  <input type="search" class="" placeholder="" aria-controls="DataTables_Table_0">
			</label>
			</div>
			<div class="TableWrapper">
				<table class="table table-striped table-bordered table-condensed TblBox">
					<thead>
					  <tr role="row">
						<th class="text-center" style="width: 30px;">S.No.</th>
						<th class="text-center" style="width: 178px;">Vehicle Name</th>
						<th class="text-center" style="width: 179px;">Vehicle Brand</th>
						<th class="text-center" style="width: 244px;">Vehicle Brand Type </th>
						<th class="text-center" style="width: 170px;">License Plate</th>
						<th class="text-center" style="width: 147px;">Powertrain</th>
						<th class="text-center" style="width: 79px;">Action</th>
					  </tr>
					</thead>
					<tbody>
						<tr>
							<td>1.</td>
							<td>Sedan</td>
							<td>Toyota</td>
							<td>Fortuner</td>
							<td>ZXCV 4612</td>
							<td>Combustion</td>
							<td class="actions">
								<button type="button" data-toggle="modal" data-target="#modalVehicle"><i class="fa fa-eye"></i></button>
								<button type="button" onclick="blockFunction()"><i class="fa fa-unlock"></i></button>
								<button type="button" onclick="deleteFunction()"><i class="fa fa-trash-o"></i></button>
							</td>
						</tr>
						<tr>
							<td>2.</td>
							<td>Sedan</td>
							<td>Toyota</td>
							<td>Fortuner</td>
							<td>ZXCV 4612</td>
							<td>Combustion</td>
							<td class="actions">
								<button type="button" data-toggle="modal" data-target="#modalVehicle"><i class="fa fa-eye"></i></button>
								<button type="button" onclick="blockFunction()"><i class="fa fa-unlock"></i></button>
								<button type="button" onclick="deleteFunction()"><i class="fa fa-trash-o"></i></button>
							</td>
						</tr>
					</tbody>
				</table>
			</div>
			<div class="dataTables_info">Showing 1 to 2 of 2 entries</div>
			<div class="dataTables_paginate paging_simple_numbers"><a class="paginate_button previous disabled">Previous</a>
				<span><a href="#">1</a></span><span><a href="#">2</a></span>
				<a class="paginate_button next disabled">Next</a>
			</div>
		</div>
	</section>	
<div class="modal fade" id="modalVehicle">
  <div class="modal-dialog" style="max-width:700px;">
    <div class="modal-content">
      <button type="button" class="btn btn-line" data-dismiss="modal"><i class="fa fa-times" aria-hidden="true"></i></button>
      <div class="modal-header"> Vehicle Detail </div>
      <form class="form-horizontal">
        <div class="modal-body">
          <div class="row">
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
              <div class="driver-column view-column">
                <div class="driver-image"> <img src="../images/err.jpg"></div>
              </div>
            </div>
            <div class="col-lg-6 col-md-6 col-sm-6 col-xs-6">
              <div class="driver-column view-column">
                <div class="driver-image"> <img src="../images/doc.jpg"></div>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-12">
              <label class="col-md-5"> Vehicle Name</label>
              <div class="col-md-7"> Sedan </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-12">
              <label class="col-md-5"> Vehicle Brand</label>
              <div class="col-md-7"> Toyota </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-12">
              <label class="col-md-5"> Vehicle Brand Type</label>
              <div class="col-md-7"> 4Runner </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-12">
              <label class="col-md-5"> License Plate</label>
              <div class="col-md-7"> dr gt utyuj hgvnghjfg </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-12">
              <label class="col-md-5"> Powertrain</label>
              <div class="col-md-7"> Combustion </div>
            </div>
          </div>
        </div>
      </form>
    </div>
  </div>
</div>
	
<?php include 'footer.php'; ?>
<script>
	function blockFunction() {
		var txt;
		var r = confirm("Are you sure, you want to block the vehicle?");
		if (r == true) {
			txt = "You pressed OK!";
		} 
		else {
			txt = "You pressed Cancel!";
		}
	}
	function deleteFunction() {
		var txt;
		var r = confirm("Are you sure, you want to delete it?");
		if (r == true) {
			txt = "You pressed OK!";
		} 
		else {
			txt = "You pressed Cancel!";
		}
	}
</script>
