<?php include 'header.php'; ?>

	<section class="BodyWrapper BookingBox">
		<div class="subscription-column">
        <div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12"><h4 class="PgTitle">Select Payment Method</h4></div>
            <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                <div class="free-subscription monthly-subscription Standard">
                    <h5><strong>Standard</strong></h5>
					<button onclick="window.location.href='standard.php'" type="button" class="PayNow">One time 4 USD </button>
                    <ul class="ComDriSection">
						<div class="ComDriBox">
							<h6>Visibility</h6>
							<li>
								<label class="SubPayment"><span class="TxtBox">Me </span>
								  <input type="checkbox">
								  <span class="checkmark"></span>
								</label>
							</li>
							<li>
								<label class="SubPayment"><span class="TxtBox">My Own driver</span> 
								  <input type="checkbox">
								  <span class="checkmark"></span>
								</label>
							</li>
							<li>
								<label class="SubPayment"><span class="TxtBox">Competitor</span>
								  <input type="checkbox">
								  <span class="checkmark"></span>
								</label>
							</li>
						</div>
						<div class="ComDriBox">
							<h6>Analytics</h6>
							<li>
								<label class="SubPayment"><span class="TxtBox">Clustering – Customer Show Density</span>
								  <input type="checkbox">
								  <span class="checkmark"></span>
								</label>
							</li>
							<li>
								<label class="SubPayment"><span class="TxtBox">Clustering – Driver Business Probability</span>
								  <input type="checkbox">
								  <span class="checkmark"></span>
								</label>
							</li>
						</div>
						<div class="ComDriBox">		
							<h6>Payment</h6>
							<li>
								<label class="SubPayment"><span class="TxtBox">MetroPay - Ride</span>
								  <input type="checkbox">
								  <span class="checkmark"></span>
								</label>
							</li>
							<li>
								<label class="SubPayment"><span class="TxtBox">MetroPay – Tax Invoice</span>
								  <input type="checkbox">
								  <span class="checkmark"></span>
								</label>
							</li>   
						</div>
                    </ul>                  
					<p class="SlogTitle fst">&nbsp;</p>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                <div class="free-subscription monthly-subscription">
                    <h5><strong>Exclusive</strong></h5>
					<button onclick="window.location.href='user-payment.php'" type="button" class="PayNow" href="standard.php">4.00 USD/p.m.</button>
					<button onclick="window.location.href='user-payment.php'" type="button" class="PayNow" href="standard.php">40.00 USD/p.a.</button>
                    <div class="clearfix"></div>
                    <ul class="ComDriSection">
						<div class="ComDriBox">
							<h6>Visibility</h6>
							<li>
								<label class="SubPayment"><span class="TxtBox">Me </span>
								  <input type="checkbox">
								  <span class="checkmark"></span>
								</label>
							</li>
							<li>
								<label class="SubPayment"><span class="TxtBox">My Own driver</span> 
								  <input type="checkbox">
								  <span class="checkmark"></span>
								</label>
							</li>
							<li>
								<label class="SubPayment"><span class="TxtBox">Competitor</span>
								  <input type="checkbox">
								  <span class="checkmark"></span>
								</label>
							</li>
						</div>
						<div class="ComDriBox">
							<h6>Analytics</h6>
							<li>
								<label class="SubPayment"><span class="TxtBox">Clustering – Customer Show Density</span>
								  <input type="checkbox">
								  <span class="checkmark"></span>
								</label>
							</li>
							<li>
								<label class="SubPayment"><span class="TxtBox">Clustering – Driver Business Probability</span>
								  <input type="checkbox">
								  <span class="checkmark"></span>
								</label>
							</li>
						</div>
						<div class="ComDriBox">		
							<h6>Payment</h6>
							<li>
								<label class="SubPayment"><span class="TxtBox">MetroPay - Ride</span>
								  <input type="checkbox">
								  <span class="checkmark"></span>
								</label>
							</li>
							<li>
								<label class="SubPayment"><span class="TxtBox">MetroPay – Tax Invoice</span>
								  <input type="checkbox">
								  <span class="checkmark"></span>
								</label>
							</li>   
						</div>
                    </ul>    
					<p class="SlogTitle">20 days try *Yearly payment 10% discount </p>
                </div>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
                <div class="free-subscription  monthly-subscription">
                    <h5><strong>Premium</strong></h5>                        
					<button onclick="window.location.href='user-payment.php'" type="button" class="PayNow">6.00 USD/p.m.</button>
					<button onclick="window.location.href='user-payment.php'" type="button" class="PayNow">60.00 USD/p.a.</button>
					<div class="clearfix"></div>                   
                    <ul class="ComDriSection">
						<div class="ComDriBox">
							<h6>Visibility</h6>
							<li>
								<label class="SubPayment"><span class="TxtBox">Me </span>
								  <input type="checkbox">
								  <span class="checkmark"></span>
								</label>
							</li>
							<li>
								<label class="SubPayment"><span class="TxtBox">My Own driver</span> 
								  <input type="checkbox">
								  <span class="checkmark"></span>
								</label>
							</li>
							<li>
								<label class="SubPayment"><span class="TxtBox">Competitor</span>
								  <input type="checkbox">
								  <span class="checkmark"></span>
								</label>
							</li>
						</div>
						<div class="ComDriBox">
							<h6>Analytics</h6>
							<li>
								<label class="SubPayment"><span class="TxtBox">Clustering – Customer Show Density</span>
								  <input type="checkbox">
								  <span class="checkmark"></span>
								</label>
							</li>
							<li>
								<label class="SubPayment"><span class="TxtBox">Clustering – Driver Business Probability</span>
								  <input type="checkbox">
								  <span class="checkmark"></span>
								</label>
							</li>
						</div>
						<div class="ComDriBox">		
							<h6>Payment</h6>
							<li>
								<label class="SubPayment"><span class="TxtBox">MetroPay - Ride</span>
								  <input type="checkbox">
								  <span class="checkmark"></span>
								</label>
							</li>
							<li>
								<label class="SubPayment"><span class="TxtBox">MetroPay – Tax Invoice</span>
								  <input type="checkbox">
								  <span class="checkmark"></span>
								</label>
							</li>   
						</div>
                    </ul>    
					<p class="SlogTitle">15 days try *Yearly payment 10% discount </p>
                </div>
            </div>
        </div>
    </div>
	</section>	

<?php include 'footer.php'; ?>
<script>
	$(function () {		
		$('.SubPayment>input:checkbox').change(function(){
            if($(this).is(":checked")) {
                $(this).parent('').addClass('active');
            } else {
                $(this).parent('').removeClass('active');
            }
        });
		//$(".SelectSrvc li").click(function () {
			//$("SelectSrvc li.active").removeClass("active");
			//$(this).addClass("active");
		//});
	});
</script>
