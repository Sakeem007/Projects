<?php include 'header.php'; ?>
<div class="UserContentBox">
	<section class="MapBox">&nbsp;</section>	
	<div class="driver-login-bottom">
		<div class="driver-login-outer">
			<h5>Total Bookings</h5>
			<span class="login-timer"><i class="fa fa-calendar"></i>  6</span>
		</div>           
		<div class="driver-login-outer">
			<h5 class="ng-binding">Total Revenues</h5>
			<span class="login-timer ng-binding"><i class="fa fa-money"></i>  1020</span>
		</div>           
		<div class="driver-login-outer">
			<h5>KM. Driven</h5>
			<span class="login-timer"><i class="fa fa-taxi"></i> 84</span>
		</div>
	</div>
</div>
<?php include 'footer.php'; ?>
