<?php include 'header.php'; ?>

	<section class="BodyWrapper">
		<a class="EditIcon">
			<i id="EdtBTn" class="icon icon-pencil" title="Edit"></i>
			<i id="EyeBTn" class="icon icon-eye" title="View"></i>
		</a>
		<div class="CustMemBox">
			<div class="row CustomerFmBox">
				<form action="" role="form" class="ProfileBox">		
					<div class="FaceWrapper">									
						<div class="DriverPhotoBox">
							<div class="DriverPhoto"><img src="../images/Driverface-image.png"></div> 
						</div>
						<div class="DriverDocumBox">
							<div class="DriverDocum"><img src="../images/identity-image.png"></div>
						</div>
					</div>
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Business Connection (selfemployeed - Rental Car Driver, Counter/Service Provider)</label>
							<p>Self Employed Chauffeur</p>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Driver Number ( Automatic Generated)</label>
							<p>D000000000026</p>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Country</label>
							<p>IN India</p>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Province / Federal State</label>
							<p>Noida</p>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>City / Municipality</label>
							<p>Noida</p>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">               
						<div class="form-group">
							<label>Zip</label>
							<p>201301</p>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Driver Address - Street Number</label>
							<p>DTIPOES39</p>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Driver Address - Street Name</label>
							<p>Gautam Buddha</p>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Address Driver - House / Apartment No.</label>
							<p>Gi-51/B</p>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Address Driver -Floor</label>
							<p>1st Floor</p>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Address Driver - Further Information</label>
							<p>A to Z</p>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Driver-Email</label>
							<p>testdriver01@yopmail.com </p>
						</div>
					</div>
					<div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">                     
						<div class="form-group">
							<label>Dialing Code</label>
							<p>+86</p>
						</div>
					</div>
					<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">                
						<div class="form-group">
							<label>Driver-Mobile Number</label>
							<p>8796 154 456</p>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Driver - Taxi License No</label>
							<p>KPL25413CF</p>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Driver Given Name</label>
							<p>Tarun</p>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Driver Family Name</label>
							<p>Tarun</p>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Driver ID Card Number</label>
							<p>ZXCV87954600</p>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Driver Employee Number</label>
							<p>002321</p>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Driver Social Insurance Number</label>
							<p>JSDFKL</p>
						</div>
					</div>		
				</form>
				<form action="" role="form" class="RegistrationForm">		
					<div class="FaceWrapper">									
						<div class="DriverPhotoBox">
							<div class="DriverPhoto"><img src="../images/Driverface-image.png"></div>                            
							<div class="upload-btn-wrapper">
							<button class="btn upload-icon">Upload a Picture</button>
								<input type="file" onchange="angular.element(this).scope().uploadImage(this, 'image')" class="custom-file-input">
							</div>
						</div>
						<div class="DriverDocumBox">
							<div class="DriverDocum"><img src="../images/identity-image.png"></div>
							<div class="upload-btn-wrapper">
								<button class="btn upload-icon">Upload an ID</button>
								<input type="file" onchange="angular.element(this).scope().uploadImage(this, 'ZAQWE')" class="custom-file-input">
							</div>
						</div>
					</div>
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Business Connection (selfemployeed - Rental Car Driver, Counter/Service Provider)</label>
							<div class="add_tags_secondry">
								<input class="tginput" type="text" data-role="tagsinput" placeholder='Write Business Connection' value="Self Employed Chauffeur">				
							</div>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Driver Number ( Automatic Generated)</label>
							<input type="text" class="form-control" value="D000000000026">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Country</label>
							<select class="form-control">
								<option>CN China</option>
								<option>DE Germany</option>
								<option>FR France</option>
								<option selected="selected">IN India</option>
								<option>ES Spain</option>
								<option>UK United Kingdom</option>
							</select>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Province / Federal State<span>*</span></label>
							<input type="text" class="form-control" value="Noida">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>City / Municipality<span>*</span> </label>
							<input type="text" class="form-control" value="Noida">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">               
						<div class="form-group">
							<label>ZIP<span>*</span></label>
							<input type="text" class="form-control" value="201301">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Driver Address - Street Number<span>*</span></label>
							<input type="text" class="form-control" value="DTIPOES39">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Driver Address - Street Name<span>*</span></label>
							<input type="text" class="form-control" value="Gautam Buddha">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Address Driver - House / Apartment No.<span>*</span></label>
							<input type="text" class="form-control" value="Gi-51/B">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Address Driver -Floor</label>
							<input type="text" class="form-control" value="1st Floor">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Address Driver - Further Information</label>
							<input type="text" class="form-control" value="A to Z">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Driver-Email<span>*</span></label>
							<input type="email" class="form-control" value="testdriver01@yopmail.com ">
						</div>
					</div>
					<div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">                     
						<div class="form-group">
							<label>Dialing Code</label>
							<input type="text" class="form-control" value="+86">
						</div>
					</div>
					<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">                
						<div class="form-group">
							<label>Driver-Mobile Number<span>*</span></label>
							<input type="text" class="form-control" value="8796 154 456">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Driver - Taxi License No</label>
							<input type="text" class="form-control" value="KPL25413CF">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Driver Given Name</label>
							<input type="text" class="form-control" value="Tarun">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Driver Family Name</label>
							<input type="text" class="form-control" value="Tarun">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Driver ID Card Number</label>
							<input type="text" class="form-control" value="ZXCV87954600">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Driver Employee Number</label>
							<input type="text" class="form-control" value="002321">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Driver Social Insurance Number</label>
							<input type="text" class="form-control" value="JSDFKL">
						</div>
					</div>	
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
						<button type="submit" class="btn btn-default signin-btn register-btn">Submit</button>
					</div>
				</form> 
			</div>
		</div>
	</section>	

<?php include 'footer.php'; ?>
<script>
	 jQuery('#EdtBTn').click(function(){
		jQuery('.ProfileBox').css("display", "none");
		jQuery('#EdtBTn').css("display", "none");
		jQuery('#EyeBTn').css("display", "block");
		jQuery('.RegistrationForm').css("display", "block");
	  });
	 jQuery('#EyeBTn').click(function(){
		jQuery('.RegistrationForm').css("display", "none");
		jQuery('#EdtBTn').css("display", "block");
		jQuery('#EyeBTn').css("display", "none");
		jQuery('.ProfileBox').css("display", "block");
	  });
</script>
