<?php include 'header.php'; ?>
	<section class="BodyWrapper BookingBox">
		<div class="ResetPass">
			<div class="row">
				<div class="registration-form-column">
				  <form class="registration-form">
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					  <div class="form-group">
						<label>Current Password</label>
						<input type="password" class="form-control" placeholder="******">
						</div>
					</div>
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					  <div class="form-group">
						<label>Password</label>
						<input type="password" class="form-control" placeholder="******">
					  </div>
					</div>
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					  <div class="form-group">
						<label>Repeat-Password</label>
						<input type="password" class="form-control" placeholder="******">
						<span class="alertDanger"></span> </div>
					</div>
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
					  <button type="submit" class="btn btn-default signin-btn register-btn">Submit</button>
					 </div>
				  </form>
				</div>
			</div>
		</div>
	</section>	
<?php include 'footer.php'; ?>
<script>

</script>
