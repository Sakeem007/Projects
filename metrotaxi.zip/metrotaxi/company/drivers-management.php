<?php include 'header.php'; ?>
	<section class="BodyWrapper BookingBox">
		<h4 class="PgTitle">List Of Drivers</h4>
		<div class="dataTables_wrapper">
			<div class="StartEndDateBox">
				<div class="row">
					<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
						<label class="control-label">Start Date</label>
						<div class="input-group">
						  <input name="" type="date">
						</div>
					</div>
					<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
						<label class="control-label">End Date</label>
						<div class="input-group">
						  <input name="" type="date">
						</div>
					</div>
					<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4 AddDrvrBtn">
						<a class="default-btn add-driver-link" href="company-add-driver.php">Add Driver</a>
					</div>
			  </div>
			</div>
			<div class="dataTables_length">
				<label>Show
				  <select name="DataTables_Table_0_length">
					<option value="10">10</option>
					<option value="25">25</option>
					<option value="50">50</option>
					<option value="100">100</option>
				  </select>
				  entries</label>
			</div>
			<div id="DataTables_Table_0_filter" class="dataTables_filter">
			<label>Search:
			  <input type="search" class="" placeholder="" aria-controls="DataTables_Table_0">
			</label>
			</div>
			<div class="DiverTableWrapper">
				<table class="table table-striped table-bordered table-condensed TblBox">
					<thead>
					  <tr role="row">
						<th class="text-center" style="width: 30px;">S.No.</th>
						<th class="text-center" style="width: 147;">Full Name</th>
						<th class="text-center" style="width: 244px;">Email ID</th>
						<th class="text-center" style="width: 100px;">Total Bookings </th>
						<th class="text-center" style="width: 100px;">License No.</th>
						<th class="text-center" style="width: 147px;">Total Revenues</th>
						<th class="text-center" style="width: 147px;">Ratings</th>
						<th class="text-center" style="width: 147px;">Location</th>
						<th class="text-center" style="width: 147px;">Country</th>
						<th class="text-center" style="width: 79px;">Action</th>
					  </tr>
					</thead>
					<tbody>
						<tr>
							<td>1.</td>
							<td>T Jon Tison</td>
							<td>abc1234@yopmail.com</td>
							<td>42</td>
							<td>PKL139TD</td>
							<td>879</td>
							<td>4</td>
							<td>Noida</td>
							<td>India</td>
							<td class="actions">
								<a href="company-view-driver.php"><i class="fa fa-eye"></i></a>
								<a href="company-edit-driver.php"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
								<button type="button" onclick="deleteFunction()"><i class="fa fa-trash-o"></i></button>
							</td>
						</tr>	
						<tr>
							<td>2.</td>
							<td>T Jon Tison</td>
							<td>abc1234@yopmail.com</td>
							<td>42</td>
							<td>PKL139TD</td>
							<td>879</td>
							<td>4</td>
							<td>Noida</td>
							<td>India</td>
							<td class="actions">
								<a href="company-view-driver.php"><i class="fa fa-eye"></i></a>
								<a href="company-edit-driver.php"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
								<button type="button" onclick="deleteFunction()"><i class="fa fa-trash-o"></i></button>
							</td>
						</tr>	
						<tr>
							<td>3.</td>
							<td>T Jon Tison</td>
							<td>abc1234@yopmail.com</td>
							<td>42</td>
							<td>PKL139TD</td>
							<td>879</td>
							<td>4</td>
							<td>Noida</td>
							<td>India</td>
							<td class="actions">
								<a href="company-view-driver.php"><i class="fa fa-eye"></i></a>
								<a href="company-edit-driver.php"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
								<button type="button" onclick="deleteFunction()"><i class="fa fa-trash-o"></i></button>
							</td>
						</tr>						
					</tbody>
				</table>
			</div>	  
			<div class="dataTables_info">Showing 1 to 2 of 2 entries</div>
			<div class="dataTables_paginate paging_simple_numbers"><a class="paginate_button previous disabled">Previous</a>
			<span><a href="#">1</a></span><span><a href="#">2</a></span>
			<a class="paginate_button next disabled">Next</a></div>			
		</div>
	</section>	
<div class="modal fade" id="modalRide">
  <div class="modal-dialog" style="max-width:700px;">
    <div class="modal-content">
      <button type="button" class="btn btn-line" data-dismiss="modal"><i class="fa fa-times" aria-hidden="true"></i></button>
      <div class="modal-header"> Ride Detail </div>
      <form class="form-horizontal" style="margin-bottom:0;">
        <div class="modal-body RideDetailsBox">
			<ul>
				<li><b>Driver's Name</b><span>Rahul Khanna</span></li>
				<li><b>Customer's Name</b><span>Deepti Srivastava</span></li>
				<li><b>Pick-up Location</b><span>D-171, D Block, Sector 63 Noida</span></li>
				<li><b>Drop Location</b><span>F-215, F Block, Sector 82 Noida</span></li>
				<li><b>Vehicle Type</b><span>Sedan</span></li>
				<li><b>Vehicle Brond</b><span>Toyota</span></li>
				<li><b>Series</b><span>4Tuner</span></li>
				<li><b>Fare</b><span>139</span></li>
				<li><b>Offered Tip</b><span>0</span></li>
				<li><b>Booking Date &amp; Time</b><span>25/08/2019 19:48:42</span></li>
				<li><b>Feedbacks</b><span>Lorem Ipsum, you need to be sure there</span></li>
				<li><b>Rating</b><span>4</span></li>
			</ul>
        </div>
      </form>
    </div>
  </div>
</div>

	
<?php include 'footer.php'; ?>
<script>
	function blockFunction() {
		var txt;
		var r = confirm("Are you sure, you want to block the vehicle?");
		if (r == true) {
			txt = "You pressed OK!";
		} 
		else {
			txt = "You pressed Cancel!";
		}
	}
	function deleteFunction() {
		var txt;
		var r = confirm("Are you sure, you want to delete it?");
		if (r == true) {
			txt = "You pressed OK!";
		} 
		else {
			txt = "You pressed Cancel!";
		}
	}
</script>
