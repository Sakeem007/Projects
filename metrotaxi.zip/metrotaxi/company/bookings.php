<?php include 'header.php'; ?>

<section class="BodyWrapper">
	<div class="DrBokingWrapper">
		<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
			<h4 class="PgTitle">Booking List</h4>
		</div>
		<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">	
			<div class="DiverBookingBox">
				<div class="booking-left-column">
					<ul class="BookinList">
						<li><b>Pickup Location</b><span>D/171 Chhajarsi Road, Block D, Sector 63, Noida 201307, India</span></li>
						<li><b>Drop Location</b><span>India, Noida, Sector 32, City Center Marg</span></li>
						<li><b>Username</b><span>Anil Kumar</span></li>
						<li><b>Email ID</b><span>anil313@gamil.com</span></li>
						<li><b>Mobile Number</b><span>+916479546213</span></li>
						<li><b>Tip</b><span>10</span></li>
					</ul>
				</div>
				<div class="booking-rght-column">
				  <ul class="BookinList">
					<li class="rate"><b>Rating</b>
					  <fieldset class="rating">
						<input type="radio" id="star5" name="rating" value="5">
						<label class="full" for="star5"></label>
						<input type="radio" id="star4half" name="rating" value="4 and a half">
						<label class="half" for="star4half"></label>
						<input type="radio" id="star4" name="rating" value="4">
						<label class="full" for="star4"></label>
						<input type="radio" id="star3half" name="rating" value="3 and a half">
						<label class="half" for="star3half"></label>
						<input type="radio" id="star3" name="rating" value="3">
						<label class="full" for="star3"></label>
						<input type="radio" id="star2half" name="rating" value="2 and a half">
						<label class="half" for="star2half"></label>
						<input type="radio" id="star2" name="rating" value="2">
						<label class="full" for="star2"></label>
						<input type="radio" id="star1half" name="rating" value="1 and a half">
						<label class="half" for="star1half"></label>
						<input type="radio" id="star1" name="rating" value="1">
						<label class="full" for="star1"></label>
						<input type="radio" id="starhalf" name="rating" value="half">
						<label class="half" for="starhalf"></label>
					  </fieldset>
					</li>
					<li><b>Date&amp;Time:</b> <span>2019-08-28 17:00:58</span></li>
					<li><b>Fare:</b> <span>64.6</span></li>
				  </ul>
				</div>
				<div class="clearfix"></div>
				<a class="accordion view-btn">View</a>
				<div class="panal">
					<label class="RideDtls">Ride Detail</label>
					<div class="row UserBookingList">
						<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
							<label>Customer's Name</label>    
						</div>
						<div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
							Deepti Srivastava
						</div>
					</div>
					<div class="row UserBookingList">
						<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
							<label>Driver's Name</label>  
						</div>
						<div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
							Test Driver driver
						</div>
					</div>
					<div class="row UserBookingList">
						<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
							<label> Pickup Location</label>    
						</div>
						<div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
							D/171 Chhajarsi Road, Block D, Sector 63, Noida 201307, India
						</div>
					</div>				
					<div class="row UserBookingList">
						<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
							<label> Drop Location</label>    
						</div>
						<div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
							India, Noida, Noida Greater Noida Expressway
						</div>
					</div>
					<div class="row UserBookingList">
						<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
							<label> Car Number</label>    
						</div>
						<div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
							dr gt utyuj hgvnghjfg
						</div>
					</div>
					<div class="row UserBookingList">
					   <div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
							<label> Vehicle Type</label>    
						</div>
						<div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
							Sedan
						</div>
					</div>				
					<div class="row UserBookingList">
						<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
							<label> Series</label>    
						</div>
						<div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
							4Runner(Toyota)
						</div>
					</div>
					<div class="row UserBookingList">
						<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
							<label> Booking Date &amp; Time</label>    
						</div>
						<div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
							2019-08-28 22:50:13 
						</div>
					</div>
					<div class="row UserBookingList">
						<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
							<label> Offered Tip</label>    
						</div>
						<div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
							5 
						</div>
					</div>
					<div class="row UserBookingList">
						<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
							<label> Rating</label>    
						</div>
						<div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
							0 
						</div>
					</div>
					<div class="row UserBookingList">
						<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
							<label> Feedbacks</label>    
						</div>
						<div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
						</div>
					</div>
				</div>
			</div>			
		</div>	
		<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">	
			<div class="DiverBookingBox">
				<div class="booking-left-column">
					<ul class="BookinList">
						<li><b>Pickup Location</b><span>D/171 Chhajarsi Road, Block D, Sector 63, Noida 201307, India</span></li>
						<li><b>Drop Location</b><span>India, Noida, Sector 32, City Center Marg</span></li>
						<li><b>Username</b><span>Anil Kumar</span></li>
						<li><b>Email ID</b><span>anil313@gamil.com</span></li>
						<li><b>Mobile Number</b><span>+916479546213</span></li>
						<li><b>Tip</b><span>10</span></li>
					</ul>
				</div>
				<div class="booking-rght-column">
				  <ul class="BookinList">
					<li class="rate"><b>Rating</b>
					  <fieldset class="rating">
						<input type="radio" id="star5" name="rating" value="5">
						<label class="full" for="star5"></label>
						<input type="radio" id="star4half" name="rating" value="4 and a half">
						<label class="half" for="star4half"></label>
						<input type="radio" id="star4" name="rating" value="4">
						<label class="full" for="star4"></label>
						<input type="radio" id="star3half" name="rating" value="3 and a half">
						<label class="half" for="star3half"></label>
						<input type="radio" id="star3" name="rating" value="3">
						<label class="full" for="star3"></label>
						<input type="radio" id="star2half" name="rating" value="2 and a half">
						<label class="half" for="star2half"></label>
						<input type="radio" id="star2" name="rating" value="2">
						<label class="full" for="star2"></label>
						<input type="radio" id="star1half" name="rating" value="1 and a half">
						<label class="half" for="star1half"></label>
						<input type="radio" id="star1" name="rating" value="1">
						<label class="full" for="star1"></label>
						<input type="radio" id="starhalf" name="rating" value="half">
						<label class="half" for="starhalf"></label>
					  </fieldset>
					</li>
					<li><b>Date&amp;Time:</b> <span>2019-08-28 17:00:58</span></li>
					<li><b>Fare:</b> <span>64.6</span></li>
				  </ul>
				</div>
				<div class="clearfix"></div>
				<a class="accordion view-btn">View</a>
				<div class="panal">
					<label class="RideDtls">Ride Detail</label>
					<div class="row UserBookingList">
						<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
							<label>Customer's Name</label>    
						</div>
						<div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
							Deepti Srivastava
						</div>
					</div>
					<div class="row UserBookingList">
						<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
							<label>Driver's Name</label>  
						</div>
						<div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
							Test Driver driver
						</div>
					</div>
					<div class="row UserBookingList">
						<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
							<label> Pickup Location</label>    
						</div>
						<div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
							D/171 Chhajarsi Road, Block D, Sector 63, Noida 201307, India
						</div>
					</div>				
					<div class="row UserBookingList">
						<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
							<label> Drop Location</label>    
						</div>
						<div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
							India, Noida, Noida Greater Noida Expressway
						</div>
					</div>
					<div class="row UserBookingList">
						<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
							<label> Car Number</label>    
						</div>
						<div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
							dr gt utyuj hgvnghjfg
						</div>
					</div>
					<div class="row UserBookingList">
					   <div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
							<label> Vehicle Type</label>    
						</div>
						<div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
							Sedan
						</div>
					</div>				
					<div class="row UserBookingList">
						<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
							<label> Series</label>    
						</div>
						<div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
							4Runner(Toyota)
						</div>
					</div>
					<div class="row UserBookingList">
						<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
							<label> Booking Date &amp; Time</label>    
						</div>
						<div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
							2019-08-28 22:50:13 
						</div>
					</div>
					<div class="row UserBookingList">
						<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
							<label> Offered Tip</label>    
						</div>
						<div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
							5 
						</div>
					</div>
					<div class="row UserBookingList">
						<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
							<label> Rating</label>    
						</div>
						<div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
							0 
						</div>
					</div>
					<div class="row UserBookingList">
						<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
							<label> Feedbacks</label>    
						</div>
						<div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
						</div>
					</div>
				</div>
			</div>			
		</div>	
		<div class="clearfix"></div>
		<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">	
			<div class="DiverBookingBox">
				<div class="booking-left-column">
					<ul class="BookinList">
						<li><b>Pickup Location</b><span>D/171 Chhajarsi Road, Block D, Sector 63, Noida 201307, India</span></li>
						<li><b>Drop Location</b><span>India, Noida, Sector 32, City Center Marg</span></li>
						<li><b>Username</b><span>Anil Kumar</span></li>
						<li><b>Email ID</b><span>anil313@gamil.com</span></li>
						<li><b>Mobile Number</b><span>+916479546213</span></li>
						<li><b>Tip</b><span>10</span></li>
					</ul>
				</div>
				<div class="booking-rght-column">
				  <ul class="BookinList">
					<li class="rate"><b>Rating</b>
					  <fieldset class="rating">
						<input type="radio" id="star5" name="rating" value="5">
						<label class="full" for="star5"></label>
						<input type="radio" id="star4half" name="rating" value="4 and a half">
						<label class="half" for="star4half"></label>
						<input type="radio" id="star4" name="rating" value="4">
						<label class="full" for="star4"></label>
						<input type="radio" id="star3half" name="rating" value="3 and a half">
						<label class="half" for="star3half"></label>
						<input type="radio" id="star3" name="rating" value="3">
						<label class="full" for="star3"></label>
						<input type="radio" id="star2half" name="rating" value="2 and a half">
						<label class="half" for="star2half"></label>
						<input type="radio" id="star2" name="rating" value="2">
						<label class="full" for="star2"></label>
						<input type="radio" id="star1half" name="rating" value="1 and a half">
						<label class="half" for="star1half"></label>
						<input type="radio" id="star1" name="rating" value="1">
						<label class="full" for="star1"></label>
						<input type="radio" id="starhalf" name="rating" value="half">
						<label class="half" for="starhalf"></label>
					  </fieldset>
					</li>
					<li><b>Date&amp;Time:</b> <span>2019-08-28 17:00:58</span></li>
					<li><b>Fare:</b> <span>64.6</span></li>
				  </ul>
				</div>
				<div class="clearfix"></div>
				<a class="accordion view-btn">View</a>
				<div class="panal">
					<label class="RideDtls">Ride Detail</label>
					<div class="row UserBookingList">
						<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
							<label>Customer's Name</label>    
						</div>
						<div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
							Deepti Srivastava
						</div>
					</div>
					<div class="row UserBookingList">
						<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
							<label>Driver's Name</label>  
						</div>
						<div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
							Test Driver driver
						</div>
					</div>
					<div class="row UserBookingList">
						<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
							<label> Pickup Location</label>    
						</div>
						<div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
							D/171 Chhajarsi Road, Block D, Sector 63, Noida 201307, India
						</div>
					</div>				
					<div class="row UserBookingList">
						<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
							<label> Drop Location</label>    
						</div>
						<div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
							India, Noida, Noida Greater Noida Expressway
						</div>
					</div>
					<div class="row UserBookingList">
						<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
							<label> Car Number</label>    
						</div>
						<div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
							dr gt utyuj hgvnghjfg
						</div>
					</div>
					<div class="row UserBookingList">
					   <div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
							<label> Vehicle Type</label>    
						</div>
						<div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
							Sedan
						</div>
					</div>				
					<div class="row UserBookingList">
						<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
							<label> Series</label>    
						</div>
						<div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
							4Runner(Toyota)
						</div>
					</div>
					<div class="row UserBookingList">
						<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
							<label> Booking Date &amp; Time</label>    
						</div>
						<div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
							2019-08-28 22:50:13 
						</div>
					</div>
					<div class="row UserBookingList">
						<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
							<label> Offered Tip</label>    
						</div>
						<div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
							5 
						</div>
					</div>
					<div class="row UserBookingList">
						<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
							<label> Rating</label>    
						</div>
						<div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
							0 
						</div>
					</div>
					<div class="row UserBookingList">
						<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
							<label> Feedbacks</label>    
						</div>
						<div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
						</div>
					</div>
				</div>
			</div>			
		</div>	
		<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">	
			<div class="DiverBookingBox">
				<div class="booking-left-column">
					<ul class="BookinList">
						<li><b>Pickup Location</b><span>D/171 Chhajarsi Road, Block D, Sector 63, Noida 201307, India</span></li>
						<li><b>Drop Location</b><span>India, Noida, Sector 32, City Center Marg</span></li>
						<li><b>Username</b><span>Anil Kumar</span></li>
						<li><b>Email ID</b><span>anil313@gamil.com</span></li>
						<li><b>Mobile Number</b><span>+916479546213</span></li>
						<li><b>Tip</b><span>10</span></li>
					</ul>
				</div>
				<div class="booking-rght-column">
				  <ul class="BookinList">
					<li class="rate"><b>Rating</b>
					  <fieldset class="rating">
						<input type="radio" id="star5" name="rating" value="5">
						<label class="full" for="star5"></label>
						<input type="radio" id="star4half" name="rating" value="4 and a half">
						<label class="half" for="star4half"></label>
						<input type="radio" id="star4" name="rating" value="4">
						<label class="full" for="star4"></label>
						<input type="radio" id="star3half" name="rating" value="3 and a half">
						<label class="half" for="star3half"></label>
						<input type="radio" id="star3" name="rating" value="3">
						<label class="full" for="star3"></label>
						<input type="radio" id="star2half" name="rating" value="2 and a half">
						<label class="half" for="star2half"></label>
						<input type="radio" id="star2" name="rating" value="2">
						<label class="full" for="star2"></label>
						<input type="radio" id="star1half" name="rating" value="1 and a half">
						<label class="half" for="star1half"></label>
						<input type="radio" id="star1" name="rating" value="1">
						<label class="full" for="star1"></label>
						<input type="radio" id="starhalf" name="rating" value="half">
						<label class="half" for="starhalf"></label>
					  </fieldset>
					</li>
					<li><b>Date&amp;Time:</b> <span>2019-08-28 17:00:58</span></li>
					<li><b>Fare:</b> <span>64.6</span></li>
				  </ul>
				</div>
				<div class="clearfix"></div>
				<a class="accordion view-btn">View</a>
				<div class="panal">
					<label class="RideDtls">Ride Detail</label>
					<div class="row UserBookingList">
						<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
							<label>Customer's Name</label>    
						</div>
						<div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
							Deepti Srivastava
						</div>
					</div>
					<div class="row UserBookingList">
						<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
							<label>Driver's Name</label>  
						</div>
						<div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
							Test Driver driver
						</div>
					</div>
					<div class="row UserBookingList">
						<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
							<label> Pickup Location</label>    
						</div>
						<div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
							D/171 Chhajarsi Road, Block D, Sector 63, Noida 201307, India
						</div>
					</div>				
					<div class="row UserBookingList">
						<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
							<label> Drop Location</label>    
						</div>
						<div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
							India, Noida, Noida Greater Noida Expressway
						</div>
					</div>
					<div class="row UserBookingList">
						<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
							<label> Car Number</label>    
						</div>
						<div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
							dr gt utyuj hgvnghjfg
						</div>
					</div>
					<div class="row UserBookingList">
					   <div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
							<label> Vehicle Type</label>    
						</div>
						<div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
							Sedan
						</div>
					</div>				
					<div class="row UserBookingList">
						<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
							<label> Series</label>    
						</div>
						<div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
							4Runner(Toyota)
						</div>
					</div>
					<div class="row UserBookingList">
						<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
							<label> Booking Date &amp; Time</label>    
						</div>
						<div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
							2019-08-28 22:50:13 
						</div>
					</div>
					<div class="row UserBookingList">
						<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
							<label> Offered Tip</label>    
						</div>
						<div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
							5 
						</div>
					</div>
					<div class="row UserBookingList">
						<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
							<label> Rating</label>    
						</div>
						<div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
							0 
						</div>
					</div>
					<div class="row UserBookingList">
						<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
							<label> Feedbacks</label>    
						</div>
						<div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
						</div>
					</div>
				</div>
			</div>			
		</div>	
		<div class="clearfix"></div>
	</div>
</section>	

<?php include 'footer.php'; ?>
<script>

jQuery(document).ready(function() {
	function close_accordion_section() {
		jQuery('.accordion').removeClass('active');
		jQuery('.panal').slideUp(500).removeClass('open');
	}
	jQuery('.accordion').click(function(e) {
		if(jQuery(e.target).is('.active')) {
			close_accordion_section();
		}else {
			close_accordion_section();
			jQuery(this).addClass('active');
			jQuery(this).next().slideDown(500);
		}
	});
	
});

</script>
