<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width,initial-scale=1">
	<title>Welcome to Metro Taxi</title>
	<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800" rel="stylesheet">
	<link href="../css/bootstrap.min.css" rel="stylesheet" type="text/css">
	<link href="../css/font-awesome.min.css" rel="stylesheet" type="text/css">
	<link href="../css/icons.css" rel="stylesheet" type="text/css">
	<link href="../css/niceCountryInput.css" rel="stylesheet" type="text/css">
	<link href="../css/mystyle.css" rel="stylesheet" type="text/css">
	<link href="../css/menu.css" rel="stylesheet" type="text/css">
	<link href="../images/favicon.png" rel="icon" type="image/gif">
</head>

<body class="InnerbodyBg">
	<div id="header" class="navbar navbar-fixed-top">
		<div id="header-container" class="navbar-container">
			<div id="o-wrapper" class="o-wrapper">
				<button id="c-button--slide-left" class="c-button">
					<a href="#" class="MenuBox"> <span></span> <span></span> <span></span> </a>
				</button>
				<div id="github-icons"></div>
			</div><!-- /o-wrapper -->
			<nav id="c-menu--slide-left" class="c-menu c-menu--slide-left">
				<button class="c-menu__close"><i class="fa fa-times"></i></button>
				<ul class="c-menu__items">
					<li class="c-menu__item"><a href="index.php" class="c-menu__link">Home</a></li>
					<li class="c-menu__item"><a href="profile.php" class="c-menu__link">Profile</a></li>
					<li class="c-menu__item"><a href="payment-method.php" class="c-menu__link">Subscription</a></li>
					<li class="c-menu__item"><a href="drivers-management.php" class="c-menu__link">Driver's Management</a></li>
					<li class="c-menu__item"><a href="vehicles-management.php" class="c-menu__link">Vehicle's Management</a></li>
					<li class="c-menu__item"><a href="ride.php" class="c-menu__link">Rides</a></li>
					<li class="c-menu__item"><a href="revenue.php" class="c-menu__link">Revenue</a></li>
					<li class="c-menu__item"><a href="/metrotaxi" class="c-menu__link">Logout</a></li>
				</ul>
			</nav><!-- /c-menu slide-left -->
			<div id="c-mask" class="c-mask"></div>
			<!-- /c-mask -->
			
			<div class="navbar-header"> 
				<a href="index.php"><img src="../images/logo1.png"></a> 
			</div>
			<div class="pull-right"> 
			  <div class="niceCountryInputSelector desk-display" data-selectedcountry="US" data-showspecial="false" data-showflags="true" data-i18nall="All selected" data-i18nnofilter="No selection" data-i18nfilter="Filter" data-onchangecallback="onChangeCallback"></div>
			</div>
		</div>
	</div>