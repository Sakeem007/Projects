<?php include 'header.php'; ?>

	<section class="BodyWrapper">
		<div class="CustMemBox">
			<div class="row CustomerFmBox">
				<form action="" role="form">					
					<div class="DriverPhotoBox">
						<div class="DriverPhoto"><img src="../images/driver-image.jpg"></div>                            
						<div class="upload-btn-wrapper">
						  <button class="btn">Take a Picture</button>
							   <input type="file" onchange="angular.element(this).scope().uploadImage(this, 'image')" class="custom-file-input">
						</div>
					</div>
					<div class="DriverDocumBox">
						<div class="DriverDocum"><img src="../images/identity-image.png"></div>
						<div class="upload-btn-wrapper">
							<button class="btn upload-icon">Upload an ID</button>
							<input type="file" onchange="angular.element(this).scope().uploadImage(this, 'ZAQWE')" class="custom-file-input">
						</div>
					</div>
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Business Connection (Rental Car Driver, Counter/Service Provider)</label>
							<div class="add_tags_secondry">
								<input class="tginput" type="text" data-role="tagsinput" placeholder='Write Business Connection' value="Individual Company Taxi Driver ">				
							</div>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Driver Given Name<span>*</span></label>
							<input type="text" class="form-control" value="T Jon">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Driver Family Name</label>
							<input type="text" class="form-control" value="Tison">
						</div>
					</div>					
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Country</label>
							<select class="form-control">
								<option>CN China</option>
								<option>DE Germany</option>
								<option>FR France</option>
								<option selected="selected">IN India</option>
								<option>ES Spain</option>
								<option>UK United Kingdom</option>
							</select>
						</div>
					</div>	
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Province / Federal State <span>*</span></label>
							<input type="text" class="form-control" value="Gti">
						</div>
					</div>	
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>City / Municipality <span>*</span></label>
							<input type="text" class="form-control" value="Gojk">
						</div>
					</div>	
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Zip<span>*</span></label>
							<input type="text" class="form-control" value="987546">
						</div>
					</div>	
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12" value="Gim,89">                
						<div class="form-group">
							<label>Street Number<span>*</span></label>
							<input type="text" class="form-control" value="T-46/d, ouoad foas d">
						</div>
					</div>			
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Driver Address - Street Name<span>*</span> </label>
							<input type="text" class="form-control" value="546">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">               
						<div class="form-group">
							<label>Address Driver - House / Apartment No<span>*</span></label>
							<input type="text" class="form-control" value="10">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Address Driver -Floor</label>
							<input type="text" class="form-control" value="5">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Driver-Email<span>*</span></label>
							<input type="email" class="form-control" value="abc1234@yopmail.com">
						</div>
					</div>
					<div class="col-lg-2 col-md-2 col-sm-2 col-xs-12">                
						<div class="form-group">
							<label>Dialing Code<span>*</span></label>
							<input type="text" class="form-control" value="+86">
						</div>
					</div>
					<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">                
						<div class="form-group">
							<label>Driver-Mobile Number</label>
							<input type="text" class="form-control" value="8795462130">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Driver ID Card Numberr</label>
							<input type="text" class="form-control" value="D879">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Driver Employee Number</label>
							<input type="text" class="form-control" value="87946551">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                     
						<div class="form-group">
							<label>Driver Social Insurance Number</label>
							<input type="text" class="form-control" value="0012506">
						</div>
					</div>								
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
						<button type="submit" class="btn btn-default signin-btn register-btn">Submit</button>
					</div>
				</form> 
			</div>
		</div>
	</section>	

<?php include 'footer.php'; ?>
<script>

</script>
