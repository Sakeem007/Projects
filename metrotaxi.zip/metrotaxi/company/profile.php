<?php include 'header.php'; ?>

	<section class="BodyWrapper">
		<a class="EditIcon">
			<i id="EdtBTn" class="icon icon-pencil" title="Edit"></i>
			<i id="EyeBTn" class="icon icon-eye" title="View"></i>
		</a>
		<div class="CustMemBox">
			<div class="row CustomerFmBox">
				<form action="" role="form" class="ProfileBox">					
					<div class="DriverPhotoBox">
						<div class="DriverPhoto"><img src="../images/driver-image.jpg"></div> 
					</div>
					<div class="DriverDocumBox">
						<div class="DriverDocum"><img src="../images/identity-image.png"></div>
					</div>
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Business Type (Taxi Company, Rental Car Company, Chauffeur Service Company, Transportation Service Company)</label>
							<p>Rental Car Company Mission Center</p>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Company Name</label>
							<p>ABC Pvt. Ltd.</p>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Given Name - Company Administrator</label>
							<p>Rahul</p>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Last Name - Company Administrator</label>
							<p>Khanna</p>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Nationality - Company Administrator</label>
							<p>India</p>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">               
						<div class="form-group">
							<label>ID Card - Company Administrator</label>
							<p>A to Z</p>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Country - Company Address</label>
							<p>India</p>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Province - Company Address</label>
							<p>zcvxzxcv</p>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>City / Municipality- Company Address</label>
							<p>Gi-51/B</p>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>ZIP- Company Address</label>
							<p>213484</p>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Street Number- Company Address</label>
							<p>Db8</p>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Street Name- Company Address Street - Company Address</label>
							<p>bzvc546</p>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                     
						<div class="form-group">
							<label>House / Apartment No.- Company Address</label>
							<p>86</p>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Address Company -Floor</label>
							<p>2nd Floor</p>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Further Information</label>
							<p>Czxcvzxcvzxcv</p>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>VAT, Tax Number - Taxi Company</label>
							<p>TR6461323</p>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Business License - Taxi Company</label>
							<p>vcvbxc</p>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Taxi License - Taxi Company</label>
							<p>ZXCV87954600</p>
						</div>
					</div>						
				</form>
				<form action="" role="form" class="RegistrationForm">					
					<div class="DriverPhotoBox">
						<div class="DriverPhoto"><img src="../images/driver-image.jpg"></div>                            
						<div class="upload-btn-wrapper">
						  <button class="btn">Take a Picture</button>
							   <input type="file" onchange="angular.element(this).scope().uploadImage(this, 'image')" class="custom-file-input">
						</div>
					</div>
					<div class="DriverDocumBox">
						<div class="DriverDocum"><img src="../images/identity-image.png"></div>
						<div class="upload-btn-wrapper">
							<button class="btn upload-icon">Upload an ID</button>
							<input type="file" onchange="angular.element(this).scope().uploadImage(this, 'ZAQWE')" class="custom-file-input">
						</div>
					</div>
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Business Type (Taxi Company, Rental Car Company, Chauffeur Service Company, Transportation Service Company)</label>
							<div class="add_tags_secondry">
								<input class="tginput" type="text" data-role="tagsinput" placeholder='Write Business Connection' value="Self Employed Chauffeur">				
							</div>
						</div>
					</div>
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">                
						<div class="form-group">
							<label>Company Name<span>*</span></label>
							<input type="text" class="form-control" value="ABC Company">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Given Name - Company Administrator<span>*</span></label>
							<input type="text" class="form-control" value="Rahul">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Last Name - Company Administrator<span>*</span></label>
							<input type="text" class="form-control" value="Khanna">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Nationality - Company Administrator</label>
							<select class="form-control">
								<option>Chinese</option>
								<option>German</option>
								<option>French</option>
								<option selected="selected">Indian</option>
								<option>Spanish</option>
								<option>British</option>
							</select>
						</div>
					</div>	
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>ID Card - Company Administrator<span>*</span></label>
							<input type="text" class="form-control" value="A to Z">
						</div>
					</div>				
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Country - Company Address<span>*</span></label>
							<select class="form-control">
								<option>CN China</option>
								<option>DE Germany</option>
								<option>FR France</option>
								<option selected="selected">IN India</option>
								<option>ES Spain</option>
								<option>UK United Kingdom</option>
							</select>
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Province - Company Address<span>*</span> </label>
							<input type="text" class="form-control" value="zcvxzxcv">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">               
						<div class="form-group">
							<label>City / Municipality- Company Address<span>*</span></label>
							<input type="text" class="form-control" value="Gi-51/B">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>ZIP- Company Address<span>*</span></label>
							<input type="text" class="form-control" value="213484">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Street Number- Company Address<span>*</span></label>
							<input type="text" class="form-control" value="Db8">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Street Name- Company Address Street - Company Address<span>*</span></label>
							<input type="text" class="form-control" value="bzvc546">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>House / Apartment No.- Company Address</label>
							<input type="text" class="form-control" value="86">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Address Company -Floor</label>
							<input type="text" class="form-control" value="2nd Floor">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Further Information</label>
							<input type="text" class="form-control" value="Contrary to popular belief, Lorem Ipsum is not simply random text.">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                     
						<div class="form-group">
							<label>VAT, Tax Number - Taxi Company<span>*</span></label>
							<input type="text" class="form-control" value="TR6461323">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Business License - Taxi Company<span>*</span></label>
							<input type="text" class="form-control" value="vcvbxc">
						</div>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">                
						<div class="form-group">
							<label>Taxi License - Taxi Company</label>
							<input type="text" class="form-control" value="ZXCV87954600">
						</div>
					</div>					
					<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
						<button type="submit" class="btn btn-default signin-btn register-btn">Submit</button>
					</div>
				</form> 
			</div>
		</div>
	</section>	

<?php include 'footer.php'; ?>
<script>
	 jQuery('#EdtBTn').click(function(){
		jQuery('.ProfileBox').css("display", "none");
		jQuery('#EdtBTn').css("display", "none");
		jQuery('#EyeBTn').css("display", "block");
		jQuery('.RegistrationForm').css("display", "block");
	  });
	 jQuery('#EyeBTn').click(function(){
		jQuery('.RegistrationForm').css("display", "none");
		jQuery('#EdtBTn').css("display", "block");
		jQuery('#EyeBTn').css("display", "none");
		jQuery('.ProfileBox').css("display", "block");
	  });
</script>
