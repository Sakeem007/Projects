<?php include 'header.php'; ?>

	<section class="BodyWrapper BookingBox">
		<div class="subscription-column">
            <div class="row">
				<h4 class="PgTitle">Select Payment Method</h4>
				<div class="mainwrapper">
					<div class="col-lg-4 col-md-6 col-sm-12 col-xs-12">
						<div class="free-subscription monthly-subscription Standard">
						<h5><strong>Standard</strong></h5>
							
						<a href="#" class="PayNow"> One time 316.676 INR/p.m. </a>
						<ul class="ComDriSection">
						<div class="ComDriBox">
							<h6 class="ng-binding">Visibility </h6>
							<li>
							<label class="SubPayment"><span class="TxtBox">Me </span>
								<input type="checkbox" disabled="" checked="">
								<span class="checkmark"></span> </label>
							</li>
							<li>
							<label class="SubPayment"><span class="TxtBox">Competitor </span>
								<input type="checkbox" disabled="">
								<span class="checkmark"></span> </label>
							</li>
						</div>
						<div class="ComDriBox">
							<h6>Analytics</h6>
							<li>
							<label class="SubPayment"><span class="TxtBox">Clustering – Customer Show Density</span>
								<input type="checkbox" disabled="">
								<span class="checkmark"></span> </label>
							</li>
							<li>
							<label class="SubPayment"><span class="TxtBox">Clustering – Driver Business Probability</span>
								<input type="checkbox" disabled="">
								<span class="checkmark"></span> </label>
							</li>
						</div>
						<div class="ComDriBox">
							<h6 class="ng-binding">Payment</h6>
							<li>
							<label class="SubPayment"><span class="TxtBox">MetroPay - Ride</span>
								<input type="checkbox" disabled="">
								<span class="checkmark"></span> </label>
							</li>
							<li>
							<label class="SubPayment"><span class="TxtBox">MetroPay - Tax Invoice</span>
								<input type="checkbox" disabled="">
								<span class="checkmark"></span> </label>
							</li>
						</div>
						</ul>
						<p class="SlogTitle fst">&nbsp;</p>
					</div>
					</div>
					<div class="col-lg-4 col-md-6 col-sm-12 col-xs-12">
						<div class="free-subscription monthly-subscription">
						<h5><strong>Exclusive</strong></h5>
						<a href="#" class="PayNow"> 475.014  INR/p.m.</a> <a href="#" class="PayNow"> 4750.14  INR/p.m.</a>
						<div class="clearfix"></div>
						<ul class="ComDriSection">
						<div class="ComDriBox">
							<h6>Visibility</h6>
							<li>
							<label class="SubPayment"><span class="TxtBox">Me </span>
								<input type="checkbox" disabled="" checked="">
								<span class="checkmark"></span> </label>
							</li>
							<li>
							<label class="SubPayment"><span class="TxtBox">Competitor</span>
								<input type="checkbox" disabled="" checked="">
								<span class="checkmark"></span> </label>
							</li>
						</div>
						<div class="ComDriBox">
							<h6 class="ng-binding">Analytics</h6>
							<li>
							<label class="SubPayment"><span class="TxtBox">Clustering – Customer Show Density</span>
								<input type="checkbox" disabled="" >
								<span class="checkmark"></span> </label>
							</li>
							<li>
							<label class="SubPayment"><span class="TxtBox">Clustering – Driver Business Probability</span>
								<input type="checkbox" disabled="">
								<span class="checkmark"></span> </label>
							</li>
						</div>
						<div class="ComDriBox">
							<h6 class="ng-binding">Payment</h6>
							<li>
							<label class="SubPayment"><span class="TxtBox">MetroPay - Ride</span>
								<input type="checkbox" disabled="">
								<span class="checkmark"></span> </label>
							</li>
							<li>
							<label class="SubPayment"><span class="TxtBox">MetroPay - Tax Invoice</span>
								<input type="checkbox" disabled="">
								<span class="checkmark"></span> </label>
							</li>
						</div>
						</ul>
						<p class="SlogTitle">20 days try *Yearly payment 10% discount </p>
					</div>
					</div>
				</div>
            </div>
        </div>
	</section>	

<?php include 'footer.php'; ?>
<script>

</script>
