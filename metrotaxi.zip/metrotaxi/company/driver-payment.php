<?php include 'header.php'; ?>
<section class="BodyWrapper BookingBox">
	<div class="PyamentWrapper">
		<ul class="payment-cards tabs">
			<li class=" current" data-tab="tab-1">
				<label class="custom-radio-column">
					<input type="radio" name="radio" checked="checked" value="Credit card">
					<span class="checkmark"></span>
					<img src="../images/mastercard-logo.png">
				</label>  
			</li>
			<li class="" data-tab="tab-2">
				<label class="custom-radio-column">
					<input type="radio" name="radio" value="Apple pay">
					<span class="checkmark"></span>
					<img src="../images/applepay-logo.png">
				</label>
			</li>
			<li class="" data-tab="tab-3">				
				<label class="custom-radio-column">
					<input type="radio" name="radio" value="WeChat"/>
					<span class="checkmark"></span>
					<img src="../images/wechat-logo.png">
				</label>
			</li>
			<li class="" data-tab="tab-4">
				<label class="custom-radio-column">
					<input type="radio" name="radio" value="Alipay" />
					<span class="checkmark"></span>
					<img src="../images/alipay-logo.png">
				</label>
			</li>
			<li class="" data-tab="tab-5">
				<label class="googlepayBtn">
					<input type="radio" name="radio" value="Google pay service"/>
					<span class="checkmark"></span>
					<img src="../images/googlepay-logo.png">
				</label>
			</li>
		</ul>
		<div id="tab-1" class="CartDetaisBox tab-content current">
			<form class="payment-form">
				<div class="row">
					<div class="col-lg-12">
						<div class="form-group">
							<label for="exampleFormControlInput1">Card Number*</label>
							<input class="form-control" maxlength="16" name="credit-number" placeholder="Card Number" type="tel" />
						</div>
					</div>
					<div class="col-lg-3 col-md-3 col-sm-3">
						<div class="form-group">
							<label for="exampleFormControlSelect2">Expiry Month*</label>
							<input type="text" class="form-control" maxlength="2" id="exampleFormControlInput2" placeholder="12" />
						</div>
					</div>
					<div class="col-lg-3 col-md-3 col-sm-3">
						<div class="form-group">
							<label for="exampleFormControlSelect2">Expiry Year*</label>
							<input type="text" class="form-control" maxlength="4" id="exampleFormControlInput3" placeholder="2020" />
						</div>
					</div>
					<div class="col-lg-2 col-md-2 col-sm-2">
						<div class="form-group">
							<label for="exampleFormControlInput3">CVV*</label>
							<input type="text" class="form-control" id="exampleFormControlInput3" placeholder="123" size="3" maxlength="3" />
						</div>
					</div>
					<div class="col-lg-12">
						<div class="form-group">
							<label for="exampleFormControlInput2">Card Holder*</label>
							<input type="text" class="form-control" id="exampleFormControlInput2" placeholder="Card Holder" />
						</div>
					</div>
					<div class="col-lg-12">
						<div class="form-group">
							<label for="exampleFormControlInput3">Email*</label>
							<input type="email" class="form-control" id="exampleFormControlInput3" placeholder="name@example.com" />
						</div>
					</div>
					<div class="col-lg-12">
						<div class="form-check">
							<input type="checkbox" class="form-check-input" id="exampleCheck1" required=""/>
							<label class="form-check-label" for="exampleCheck1">I have read and agree to the terms and conditions. </label>
						</div>
					</div>
					<div class="col-lg-12 BtnBox">
						<button type="submit" class="btn btn-default signin-btn submit-btn" >Submit</button>
						<button type="submit" class="btn btn-default signin-btn cancel-btn">Cancel</button>
					</div>
				</div>
			</form>
		</div>
		<div id="tab-2" class="UserPayBox tab-content">
			<div class="CartDetaisBox">
				Apply pay data
			</div>
		</div>		
		<div id="tab-3" class="UserPayBox tab-content">
			<div class="CartDetaisBox">
				We chat pay data
			</div>
		</div>		
		<div id="tab-4" class="UserPayBox tab-content">
			<div class="CartDetaisBox">
				<div class="row">
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
						<label>Description:</label>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
						Subcription plan (Monthly) 
					</div>
				</div>
				<div class="row">
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
						<label>Amount:</label>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
						100
					</div>
				</div>
				<div class="row">
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
						<label>Currency:</label>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
						EUR 
					</div>
				</div>
				<div class="row">
					<div class="col-lg-12 BtnBox">
						<button type="submit" class="btn btn-default signin-btn submit-btn">Make Payment</button>
					</div>
				</div>
			</div>
		</div>
		<div id="tab-5" class="UserPayBox tab-content">
			<div class="CartDetaisBox GooglePya">
				<div class="row">
					<div class="col-lg-6 col-md-6 col-sm-6">
						<label>Description:</label>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6">
						Subcription plan (Monthly) 
					</div>
				</div>				
				<div class="row">
					<div class="col-lg-6 col-md-6 col-sm-6">
						<label>Amount:</label>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6">
						100 
					</div>
				</div>
				<div class="row">
					<div class="col-lg-6 col-md-6 col-sm-6">
						<label>Currency:</label>
					</div>
					<div class="col-lg-6 col-md-6 col-sm-6">
						EUR
					</div>
				</div>
				<div class="row">
					<div class="col-lg-12 BtnBox">
						<div id="container_gpays"><button type="submit" class="btn btn-default signin-btn submit-btn">Buy with G pay</button></div>
					</div>
				</div>
			</div>			   
		</div>		 
	</div>
</section>	
<?php include 'footer.php'; ?>
<script>
		
		$(document).ready(function(){
	
	$('ul.tabs li').click(function(){
		var tab_id = $(this).attr('data-tab');

		$('ul.tabs li').removeClass('current');
		$('.tab-content').removeClass('current');

		$(this).addClass('current');
		$("#"+tab_id).addClass('current');
	})

})
</script>
