<?php include 'header.php'; ?>

<section class="BodyWrapper">
	<div class="ComViewDriver">
		<div id="exTab1">
			<ul class="nav nav-pills">
				<li class="active"> <a href="javascript:void(0);" data-target="#1a" data-toggle="tab" aria-expanded="true">Profile</a> </li>
				<li class=""><a href="javascript:void(0);" data-target="#2a" data-toggle="tab" aria-expanded="false">Rides</a> </li>
				<li class=""><a href="javascript:void(0);" data-target="#3a" data-toggle="tab" aria-expanded="false">Revenue</a> </li>
			</ul>
			<div class="tab-content clearfix">
				<div class="tab-pane active" id="1a">				
					<div class="ComViDri">
						<div class="registration-form-column">					
							<div class="driver-column">
								<div class="driver-image"><img src="https://www.chawtechsolutions.co.in/metrotaxi/uploads/driver/09e2a5992e42346b0977a4a95990db67.jpg"></div>
							</div>
							<div class="driver-column aadahar-column">
								<div class="driver-image"><img src="https://www.chawtechsolutions.co.in/metrotaxi/uploads/driver/da7a45cc0da5f3d47adb432e410ae67d.jpg"></div>
							</div>
							<div class="clearfix"></div>
							<div class="row clearfix">
								<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
									<div class="form-group">
										<label>Driver Given Name: </label> Test Driver 
									</div>
								</div>
								<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
									<div class="form-group">
									 <label>Driver Family Name:</label> Pintu
									</div>
								</div>
								<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
									<div class="form-group">
										<label>Country:</label> DE Germany 
									</div>
								</div>
								<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
									<div class="form-group">
										<label>Province / Federal State: </label> fefe 
									</div>
								</div>
								<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
									<div class="form-group">
										<label>City / Municipality: </label> fsfs 
									</div>
								</div>
								<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
									<div class="form-group">
										<label>ZIP: </label>	23242 
									</div>
								</div>
								<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
									<div class="form-group">
										<label>Street Number: </label> 342 
									</div>
								</div>
								<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
									<div class="form-group">
										<label>Driver Address - Street Name: </label> ABC 
									</div>
								</div>
								<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
									<div class="form-group">
										<label>Address Driver - House / Apartment No.: </label> B-20
									</div>
								</div>
								<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
									<div class="form-group">
										<label>Address Driver -Floor: </label> 3rd Floor 
									</div>
								</div>
								<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
									<div class="form-group">
										<label>Driver-Email: </label> testlicdriver1@yopmail.com 
									</div>
								</div>
								<div class="col-lg-2 col-md-2 col-sm-6 col-xs-12">
									<div class="form-group">
									<label>Dialing Code:</label> +86 </div>
								</div>
								<div class="col-lg-4 col-md-4 col-sm-6 col-xs-12">
									<div class="form-group">
										<label>Driver-Mobile Number: </label> 9784613001
									</div>
								</div>
								<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
									<div class="form-group">
										<label>Driver ID Card Number:</label> IDP546
									</div>
								</div>
								<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
									<div class="form-group">
										<label>Driver Employee Number:</label> 0096 
									</div>
								</div>
								<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
									<div class="form-group">
										<label>Driver Social Insurance Number:</label> sadfzxv
									</div>
								</div>
							</div>
						<div class="clearfix"></div>
						</div>
					</div>
				</div>
				<div class="tab-pane fade" id="2a">
					<section class="DriverRevenueBox"> 
						<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true" style="    color: #000;"> 
							<div class="RideNotFound" style=""> No Rides Found
								<div class="RideNotFoundPic"><img src="https://www.chawtechsolutions.co.in/metrotaxi/assets/images/ridenotfound.gif"></div>
							</div>
						</div>
					</section>
				</div>
				<div class="tab-pane fade" id="3a">
					<section class="DriverRevenueBox">
						<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
							<h4>Revenues</h4>
						</div>
						<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
							<ul class="revenue-list">
								<li>
								<h5>Yearly Total</h5>
								<p>0</p>
								</li>
								<li>
								<h5>Monthly Total</h5>
								<p>0</p>
								</li>
								<li>
								<h5>Weekly Total</h5>
								<p>0</p>
								</li>
							</ul>
						</div>
						<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
							<div id="container" class="RevenueBox" data-highcharts-chart="0" style="overflow: hidden;">
								<div id="highcharts-k0b2t6w-0" style="position: relative; overflow: hidden; width: 528px; height: 396px; text-align: left; line-height: normal; z-index: 0; left: 0px; top: 0px;" dir="ltr" class="highcharts-container "><svg version="1.1" class="highcharts-root" style="font-family:&quot;Lucida Grande&quot;, &quot;Lucida Sans Unicode&quot;, Arial, Helvetica, sans-serif;font-size:12px;" xmlns="http://www.w3.org/2000/svg" width="528" height="396" viewBox="0 0 528 396">
								<desc>Created with Highcharts 7.1.1</desc>
								<defs>
								<clipPath id="highcharts-k0b2t6w-1-">
								<rect x="0" y="0" width="458" height="265" fill="none"></rect>
								</clipPath>
								</defs>
								<rect fill="#ffffff" class="highcharts-background" x="0" y="0" width="528" height="396" rx="0" ry="0"></rect>
								<rect fill="none" class="highcharts-plot-background" x="60" y="53" width="458" height="265"></rect>
								<g class="highcharts-grid highcharts-xaxis-grid" data-z-index="1">
								<path fill="none" data-z-index="1" class="highcharts-grid-line" d="M 517.5 53 L 517.5 318" opacity="1"></path>
								<path fill="none" data-z-index="1" class="highcharts-grid-line" d="M 59.5 53 L 59.5 318" opacity="1"></path>
								</g>
								<g class="highcharts-grid highcharts-yaxis-grid" data-z-index="1">
								<path fill="none" stroke="#e6e6e6" stroke-width="1" data-z-index="1" class="highcharts-grid-line" d="M 60 186.5 L 518 186.5" opacity="1"></path>
								</g>
								<rect fill="none" class="highcharts-plot-border" data-z-index="1" x="60" y="53" width="458" height="265"></rect>
								<g class="highcharts-axis highcharts-xaxis" data-z-index="2">
								<path fill="none" class="highcharts-axis-line" stroke="#ccd6eb" stroke-width="1" data-z-index="7" d="M 60 318.5 L 518 318.5"></path>
								</g>
								<g class="highcharts-axis highcharts-yaxis" data-z-index="2">
								<text x="26.050000190734863" data-z-index="7" text-anchor="middle" transform="translate(0,0) rotate(270 26.050000190734863 185.5)" class="highcharts-axis-title" style="color:#666666;fill:#666666;" y="185.5">
								<tspan>Earnings</tspan>
								</text>
								<path fill="none" class="highcharts-axis-line" data-z-index="7" d="M 60 53 L 60 318"></path>
								</g>
								<g class="highcharts-series-group" data-z-index="3">
								<g data-z-index="0.1" class="highcharts-series highcharts-series-0 highcharts-column-series highcharts-color-0  highcharts-tracker" transform="translate(60,53) scale(1 1)" clip-path="url(#highcharts-k0b2t6w-1-)">
								<rect x="110" y="134" width="55" height="0" fill="#7cb5ec" opacity="1" class="highcharts-point highcharts-color-0"></rect>
								</g>
								<g data-z-index="0.1" class="highcharts-markers highcharts-series-0 highcharts-column-series highcharts-color-0 " transform="translate(60,53) scale(1 1)" clip-path="none"></g>
								<g data-z-index="0.1" class="highcharts-series highcharts-series-1 highcharts-column-series highcharts-color-1  highcharts-tracker" transform="translate(60,53) scale(1 1)" clip-path="url(#highcharts-k0b2t6w-1-)">
								<rect x="202" y="134" width="55" height="0" fill="#434348" opacity="1" class="highcharts-point highcharts-color-1"></rect>
								</g>
								<g data-z-index="0.1" class="highcharts-markers highcharts-series-1 highcharts-column-series highcharts-color-1 " transform="translate(60,53) scale(1 1)" clip-path="none"></g>
								<g data-z-index="0.1" class="highcharts-series highcharts-series-2 highcharts-column-series highcharts-color-2  highcharts-tracker" transform="translate(60,53) scale(1 1)" clip-path="url(#highcharts-k0b2t6w-1-)">
								<rect x="293" y="134" width="55" height="0" fill="#90ed7d" opacity="1" class="highcharts-point highcharts-color-2"></rect>
								</g>
								<g data-z-index="0.1" class="highcharts-markers highcharts-series-2 highcharts-column-series highcharts-color-2 " transform="translate(60,53) scale(1 1)" clip-path="none"></g>
								</g>
								<text x="264" text-anchor="middle" class="highcharts-title" data-z-index="4" style="color:#333333;font-size:18px;fill:#333333;" y="24">
								<tspan>Driver Revenue(2019)</tspan>
								</text>
								<text x="264" text-anchor="middle" class="highcharts-subtitle" data-z-index="4" style="color:#666666;fill:#666666;" y="52"></text>
								<g class="highcharts-legend" data-z-index="7" transform="translate(143,352)">
								<rect fill="none" class="highcharts-legend-box" rx="0" ry="0" x="0" y="0" width="241" height="29" visibility="visible"></rect>
								<g data-z-index="1">
								<g>
								<g class="highcharts-legend-item highcharts-column-series highcharts-color-0 highcharts-series-0" data-z-index="1" transform="translate(8,3)">
								<text x="21" style="color:#333333;cursor:pointer;font-size:12px;font-weight:bold;fill:#333333;" text-anchor="start" data-z-index="2" y="15">
								<tspan>Weekly</tspan>
								</text>
								<rect x="2" y="4" width="12" height="12" fill="#7cb5ec" rx="6" ry="6" class="highcharts-point" data-z-index="3"></rect>
								</g>
								<g class="highcharts-legend-item highcharts-column-series highcharts-color-1 highcharts-series-1" data-z-index="1" transform="translate(90.8499984741211,3)">
								<text x="21" y="15" style="color:#333333;cursor:pointer;font-size:12px;font-weight:bold;fill:#333333;" text-anchor="start" data-z-index="2">
								<tspan>Monthly</tspan>
								</text>
								<rect x="2" y="4" width="12" height="12" fill="#434348" rx="6" ry="6" class="highcharts-point" data-z-index="3"></rect>
								</g>
								<g class="highcharts-legend-item highcharts-column-series highcharts-color-2 highcharts-series-2" data-z-index="1" transform="translate(180.38333129882812,3)">
								<text x="21" y="15" style="color:#333333;cursor:pointer;font-size:12px;font-weight:bold;fill:#333333;" text-anchor="start" data-z-index="2">
								<tspan>Yealy</tspan>
								</text>
								<rect x="2" y="4" width="12" height="12" fill="#90ed7d" rx="6" ry="6" class="highcharts-point" data-z-index="3"></rect>
								</g>
								</g>
								</g>
								</g>
								<g class="highcharts-axis-labels highcharts-xaxis-labels" data-z-index="7">
								<text x="289" style="color:#666666;cursor:default;font-size:11px;fill:#666666;" text-anchor="middle" transform="translate(0,0)" y="337" opacity="1">
								<tspan>Company Revenue</tspan>
								</text>
								</g>
								<g class="highcharts-axis-labels highcharts-yaxis-labels" data-z-index="7">
								<text x="45" style="color:#666666;cursor:default;font-size:11px;fill:#666666;" text-anchor="end" transform="translate(0,0)" y="190" opacity="1">0</text>
								</g>
								<text x="518" class="highcharts-credits" text-anchor="end" data-z-index="8" style="cursor:pointer;color:#999999;font-size:9px;fill:#999999;" y="391"></text>
								</svg>
								</div>
							</div>
						</div>
					</section>
				</div>
			</div>
		</div>
	</div>
</section>	

<?php include 'footer.php'; ?>
<script>

</script>
