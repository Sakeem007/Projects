<?php include 'header.php'; ?>
<div class="UserContentBox">
	<section class="MapBox">&nbsp;</section>	
	<div class="driver-login-bottom">
		<div class="driver-login-outer">
			<h5>Total Cars</h5>
			<span class="login-timer"><i class="fa fa-taxi"></i>102</span>
		</div> 
		<div class="driver-login-outer">
			<h5>Total Drivers</h5>
			<span class="login-timer"><i class="fa fa-user"></i>91</span>
		</div> 
		<div class="driver-login-outer">
			<h5>Total Bookings</h5>
			<span class="login-timer"><i class="fa fa-calendar"></i>81</span>
		</div>           
		<div class="driver-login-outer">
			<h5>Total Revenues</h5>
			<span class="login-timer"><i class="fa fa-money"></i>9785465</span>
		</div>           
		<div class="driver-login-outer">
			<h5>Active Drivers</h5>
			<span class="login-timer"><i class="fa fa-check"></i>39</span>
		</div>
	</div>
</div>
<?php include 'footer.php'; ?>
