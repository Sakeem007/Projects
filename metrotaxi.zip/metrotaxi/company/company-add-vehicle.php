<?php include 'header.php'; ?>
	<section class="BodyWrapper BookingBox">
		<h4 class="PgTitle">Add Vehicles</h4>
		<form class="registration-form adddriver-form AddVehi">
			<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
			  <div class="form-group">
				<label>Vehicle Type</label>
				<select class="form-control" id="exampleFormControlSelect1">
				  <option value="1" selected="selected" style="">Sedan</option>
				  <option value="2">SUV</option>
				  <option value="3">Coupe</option>
				  <option value="4">MiniVan</option>
				  <option value="5">Van</option>
				  <option value="6">Convertible</option>
				  <option value="7">Commercial Van</option>
				  <option value="8">Wagon</option>
				  <option value="9">Bike</option>
				  <option value="10">eScooter</option>
				  <option value="11">TwoWheeler</option>
				  <option value="12">TriCycle</option>
				  <option value="13">Quad</option>
				  <option value="14">Truck</option>
				  <option value="15">Other</option>          
				  <option value="16">Sedan11</option>          
				  <option value="17">Sedan13</option>          
				  <option value="18">xsxsdxsxs</option>    
				</select>
			  </div>
			</div>
			<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
			  <div class="form-group">
				<label>Vehicle Brand</label>
				<select class="form-control" id="exampleFormControlSelect2">
				  <option value="1" selected="selected" style="">Toyota</option>
				  <option value="2">Audi</option>
				  <option value="3">BMW</option>
				  <option value="4">Ford</option>
				  <option value="5">Holden</option>
				  <option value="6">Hyundai</option>
				  <option value="7">Kia</option>
				  <option value="8">Mazda</option>
				  <option value="9">Mercedes</option>
				  <option value="10">Nissan</option>
				  <option value="11">Peugot</option>
				  <option value="12">Volkswagen</option>
				  <option value="13">Vinaxuki</option>
				  <option value="14">Effa</option>
				  <option value="15">LuAZ</option>
				  <option value="16">ZAZ</option>
				  <option value="17">LAZ</option>
				  <option value="18">VinFast</option>
				  <option value="19">Mekong Auto</option>
				  <option value="20">World Auto</option>
				  <option value="21">GM Uzbekistan</option>
				  <option value="22">KrAZ</option>
				  <option value="23">Etalon</option>
				  <option value="24">Bohdan</option>
				  <option value="25">SAZ</option>
				  <option value="26">Western Star</option>
				  <option value="27">Tesla</option>
				  <option value="28">SSC</option>
				  <option value="29">Saleen</option>
				  <option value="30">Rossion</option>
				  <option value="31">Other</option>
				</select>
			  </div>
			</div>
			<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
			  <div class="form-group">
				<label>Vehicle Brand Type</label>
				<select class="form-control">
				  <option value="137" selected="selected" style="">4Runner</option>
				  <option value="138">86</option>
				  <option value="139">Aurion</option>
				  <option value="140">Avalon</option>
				  <option value="141">Avensis</option>
				  <option value="142">Blizzard</option>
				  <option value="143">Bundera</option>
				  <option value="144">Camry</option>
				  <option value="145">Celica</option>
				  <option value="146">Coaster</option>
				  <option value="147">Corolla</option>
				  <option value="148">Cressida</option>
				  <option value="149">Crown</option>
				  <option value="150">C-HR</option>
				  <option value="151">Dyna</option>
				  <option value="152">Echo</option>
				  <option value="153">FJ Cruiser</option>
				  <option value="154">Fortuner</option>
				  <option value="155">HiAce</option>
				  <option value="156">HiLux</option>
				  <option value="157">Kluger</option>
				  <option value="158">Land Cruiser</option>
				  <option value="159">Land Cruiser Prado</option>
				  <option value="160">Lexcen</option>
				  <option value="161">LITEACE</option>
				  <option value="162">Mirai</option>
				  <option value="163">MR2</option>
				  <option value="164">Paseo</option>
				  <option value="165">Prius</option>
				  <option value="166">Prius V</option>
				  
				</select>
			  </div>
			</div>
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<div class="form-group">
					<label>Powertrain</label>
					<div class="checkbox">
						<label class="custom-radio-column">Combustion
							<input type="radio" name="Powertrain" value="Combustion">
							<span class="checkmark"></span> 
						</label>
						<label class="custom-radio-column">Hybrid
							<input type="radio" name="Powertrain" value="Hybrid">
							<span class="checkmark"></span> 
						</label>
						<label class="custom-radio-column">Full Electric
							<input type="radio" name="Powertrain" value="Full Electric">
							<span class="checkmark"></span> 
						</label>
						<label class="custom-radio-column">ManPower
							<input type="radio" name="Powertrain" value="ManPower">
							<span class="checkmark"></span> 
						</label>				  
					</div>
				</div>
			</div>
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<div class="form-group">
					<label>Driving Mode</label>
					<div class="checkbox">
						<label class="custom-radio-column">Driver
							<input type="radio" name="DrivingMode" value="Driver">
							<span class="checkmark"></span> 
						</label>
						<label class="custom-radio-column">Autonom
							<input type="radio" name="DrivingMode" value="Autonom">
							<span class="checkmark"></span> 
						</label>									  
					</div>
				</div>
			</div>
			<div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
			  <div class="form-group">
				<label>License Plate No.</label>
				<input type="text" class="form-control">
			  </div>
			</div>
			<div class="row">
			  <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				<div class="driver-column upload-column">
				  <div class="driver-image"> <img src="../images/err.jpg"></div>
				  <div class="upload-btn-wrapper upload-white-bg">
					<button class="btn">Upload Vehicle image</button>
					<input type="file" class="custom-file-input">
				  </div>
				</div>
				<div class="driver-column upload-column">
				  <div class="driver-image"> <img src="../images/doc.jpg"></div>
				  <div class="upload-btn-wrapper upload-white-bg">
					<button class="btn">Upload Document(.jpg)</button>
					<input type="file" class="custom-file-input">
				  </div>
				  
				</div>
			  </div>
			</div>
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
			  <button type="submit" class="btn btn-default signin-btn register-btn">Save</button>
			</div>
			<div class="clearfix"></div>
		</form>
	</section>		
<?php include 'footer.php'; ?>
<script>
	
</script>
