		<div class="FooterWrapper">
			<ul>
				<li class="active"><a href="index.php" class="fa fa-home"><span>Home</span></a></li>	
				<li class=""><a href="login.php" class="fa fa-user"><span>Profile</span></a></li>		
			</ul>
		</div>
		<script src="js/jquery-2.2.4.min.js"></script> 
		<script src="js/bootstrap.min.js"></script> 
		<script src="js/niceCountryInput.js"></script>
		<script src="js/menu.js"></script> 
		<script src="js/tagsinput.js"></script> 
		<script>
			function onChangeCallback(ctr){
				console.log("The country was changed: " + ctr);
				//$("#selectionSpan").text(ctr);
			}
			$(document).ready(function () {
				$(".niceCountryInputSelector").each(function(i,e){
					new NiceCountryInput(e).init();
				});
			});		
			 jQuery('.ShowDesk-display').click(function(){
				jQuery('.login-form').toggle();  
			  });	
			  
			//Footer Menu active js
				$(function() {
					$('.FooterWrapper li').click(function() {
						$('.FooterWrapper li.active').removeClass('active');
						$(this).addClass('active');
					});
				});
				
				$(document).ready(function () {
					var url = window.location;
					$('.FooterWrapper ul li a[href="' + url + '"]').parent().addClass('active');
					$('.FooterWrapper ul li a').filter(function () {
						return this.href == url;
					}).parent().addClass('active');
				});


				
		</script>
	</body>
</html>