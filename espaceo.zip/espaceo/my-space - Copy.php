<?php include('header.php');?>
	<!-- Being: my space box -->
<article class="mySpaceBox">
	<div class="container">
		<nav class="nav nav-tab">
			<ul>
				<li class="active"><a href="#Mon_Compte" data-toggle="tab">Mon Compte</a></li>
				<li><a href="#Web_Mail" data-toggle="tab">Web Mail</a></li>
				<li><a href="#Mon_Agenda" data-toggle="tab">Mon Agenda</a></li>
				<li><a href="#Mes_Documents" data-toggle="tab">Mes Documents</a></li>
				<li><a href="#Formation" data-toggle="tab">Formation</a></li>				<li><a href="#myspaceParametres" data-toggle="tab">Paramètres</a></li>
			</ul>
		</nav>
		<div class="tab-content">
			<div id="Mon_Compte" class="item tab-pane fade in active">
				<div class="row">
					<?php include('my-space-compte.php');?>
				</div>
			</div>
			<div id="Web_Mail" class="item tab-pane fade">
				<div class="row">
					<?php include('my-space-mail.php');?>
				</div>
			</div>
			<div id="Mon_Agenda" class="item tab-pane fade">
				<div class="row">
					<?php include('my-space-agenda.php');?>
				</div>
			</div>
			<div id="Mes_Documents" class="item tab-pane fade">
				<div class="row">
					<?php include('my-space-documents.php');?>
				</div>
			</div>
			<div id="Formation" class="item tab-pane fade">
				<div class="row">
					<?php include('my-space-formation.php');?>
				</div>
			</div>			<div id="myspaceParametres" class="item tab-pane fade">				<div class="row">					<?php include('my-space-parametres.php');?>				</div>			</div>
		</div>
	</div>
</article>
<?php include('footer.php');?>