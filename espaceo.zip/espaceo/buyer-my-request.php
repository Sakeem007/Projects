<?php include('header4.php');?>
<div class="SellerMyOffers">
	<div class="container">	
		<div class="tab-content">	
			<div class="row">
				<!--<div class="banners" style="background-image: url(images/searvhBannerbg.jpg);">
					<h2>Chercher un bien <span>(Maison & Appartement)</span></h2>
					<h5>Je veux consulter l'offre 
					<select>
						<option>Vente</option>
						<option>Location</option>
					</select> pour les  
					<select data-placeholder="ville,code postal" multiple="" name="address[]" class="select select2-hidden-accessible" tabindex="-1" aria-hidden="true">
						<option value="">Maisons / Appartements / Terrains </option>
					</select>  avec un rayon de  
					<input type="text" name="distance" placeholder="Kms" id="distance" value=""> et je peux ajouter <span class="SellerMonForm">+ de criteres</span>  et en utilisant 
					<select name="image_type" class="CategorieImages">
						<option value="">l’imagerie</option>
						<option value="office">Bureau</option> 
						<option value="bedroom">Chambre</option> 
						<option value="kitchen">Cuisine</option> 
						<option value="outdoor_building">Façade immeuble</option> 
						<option value="water_view">Vue sur l'eau</option> 
						<option value="front_house">Façade maison</option> 
						<option value="backyard">Arrière-cour</option> 
						<option value="dining_area">Salle à manger</option> 
						<option value="bathroom">Salle de bains</option> 
						<option value="living_room">Salon</option> 
						<option value="mountain_view">Vue sur la montagne</option> 
						<option value="foyer_entrance">Entrée_du_foyer</option> 
						<option value="gym">Gym</option> 
						<option value="garage">Garage</option> 
						<option value="wine_room">Cave à vin</option> 
						<option value="cinema_room">Salle de cinéma</option> 
						<option value="plan">Plan</option> 
					</select></h5>
					<a href="#" class="whiteBtn">Lancer recherche</a>
					<a href="#" class="whiteBtn">Lancer recherche et creer une requete</a>
					
					<div id="seller_de_criteres_form" class="expend-form">
						<div class="maisonsFormMain_Wrapper"> 
							<a href="javascript:void();" class="SellerClose"><i class="fa fa-times" ></i></a>
							<h4>"Critère(s) supplémentaires"</h4>
							<div class="Field_Wrapper">
							  <label>Nb de pièce(s):</label>
							  <select name="pices">
								<option value=""></option>
								<option value="1">1</option>
								<option value="2">2</option>
								<option value="3">3</option>
								<option value="4">4</option>
								<option value="5">5</option>
								<option value="6">6</option>
								<option value="7">7</option>
								<option value="8">8</option>
								<option value="9">9</option>
								<option value="10">10</option>
								<option value="11">11</option>
								<option value="12">12</option>
								<option value="13">13</option>
								<option value="14">14</option>
								<option value="15">15</option>
							  </select>
							  <span>ou entre</span>
							  <select name="pices_min">
								<option value=""></option>
								<option value="1">1</option>
								<option value="2">2</option>
								<option value="3">3</option>
								<option value="4">4</option>
								<option value="5">5</option>
								<option value="6">6</option>
								<option value="7">7</option>
								<option value="8">8</option>
								<option value="9">9</option>
								<option value="10">10</option>
								<option value="11">11</option>
								<option value="12">12</option>
								<option value="13">13</option>
								<option value="14">14</option>
								<option value="15">15</option>
							  </select>
							  <span>et</span>
							  <select name="pices_max">
								<option value=""></option>
								<option value="1">1</option>
								<option value="2">2</option>
								<option value="3">3</option>
								<option value="4">4</option>
								<option value="5">5</option>
								<option value="6">6</option>
								<option value="7">7</option>
								<option value="8">8</option>
								<option value="9">9</option>
								<option value="10">10</option>
								<option value="11">11</option>
								<option value="12">12</option>
								<option value="13">13</option>
								<option value="14">14</option>
								<option value="15">15</option>
							  </select>
							</div>
							<div class="clearfix"></div>
							<div class="Field_Wrapper">
							  <label>Surface habitable:</label>
							  <input type="text" name="surface" value="">
							  <span>ou entre</span>
							  <input type="text" name="surface_min" value="">
							  <span>et</span>
							  <input type="text" name="surface_max" value="">
							</div>
							<div class="clearfix"></div>
							<div class="Field_Wrapper">
							  <label>Surface du terrain:</label>
							  <input type="text" name="surface_land" value="">
							  <span>ou entre</span>
							  <input type="text" name="surface_land_min" value="">
							  <span>et</span>
							  <input type="text" name="surface_land_max" value="">
							</div>
							<div class="clearfix"></div>
							<div class="Field_Wrapper">
							  <label>Nb de chambre(s):</label>
							  <select name="nbchambres">
								<option value=""></option>
								<option value="1">1</option>
								<option value="2">2</option>
								<option value="3">3</option>
								<option value="4">4</option>
								<option value="5">5</option>
								<option value="6">6</option>
								<option value="7">7</option>
								<option value="8">8</option>
								<option value="9">9</option>
								<option value="10">10</option>
								<option value="11">11</option>
								<option value="12">12</option>
								<option value="13">13</option>
								<option value="14">14</option>
								<option value="15">15</option>
							  </select>
							  <span>ou entre</span>
							  <select name="nbchambres_min">
								<option value=""></option>
								<option value="1">1</option>
								<option value="2">2</option>
								<option value="3">3</option>
								<option value="4">4</option>
								<option value="5">5</option>
								<option value="6">6</option>
								<option value="7">7</option>
								<option value="8">8</option>
								<option value="9">9</option>
								<option value="10">10</option>
								<option value="11">11</option>
								<option value="12">12</option>
								<option value="13">13</option>
								<option value="14">14</option>
								<option value="15">15</option>
							  </select>
							  <span>et</span>
							  <select name="nbchambres_max">
								<option value=""></option>
								<option value="1">1</option>
								<option value="2">2</option>
								<option value="3">3</option>
								<option value="4">4</option>
								<option value="5">5</option>
								<option value="6">6</option>
								<option value="7">7</option>
								<option value="8">8</option>
								<option value="9">9</option>
								<option value="10">10</option>
								<option value="11">11</option>
								<option value="12">12</option>
								<option value="13">13</option>
								<option value="14">14</option>
								<option value="15">15</option>
							  </select>
							</div>
							<div class="clearfix"></div>
							<div class="Field_Wrapper">
							  <label>Nb de SDB:</label>
							  <input type="text" name="bathroom" value="">
							  <span>ou entre</span>
							  <input type="text" name="bathroom_min" value="">
							  <span>et</span>
							  <input type="text" name="bathroom_max" value="">
							</div>
							<div class="clearfix"></div>
							<div class="Field_Wrapper last">
							  <label>Prix de vente:</label>
							  <span>entre </span>
							  <input type="text" name="price_min" value="">
							  <b>€</b> <span>et</span>
							  <input type="text" name="price_max" value="">
							  <b>€</b> </div>
							<div class="clearfix"></div>
							<div class="Valider_Box">
							  <input type="submit" class="whiteBtn" value="Valider">
							  <a class="resetlast" href=""></a></div>
							<div class="clearfix"></div>
						</div>
					</div>
				</div>
				<div class="filter">
					<form action="#" method="post">
						<ul>
							<li>Filtre :</li>
							<li><select>
								<option>En-ligne/Expirees</option>
								<option>En-ligne/Expirees</option>
								<option>En-ligne/Expirees</option>
							</select></li>
							<li><select>
								<option>Date de parution</option>
								<option>Date de parution</option>
								<option>Date de parution</option>
							</select></li>
							<li><select>
								<option>PRO/PAP</option>
								<option>PRO/PAP</option>
								<option>PRO/PAP</option>
							</select></li>
							<li>
								<select>
									<option>Par agence</option>
								</select>
							</li>
							<li>
								<select>
									<option>Tri par prix</option>
									<option>Tri par prix</option>
									<option>Tri par prix</option>
								</select>
							</li>
							<li>
								<select name="announcer">
									<option value="">Tri annonceurs</option>
									<option value="all">Tous</option>
									<option value="leboncoin">LBC</option>
									<option value="seloger">Seloger</option>
									<option value="logicimmo">Logicimmo</option>
								</select>
							</li>
							<li>
								<select name="rankimo">
									<option value="">Tri Rankimo</option>
									<option value="1">N°1</option>
									<option value="5">5 premiers</option>
									<option value="10">10 premiers</option>
									<option value="20">20 premiers</option>
								</select>
							</li>
							<li>
								<select name="orderbydate">
									<option value="">Neuf/Ancien</option>
									<option value="desc">Neuf</option>
									<option value="asc">Ancien</option>
								</select>
							</li>
							<li>
								<select name="chassimo">
									<option value="">Chassimo</option>
									<option value="vert">Vert</option>
									<option value="rouge">Rouge</option>
								</select>
							</li>
							<li>
								<select name="chassimo_user"><option value="">Chassimo team</option>			
									<option value="1">Philippe Soulié</option>
									<option value="5">Philippe Soulié</option>
									<option value="6">Philippe Soulié</option>
									<option value="10"> Clément</option>
									<option value="16">BONNET Alex</option>
									<option value="18">KINCHE Stéphanie</option>
									<option value="19">GROSJEAN Laurence</option>
									<option value="23">ROL Sébastien</option>
								</select>
							</li>
							<li class="btns">
								<button class="submit" type="submit"></button>            
							</li>
							<li class="btns">
								<a class="resetlast" href="javascript:void(0)"></a> 
							</li>
						</ul>
					</form>
				</div>-->
				<div id="SellreMySpace">
					<div class="offrimoBox">
						<div class="SellerNewOffer">
							<a href="javascript:void(0)" data-toggle="modal" data-target="#BuyerMyRequest"><i class="fa fa-plus-circle"></i> Nouvelle Demande</a>
						</div>
						<div class="repter">
							<div class="tablebox">
								<div class="box">
									<div class="headerTop">Besoins</div>
									<div class="contents MyCriteria">
										<div class="MyCriteriaLeft">
											<h4>Primaires</h4>							
											<ul>
												<li>Type: <span>Maison</span></li>
												<li>Surface: <span>à <b>m²</b></span></li>
												<li>Entre: <span>et <b>Chambres</b></span></li>
												<li>Terrain: <span>à <b>m²</b></span></li>
												<li>Prix: <span>500 000 <b>€</b></span></li>
											</ul>
										</div>
										<div class="MyCriteriaRight">						
											<h4>Secondaires</h4>							
											<ul>
												<li>Type: <span>Tous</span></li>
												<li>Les plus: <span>Garage</span></li>
												<li>Environnement: <span>Calme</span></li>
												<li>Style: <span>Moderne</span></li>
												<li>Etat général: <span>Rien à faire</span></li>
											</ul>
										</div>
									</div>
								</div>
								<div class="box">
									<div class="headerTop">Secteurs</div>
									<div class="contents">
										<p><strong>Lieux:</strong>
											74140 (Toutes les communes),<br> 74380 Cranves-Sales,<br> 74890 Bons-en-Chablais
										</p>
										<div class="ReferentsTbs"><b>Référents:</b> <a href="javascript:void(0)">Adresse</a><br><a href="javascript:void(0)">Santé</a><a href="javascript:void(0)">Education</a><a href="javascript:void(0)">Transports</a>
										</div>
									</div>
								</div>
								<div class="box">
									<div class="headerTop">Matchimo</div>
									<div class="MatchimoBox">
										<ul>
											<li>Offres +/- Comparables ( 67 ) <a href="javascript:void(0)">Voir</a></li>
											<li>Offres Comparables ( 15 )  <a href="javascript:void(0)">Voir</a></li>
											<li>Correspondance max 82% <a href="javascript:void(0)">Voir</a></li>
											<li>Synthèse Cohérence <a href="javascript:void(0)">Voir détails</a></li>
										</ul>	
									</div>
								</div>
								<div class="box">
									<div class="headerTop">Action</div>
									<div class="SellerAction">
										<ul>
											<li><a href="javascript:void(0)">Simuler <i class="fa fa-eye"></i></a></li>
											<li><a href="javascript:void(0)">Modifier <i class="fa fa-edit"></i></a></li>
											<li><a href="javascript:void(0)">Effacer <i class="fa fa-trash"></i></a></li>
										</ul>
									</div>
								</div>			
							</div>
						</div>
						<div class="repter">
							<div class="tablebox">
								<div class="box">
									<div class="headerTop">Besoins</div>
									<div class="contents MyCriteria">
										<div class="MyCriteriaLeft">
											<h4>Primaires</h4>							
											<ul>
												<li>Type: <span>Maison</span></li>
												<li>Surface: <span>à <b>m²</b></span></li>
												<li>Entre: <span>et <b>Chambres</b></span></li>
												<li>Terrain: <span>à <b>m²</b></span></li>
												<li>Prix: <span>500 000 <b>€</b></span></li>
											</ul>
										</div>
										<div class="MyCriteriaRight">						
											<h4>Secondaires</h4>							
											<ul>
												<li>Type: <span>Tous</span></li>
												<li>Les plus: <span>Garage</span></li>
												<li>Environnement: <span>Calme</span></li>
												<li>Style: <span>Moderne</span></li>
												<li>Etat général: <span>Rien à faire</span></li>
											</ul>
										</div>
									</div>
								</div>
								<div class="box">
									<div class="headerTop">Secteurs</div>
									<div class="contents">
										<p><strong>Lieux:</strong>
											74140 (Toutes les communes),<br> 74380 Cranves-Sales,<br> 74890 Bons-en-Chablais
										</p>
										<div class="ReferentsTbs"><b>Référents:</b> <a href="javascript:void(0)">Adresse</a><br><a href="javascript:void(0)">Santé</a><a href="javascript:void(0)">Education</a><a href="javascript:void(0)">Transports</a>
										</div>
									</div>
								</div>
								<div class="box">
									<div class="headerTop">Matchimo</div>
									<div class="MatchimoBox">
										<ul>
											<li>Offres +/- Comparables ( 67 ) <a href="javascript:void(0)">Voir</a></li>
											<li>Offres Comparables ( 15 )  <a href="javascript:void(0)">Voir</a></li>
											<li>Correspondance max 82% <a href="javascript:void(0)">Voir</a></li>
											<li>Synthèse Cohérence <a href="javascript:void(0)">Voir détails</a></li>
										</ul>	
									</div>
								</div>
								<div class="box">
									<div class="headerTop">Action</div>
									<div class="SellerAction">
										<ul>
											<li><a href="javascript:void(0)">Simuler <i class="fa fa-eye"></i></a></li>
											<li><a href="javascript:void(0)">Modifier <i class="fa fa-edit"></i></a></li>
											<li><a href="javascript:void(0)">Effacer <i class="fa fa-trash"></i></a></li>
										</ul>
									</div>
								</div>			
							</div>
						</div>
					</div>	
				</div>
			</div>
		</div>
	</div>
</div>

<?php include('footer.php');?>

