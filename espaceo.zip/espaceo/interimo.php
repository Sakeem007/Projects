<?php include('header.php');?>
	
	<!-- Being: my space box -->
	<article class="InterimoMainWrapper">
		<div class="container">			
			
			<nav class="nav nav-tab">
				<ul>
					<li class="active"><a href="#interimoMesPartenaires" data-toggle="tab">Mes Partenaires</a></li>
					<li><a href="#interimoInerOffrimo" data-toggle="tab">Inter-Offrimo</a></li>
					<li><a href="#interimoSuiviInerimo" data-toggle="tab">Suivi Interimo</a></li>
				</ul>
			</nav>
			<div class="tab-content">
				<div id="interimoMesPartenaires" class="item tab-pane fade in active">
					<div class="row">
						<?php include('mes-partenaires.php');?>
					</div>
				</div>
				<div id="interimoInerOffrimo" class="item tab-pane fade">
					<div class="row">
						<?php include('inter-offrimo.php');?>
					</div>
				</div>
				<div id="interimoSuiviInerimo" class="item tab-pane fade">
					<div class="row">
						<?php include('interimo-suivi-snerimo.php');?>
					</div>
				</div>				
			</div>
			
		</div>
	</article>

<?php include('footer.php');?>

<?php include('modal.php');?>