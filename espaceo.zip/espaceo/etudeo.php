<!-- Being: Etudeo box -->
<article class="evalueoBox">
	<nav class="nav nav-tab">
		<ul>
			<li class="active"><a href="#etudeo-transaction" data-toggle="tab">Etudeo Transaction</a></li>
			<li><a href="#EtudeoNeuf" data-toggle="tab">Etudeo Neuf</a></li>
		</ul>
	</nav>
	<div class="tab-content">
		<div id="etudeo-transaction" class="item tab-pane fade in active">
			<nav class="nav nav-tab arrow">
				<ul>
					<li class="active"><a href="#Etudeo" data-toggle="tab">Etudeo</a></li>				
					<li><a href="#Etudeo_Evaluations" data-toggle="tab"> Etudeo sauvegardées</a></li>
				</ul>
			</nav>
			<div class="tab-content">
				<div id="Etudeo" class="item tab-pane fade in active">
					<div class="row">
						<?php include('etudeo-report.php');?>
					</div>
				</div>
				<div id="Etudeo_Evaluations" class="item tab-pane fade">
					<div class="row">
						<?php include('etudeo-sauvegardées.php');?>
					</div>
				</div>				
			</div>
		</div>
		<div id="EtudeoNeuf" class="item tab-pane fade">
			<div class="row">
				<?php include('etudeo-neuf.php');?>
			</div>
		</div>
	</div>
</article>
<!-- End: offrimo box -->