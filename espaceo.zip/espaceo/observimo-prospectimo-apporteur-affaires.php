<div class="banners" style="background-image: url(images/research-motor-img.png); background-position:bottom;">
	<div class="Banners_TxT">
		<h5>" Je peux suivre mes apporteurs d'affaires et leurs indications sur mon<br />
				<select>
				<option>Secteur</option>   
				<option>Secteur1</option>
				<option>Secteur2</option>
			</select>
			mais aussi par <select>
				<option>Type de biens indiqués</option>   
				<option>item1</option>
				<option>item2</option>
			</select><br />
			par <input type="text" placeholder="Code postal, ville, adresse" name=""> 
			et avec l'option<select>
				<option>Equipe</option>   
				<option>Equipe1</option>
				<option>Equipe2</option>
			</select>
		</h5> 
	</div>
</div>										
<div class="prospectimo_filter_box p-filter-box">
		<div class="filter">
		  <form class="filter_form" action="#" method="post">
			<ul>
			  <li>Filtre :</li>
			  <li>
				<input class="first_intp" name="" placeholder="Apporteur de A à Z" type="text">
			  </li>
			  <li>
				<input class="first_intp" name="" placeholder="Par nom d'Apporteur" type="text">
			  </li>
			  <li>
				<select name="">
				  <option>Date de l'indication</option>
				  <option>-48h</option>
				  <option>-7jrs</option>
				  <option>-15jrs</option>
				  <option>+15jrs</option>
				</select>
			  </li>
			  <li>
				<select name="">
				  <option>Dernière</option>
					<option>24h</option>
					<option>48h</option>
					<option>-7jrs</option>
					<option>+7jrs</option>
				</select>
			  </li>
			  <li>
				<select name="">
				  <option>Statut dernière</option>
				  <option>NRP</option>
				  <option>A rappeler</option>
				  <option>Contact</option>
				  <option>RDV Estimation</option>
				  <option>RDV Mandat</option>
				</select>
			  </li>
			  <li>				
				<input name="" placeholder="Mots clefs" type="text">
			  </li>			 
			  <li class="btns"><button class="submit" type="submit"></button></li>            
            <li class="btns"><a class="resetlast" href="#"></a></li>
			</ul>
		  </form>
		</div>
	</div>	
	<div class="prospectimo_Data_wrapper Reporting_Bals">
     	<div class="Ajouter_Popuo_Box"><a href="#apporteur-Ajouter-List" data-toggle="modal" data-backdrop="true"><i class="fa fa-plus-square"></i> Ajouter une indication</a></div>
		<div class="col-md-12 col-sm-12 col-xs-12 majbals-container">
				<div class="majbals-box-1">
				<div class="col-xs-12 majbals-val">
					<ul>
						<li><a href="#maison-box" data-toggle="modal" data-backdrop="true"><i class="fa fa-eye"></i> Voir</a>
						</li>
						<li><a><i class="green-btn fa fa-circle"></i> Active</a>
						</li>
					</ul>
				</div>
					<div class="col-xs-12 Prospectimo_majbal">
						<div id="maison5pieces" class="carousel slide" data-ride="carousel">
							<!-- Wrapper for slides -->
							<div class="carousel-inner">
								<div class="carousel-caption">Maison 4Pièces
									<br><i class="fa fa-map-marker"></i> 41 aveue du lac
									<br>Indiquée par Philippe Soulié le 15/08/18
								</div>
								<div class="date_BoX"><span>15/08/18</span></div>
								<div class="item active" style="background:url(images/offrimo1.png)"></div>
								<div class="item" style="background:url(images/offrimo2.png)"></div>
							</div>
							<!-- Left and right controls -->
							<a class="left carousel-control" href="#maison5pieces" data-slide="prev"> <span class="glyphicon glyphicon-chevron-left"></span>  <span class="sr-only">Previous</span> 
							</a>
							<a class="right carousel-control" href="#maison5pieces" data-slide="next"> <span class="glyphicon glyphicon-chevron-right"></span>  <span class="sr-only">Next</span> 
							</a>
						</div>
					</div>
					<div class="col-xs-12 maison-bottom-list">
						<ul>
							<li><a href="#">Identifier </a>
							</li>
							<li><a href="#">Infos</a>
							</li>
							<li><a href="#">Découvrimo</a>
							</li>
							<li><a href="#">Potentiel</a>
							</li>
							<!--<li><a href="#" data-toggle="modal" data-target="#maison-box-Suivi">Suivi</a></li>-->
						</ul>
					</div>
				</div>
				<div class="majbals-box-1">
				<div class="col-xs-12 majbals-val">
					<ul>
						<li><a href="#maison-box" data-toggle="modal"  data-backdrop="true"><i class="fa fa-eye"></i> Voir</a>
						</li>
						<li><a><i class=" fa fa-circle"></i> Active</a>
						</li>
					</ul>
				</div>
					<div class="Inbox_Box">
                    <div class="Inbox_pik_Box">
						<img src="images/mailbox-full.png" class="img-responsive center-block" alt="mailbox" />		<div class="Inbox_Box_caption">Maison 3Pièces
                            <br><i class="fa fa-map-marker"></i> 2 aveue du lac
                            <br>Indiquée par Philippe Soulié le 5/08/18
                        </div>                        
                        </div>                       
					</div>                    
					<div class="col-xs-12 maison-bottom-list">
						<ul>
							<li><a href="#">Identifier </a>
							</li>
							<li><a href="#">Infos</a>
							</li>
							<li><a href="#">Découvrimo</a>
							</li>
							<li><a href="#">Potentiel</a>
							</li>
							<!--<li><a href="#" data-toggle="modal" data-target="#maison-box-Suivi">Suivi</a></li>-->
						</ul>
					</div>
				</div>
				
                <div class="majbals-box-1">
				<div class="col-xs-12 majbals-val">
					<ul>
						<li><a href="#maison-box" data-toggle="modal"  data-backdrop="true"><i class="fa fa-eye"></i> Voir</a>
						</li>
						<li><a><i class=" fa fa-circle"></i> Active</a>
						</li>
					</ul>
				</div>
					<div class="col-xs-12 Prospectimo_majbal">
						<div id="maison6pieces" class="carousel slide" data-ride="carousel">
							<!-- Wrapper for slides -->
							<div class="carousel-inner">
								<div class="carousel-caption">Maison 4Pièces
									<br><i class="fa fa-map-marker"></i> 41 aveue du lac
									<br>Indiquée par Philippe Soulié le 15/08/18</div>
							<div class="date_BoX"><span>15/08/18</span></div>
								<div class="item active" style="background:url(images/pic1.jpg)"></div>
								<div class="item" style="background:url(images/pic4.png)"></div>
							</div>
							<!-- Left and right controls -->
							<a class="left carousel-control" href="#maison6pieces" data-slide="prev"> <span class="glyphicon glyphicon-chevron-left"></span>  <span class="sr-only">Previous</span> 
							</a>
							<a class="right carousel-control" href="#maison6pieces" data-slide="next"> <span class="glyphicon glyphicon-chevron-right"></span>  <span class="sr-only">Next</span> 
							</a>
						</div>
					</div>
					<div class="col-xs-12 maison-bottom-list">
						<ul>
							<li><a href="#">Identifier </a>
							</li>
							<li><a href="#">Infos</a>
							</li>
							<li><a href="#">Découvrimo</a>
							</li>
							<li><a href="#">Potentiel</a>
							</li>
							<!--<li><a href="#" data-toggle="modal" data-target="#maison-box-Suivi">Suivi</a></li>-->
						</ul>
					</div>
				</div>
                <div class="majbals-box-1">
				<div class="col-xs-12 majbals-val">
					<ul>
						<li><a href="#maison-box" data-toggle="modal" data-backdrop="true"><i class="fa fa-eye"></i> Voir</a>
						</li>
						<li><a><i class="green-btn fa fa-circle"></i> Active</a>
						</li>
					</ul>
				</div>
					<div class="Inbox_Box">
                    <div class="Inbox_pik_Box">
						<img src="images/mailbox-full.png" class="img-responsive center-block" alt="mailbox" />
                        
								<div class="Inbox_Box_caption">Maison 3Pièces
									<br><i class="fa fa-map-marker"></i> 2 aveue du lac
									<br>Indiquée par Philippe Soulié le 5/08/18
                                 </div>
                        </div>                       
					</div>                    
					<div class="col-xs-12 maison-bottom-list">
						<ul>
							<li><a href="#">Identifier </a>
							</li>
							<li><a href="#">Infos</a>
							</li>
							<li><a href="#">Découvrimo</a>
							</li>
							<li><a href="#">Potentiel</a>
							</li>
							<!--<li><a href="#" data-toggle="modal" data-target="#maison-box-Suivi">Suivi</a></li>-->
						</ul>
					</div>
				</div>
                
                <div class="majbals-box-1">
				<div class="col-xs-12 majbals-val">
					<ul>
						<li><a href="#maison-box" data-toggle="modal"  data-backdrop="true"><i class="fa fa-eye"></i> Voir</a>
						</li>
						<li><a><i class=" fa fa-circle"></i> Active</a>
						</li>
					</ul>
				</div>
					<div class="col-xs-12 Prospectimo_majbal">
						<div id="maison9pieces" class="carousel slide" data-ride="carousel">
							<!-- Wrapper for slides -->
							<div class="carousel-inner">
								<div class="carousel-caption">Maison 4Pièces
									<br><i class="fa fa-map-marker"></i> 41 aveue du lac
									<br>Indiquée par Philippe Soulié le 15/08/18
								</div>
								<div class="date_BoX"><span>15/08/18</span></div>
								<div class="item active" style="background:url(images/pic1.jpg)"></div>
								<div class="item" style="background:url(images/pic4.png)"></div>
							</div>
							<!-- Left and right controls -->
							<a class="left carousel-control" href="#maison9pieces" data-slide="prev"> <span class="glyphicon glyphicon-chevron-left"></span>  <span class="sr-only">Previous</span> 
							</a>
							<a class="right carousel-control" href="#maison9pieces" data-slide="next"> <span class="glyphicon glyphicon-chevron-right"></span>  <span class="sr-only">Next</span> 
							</a>
						</div>
					</div>
					<div class="col-xs-12 maison-bottom-list">
						<ul>
							<li><a href="#">Identifier </a>
							</li>
							<li><a href="#">Infos</a>
							</li>
							<li><a href="#">Découvrimo</a>
							</li>
							<li><a href="#">Potentiel</a>
							</li>
							<!--<li><a href="#" data-toggle="modal" data-target="#maison-box-Suivi">Suivi</a></li>-->
						</ul>
					</div>
				</div>
                <div class="majbals-box-1">
				<div class="col-xs-12 majbals-val">
					<ul>
						<li><a href="#maison-box" data-toggle="modal" data-backdrop="true"><i class="fa fa-eye"></i> Voir</a>
						</li>
						<li><a><i class="green-btn fa fa-circle"></i> Active</a>
						</li>
					</ul>
				</div>
					<div class="Inbox_Box">
                    <div class="Inbox_pik_Box">
						<img src="images/mailbox-full.png" class="img-responsive center-block" alt="mailbox" />
							<div class="Inbox_Box_caption">Maison 3Pièces
								<br><i class="fa fa-map-marker"></i> 2 aveue du lac
								<br>Indiquée par Philippe Soulié le 5/08/18
							 </div>
                        </div>                       
					</div>                    
					<div class="col-xs-12 maison-bottom-list">
						<ul>
							<li><a href="#">Identifier </a>
							</li>
							<li><a href="#">Infos</a>
							</li>
							<li><a href="#">Découvrimo</a>
							</li>
							<li><a href="#">Potentiel</a>
							</li>
							<!--<li><a href="#" data-toggle="modal" data-target="#maison-box-Suivi">Suivi</a></li>-->
						</ul>
					</div>
				</div>
                <div class="majbals-box-1">
				<div class="col-xs-12 majbals-val">
					<ul>
						<li><a href="#maison-box" data-toggle="modal"  data-backdrop="true"><i class="fa fa-eye"></i> Voir</a>
						</li>
						<li><a><i class=" fa fa-circle"></i> Active</a>
						</li>
					</ul>
				</div>
					<div class="col-xs-12 Prospectimo_majbal">
						<div id="maison11pieces" class="carousel slide" data-ride="carousel">
							<!-- Wrapper for slides -->
							<div class="carousel-inner">
								<div class="carousel-caption">Maison 4Pièces
									<br><i class="fa fa-map-marker"></i> 41 aveue du lac
									<br>Indiquée par Philippe Soulié le 15/08/18
								</div>
								<div class="date_BoX"><span>15/08/18</span></div>
								<div class="item active" style="background:url(images/pic1.jpg)"></div>
								<div class="item" style="background:url(images/pic4.png)"></div>
							</div>
							<!-- Left and right controls -->
							<a class="left carousel-control" href="#maison11pieces" data-slide="prev"> <span class="glyphicon glyphicon-chevron-left"></span>  <span class="sr-only">Previous</span> 
							</a>
							<a class="right carousel-control" href="#maison11pieces" data-slide="next"> <span class="glyphicon glyphicon-chevron-right"></span>  <span class="sr-only">Next</span> 
							</a>
						</div>
					</div>
					<div class="col-xs-12 maison-bottom-list">
						<ul>
							<li><a href="#">Identifier </a>
							</li>
							<li><a href="#">Infos</a>
							</li>
							<li><a href="#">Découvrimo</a>
							</li>
							<li><a href="#">Potentiel</a>
							</li>
							<!--<li><a href="#" data-toggle="modal" data-target="#maison-box-Suivi">Suivi</a></li>-->
						</ul>
					</div>
				</div>
                <div class="majbals-box-1">
				<div class="col-xs-12 majbals-val">
					<ul>
						<li><a href="#maison-box" data-toggle="modal" data-backdrop="true"><i class="fa fa-eye"></i> Voir</a>
						</li>
						<li><a><i class="green-btn fa fa-circle"></i> Active</a>
						</li>
					</ul>
				</div>
					<div class="Inbox_Box">
                    <div class="Inbox_pik_Box">
						<img src="images/mailbox-full.png" class="img-responsive center-block" alt="mailbox" />
							<div class="Inbox_Box_caption">Maison 3Pièces
								<br><i class="fa fa-map-marker"></i> 2 aveue du lac
								<br>Indiquée par Philippe Soulié le 5/08/18
							 </div>
                        </div>                       
					</div>                    
					<div class="col-xs-12 maison-bottom-list">
						<ul>
							<li><a href="#">Identifier </a>
							</li>
							<li><a href="#">Infos</a>
							</li>
							<li><a href="#">Découvrimo</a>
							</li>
							<li><a href="#">Potentiel</a>
							</li>
							<!--<li><a href="#" data-toggle="modal" data-target="#maison-box-Suivi">Suivi</a></li>-->
						</ul>
					</div>
				</div>
		</div>
	</div>