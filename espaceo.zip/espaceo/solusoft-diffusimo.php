<div class="banners" style="background-image: url(images/research-motor-img.png);">
	<div class="Banners_TxT">	
		<h2>Coming Soon !</h2>
		<h5>
		<p>"Bientôt votre Logiciel Transaction 2.0"</p>
	</div>
</div>
<div class="offrimo">
	<!--<div class="filter diffusimo">
		<form action="#" method="post">
			<ul>
				<li>Filtre :</li>
				<li>
					<select>
						<option>par support</option>
					</select>
				</li>
				<li>
					<input type="date" placeholder="Date parution" />
				</li>
				<li>
					<select>
						<option>Trie par prix</option>
					</select>
				</li>
				<li>
					<select>
						<option>Par agent</option>
					</select>
				</li>
				<li>
					<input type="text" />
				</li>
				<li class="btns">
					<button class="submit" type="submit"></button>            
				</li>
				<li class="btns">
					<a class="resetlast" href="#"></a> 
				</li>
			</ul>
		</form>
	</div>-->
	<div class="CominngSoonBox"><img src="images/cominng_soon.jpg" /></div>
	
</div>