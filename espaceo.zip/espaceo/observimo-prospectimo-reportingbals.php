<div class="banners" style="background-image: url(images/research-motor-img.png); background-position:bottom;">
	<div class="Banners_TxT">
		<h5>"Je peux consulter le reporting BALs sur mon territoire <br />avec 
				<select>
				<option hidden>l'option equipe</option>   
				<option>Team member1</option>
				<option>Team member2</option>
			</select> "
		</h5> 
	</div>	
</div>
<div class="Reporting_Bals_wrapper">
		<div class="col-md-12 col-sm-12 col-xs-12 majbals-container">
			<div class="Reporting_Box">
				<div class="Reporting_top_txt">
					<p><span>Mon Territoire</span></p>
				</div>
				<div class="Inbox_Box">
				<div class="Inbox_pik_Box">
					<img src="images/mailbox-full.png" class="img-responsive center-block" alt="mailbox" />		
						<div class="Reporting_bottom_section">
							<ul>      
								<li><label>Total:</label> <span>3000</span> BALs</li>
								<li><label>Secteur secondaire:</label> <span>1500</span> BALs</li>
								<li><label>Secteur prioritaire:</label> <span>1000</span> BALs</li>
							</ul>
						</div>                      
					</div>                       
				</div>    
			</div>
			<div class="Reporting_Box">
				<div class="Reporting_top_txt">
					<p><span>BAL activées</span></p>
					<ul>      
						<li><a href="#">Territoire</a></li>
						<li><a href="#">SS</a></li>
						<li><a href="#">SP</a></li>
						<div class="clr"></div>
					</ul>
				</div>
				<div class="Inbox_Box">
				<div class="Inbox_pik_Box">
					<img src="images/mailbox-full.png" class="img-responsive center-block" alt="mailbox" />		
						<div class="Reporting_bottom_section">
							<ul>      
								<li>BALs activées sur Secteur Secondaire</li>
								<li class="totle_Box"><span>104</span></li>
								<li>(soit 8% des BALs du Secteur Secondaire)</li>
							</ul>
						</div>                      
					</div>                       
				</div>    
			</div>
			<div class="Reporting_Box">
				<div class="Reporting_top_txt">
					<ul class="Potentiel_Wp">      
						<li><a href="#">Potentiel BALs</a></li>
						<li>
							<select>
								<option>provide choice:</option>   
								<option>Vente</option>
								<option>Location</option>
								<option>Gestion locative</option>
								<option>Division parcellaire</option>
								<option>Promotion</option>
								<option>Apporteur d’affaires</option>
							</select> </li>
						<div class="clr"></div>
					</ul>
					<ul>      
						<li><a href="#">Territoire</a></li>
						<li><a href="#">SS</a></li>
						<li><a href="#">SP</a></li>
						<div class="clr"></div>
					</ul>
				</div>
				<div class="Inbox_Box">
				<div class="Inbox_pik_Box">
					<img src="images/mailbox-full.png" class="img-responsive center-block" alt="mailbox" />		
						<div class="Reporting_bottom_section">
							<ul>      
								<li>BALs en vente sur mon territoire</li>
								<li class="totle_Box"><span>21</span></li>
								<li>Soit 1% des BALs du territoire</li>
							</ul>
						</div>                      
					</div>                       
				</div>    
			</div>
		</div>
		<div class="Reporting_Bals_bottom_wrapper">
			<form action="" method="get">
			<p>J'ai <input type="text" name="">  BALs à suivre sur mon <span>SP</span></p>
			<p>Le mois dernier j'ai activé<input type="text" name="">BALs soit depuis le début de mon activité une moyenne de<input type="text" name="">BALs activées par mois.</p>
			<p>Le mois dernier j'ai eu <input type="text" name=""><em>BALs en 
			<select>
				<option>RDVs</option>
				<option>RDV Remise estimation vente</option>   
				<option>RDV Remise estimation location</option>
				<option>RDV signature mandat de vente</option>
				<option>RDV signature mandat de vente</option>
				<option>RDV signature mandat de gestion</option>
				<option>RDV signature mandat de location</option>
				<option>RDV signature contrat apporteur affaires</option>
				<option>RDV projet division</option>
				<option>RDV projet promotion</option>
			</select> 
			soit depuis le début de mon activité une moyenne de</em><input type="text" name=""> 
			<select>
				<option>RDVs</option>
				<option>RDV Remise estimation vente</option>   
				<option>RDV Remise estimation location</option>
				<option>RDV signature mandat de vente</option>
				<option>RDV signature mandat de vente</option>
				<option>RDV signature mandat de gestion</option>
				<option>RDV signature mandat de location</option>
				<option>RDV signature contrat apporteur affaires</option>
				<option>RDV projet division</option>
				<option>RDV projet promotion</option>
			</select>  par mois.</p>
			</form>
		</div>
	</div>