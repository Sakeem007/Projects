<div class="banners" style="background-image: url(images/research-motor-img.png); background-position:bottom;">
	<div class="Banners_TxT">
		<h5>"Je veux consulter ou imprimer un document,<br /> soit par ordre
				<select>
				<option hidden>alphabétique/thème</option>   
				<option>thème1</option>
				<option>thème2</option>
			</select> "
		</h5> 
	</div>	
</div>
<div class="SpaceSearchMoter">
	<ul>
		<li>Listing des documents <span>12</span> <button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#VousPouvezImprimer"></button></li>
		<li><input type="text" /><button class="submit" type="submit"></button> <a class="resetlast" href="#"></a></li>
	</ul>
</div>
<div class="documentTab">
	<div class="MySpcDucuments">
			<table>
				<thead>
					<tr>
						<th>Intitulé des documents A-Z</th>
						<th>Documents PDF</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td>Albert</td>
						<td><a href="#" target="_blank">00780-zxdcvzxczx.pdf</a></td>
					</tr>
					<tr>
						<td>Ragahvendra</td>
						<td><a href="#" target="_blank">00780-zxdcvzxczx.pdf</a></td>
					</tr>
					<tr>
						<td>Albert</td>
						<td><a href="#" target="_blank">00780-zxdcvzxczx.pdf</a></td>
					</tr>
				</tbody>
			</table>
			<table class="IntituleDocuments">
				<thead>
					<tr>
						<th>Intitulé des documents <select>
				<option hidden>Thème</option>   
				<option>Agence</option>
				<option>Vendeur</option>
				<option>Acheteur</option>
				<option>Mandataire</option>
			</select></th>
						<th>Documents PDF</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td>Albert</td>
						<td><a href="#" target="_blank">00780-zxdcvzxczx.pdf</a></td>
					</tr>
					<tr>
						<td>Ragahvendra</td>
						<td><a href="#" target="_blank">00780-zxdcvzxczx.pdf</a></td>
					</tr>
					<tr>
						<td>Albert</td>
						<td><a href="#" target="_blank">00780-zxdcvzxczx.pdf</a></td>
					</tr>
				</tbody>
			</table>
		</div>
</div>


