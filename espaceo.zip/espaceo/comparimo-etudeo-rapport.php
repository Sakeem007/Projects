<div class="evalueo">
	<div class="container">
		<div class="row">
			<aside class="item col-xs-12 col-sm-12 col-md-12 col-lg-12">
				<div id="all-etudeo-pdf" class="repport-pdf">
					<!-- Start: page 1 -->				
					<div class="picBg">
						<div class="etudeoMain">
							<div class="etudeoText">
								<div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
									<div class="left-border">
										<h6>Votre bien:</h6>
										<span>Maison - 150m<sup>2</sup> 74140, Douvaine</span>
									</div>
								</div>
								<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
									<img src="pdf/logo1.png"/>
								</div>
								<h3></h3>
							</div>
							<div class="bottom-arrow-bg">
								<div class="left-border">
									<ul>
										<li>A la demande de : Mme et Mr Soulié</li>
										<li>Votre Home Conseiller : Mr Philippe Soulié</li>
										<li>Fait le: Lundi 01 Mai 2017</li>
									</ul>
								</div>
							</div>
						</div>					
					</div>
					<!-- End: page 1 -->
					<!-- Start: page 2 -->
					<div class="page">
						<div class="titles active">
							<span>1</span>
							Sommaire
						</div>
						<div class="sommaire">
							<h1>Sommaire</h1>
						</div>						
						<div class="titles">
							<span>1</span>
							Sommaire
						</div>
						<div class="titles">
							<span>2</span>
							Présentation de notre Agence
						</div>
						<div class="titles">
							<span>3</span>
							Notre application ETUDEO©
						</div>
						<div class="titles">
							<span>4</span>
							Tout sur votre annonce mise en ligne
						</div>
						<div class="titles">
							<span>5</span>
							Synthése de notre étude immobiliere
						</div>
						<div class="titles">
							<span>6</span>
							Les bénéﬁces de ETUDEO© et EVALUEO©
						</div>	
						<div class="sommaire">
							<div class="clear"><br><br><br></div>
							<h2>Prét pour la prochaine étape ...?</h2>
						</div>
						<!-- water mark -->
						<div class="whater-mark bottom">
							<div class="home-conseiller">
								<div class="col col-xs-12 col-sm-2 col-md-2 col-lg-2">
									<img src="pdf/limmolier.png"/>
								</div>
								<div class="col col-xs-12 col-sm-6 col-md-6 col-lg-6">
									<ul>
										<li>Votre Home Conseiller</li>
										<li>Mr.Philippe Soulie</li>
										<li>Tél : 06 50 65 68 78</li>
										<li>Email : philippe.soulie@limmobilier.net</li>
									</ul>
								</div>
								<div class="col col-xs-12 col-sm-4 col-md-4 col-lg-4">
									<ul>
										<li>Notre Réseau</li>
										<li>Tél. : 04 57 43 00 50 / 04 57 43 00 49</li>
										<li>E-mail : contact@limmobilier.net</li>
										<li>Site web : https://www.limmobilier.net</li>
										<li>Adresse : 2 Avenue du Lac 74140 Douvaine</li>
									</ul>
								</div>
							</div>
						</div>
						<!-- water mark -->
					</div>
					<!-- End: page 2 -->
					<!-- Start: page 3 -->
					<div class="page">
						<div class="titles active">
							<span>2</span>
							Présentation de notre société
						</div>
						<div class="title-blue">
							<span><span>Notre histoire</span></span>
						</div>
						<div class="paddLeft">
							<p>Depuis 1998, les fondateurs de <strong>L'IMMOBILIER</strong>, spécialisés dans les métiers de l'immobilier, ont toujours développé un esprit de qualité, d’exigence et de réussite. Ce qui guide le groupe, c’est la passion : la passion des autres, la passion de son métier, l'immobilier, avec en plus, une vision global de son activité. Cette passion c’est le ﬁl conducteur de son histoire, elle ne s’est jamais démentie, elle est le moteur pour atteindre son objectif: votre satisfaction.</p>
						</div>
						<div class="title-blue">
							<span><span>Nos valeurs</span></span>
						</div>
						<div class="paddLeft">
							<p>Notre groupe cultive avant tout l’excellence, cette démarche se traduit concretement par une recherche constante des meilleures performances, dans les métiers de l’immobilier. Notre groupe privilégie en effet, depuis sa création, les valeurs d’avant—garde, que sont la dimension humaine, la famille, la durabilité, le respect de l'environnement.</p>
							<p> << La valeur d'une entreprise est déterminée par la valeur des gens qui la compose >>.</p>
						</div>
						
						<div class="title-blue">
							<span><span>Notre savoir faire</span></span>
						</div>
						<div class="paddLeft">
							<p><strong>L'IMMOBILIER</strong> est au coeur de notre savoir faire, et plus particuliérement la vente immobiliere. Nous avons développé une application inédite appelée <strong>EVALUEO©</strong>, qui est une application capable d'analyseren temps réeltoutes les données du marché immobilier régional et local, de comparer les biens en vente, tout en tenant compte des caractéristiques de votre bien.</p>
						</div>
						<div class="title-blue">
							<span><span>Notre objectif</span></span>
						</div>
						<div class="paddLeft">
							<p>Nous souhaitons vous donner le meilleur prix de vente, c'est a dire le prix du marché actuel, et vous proposer la meilleur stratégie commerciale, car nous souhaitons vendre votre bien au meilleur prix, et dans les meilleurs délais.</p>
						</div>
						<div class="text-center col-xs-12 col-sm-12 col-md-12 col-lg-12">
							<img src="pdf/pic13.png"/>
						</div>
						<!-- water mark -->
						<div class="whater-mark bottom">
							<div class="home-conseiller">
								<div class="col col-xs-12 col-sm-2 col-md-2 col-lg-2">
									<img src="pdf/limmolier.png"/>
								</div>
								<div class="col col-xs-12 col-sm-6 col-md-6 col-lg-6">
									<ul>
										<li>Votre Home Conseiller</li>
										<li>Mr.Philippe Soulie</li>
										<li>Tél : 06 50 65 68 78</li>
										<li>Email : philippe.soulie@limmobilier.net</li>
									</ul>
								</div>
								<div class="col col-xs-12 col-sm-4 col-md-4 col-lg-4">
									<ul>
										<li>Notre Réseau</li>
										<li>Tél. : 04 57 43 00 50 / 04 57 43 00 49</li>
										<li>E-mail : contact@limmobilier.net</li>
										<li>Site web : https://www.limmobilier.net</li>
										<li>Adresse : 2 Avenue du Lac 74140 Douvaine</li>
									</ul>
								</div>
							</div>
						</div>
						<!-- water mark -->
					</div>
					<!-- End: page 3 -->
					<!-- Start: page 4 -->
					<div class="page">
						<div class="titles active">
							<span>3</span>
							Notre application ETUDEO©
						</div>
						<div class="etudeo">
							<p><strong>ETUDEO©</strong> vient de la fusion des mots ETUDE et IMMOBILIER, ce rapport utilise 4 applications qui sont les suivantes:</p>
						</div>
						<div class="title-blue">
							<span>OFFRIMO©</span> Visualiser l'offre immobiliére
						</div>
						<div class="etudeo">
							<p><strong>OFFRIMO©</strong> vient de la fusion des mots <strong>OFFRE</strong> et <strong>IMMOBILIER</strong>, nous utilisons cette application qui nous permet d’étre informés de toutes les annonces de l'offre immobiliere, données par tous les sites d’annonces, pour tous les biens publiés par les particuliers et les agences, et cela, en temps réel.</p>
							<p>Cette offre peut étre consultée par défaut, suivant les annonces données par les sites immobilier, mais peut également étre affinée suivant un moteur de recherche intelligent.</p>
						</div>
						
						<div class="title-blue">
							<span>RANKIMO©</span> Classer l'offre immobiliére
						</div>
						<div class="etudeo">
							<p><strong>RANKIMO©</strong> vient de la fusion du mot anglais <strong>"RANK"</strong> qui signiﬁe <strong>"CLASSER"</strong> et de <strong>IMMOBILIER</strong>, car nous utilisons cette application qui nous permet de classer les annonces de l'offre immobiliére données par tous les sites d'annonces, pour tous les biens publiés par les particuliers et les agences, et cela, en temps réel.</p>
							<p>Ce classement se fait par défaut, suivant les informations données par les sites d'annonces immobilieres, mais peut également étre paramétréer pour affiner le classement.</p>
						</div>
						
						<div class="title-blue">
							<span>COMPARIMO©</span> Comparer l'offre immobiliére
						</div>
						<div class="etudeo">
							<p><strong>COMPARIMO©</strong> vient de la fusion des mots <strong>COMPARER et IMMOBILIER</strong>, nous utilisons cette application qui nous permet de comparer les annonces de l'offre immobiliere données par tous les sites d'annonces, pour tous les biens publiés par les particuliers et les agences, et cela, en temps réel.</p>
							<p>Cette comparaison se fait par défaut, suivant les informations données par les sites d'annonces immobilieres, mais peut également étre paramétréer pour affiner la comparaison.</p>
						</div>
						
						<div class="title-blue">
							<span>OBSERVIMO©</span> Qualiﬁer l'offre immobiliére
						</div>
						<div class="etudeo">
							<p><strong>OBSERVIMO©</strong> vient de la fusion des mots <strong>OBSERVER et IMMOBILIER</strong>, nous utilisons cette application qui nous permet de qualiﬁer un département, une ville, un quartier ou une rue, en identiﬁant ses points forts et ses points faibles, cette qualiﬁcation se fait sur des indicateurs démographiques, sociaux, environnementaux, de commodités, transports...</p>
							<p>Nous pouvons ainsi qualiﬁer une adresse a 360°, nous savons 00 se situe votre bien.</p>
						</div>
						
						<!-- water mark -->
						<div class="whater-mark bottom">
							<div class="home-conseiller">
								<div class="col col-xs-12 col-sm-2 col-md-2 col-lg-2">
									<img src="pdf/limmolier.png"/>
								</div>
								<div class="col col-xs-12 col-sm-6 col-md-6 col-lg-6">
									<ul>
										<li>Votre Home Conseiller</li>
										<li>Mr.Philippe Soulie</li>
										<li>Tél : 06 50 65 68 78</li>
										<li>Email : philippe.soulie@limmobilier.net</li>
									</ul>
								</div>
								<div class="col col-xs-12 col-sm-4 col-md-4 col-lg-4">
									<ul>
										<li>Notre Réseau</li>
										<li>Tél. : 04 57 43 00 50 / 04 57 43 00 49</li>
										<li>E-mail : contact@limmobilier.net</li>
										<li>Site web : https://www.limmobilier.net</li>
										<li>Adresse : 2 Avenue du Lac 74140 Douvaine</li>
									</ul>
								</div>
							</div>
						</div>
						<!-- water mark -->
					</div>
					<!-- End: page 4 -->
					<!-- Start: page 5 -->
					<div class="page">
						<div class="titles active">
							<span>4</span>
							Tout sur votre annonce mise en ligne
						</div>
						<div class="title-blue">
							<span><em>Vos photos</em></span>
							<label><input type="checkbox"/><em></em></label>
						</div>
						<div class="row">
							<div class="recherch">
								<div class="col col-xs-12 col-sm-4 col-md-4 col-lg-4">
									<label style="background-image: url(pdf/pic14.jpg);"></label>
								</div>
								<div class="col col-xs-12 col-sm-4 col-md-4 col-lg-4">
									<label style="background-image: url(pdf/pic14.jpg);"></label>
								</div>
								<div class="col col-xs-12 col-sm-4 col-md-4 col-lg-4">
									<label style="background-image: url(pdf/pic14.jpg);"></label>
								</div>
							</div>
						</div>
						<div class="title-blue">
							<span><em>Votre texte publicitaire</em></span>
							<label><input type="checkbox"/><em></em></label>
						</div>
						<div class="publicitaire">
							<span class="greenBtn">PAP</span>
							<div class="border-box">
								<p>Appartement de 97 m2 dans quartier recherché a Seynod. Proche des commodités, des grands axes et d'Annecy. Cet appartement est orienté Sud-Est Sud et donne sur un parc paysagé au calme.</p>
							</div>
						</div>
						<div class="publicitaire">
							<span class="orengBtn">PRO</span>
							<div class="row">
								<div class="col col-xs-12 col-sm-4 col-md-4 col-lg-4">
									<div class="border-box">
										<h6>Agence SAFTI</h6>
										<p>Appartement de 97 m2 dans quartier recherche a Seynod. Proche des commodités, des grands axes et d'Annecy. Cet appartement est orienté Sud-Est Sud et donne sur un parc paysagé au calme.</p>
									</div>
								</div>
								<div class="col col-xs-12 col-sm-4 col-md-4 col-lg-4">
									<div class="border-box">
										<h6>Agence POIRIER</h6>
										<p>Appartement de 97 m2 dans quartier recherche a Seynod. Proche des commodités, des grands axes et d'Annecy. Cet appartement est orienté Sud-Est Sud et donne sur un parc paysagé au calme.</p>
									</div>
								</div>
								<div class="col col-xs-12 col-sm-4 col-md-4 col-lg-4">
									<div class="border-box">
										<h6>Agence CAPIFRANCE</h6>
										<p>Appartement de 97 m2 dans quartier recherche a Seynod. Proche des commodités, des grands axes et d'Annecy. Cet appartement est orienté Sud-Est Sud et donne sur un parc paysagé au calme.</p>
									</div>
								</div>
							</div>
						</div>
						
						<div class="table col-xs-12 col-sm-12 col-md-12 col-lg-12">
							<div class="title-blue">
								<span><em>Comment est vu votre bien sur internet ?</em></span>
								<label><input type="checkbox"/><em></em></label>
							</div>
							<table>
								<thead>
									<tr>
										<th></th>
										<th>PAP</th>
										<th>Agence SAFTI</th>
										<th>Agence POIRIER</th>
										<th>Agence CAPIFRANCE</th>
									</tr>
								</thead>
								<tbody>
									<tr>
										<td>Prix</td>
										<td>305 000 €</td>
										<td>329 000 €</td>
										<td>317 000 €</td>
										<td>341 000 €</td>
									</tr>
									<tr>
										<td>Pieces</td>
										<td>4</td>
										<td>4</td>
										<td>5</td>
										<td>4</td>
									</tr>
									<tr>
										<td>SH</td>
										<td>92 m<sup>2</sup></td>
										<td>95 m<sup>2</sup></td>
										<td>97 m<sup>2</sup></td>
										<td>104 m<sup>2</sup></td>
									</tr>
								</tbody>
							</table>
						</div>
						<div class="title-blue">
							<span><em>Historique de votre annonce sur internet</em></span>
						</div>
						<div class="etudeo">
							<div class="tranLi">
								<ul>
									<li>Mise en ligne le 11/07/2017 et en ligne depuis 30 jours</li>
									<li>Présentée actuellement par 3 agences</li>
									<li>Evolution du prix:</li>
								</ul>
								<img src="pdf/graf.jpg"/>
							</div>
						</div>
						<!-- water mark -->
						<div class="whater-mark bottom">
							<div class="home-conseiller">
								<div class="col col-xs-12 col-sm-2 col-md-2 col-lg-2">
									<img src="pdf/limmolier.png"/>
								</div>
								<div class="col col-xs-12 col-sm-6 col-md-6 col-lg-6">
									<ul>
										<li>Votre Home Conseiller</li>
										<li>Mr.Philippe Soulie</li>
										<li>Tél : 06 50 65 68 78</li>
										<li>Email : philippe.soulie@limmobilier.net</li>
									</ul>
								</div>
								<div class="col col-xs-12 col-sm-4 col-md-4 col-lg-4">
									<ul>
										<li>Notre Réseau</li>
										<li>Tél. : 04 57 43 00 50 / 04 57 43 00 49</li>
										<li>E-mail : contact@limmobilier.net</li>
										<li>Site web : https://www.limmobilier.net</li>
										<li>Adresse : 2 Avenue du Lac 74140 Douvaine</li>
									</ul>
								</div>
							</div>
						</div>
						<!-- water mark -->
					</div>
					<!-- End: page 5 -->
					<!-- Start: page 6 -->
					<div class="page">
						<div class="titles active">
							<span>6</span>
							Les bénéﬁces de ETUDEO© et EVALUEO©
						</div>
						<div class="etudeo">
							<h5>L’information et une valeur économique, elle permet de prendre la meilleure décision, de suivre l’évaluation de sa décision et de réussir son projet, dans votre cas c'est de vendre au meilleur priX et dans les meilleurs conditions et délais et de coﬁts.</h5>
						</div>
						<div class="benefite">
							<ul>
								<li>
									<strong>OFFRIMO</strong>
									<span>Je vois l’offre proposée par la concurrence</span>
								</li>
								<li>
									<strong>RANKIMO</strong>
									<span>Je classe cetTe offre concurrente</span>
								</li>
								<li>
									<strong>COMPARIMO</strong>
									<span>Je compare mon bien a l’offre concurrente</span>
								</li>
								<li>
									<strong>OBSERVIMO</strong>
									<span>Je valorise I ’offre concurrente</span>
								</li>
								<li>
									<strong>EVALUEO</strong>
									<span>J'evalue mon bien au juste prix</span>
								</li>
								<li>
									<strong>SIMULATEUR</strong>
									<span>Je simule mon annonce envisagée</span>
								</li>
								<li>
									<h6>Je vends ! <img src="pdf/icon1.png"/></h6>
								</li>
							</ul>
						</div>
						<div class="text-padd">
							<h5>"Pour réussir votre projet de mise en vente, et la vente de votre bien, nous vous proposons de nous revoir pour vous remettre votre <strong>AVIS DE VALEUR EVALUEO© "</strong></h5>
						</div>
						<!-- water mark -->
						<div class="whater-mark bottom">
							<div class="home-conseiller">
								<div class="col col-xs-12 col-sm-2 col-md-2 col-lg-2">
									<img src="pdf/limmolier.png"/>
								</div>
								<div class="col col-xs-12 col-sm-6 col-md-6 col-lg-6">
									<ul>
										<li>Votre Home Conseiller</li>
										<li>Mr.Philippe Soulie</li>
										<li>Tél : 06457430050</li>
										<li>Email : philippe.soulie@limmobilier.net</li>
									</ul>
								</div>
								<div class="col col-xs-12 col-sm-4 col-md-4 col-lg-4">
									<ul>
										<li>Notre Réseau</li>
										<li>Tél. : 06457430050</li>
										<li>E-mail : contact@limmobilier.net</li>
										<li>Site web : https://www.limmobilier.net</li>
										<li>Adresse : 2 Avenue du Lac 74140 Douvaine</li>
									</ul>
								</div>
							</div>
							<span class="pull-left">http://app.espaceo.net/client/evalueo/go_print/restore/308</span>
							<span class="pull-right">09/09</span>
						</div>
						<!-- water mark -->
					</div>
					<!-- End: page 6 -->
				</div>
			</aside>
		</div>
	</div>
</div>
