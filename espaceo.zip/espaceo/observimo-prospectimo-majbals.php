<div class="banners" style="background-image: url(images/bg-4.jpg);">
	<div class="Banners_TxT">
		<h2>Créer et suivre ses BALs</h2> 
		<h5>" Je consulte et je mets à jour les Boîtes à lettres de mon<br>
		  territoire sur mon Secteur
		  <select>
			<option>Tous</option>
			<option>Prioritaire</option>
			<option>Secondaire</option>
		  </select>
		</h5>
	</div>	
</div>
<div class="clr"></div>
<div class="prospectimo_filter_box p-filter-box">
		<div class="filter">
		  <form class="filter_form" action="#" method="post">
			<ul>
			  <li>Filtre :</li>
			  <li>
				<input class="first_intp" name="" placeholder="Mots clefs mean key words i can note in box" type="text">
				<button class="first_Btn">Submit</button>
			  </li>
			  <li>
				<select name="">
				  <option>Statuts BALs</option>
				  <option>Activée</option>
				  <option>Non activée</option>
				</select>
			  </li>
			  <li>
				<select name="">
				  <option>Dernière</option>
				  <option>same suivi in offrimo</option>
				</select>
			  </li>
			  <li>
				<select name="">
				  <option>Statut dernière</option>
				  <option>MAJ</option>
				  <option>Flyer</option>
				  <option>Contact</option>
				  <option>Passage</option>
				  <option>A rappeler</option>
				</select>
			  </li>
			  <li>
				<select name="">
				  <option>Taux Complétude</option>
				  <option>0 à 25%</option>
				  <option>25% à 50%</option>
				  <option>50% à 75%</option>
				  <option>75% à 100%</option>
				</select>
			  </li>
			  <li>
				<select name="">
				  <option>Potentiel</option>
				  <option>A estimer</option>
				  <option>A vendre</option>
				  <option>A gérer</option>
				  <option>A louer</option>
				  <option>DP</option>
				  <option>Promotion</option>
				  <option>Apporteur aff</option>
				</select>
			  </li>
			  <li>
				<select name="">
				  <option>Statut Habitation</option>
				  <option>Inoccupée</option>
				  <option>Abandonnée</option>
				</select>
			  </li>
			  <li>
				<select name="">
				  <option>Maturité BALs</option>
				  <option>7ans</option>
				  <option>+- 2ans</option>
				  <option>-3ans</option>
				</select>
			  </li>
			</ul>
		  </form>
		</div>
	</div>
<div class="prospectimo_Data_wrapper">
	<div class="col-md-12 col-sm-12 col-xs-12 majbals-container">
		<div class="col-md-5 col-sm-7 col-xs-12 majbals-map">
			<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d11379754.90301434!2d-6.929476864819009!3d45.86609808040356!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd54a02933785731%3A0x6bfd3f96c747d9f7!2sFrance!5e0!3m2!1sen!2sin!4v1534584981505" width="100%" height="464" frameborder="0" style="border:0" allowfullscreen></iframe>
		</div>
		<div class="col-md-7 col-sm-7 col-xs-12 majbals-right">
			<div class="col-md-6 col-sm-6 col-xs-12 majbals-box-1 border-right">
				<div class="col-xs-12 majbals-val">
					<ul>
						<li><a href="#maison-box" data-toggle="modal" data-backdrop="true"><i class="fa fa-eye"></i> Voir</a>
						</li>
						<li><a><i class="green-btn fa fa-circle"></i> Active</a>
						</li>
					</ul>
				</div>
				<div class="col-xs-12 Prospectimo_majbal">
					<div id="maison4pieces" class="carousel slide" data-ride="carousel">
						<!-- Wrapper for slides -->
						<div class="carousel-inner">
							<div class="carousel-caption">Maison 4Pièces
								<br>41 aveue du lac
								<br>74140 DOUVAINE</div>
							<div class="item active" style="background:url(images/offrimo1.png)"></div>
							<div class="item" style="background:url(images/offrimo2.png)"></div>
						</div>
						<!-- Left and right controls -->
						<a class="left carousel-control" href="#maison4pieces" data-slide="prev"> <span class="glyphicon glyphicon-chevron-left"></span>  <span class="sr-only">Previous</span> 
						</a>
						<a class="right carousel-control" href="#maison4pieces" data-slide="next"> <span class="glyphicon glyphicon-chevron-right"></span>  <span class="sr-only">Next</span> 
						</a>
					</div>
				</div>
				<div class="col-xs-12 maison-bottom-list">
					<ul>
						<li><a href="#maison-box-Identifier" data-toggle="modal" data-backdrop="true">Identifier </a>
						</li>
						<li><a href="#maison-box-Infos" data-toggle="modal" data-backdrop="true">Infos</a>
						</li>
						<li><a href="#">Découvrimo</a>
						</li>
						<li><a href="#">Potentiel</a>
						</li>
						<li><a href="#maison-box-Suivi" data-toggle="modal" data-backdrop="true">Suivi</a></li>
					</ul>
				</div>
			</div>
			<div class="col-md-6 col-sm-6 col-xs-12 majbals-box-1 border-bottom">
				<div class="col-xs-12 majbals-val">
					<ul>
						<li><a href="#maison-box" data-toggle="modal"  data-backdrop="true"><i class="fa fa-eye"></i> Voir</a>
						</li>
						<li><a><i class=" fa fa-circle"></i> Active</a>
						</li>
					</ul>
				</div>
				<div class="col-xs-12">
					<img src="images/mailbox-full.png" class="img-responsive center-block" alt="mailbox">
				</div>
			</div>
			<div class="col-md-6 col-sm-6 col-xs-12 majbals-box-1 border-right">
				<div class="col-xs-12 majbals-val">
					<ul>
						<li><a href="#maison-box" data-toggle="modal"  data-backdrop="true"><i class="fa fa-eye"></i> Voir</a>
						</li>
						<li><a href="#"><i class="fa fa-circle"></i> Active</a>
						</li>
					</ul>
				</div>
				<div class="col-xs-12">
					<img src="images/mailbox-full.png" class="img-responsive center-block" alt="mailbox">
				</div>
			</div>
			<div class="col-md-6 col-sm-6 col-xs-12 majbals-box-1">
				<div class="col-xs-12 majbals-val">
					<ul>
						<li><a href="#maison-box" data-toggle="modal"  data-backdrop="true"><i class="fa fa-eye"></i> Voir</a>
						</li>
						<li><a><i class="green-btn fa fa-circle"></i> Active</a>
						</li>
					</ul>
				</div>
				<div class="col-xs-12 Prospectimo_majbal_2">
					<div id="maison4pieces2" class="carousel slide" data-ride="carousel">
						<!-- Wrapper for slides -->
						<div class="carousel-inner">
							<div class="carousel-caption">appartement/terrain</div>
							<div class="item active" style="background:url(images/map1.jpg)"></div>
							<div class="item" style="background:url(images/pic4.png)"></div>
						</div>
						<!-- Left and right controls -->
						<a class="left carousel-control" href="#maison4pieces2" data-slide="prev"> <span class="glyphicon glyphicon-chevron-left"></span>  <span class="sr-only">Previous</span> 
						</a>
						<a class="right carousel-control" href="#maison4pieces2" data-slide="next"> <span class="glyphicon glyphicon-chevron-right"></span>  <span class="sr-only">Next</span> 
						</a>
					</div>
				</div>				
				<div class="col-xs-12 maison-bottom-list">
					<ul>
						<li><a href="#">Identifier </a>
						</li>
						<li><a href="#">Infos</a>
						</li>
						<li><a href="#">Découvrimo</a>
						</li>
						<li><a href="#">Potentiel</a>
						</li>
						<li><a href="#maison-box-Suivi" data-toggle="modal" data-backdrop="true">Suivi</a></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
</div>	


