jQuery(document).ready(function(){
	jQuery('.mobileBtn').click(function(){
		jQuery('.menuBox').slideToggle();
	});
	//jQuery("#calendar").kendoCalendar();
	//jQuery(".k-calendar .k-header .k-link").unbind();
	
	jQuery('.header .topHeader .profile > a').click(function(){
		jQuery('.header .topHeader .profile ul').slideToggle('');
	});
	jQuery('.repter .padRight .plus').click(function(){
		jQuery(this).next().toggle();
		jQuery(this).next().next().toggle();
		jQuery(this).parent().toggleClass('active');
	});
	jQuery('.agendaBox .agendaClndr #sortAgenda.bars').click(function(){
		jQuery('.agendaBox .tableColum').toggleClass('active');
	});
	jQuery('#owl-slider1').owlCarousel({
		items:1,
		nav:true,
		loop:true,
		autoplay:true,
		autoplayTimeout: 5000,
		autoplaySpeed:1500
	});
	jQuery('#owl-le-bien').owlCarousel({
		items:1,
		nav:false,
		loop:true,
		animateOut: 'fadeOut',
		autoplay:true,
		autoplayTimeout: 5000,
		autoplaySpeed:3000
	});
	jQuery('#all_Diff_check_open').click(function(){
		jQuery(this).toggleClass('active');
		jQuery('#diffusimo_togg_show').toggleClass('active');
	});
	jQuery('.photoGallery .remove').click(function(){
		jQuery(this).parent().parent('.gallery').css('opcity','0');
		jQuery(this).parent().parent('.gallery').remove('');
	});
	jQuery('.maping .focus').click(function(){
		jQuery(this).parent().next('.img').imgZoom('');
	});
	/* jQuery('#owl-feedback').owlCarousel({
		center: true,
		items:2,
		loop:true,
		autoplay:true,
		autoplayTimeout: 5000,
		autoplaySpeed:1500,
		margin:12,
		responsive:{
		0:{
		items:1
		},
		767:{
		items:2
		}
		}
	}); */
	jQuery('.sectorimo_territoires .borderGray .orengeTitle').click(function(){
		jQuery(this).toggleClass('active');
		jQuery(this).next('.grayBg').slideToggle('');
	});
	/* jQuery('.evalueoBox .valeurs .nav-tab .color').click(function(){
		jQuery('.evalueoBox .valeurs .nav-tab .color').removeClass('togg');
		jQuery(this).addClass('togg');
	}); */
		
	/* jQuery('.evalueoBox .greenCont .greenBorder .heading').click(function(){
		jQuery(this).toggleClass('active');
		jQuery(this).next('.panel').slideToggle('');
	}); */
	jQuery('.banners #maisons_de_criteres_btn').click(function(){
		jQuery('.banners #maisons_de_criteres_form').slideDown('');
	});
	jQuery('.banners #maisons_de_criteres_close').click(function(){
		jQuery('.banners #maisons_de_criteres_form').slideUp('');
	});
	jQuery('.totalRankMap #total_prix_de_rank_enable').click(function(){
		jQuery('.totalRankMap #total_prix_de_rank').removeAttr('disabled');
	});
	jQuery('.comparimoBox .simulateur .banners #maisons_de_criteres_btn').click(function(){
		jQuery('.comparimoBox .simulateur').addClass('marginBottom');
	});
	jQuery('.comparimoBox .simulateur .banners .expend-form .close').click(function(){
		jQuery('.comparimoBox .simulateur').removeClass('marginBottom');
	});
	
	jQuery('.scrolTop').click(function(){
		jQuery("html, body").animate({ scrollTop: 0 }, 600);
		return false;
	});
		
	/* jQuery('.repport-btns li a#photo_du_bien').click(function(){
		jQuery("#all-repport-pdf .#photo-upload").animate({ scrollTop: 0 },600);
		return false;
	}); */
	
	jQuery('.repport-btns li a').click(function() {
        var el = jQuery(this).attr('href');
        var el = el.substring(el.indexOf('#')+1);
        var elWrapped = jQuery('#'+el);
        scrollToDiv(elWrapped, 60);
        return true;
    });

    function scrollToDiv(element, navheight) {
        var offset = element.offset();
        var offsetTop = offset.top;
        var totalScroll = offsetTop - navheight;
        jQuery('#all-repport-pdf ').animate({
            scrollTop: totalScroll
        }, 500);
    };
	
	/* sticky */
	if(jQuery('#headerWrapper').length > 0 ){
	var target = jQuery('#headerWrapper').offset().top;	
	jQuery(window).scroll(function() {		
	    if (jQuery(window).scrollTop() > target) {			
			jQuery('#headerWrapper').addClass('sticky');			
			} else {			
			jQuery('#headerWrapper').removeClass('sticky');       
		}		
	});	
	}
	/**************** *************/
		
});

jQuery('.tabs li').click(function(){
	var tab_id = jQuery(this).attr('data-tab');
	jQuery('.tabs li').removeClass('active');
	jQuery('.tabPane').removeClass('active');
	jQuery(this).addClass('active');
	jQuery("#"+tab_id).addClass('active');
});
jQuery('<div class="quantity-nav"><div class="quantity-button quantity-up"></div><div class="quantity-button quantity-down"></div></div>').insertAfter('.quantity input');
jQuery('.quantity').each(function() {
	var spinner = jQuery(this),
	input = spinner.find('input[type="number"]'),
	btnUp = spinner.find('.quantity-up'),
	btnDown = spinner.find('.quantity-down'),
	min = input.attr('min'),
	max = input.attr('max');
	btnUp.click(function() {
		var oldValue = parseFloat(input.val());
		if (oldValue >= max) {
			var newVal = oldValue;
			} else {
			var newVal = oldValue + 1;
		}
		spinner.find("input").val(newVal);
		spinner.find("input").trigger("change");
	});
	btnDown.click(function() {
		var oldValue = parseFloat(input.val());
		if (oldValue <= min) {
			var newVal = oldValue;
			} else {
			var newVal = oldValue - 1;
		}
		spinner.find("input").val(newVal);
		spinner.find("input").trigger("change");
	});
});

jQuery(document).ready(function(){
	jQuery(function(){
		if(jQuery('#offer-price1').length > 0){
			var span = document.getElementById("offer-price1"),
			res = document.getElementById("offer-result1");
			span.addEventListener("input", function() {
				res.innerHTML = span.value + " &euro;";
			}, false);
			
		}
	});
	jQuery(function(){
		if(jQuery('#offer-price2').length > 0){
			var span = document.getElementById("offer-price2"),
			res = document.getElementById("offer-result2");
			span.addEventListener("input", function() {
				res.innerHTML = span.value + " &euro;";
			}, false);
		}
	});
	jQuery(function(){
		if(jQuery('#offer-price3').length > 0){
			var span = document.getElementById("offer-price3"),
			res = document.getElementById("offer-result3");
			span.addEventListener("input", function() {
				res.innerHTML = span.value + " &euro;";
			}, false);
		}
	});
	jQuery(function(){
		if(jQuery('#offer-price4').length > 0){
			var span = document.getElementById("offer-price4"),
			res = document.getElementById("offer-result4");
			span.addEventListener("input", function() {
				res.innerHTML = span.value + " &euro;";
			}, false);
		}
	});
});

/***************** Comparimo JS *******************/
jQuery(document).ready(function(){
	jQuery(function(){
		if(jQuery('#comparimo-price1').length > 0){
			var span = document.getElementById("comparimo-price1"),
			res = document.getElementById("comparimo-result1");
			span.addEventListener("input", function() {
				res.innerHTML = span.value + " &euro;";
			}, false);
		}
	});
	jQuery(function(){
		if(jQuery('#comparimo-price2').length > 0){
			var span = document.getElementById("comparimo-price2"),
			res = document.getElementById("comparimo-result2");
			span.addEventListener("input", function() {
				res.innerHTML = span.value + " &euro;";
			}, false);
		}
	});
	jQuery(function(){
		if(jQuery('#comparimo-price3').length > 0){
			var span = document.getElementById("comparimo-price3"),
			res = document.getElementById("comparimo-result3");
			span.addEventListener("input", function() {
				res.innerHTML = span.value + " &euro;";
			}, false);
		}
	});
	jQuery(function(){
		if(jQuery('#comparimo-price4').length > 0){
			var span = document.getElementById("comparimo-price4"),
			res = document.getElementById("offer-result4");
			span.addEventListener("input", function() {
				res.innerHTML = span.value + " &euro;";
			}, false);
		}
	});
});

