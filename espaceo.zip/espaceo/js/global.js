jQuery(document).ready(function(){
	jQuery('.mobileBtn').click(function(){
		jQuery('.menuBox').slideToggle();
	});
	//jQuery("#calendar").kendoCalendar();
	//jQuery(".k-calendar .k-header .k-link").unbind();
	
	jQuery('.header .topHeader .profile > a').click(function(){
		jQuery('.header .topHeader .profile ul').slideToggle('');
	});
	jQuery('.repter .padRight .plus').click(function(){
		jQuery(this).next().toggle();
		jQuery(this).next().next().toggle();
		jQuery(this).parent().toggleClass('active');
	});
	jQuery('.agendaBox .agendaClndr #sortAgenda.bars').click(function(){
		jQuery('.agendaBox .agendaClndr #sortAgenda').hide();
		jQuery('.agendaBox .tableColum').toggleClass('active');
	});
	jQuery('#owl-slider1').owlCarousel({
		items:1,
		nav:true,
		loop:true,
		autoplay:true,
		autoplayTimeout: 5000,
		autoplaySpeed:1500
	});
	jQuery('#owl-le-bien').owlCarousel({
		items:1,
		nav:false,
		loop:true,
		animateOut: 'fadeOut',
		autoplay:true,
		autoplayTimeout: 5000,
		autoplaySpeed:3000
	});
	jQuery('.comparimo-annonces-vs-offrimo').owlCarousel({
		items:1,
		nav:true,
		loop:true,
		autoplay:false
	});
	jQuery('#all_Diff_check_open').click(function(){
		jQuery(this).toggleClass('active');
		jQuery('#diffusimo_togg_show').toggleClass('active');
	});
	jQuery('.photoGallery .remove').click(function(){
		jQuery(this).parent().parent('.gallery').css('opcity','0');
		jQuery(this).parent().parent('.gallery').remove('');
	});
	jQuery('.maping .focus').click(function(){
		jQuery(this).parent().next('.img').imgZoom('');
	});
	
	jQuery('.sectorimo_territoires .borderGray .orengeTitle').click(function(){
		jQuery(this).toggleClass('active');
		jQuery(this).next('.grayBg').slideToggle('');
	});
	/* jQuery('.evalueoBox .valeurs .nav-tab .color').click(function(){
		jQuery('.evalueoBox .valeurs .nav-tab .color').removeClass('togg');
		jQuery(this).addClass('togg');
	}); */
		
	/* jQuery('.evalueoBox .greenCont .greenBorder .heading').click(function(){
		jQuery(this).toggleClass('active');
		jQuery(this).next('.panel').slideToggle('');
	}); */
	//jQuery('#maisons_de_criteres_btn').click(function(){
		//jQuery('#maisons_de_criteres_form').slideDown('');
	
	jQuery('#maisons_de_criteres_btn1').click(function(){
		jQuery('#maisons_de_criteres_form1').slideDown('');
	});
	jQuery('#maisons_de_criteres_btn2').click(function(){
		jQuery('#maisons_de_criteres_form2').slideDown('');
	});
	jQuery('#maisons_de_criteres_close').click(function(){
		jQuery('#maisons_de_criteres_form').slideUp('');
		jQuery('#maisons_de_criteres_form1').slideUp('');
		jQuery('#maisons_de_criteres_form2').slideUp('');
	});
	jQuery('.totalRankMap #total_prix_de_rank_enable').click(function(){
		jQuery('.totalRankMap #total_prix_de_rank').removeAttr('disabled');
	});
	jQuery('.comparimoBox .simulateur .banners #maisons_de_criteres_btn').click(function(){
		jQuery('.comparimoBox .simulateur').addClass('marginBottom');
	});
	jQuery('.comparimoBox .simulateur .banners .expend-form .close').click(function(){
		jQuery('.comparimoBox .simulateur').removeClass('marginBottom');
	});
	
    jQuery('#maisons_de_criteres_close01').click(function(){
	jQuery('#maisons_de_criteres_form1').slideUp('');
    }); 
	
  
  
	jQuery('.scrolTop').click(function(){
		jQuery("html, body").animate({ scrollTop: 0 }, 600);
		return false;
	});	
	jQuery('.scrolTop').click(function(){
		
		jQuery(".repport-pdf").animate({ scrollTop: 0 }, 600);		
		return false;
	});
	jQuery('#all-repport-pdf').scroll(function(){		
	if (jQuery('#all-repport-pdf').scrollTop() ){
		jQuery(".dataScroll").addClass('showScroll');	
	}
	else{
		jQuery(".dataScroll").removeClass('showScroll');	
	}	
		return false;
	});



	
	/* jQuery('.repport-btns li a#photo_du_bien').click(function(){
		jQuery("#all-repport-pdf .#photo-upload").animate({ scrollTop: 0 },600);
		return false;
	}); */
	
	jQuery('.repport-btns li a').click(function() {
        var el = jQuery(this).attr('href');
        var el = el.substring(el.indexOf('#')+1);
        var elWrapped = jQuery('#'+el);
        scrollToDiv(elWrapped, 60);
        return true;
    });

    function scrollToDiv(element, navheight) {
        var offset = element.offset();
        var offsetTop = offset.top;
        var totalScroll = offsetTop - navheight;
        jQuery('#all-repport-pdf ').animate({
            scrollTop: totalScroll
        }, 500);
    };
	
	/* sticky */
	 /*if(jQuery('#headerWrapper').length > 0 ){
	var target = jQuery('#headerWrapper').offset().top;	
	jQuery(window).scroll(function() {		
	    if (jQuery(window).scrollTop() > target) {			
			jQuery('#headerWrapper').addClass('sticky');			
			} else {			
			jQuery('#headerWrapper').removeClass('sticky');       
		}		
	});	
	}*/ 
	/**************** *************/
		
});

jQuery('.tabs li').click(function(){
	var tab_id = jQuery(this).attr('data-tab');
	jQuery('.tabs li').removeClass('active');
	jQuery('.tabPane').removeClass('active');
	jQuery(this).addClass('active');
	jQuery("#"+tab_id).addClass('active');
});
jQuery('<div class="quantity-nav"><div class="quantity-button quantity-up"></div><div class="quantity-button quantity-down"></div></div>').insertAfter('.quantity input');
jQuery('.quantity').each(function() {
	var spinner = jQuery(this),
	input = spinner.find('input[type="number"]'),
	btnUp = spinner.find('.quantity-up'),
	btnDown = spinner.find('.quantity-down'),
	min = input.attr('min'),
	max = input.attr('max');
	btnUp.click(function() {
		var oldValue = parseFloat(input.val());
		if (oldValue >= max) {
			var newVal = oldValue;
			} else {
			var newVal = oldValue + 1;
		}
		spinner.find("input").val(newVal);
		spinner.find("input").trigger("change");
	});
	btnDown.click(function() {
		var oldValue = parseFloat(input.val());
		if (oldValue <= min) {
			var newVal = oldValue;
			} else {
			var newVal = oldValue - 1;
		}
		spinner.find("input").val(newVal);
		spinner.find("input").trigger("change");
	});
});

jQuery(document).ready(function(){
	jQuery(function(){
		if(jQuery('#offer-price1').length > 0){
			var span = document.getElementById("offer-price1"),
			res = document.getElementById("offer-result1");
			span.addEventListener("input", function() {
				res.innerHTML = span.value + " &euro;";
			}, false);
			
		}
	});
	jQuery(function(){
		if(jQuery('#offer-price2').length > 0){
			var span = document.getElementById("offer-price2"),
			res = document.getElementById("offer-result2");
			span.addEventListener("input", function() {
				res.innerHTML = span.value + " &euro;";
			}, false);
		}
	});
	jQuery(function(){
		if(jQuery('#offer-price3').length > 0){
			var span = document.getElementById("offer-price3"),
			res = document.getElementById("offer-result3");
			span.addEventListener("input", function() {
				res.innerHTML = span.value + " &euro;";
			}, false);
		}
	});
	jQuery(function(){
		if(jQuery('#offer-price4').length > 0){
			var span = document.getElementById("offer-price4"),
			res = document.getElementById("offer-result4");
			span.addEventListener("input", function() {
				res.innerHTML = span.value + " &euro;";
			}, false);
		}
	});
});

/***************** Comparimo JS *******************/
jQuery(document).ready(function(){
	jQuery(function(){
		if(jQuery('#comparimo-price1').length > 0){
			var span = document.getElementById("comparimo-price1"),
			res = document.getElementById("comparimo-result1");
			span.addEventListener("input", function() {
				res.innerHTML = span.value + " &euro;";
			}, false);
		}
	});
	jQuery(function(){
		if(jQuery('#comparimo-price2').length > 0){
			var span = document.getElementById("comparimo-price2"),
			res = document.getElementById("comparimo-result2");
			span.addEventListener("input", function() {
				res.innerHTML = span.value + " &euro;";
			}, false);
		}
	});
	jQuery(function(){
		if(jQuery('#comparimo-price3').length > 0){
			var span = document.getElementById("comparimo-price3"),
			res = document.getElementById("comparimo-result3");
			span.addEventListener("input", function() {
				res.innerHTML = span.value + " &euro;";
			}, false);
		}
	});
	jQuery(function(){
		if(jQuery('#comparimo-price4').length > 0){
			var span = document.getElementById("comparimo-price4"),
			res = document.getElementById("offer-result4");
			span.addEventListener("input", function() {
				res.innerHTML = span.value + " &euro;";
			}, false);
		}
	});
	
	
/* 	jQuery(function(){
  jQuery(".accordian h3").click(function(e){
    jQuery('accordian h3').find('.fa.fa-plus open').toggleClass('open');
    jQuery(jQuery(e.target).find('.fa.fa-plus').toggleClass('open'));
  jQuery(".accordian ul ul").slideUp();
    if (jQuery(this).next().is(":hidden")){
    jQuery(this).next().slideDown();
    }
  }); */
/* jQuery('.zac ul li a').click(function(){
  	jQuery('.zac').addClass('col-xs-12 col-sm-4 col-md-4 col-lg-4');
	jQuery('.accordian div').removeClass('col-lg-8 col-md-8 col-sm-8 col-xs-12');
  });
   jQuery('.territory ul li a').click(function(){
  	jQuery('.boites').css("display", "block");
  });

    jQuery('.boites ul li a').click(function(){
  	jQuery('.zac, .territory').removeClass("col-xs-12 col-sm-4 col-md-4 col-lg-4");
  	jQuery('.zac, .territory').addClass("col-xs-12 col-sm-2 col-md-2 col-lg-2");
  	jQuery('.information-bx').css("display", "block");
  	jQuery('.information-bx').addClass('col-xs-12 col-sm-4 col-md-4 col-lg-4');
  });
  });*/
}); 
/// evalue dowpdown js
 jQuery('.Select_citys').click(function(){
  	jQuery('.Add_city_dropBox').toggle();  
  });
  function showhide() 
        {  
            var div = document.getElementById("Add_city_dropBox");  
            if (div.style.display !== "none") {  
                div.style.display = "none";  
            }  
            else {  
                div.style.display = "block";  
            }  
        }
/// Simulateur Offer Form js
 jQuery('.mon_offer_Edit').click(function(){
  	jQuery('.expend-form').toggle(100);  
  });
  function showhide() 
        {  
            var div = document.getElementById("colse-btn");  
            if (div.style.display !== "none") {  
                div.style.display = "none";  
            }  
            else {  
                div.style.display = "block";  
            }  
        }
/// Evalueo edition rapport Informartions js
 jQuery('.Informartions_detail_Box').click(function(){
  	jQuery('.Informartions_Form_Box').toggle();  
  });

/// Evalueo edition rapport Comparimo js
 jQuery('.Comparimo_detail_Box').click(function(){
  	jQuery('.Comparimo_Form_Box').toggle();  
  });
  

/// Chassimo  
  jQuery('#ChaSurfaceTerrain').click(function(){
	jQuery('.ChaSurface').toggle();  
  }); 
  jQuery('#ChaSurfacesol').click(function(){
	jQuery('.Chasol_txt').toggle();  
  }); 
  
/*  //Sectorimo parametrem3-1
  jQuery('#ParaListBox1').click(function(){
	jQuery('.ParaDetailsBox1').toggle(500);  
  });
 //Sectorimo parametrem3-2
  jQuery('#ParaListBox2').click(function(){
	jQuery('.ParaDetailsBox2').toggle(500);  
  });
 //Sectorimo parametrem3-3
  jQuery('#ParaListBox').click(function(){
	jQuery('.ParaDetailsBox').toggle(500);  
  }); */
/* Simulateur */
   jQuery('.myBtn').click(function(){
  	jQuery('.SimulateurListin').css("display", "block");
  });

$('body').on('click','.close-div1', function(){
  $(this).closest(".Reporting_Box").remove();
});
//Callimo 3rd page
$('body').on('click','.archiverRemove', function(){ 
  var r = confirm("Supprimez-vous cette offre");
  if (r == true) {
     $(this).closest(".RemoveOffer").remove();
  } else {
   
  } 
});

 
 // home Page slider
jQuery('#owl-history').owlCarousel({
		items:2,
		loop:true,
		nav:true,
		margin: 15,
		autoplay:true,
		autoplayTimeout: 5000,
		autoplaySpeed:1500,
		responsive:{
			0:{
				items:1,
			},
			480:{
				items:1,
			},
			768:{
				items:2,
			},
			992:{
				items:2,
			}
		}
	}); 
	
	jQuery('#owl-chassimo').owlCarousel({
		 loop: false,
                margin: 10,
                nav: true,
                navRewind: false,
				slideBy: 1,
                responsive: {
                  0: {
                    items: 1
                  },
                  480: {
                    items: 1
                  },
                  767: {
                    items: 2
                  },
                  1000: {
                    items: 3
                  }
                }
	}); 
	 jQuery('.owl-carousel').owlCarousel({
    loop:true,
    margin:10,
    nav:true,
    responsive:{
        0:{
            items:1
        },
        767:{
            items:2
        },
        1000:{
            items:3
        }
    }
});

 jQuery('#Avez_vous').click(function(){
	jQuery('#Avez_vous_details').show();
  });
jQuery('.Avez_vous_hide').click(function(){
	jQuery('#Avez_vous_details').hide();
});
// offrimo table list
jQuery('#ComepareShow').click(function(){
	jQuery('.ComepareProperties').toggle();  
  }); 
// Active menu

$(document).ready(function () {
        var url = window.location;
        $('ul.navbar-nav a[href="' + url + '"]').parent().addClass('active');
        $('ul.navbar-nav a').filter(function () {
            return this.href == url;
        }).parent().addClass('active');
    });

/// ----- new js 2020 start here -----

// Evalue v5
jQuery('.Add_city_dropBoxClose').click(function(){
	jQuery('.Add_city_dropBox').hide();  
  });
// Seller 
jQuery('.SellerMonForm').click(function(){
	jQuery('#seller_de_criteres_form').show();  
  });
jQuery('.SellerClose').click(function(){
	jQuery('#seller_de_criteres_form').hide();  
  });
  
//Seller Type House and Apartment show hide
jQuery('#SellerHouse').click(function(){
	jQuery('#SellerSelectApartment').hide();  
	jQuery('#SellerSelectHouse').show();  
  });
jQuery('#SellerApartment').click(function(){
	jQuery('#SellerSelectHouse').hide();  
	jQuery('#SellerSelectApartment').show(); 
  });
  
//Buyer Type House and Apartment show hide
jQuery('#BuyerHouse').click(function(){
	jQuery('#SelectHouse').show();  
	jQuery('#SelectApartment').hide();  
  });
jQuery('#BuyerApartment').click(function(){
	jQuery('#SelectHouse').hide();  
	jQuery('#SelectApartment').show(); 
  });
//Lebonconr Text show
  jQuery('.ReadMore').click(function(){
	jQuery('#ReadMoreTxt').show();  
	jQuery('.DoutPoint').hide();  
	jQuery('.ReadMore').hide();  
  }); 
//Simulateur en ligne
jQuery('.myBtn').click(function(){ 
	jQuery('.Simulez_annonce_BoX').slideUp('');
  });
jQuery('#maisons_de_criteres_btn2').click(function(){ 
	jQuery('.Simulez_annonce_BoX').slideDown('');
  });



//My space Territory settings
  jQuery('.SpSs').click(function(){
	jQuery('.QualifySectorBox').slideDown();  
  });
	$('span.fa-times').click(function(){
		jQuery('.QualifySectorBox').slideUp();  
	}); 
  jQuery('.SpSs1').click(function(){
	jQuery('.SecoBox').slideDown();  
  });
	$('span.fa-times').click(function(){
		jQuery('.SecoBox').slideUp();  
	}); 
 $( function() {
    $(".BusssTitle .fa-times").click( function() {	
		$( this ).parent().parent().parent().hide();
    });
  });


//Buyer progress bar

(function($) {    
    "use strict";    
    var DEBUG = false, // make true to enable debug output
      PLUGIN_IDENTIFIER = "RangeSlider";
  
    var RangeSlider = function( element, options ) {
      this.element = element;
      this.options = options || {};
      this.defaults = {
        output: {
          prefix: '', // function or string
          suffix: '', // function or string
          format: function(output){
            return output;
          }
        },
        change: function(event, obj){}
      };
      this.metadata = $(this.element).data('options');
    };
    RangeSlider.prototype = {
      init: function() {
        if(DEBUG && console) console.log('RangeSlider init');
        this.config = $.extend( true, {}, this.defaults, this.options, this.metadata );
        var self = this;
        this.trackFull = $('<div class="track track--full"></div>').appendTo(self.element);
        this.trackIncluded = $('<div class="track track--included"></div>').appendTo(self.element);
        this.inputs = [];
        $('input[type="range"]', this.element).each(function(index, value) {
          var rangeInput = this;
          rangeInput.output = $('<output>').appendTo(self.element);
          rangeInput.output.zindex = parseInt($(rangeInput.output).css('z-index')) || 1;
          rangeInput.thumb = $('<div class="slider-thumb">').prependTo(self.element);
          rangeInput.initialValue = $(this).val();
          rangeInput.update = function() {
            if(DEBUG && console) console.log('RangeSlider rangeInput.update');
            var range = $(this).attr('max') - $(this).attr('min'),
              offset = $(this).val() - $(this).attr('min'),
              pos = offset / range * 100 + '%',
              transPos = offset / range * -100 + '%',
              prefix = typeof self.config.output.prefix == 'function' ? self.config.output.prefix.call(self, rangeInput) : self.config.output.prefix,
              format = self.config.output.format($(rangeInput).val()),
              suffix = typeof self.config.output.suffix == 'function' ? self.config.output.suffix.call(self, rangeInput) : self.config.output.suffix;
            $(rangeInput.output).html(prefix + '' + format + '' + suffix);
            $(rangeInput.output).css('left', pos);
            $(rangeInput.output).css('transform', 'translate('+transPos+',0)');
            $(rangeInput.thumb).css('left', pos);
            $(rangeInput.thumb).css('transform', 'translate('+transPos+',0)');
            self.adjustTrack();
          };
          rangeInput.sendOutputToFront = function() {
            $(this.output).css('z-index', rangeInput.output.zindex + 1);
          };
          rangeInput.sendOutputToBack = function() {
            $(this.output).css('z-index', rangeInput.output.zindex);
          };
          $(rangeInput.thumb).on('mousedown', function(event){
            self.sendAllOutputToBack();
            rangeInput.sendOutputToFront();
            $(this).data('tracking', true);
            $(document).one('mouseup', function() {
              $(rangeInput.thumb).data('tracking', false);
              self.change(event);
            });
          });
          $('body').on('mousemove', function(event){
            if($(rangeInput.thumb).data('tracking')) {
              var rangeOffset = $(rangeInput).offset(),
                relX = event.pageX - rangeOffset.left,
                rangeWidth = $(rangeInput).width();
              if(relX <= rangeWidth) {
                var val = relX/rangeWidth;
                $(rangeInput).val(val * $(rangeInput).attr('max'));
                rangeInput.update();
              }
            }
          });
          $(this).on('mousedown input change touchstart', function(event) {
            if(DEBUG && console) console.log('RangeSlider rangeInput, mousedown input touchstart');
            self.sendAllOutputToBack();
            rangeInput.sendOutputToFront();
            rangeInput.update();
          });
          $(this).on('mouseup touchend', function(event){
            if(DEBUG && console) console.log('RangeSlider rangeInput, change');
            self.change(event);
          });
          self.inputs.push(this);
        });
        this.reset();
        return this;
      },      
      sendAllOutputToBack: function() {
        $.map(this.inputs, function(input, index) {
          input.sendOutputToBack();
        });
      },      
      change: function(event) {
        if(DEBUG && console) console.log('RangeSlider change', event);
        var values = $.map(this.inputs, function(input, index) {
          return {
            value: parseInt($(input).val()),
            min: parseInt($(input).attr('min')),
            max: parseInt($(input).attr('max'))
          };
        });
        values.sort(function(a, b) {
          return a.value - b.value;
        });        
        this.config.change.call(this, event, values);
      },      
      reset: function() {
        if(DEBUG && console) console.log('RangeSlider reset');
        $.map(this.inputs, function(input, index) {
          $(input).val(input.initialValue);
          input.update();
        });
      },
       adjustTrack: function() {
        if(DEBUG && console) console.log('RangeSlider adjustTrack');
        var valueMin = Infinity,
          rangeMin = Infinity,
          valueMax = 0,
          rangeMax = 0;
        $.map(this.inputs, function(input, index) {
          var val = parseInt($(input).val()),
            min = parseInt($(input).attr('min')),
            max = parseInt($(input).attr('max'));
          valueMin = (val < valueMin) ? val : valueMin;
          valueMax = (val > valueMax) ? val : valueMax;
          rangeMin = (min < rangeMin) ? min : rangeMin;
          rangeMax = (max > rangeMax) ? max : rangeMax;
        });
        
        if(this.inputs.length > 1) {
          this.trackIncluded.css('width', (valueMax - valueMin) / (rangeMax - rangeMin) * 100 + '%');
          this.trackIncluded.css('left', (valueMin - rangeMin) / (rangeMax - rangeMin) * 100 + '%');
        } else {
          this.trackIncluded.css('width', valueMax / (rangeMax - rangeMin) * 100 + '%');
          this.trackIncluded.css('left', '0%');
        }
      }
    };
  
    RangeSlider.defaults = RangeSlider.prototype.defaults;
    
    $.fn.RangeSlider = function(options) {
      if(DEBUG && console) console.log('$.fn.RangeSlider', options);
      return this.each(function() {
        var instance = $(this).data(PLUGIN_IDENTIFIER);
        if(!instance) {
          instance = new RangeSlider(this, options).init();
          $(this).data(PLUGIN_IDENTIFIER,instance);
        }
      });
    };
  
  }
)(jQuery);

var rangeSlider = $('#facet-price-range-slider');
if(rangeSlider.length > 0) {
  rangeSlider.RangeSlider({
    output: {
      format: function(output){
        return output.replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,");
      },
      suffix: function(input){
        return parseInt($(input).val()) == parseInt($(input).attr('max')) ? this.config.maxSymbol : '';
      }
    }
  });
};

// my space territory settings
 var counter = 0;

    function addInput() {
        var form = document.getElementById('formulario');
        counter++;
        var template = document.getElementById('dynInp0');
        var clone = template.cloneNode(true);
        clone.id = "dynInp" + counter;
        var tag = clone.children[0];
        tag.textContent = "Entry " + counter;
        var rem = clone.children[4];
        rem.style.display = 'inline-block';
        form.appendChild(clone);
      }
    function removeInput(ele) {
      var form = document.getElementById('formulario');
      var parent = ele.parentNode;
      var removed = form.removeChild(parent);
    };
	
///	
 var counter = 0;

    function addInputs() {
        var form = document.getElementById('addAdvisers');
        counter++;
        var template = document.getElementById('dynmicInp0');
        var clones = template.cloneNode(true);
        clones.id = "dynmicInp" + counter;
        var tag = clones.children[0];
        tag.textContent = "Entry " + counter;
        var rem = clones.children[4];
        rem.style.display = 'inline-block1';
        form.appendChild(clones);
      }
    function removeInputs(ele) {
      var form = document.getElementById('addAdvisers');
      var parent = ele.parentNode;
      var removed = form.removeChild(parent);
    };




