<div class="evalueo">
	<div class="row">
		<aside class="valeurs col-xs-12 col-sm-12 col-md-12 col-lg-12">
			<div class="nav-tab">
				<ul>
					<li class="active">						<a data-toggle="tab" href="#greenEvalueo">
							<div class="green color" style="background-image: url(images/icon14.png);">
								<h6>V1 : VALEUR INDICATIVE</h6>
								<span class="rate">152 500 &euro;</span>
								<div class="toggleOpen">
									<div class="range2">
										<span class="plusMinus" data-toggle="modal" data-target="#rangeModal"></span>										<span class="plusMinus minus" data-toggle="modal" data-target="#rangeModal"></span>										<input type="text" value="5"/>									</div>									<p>Cette valeur est celle indiquée par les sites internet les plus sérieux et fiable, elle est  appelée valeur  indicative.</p>									<span href="#" class="valeurBtn">Créer la valeur</span>								</div>							</div>						</a>					</li>					<li><a data-toggle="tab" href="#purpalEvalueo">						<div class="purpal color" style="background-image: url(images/icon15.png);">							<h6>V2 : VALEUR D’USAGE</h6>							<span class="rate">152 500 &euro;</span>							<div class="toggleOpen">								<div class="range2">									<span class="plusMinus" data-toggle="modal" data-target="#rangeModal"></span>									<span class="plusMinus minus" data-toggle="modal" data-target="#rangeModal"></span>									<input type="text" value="5"/>								</div>								<p>Cette valeur s’appuie sur la valeur du terrain actualisée, et sur la valeur de reconstruction du bien fonction de son état actuel et des nouvelles normes de construction.</p>								<span href="#" class="valeurBtn">Créer la valeur</span>							</div>
						</div>
					</a></li>
					<li><a data-toggle="tab" href="#yellowEvalueo">
						<div class="yellow color" style="background-image: url(images/icon16.png);">							<h6>V3 : VALEUR PAR CAPITALISATION</h6>							<span class="rate">152 500 &euro;</span>							<div class="toggleOpen">								<div class="range2">									<span class="plusMinus" data-toggle="modal" data-target="#rangeModal"></span>									<span class="plusMinus minus" data-toggle="modal" data-target="#rangeModal"></span>									<input type="text" value="5"/>								</div>								<p>Cette valeur repose sur un rappot entre un loyer estimé, et un taux de rendement déterminé, cette valeur  repose sur le constat  que la valeur d’un bein et liée au revenue qu’il peut en pronner.</p>								<span href="#" class="valeurBtn">Créer la valeur</span>							</div>						</div>					</a></li>					<li>						<a data-toggle="tab" href="#redEvalueo">
							<div class="pink color"><!--style="background-image: url(images/icon17.png);"-->
								<h6>V4 : VALEUR COMPARIMO</h6>
								<span class="rate">152 500 &euro;</span>
								<div class="toggleOpen">
									<div class="ponderation">
										Pondération
										<ul>
											<li class="active"></li>
											<li></li>
											<li></li>
										</ul>
									</div>
									<p>Cette valeur consiste à établir la valeur d’un bien par comparaison  aux bien similaires par référence à la surface, nombre de piéces... Nous prenons donc la moyenne des prix des  biens comparables mis en vente en temps  réel</p>
									<span href="#" class="valeurBtn">Créer la valeur</span>
								</div>
							</div>
						</a>					</li>					<li>						<a data-toggle="tab" href="#graydEvalueo">
							<div class="Graycolor color"> <!--style="background-image: url(images/icon17.png);"--> 
								<h6>V5 : VALEUR COMPARIMO BIEN VENDU</h6>
								<span class="rate">152 500 &euro;</span>
								<div class="toggleOpen">
									<div class="ponderation">
										Pondération
										<ul>
											<li class="active"></li>
											<li></li>
											<li></li>
										</ul>
									</div>
									<p>Cette valeur consiste à établir la valeur d’un bien par comparaison  aux bien similaires par référence à la surface, nombre de piéces... Nous prenons donc la moyenne des prix des  biens comparables mis en vente en temps  réel</p>
									<span href="#" class="valeurBtn">Créer la valeur</span>
								</div>
							</div>
						</a>					</li>
					<li>
						<div class="color blue">
							<span>EVALUEO</span>
							<span>455 000 &euro;</span>
						</div>
					</li>
				</ul>
			</div>
			<div class="tab-content">
				<div id="greenEvalueo" class="item tab-pane fade in active">					<?php include('evalueo-les-valeurs-indicative.php');?>				</div>				<div id="purpalEvalueo" class="item tab-pane fade">					<?php include('evalueo-les-valeurs-D-usage.php');?>				</div>
				<div id="yellowEvalueo" class="item tab-pane fade">					<?php include('evalueo-les-valeurs-capitalisation.php');?>				</div>				<div id="redEvalueo" class="item tab-pane fade">					<?php include('evalueo-les-valeurs-comparimo.php');?>				</div>				<div id="graydEvalueo" class="item tab-pane fade">					<?php include('evalueo-les-valeurs-evalueo-bien.php');?>				</div>
			</div>
		</aside>
	</div>
</div>