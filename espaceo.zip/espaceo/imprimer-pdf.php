<!doctype html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=0," />
<meta name="SKYPE_TOOLBAR" content="SKYPE_TOOLBAR_PARSER_COMPATIBLE"/>

<title>Espaceo</title>

	<link rel="icon" type="image/png" href="images/favicon.png">
	<link href="https://fonts.googleapis.com/css?family=Raleway:300,400,500,600,700" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Josefin+Sans:300,400,600" rel="stylesheet">  
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/global.css">
</head>

<body>
<div id="wrapper">
<div class="evalueo">
	<div class="container">
		<div class="row">
			<aside class="item col-xs-12 col-sm-12 col-md-12 col-lg-12">
				<div id="offrimo-imprimer-pdf" class="repport-pdf offrimo-imprimer-pdf">
					<!-- Start: page 1 -->
					<div class="page">
						<div class="header-blue">
							<div class="cell">
								<img src="pdf/limmolier1.png"/>
							</div>
							<div class="col">
								<h5>5 PIÈCES DE 185 M²</h5>
								<h1>Propriété d’exception sur un terrain clos</h1>
								<h6>Situé à SCIEZ<br>Réf : Df74389</h6>
							</div>
							<div class="cell">
								<img src="pdf/ecconomi.png"/>
							</div>
						</div>
						<div class="row terrain">
							<div class="col col-xs-12 col-sm-6 col-md-6 col-lg-6">
								<div class="border">
									<div class="img" style="background-image: url(pdf/pic16.jpg);"></div>
								</div>
								<div class="border">
									<div class="img" style="background-image: url(pdf/pic17.jpg);"></div>
								</div>
							</div>
							<div class="col col-xs-12 col-sm-6 col-md-6 col-lg-6">
								<div class="border full">
									<div class="img" style="background-image: url(pdf/pic18.jpg);">
										<div class="bottom">
											<h1>819 000 &euro;</h1>
											<p>* Frais d'agence inclus à la charge du vendeur</p>
										</div>
									</div>
								</div>
							</div>
							<div class="clear"></div>
							<div class="col col-xs-12 col-sm-3 col-md-3 col-lg-3">
								<div class="border">
									<ul>
										<li><img src="pdf/house.png"/>Type de bien : Maison</li>
										<li><img src="pdf/icon16.png"/>Nombre de pièces : 5</li>
										<li><img src="pdf/icon15.png"/>Surface terrain : 1680 m²</li>
										<li><img src="pdf/icon17.png"/>Surface habitable : 185 m²</li>
										<li><img src="pdf/icon14.png"/>Surface utile : 185 m²</li>
									</ul>
								</div>
							</div>
							<div class="col col-xs-12 col-sm-9 col-md-9 col-lg-9">
								<div class="border">
									<div class="text">
										<p>Dans le calme champêtre de Sciez venez découvrir cete propriété d’exception sur un terrain clos et arboré de 1680 m² avec piscine.</p>
										<p>La maison de 185 m² habitables dispose d’un espace de vie de 60 m² composée d’une cuisine américaine ouverte sur le séjour donnant sur la terrasse vitrée.</p>
										<p>1 suite au RDC avec SDB douche - 1 grande chambre et dressing - à l’étage 2 grandes chambres traversantes - 1 SDB - 1 terrasse en tropézienne - en demi étage inférieur :</p>
										<p>1 grande buanderie avec douche - 1 bureau poss chambre - grand garage 2 voitures atelier - la propriété dispose de 6 parkings couverts</p>
									</div>
								</div>
							</div>
							<div class="col col-xs-12 col-sm-12 col-md-12 col-lg-12">
								<div class="border">
									<h5>Dans la ville de Sciez:</h5>
									<div class="sciez">
										<ul>
											<li class="yello">
												<span><img src="pdf/cheers.png"/></span>
												<strong>Si on sortait ?</strong>
												<p>Restaurant (2) Monument historique (2) Bibliothèque (1) Terrain et Salle de sport (9)</p>
											</li>
											<li class="syan">
												<span><img src="pdf/bus.png"/></span>
												<strong>Utiliser des transport ?</strong>
												<p>Parking (3) Station service (2)</p>
											</li>
											<li class="orange">
												<span><img src="pdf/shopping-cart.png"/></span>
												<strong>Faites vos courses !</strong>
												<p>Supermarché et Hypermarché (2) Bureau de poste (1) Boucherie (1) Boulangerie (4)</p>
											</li>
											<li class="green">
												<span><img src="pdf/heart-outline.png"/></span>
												<strong>Votre santé d’abord !</strong>
												<p>Médecin généraliste (5) Pharmacie (1)</p>
											</li>
											<li class="purpul">
												<span><img src="pdf/university-cap.png"/></span>
												<strong>Aller à l’école ...</strong>
												<p>Ecole primaire (2) Crèche (1)</p>
											</li>
										</ul>
									</div>
								</div>
							</div>
						</div>
						<!-- water mark -->
						<div class="text-center bottom">
							<h2>L’IMMOBILIER :</h2>
							<p>Tél : 04 57 43 00 49  / 04 57 43 00 50  -  contact@limmobilier.net  -  www.limmobilier.net <br> Adresse : 2 Avenue du Lac - 74140 Douvaine</p>
						</div>
						<!-- water mark -->
					</div>
					<!-- End: page 1 -->					
				</div>
			</aside>
		</div>
	</div>
</div>
</body>
</html>