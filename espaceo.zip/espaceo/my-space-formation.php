<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
	<h1>Formation</h1>
</div>