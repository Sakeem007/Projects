<article class="Prospectimo">
	<div class="container">
		<nav class="nav nav-tab child-nav-tab">
			<ul>
				<li class="active"><a href="#prospectimo-majbals" data-toggle="tab">MAJ BALs <span>"Créer et suivre ses BALs"</span></a>
				</li>
				<li><a href="#prospectimo-reportingbals" data-toggle="tab">Reporting BALs <span>"Consulter ses statistiques"</span></a>
				</li>
				<li><a href="#prospectimo-apporteur-affaires" data-toggle="tab">Apporteur Affaires <span>"Suivre ses apporteurs et leurs indications"</span></a>
				</li>
			</ul>
		</nav>
		<div class="tab-content">
			<div id="prospectimo-majbals" class="item tab-pane fade in active">
				<div class="row">
					<?php include('observimo-prospectimo-majbals.php');?>
				</div>
			</div>
			<div id="prospectimo-reportingbals" class="item tab-pane fade">
				<div class="row">
					<?php include('observimo-prospectimo-reportingbals.php');?>
				</div>
			</div>
			<div id="prospectimo-apporteur-affaires" class="item tab-pane fade">
				<div class="row">
					<?php include('observimo-prospectimo-apporteur-affaires.php');?>
					</div>
				</div>
			</div>
		</div>
</article>