<?php include('header.php');?>	
<!-- Being: observimo box -->
<article class="observimoBox">
	<div class="container">			
		
		<nav class="nav nav-tab">
			<ul>
				<li class="active"><a href="#Sectorimo" data-toggle="tab">Sectorimo</a></li>
				<li><a href="#Prospectimo" data-toggle="tab">Prospectimo</a></li>
				<li><a href="#Urbanimo" data-toggle="tab">Urbanimo</a></li>
				<li><a href="#MLN" data-toggle="tab">MLN</a></li>
				<li><a href="#SectorimoParameter" data-toggle="tab">Sectorimo Parameter</a></li>
			</ul>
		</nav>
		<div class="tab-content">
			<div id="Sectorimo" class="item tab-pane fade in active">
				<div class="row">
					<div class="tab-content">
						<div id="Territoires_Agents" class="item tab-pane fade in active">
							<?php include('observimo-sectorimo.php');?>
						</div>			
					</div>
				</div>
			</div>
			<div id="Prospectimo" class="item tab-pane fade">
				<div class="row">					
					<div class="tab-content">
						<?php include('observimo-prospectimo.php');?>
					</div>
				</div>
			</div>
			<div id="Urbanimo" class="item tab-pane fade">
				<div class="row">	
					<div class="tab-content">
						<?php include('observimo-urbanimo.php');?>
					</div>
				</div>
			</div>
			<div id="MLN" class="item tab-pane fade">
				<div class="row">	
					<div class="tab-content">
						<?php include('observimo-mln.php');?>
					</div>
				</div>
			</div>
			<div id="SectorimoParameter" class="item tab-pane fade">
				<div class="row">	
					<?php include('observimo-sectorimo-parameter.php');?>
				</div>
			</div>
		</div>
		
	</div>
</article>
<!-- End: observimo box -->
<?php include('footer.php');?>
<?php include('modal.php');?>