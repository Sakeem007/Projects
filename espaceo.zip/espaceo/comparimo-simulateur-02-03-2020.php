<div class="simulateur">
	<div class="banners" style="background-image: url(images/bg-4.jpg);">
		<h2>Chercher un bien (Maisons & Appartements)</h2>
		<p>parmi plus de 65037 annonces immobilieres en haute Savoie</p>
		<h5>Je veux consulter les 
		<select>
			<option>Maisons/Appartements</option>
			<option>Maisons/Appartements</option>
		</select>  a 
		<select data-placeholder="ville,code postal" multiple="" name="address[]" class="select select2-hidden-accessible" tabindex="-1" aria-hidden="true">
			<option value="">(Toutes les villes) </option>
			<option value=""></option>
			<option value="74000">(Toutes les villes) 74000</option>
			<option value="74100">(Toutes les villes) 74100</option>
			<option value="74120">(Toutes les villes) 74120</option>
			<option value="74140">(Toutes les villes) 74140</option>
			<option value="74170">(Toutes les villes) 74170</option>
			<option value="74190">(Toutes les villes) 74190</option>
			<option value="74210">(Toutes les villes) 74210</option>
			<option value="74270">(Toutes les villes) 74270</option>
		</select>  avec un rayon de 
		<input type="text" name="distance" placeholder="Kms" id="distance" value=""> et je peux ajouter <span class="maisons_de_criteres_btn">+ de criteres</span></h5>
		<a href="#" class="whiteBtn">Lancer recherche</a>
		<a href="#" class="whiteBtn">Lancer recherche et creer une requete</a>
		
		<div id="maisons_de_criteres_form" class="expend-form">
			<div class="form">
				<h4>Simulez votre annonce test</h4>
				<form action="#" method="post">
					<div class="reapter">
						<div class="left">
							<h5>Votre bien</h5>
						</div>
						<div class="right">
							<div class="row">
								<div class="first col-xs-12 col-sm-3 col-md-3 col-lg-3">
									<label><span>Ville:</span><span><input type="text" value=""/></span></label>
									<label><span>Type:</span><span><input type="text" value=""/></span></label>
								</div>
								<div class="second col-xs-12 col-sm-5 col-md-5 col-lg-5">
									<label><span>Adresse:</span><span><input type="text" value=""/></span></label>
									<label class="sort"><span>Surface habitable:</span><span><input type="text" value=""/></span></label>
									<label class="sort"><span>Nbr de pieces:</span><span><input type="text" value=""/></span></label>
								</div>
								<div class="third col-xs-12 col-sm-4 col-md-4 col-lg-4">
									<label><span>Code postal:</span><span><input type="text" value=""/></span></label>
									<label><span>Prix envisage:</span><span><input type="text" value=""/></span></label>
								</div>
							</div>
						</div>
					</div>
					<div class="reapter">
						<div class="left">
							<h5>Vos coordonnees</h5>
						</div>
						<div class="right">
							<div class="row">
								<div class="first col-xs-12 col-sm-3 col-md-3 col-lg-3">
									<label><span>Nom:</span><span><input type="text" value=""/></span></label>
									<label><span>Tel:</span><span><input type="text" value=""/></span></label>
								</div>
								<div class="second col-xs-12 col-sm-5 col-md-5 col-lg-5">
									<label><span>Adresse:</span><span><input type="text" value=""/></span></label>
									<label><span>E-mail:</span><span><input type="text" value=""/></span></label>
								</div>
								<div class="third col-xs-12 col-sm-4 col-md-4 col-lg-4">
									<label><span>Code postal:</span><span><input type="text" value=""/></span></label>
									<label><span>Facebook:</span><span><a href="#" class="facebookBtn">facebook<small>Connectez-vous avec Facebook</small></a></span></label>
								</div>
							</div>
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
	<div class="filter">
		<form action="#" method="post">
			<ul>
				<li>Filtre :</li>
				<li><select>
					<option hidden>Annouce</option>
					<option value="Actives">Actives</option>
					<option value="Acroches">Acroches</option>
					<option value="Archiver">Archiver</option>
				</select></li>
				<li><select>
					<option hidden>Prix</option>
					<option value="">Buisses</option>
					<option value="">Multi</option>
				</select></li>
				<li><select>
					<option hidden>Date</option>
					<option value="New">New</option>
					<option value="15 Day">15 Day</option>
					<option value="30 Day">30 Day</option>
				</select></li>
				<li><select>
					<option hidden>Mon equipe</option>
					<option value="Mon equipe">Mon equipe</option>
					<option value="Mon equipe">Mon equipe</option>
				</select></li>
				<li class="btns"><button type="submit" class="submit"></button></li>
			</ul>
		</form>
	</div>
	<div class="comparimoBox">
		<div class="nav nav-tab">
			<ul>
				<li class="active"><a href="#Tous_les_biens" data-toggle="tab">Simulateur Online</a></li>
				<li><a href="#Top_RANKIMO" data-toggle="tab">Accroche Con..</a></li>
				<div class="panel">		
					<?php include('comparimo-simulateur-rankimo.php');?>
				</div>
				<li><a href="#ScannerunBien" data-toggle="tab">Scaner un bien</a></li>
				<div class="panel">					
					<?php include('comparimo-simulateur-analyse.php');?>					
				</div>
			</ul>
		</div>
		<div class="tab-content">
			<div id="Tous_les_biens" class="item tab-pane fade in active">
				<div class="row">
					<?php include('comparimo-scannerunbien.php');?>
				</div>
			</div>
			<div id="Top_RANKIMO" class="item tab-pane fade">
				<div class="row">
					<?php include('comparimo-simulateur-rankimo.php');?>
				</div>
			</div>
			<div id="ScannerunBien" class="item tab-pane fade">
				<div class="row">
					<?php include('comparimo-simulateur-tous-les-biens.php');?>
				</div>
			</div>
		</div>
	</div>
</div>