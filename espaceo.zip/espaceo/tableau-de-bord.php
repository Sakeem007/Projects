<div class="CallimoDashboardBox">
	<div class="tableColum col-xs-12 col-sm-12 col-md-12 col-lg-12">
		<ul>
			<li>
				<div class="col-xs-12 col-sm-9 col-md-9 col-lg-9"><strong>Total des demandes de suivis</strong>Dernière demande du 10/04/2019</div>
				<div class="col-xs-12 col-sm-1 col-md-1 col-lg-1"><span>71</span></div>
			</li>
			<h3>Suivis par secteurs</h3>			
			<li>
				<div class="col-xs-12 col-sm-9 col-md-9 col-lg-9"><strong>Douvaine & environs</strong>Dernière demande du 10/04/2019</div>
				<div class="col-xs-12 col-sm-1 col-md-1 col-lg-1"><span>36</span></div>
				<div class="col-xs-12 col-sm-2 col-md-2 col-lg-2"><a href="javascript:void(0);">Passer au suivi</a></div>
			</li>	
			<li>
				<div class="col-xs-12 col-sm-9 col-md-9 col-lg-9"><strong>Annemasse & environs</strong>Dernière demande du 10/04/2019</div>
				<div class="col-xs-12 col-sm-1 col-md-1 col-lg-1"><span>03</span></div>
				<div class="col-xs-12 col-sm-2 col-md-2 col-lg-2"><a href="javascript:void(0);">Passer au suivi</a></div>
			</li>	
			<li>
				<div class="col-xs-12 col-sm-9 col-md-9 col-lg-9"><strong>Thonon & environs</strong>Dernière demande du 10/04/2019</div>
				<div class="col-xs-12 col-sm-1 col-md-1 col-lg-1"><span>25</span></div>
				<div class="col-xs-12 col-sm-2 col-md-2 col-lg-2"><a href="javascript:void(0);">Passer au suivi</a></div>
			</li>	
			<li>
				<div class="col-xs-12 col-sm-9 col-md-9 col-lg-9"><strong>Annecy & environs</strong>Dernière demande du 10/04/2019</div>
				<div class="col-xs-12 col-sm-1 col-md-1 col-lg-1"><span>05</span></div>
				<div class="col-xs-12 col-sm-2 col-md-2 col-lg-2"><a href="javascript:void(0);">Passer au suivi</a></div>
			</li>	
			<li>
				<div class="col-xs-12 col-sm-9 col-md-9 col-lg-9"><strong>Bourgoin & environs</strong>Dernière demande du 10/04/2019</div>
				<div class="col-xs-12 col-sm-1 col-md-1 col-lg-1"><span>10</span></div>
				<div class="col-xs-12 col-sm-2 col-md-2 col-lg-2"><a href="javascript:void(0);">Passer au suivi</a></div>
			</li>	
			<li>
				<div class="col-xs-12 col-sm-9 col-md-9 col-lg-9"><strong>Genève & environs</strong>Dernière demande du 10/04/2019</div>
				<div class="col-xs-12 col-sm-1 col-md-1 col-lg-1"><span>16</span></div>
				<div class="col-xs-12 col-sm-2 col-md-2 col-lg-2"><a href="javascript:void(0);">Passer au suivi</a></div>
			</li>
		<ul>
	</div>
</div>