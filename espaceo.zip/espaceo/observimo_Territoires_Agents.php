<div class="sectorimo_territoires">
	<div class="row">
		<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
			<form class="spec-filter">
				<h5>ParamÃ¨tre ma zone dâ€™activitÃ© commerciale</h5> 
				<input type="text" name="" placeholder="Search by: zac, Territory, leader, manager..."> <span class="or">Or</span> 
				<select>
					<option value="Select Filter">Select Filter</option>
					<option value="Select Filter">Select Filter</option>
					<option value="Select Filter">Select Filter</option>
					<option value="Select Filter">Select Filter</option>
					<option value="Select Filter">Select Filter</option>
					<option value="Select Filter">Select Filter</option>
				</select>
				<button type="submit">Submit</button>
			</form>
		</div>
	</div>
	<div class="row accordian_main_wrapper">
		<aside class="zac">
			<div class="accordian">
				<div class="col-lg-8 col-md-8 col-sm-8 col-xs-12">
					<ul>
						<li>
							<h3 class="title"><span class="fa fa-plus"></span> Zac1 <b>Leader Name</b></h3> 
							<ul>
								<li><a href="#">Territory <span>Manager Name</span></a>
								</li>
								<li><a href="#">Territory2 <span>Manager Name</span></a>
								</li>
								<li><a href="#">Territory3 <span>Manager Name</span></a>
								</li>
								<li><a href="#">Territory4 <span>Manager Name</span></a>
								</li>
							</ul>
						</li>
						<li>
							<h3 class="title"><span class="fa fa-plus"></span> Zac2 <b>Leader Name</b></h3> 
							<ul>
								<li><a href="#">Territory <span>Manager Name</span></a>
								</li>
								<li><a href="#">Territory2 <span>Manager Name</span></a>
								</li>
								<li><a href="#">Territory3 <span>Manager Name</span></a>
								</li>
								<li><a href="#">Territory4 <span>Manager Name</span></a>
								</li>
							</ul>
						</li>
						<li>
							<h3 class="title"><span class="fa fa-plus"></span> Zac3 <b>Leader Name</b></h3> 
							<ul>
								<li><a href="#">Territory <span>Manager Name</span></a>
								</li>
								<li><a href="#">Territory2 <span>Manager Name</span></a>
								</li>
								<li><a href="#">Territory3 <span>Manager Name</span></a>
								</li>
								<li><a href="#">Territory4 <span>Manager Name</span></a>
								</li>
							</ul>
						</li>
					</ul>
				</div>
			</div>
		</aside>
		<div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 manager_right_section">
			<div class="accordian">
				<ul>
					<li>
						<h3 class="title"><span class="fa fa-plus"></span> Leader Name </h3> 
						<ul>
							<li><a href="#">Manager Name</a>
							</li>
							<li><a href="#">Manager Name</a>
							</li>
							<li><a href="#">Manager Name</a>
							</li>
							<li><a href="#">Manager Name</a>
							</li>
						</ul>
					</li>
					<li>
						<h3 class="title"><span class="fa fa-plus"></span> Leader Name </h3> 
						<ul>
							<li><a href="#">Manager Name</a>
							</li>
							<li><a href="#">Manager Name</a>
							</li>
							<li><a href="#">Manager Name</a>
							</li>
							<li><a href="#">Manager Name</a>
							</li>
						</ul>
					</li>
					<li>
						<h3 class="title"><span class="fa fa-plus"></span> Leader Name </h3> 
						<ul>
							<li><a href="#">Manager Name</a>
							</li>
							<li><a href="#">Manager Name</a>
							</li>
							<li><a href="#">Manager Name</a>
							</li>
							<li><a href="#">Manager Name</a>
							</li>
						</ul>
					</li>
				</ul>
			</div>
		</div>
		<aside class="territory col-xs-12 col-sm-4 col-md-4 col-lg-4" style="display: none;">
			<div class="accordian">
				<ul class="Territory_details">
					<li>
						<h3 class="title headdin">Territory <b>Manager Name</b></h3> 
					</li>
					<li>
						<h3 class="title"><span class="fa fa-plus"></span> Sector Priority (1200) <b>Agent Name</b></h3> 
						<ul class="details_list" style="display: block !important;">
							<h4>Sorty By A-Z</h4> 
							<li><a href="#"><b>A</b> Bottolate- address </a>
							</li>
							<li><a href="#"><b>B</b> Bottolate- address </a>
							</li>
							<li><a href="#"><b>C</b> Bottolate- address </a>
							</li>
							<li><a href="#"><b>D</b> Bottolate- address </a>
							</li>
						</ul>
					</li>
					<li>
						<h3 class="title"><span class="fa fa-plus"></span> Sector Secondry (1200) </h3> 
						<ul class="details_list">
							<h4>Sorty By A-Z</h4> 
							<li><a href="#"><b>A</b> Bottolate- address </a>
							</li>
							<li><a href="#"><b>B</b> Bottolate- address </a>
							</li>
							<li><a href="#"><b>C</b> Bottolate- address </a>
							</li>
							<li><a href="#"><b>D</b> Bottolate- address </a>
							</li>
						</ul>
					</li>
				</ul>
			</div>
		</aside>
		<aside class="information-bx col-xs-12 col-sm-8 col-md-8 col-lg-8" style="display: none;">Information</aside>	
	</div>
</div>
	<div class="form_button_wrapper">
		<ul>
			<!--<li><a data-toggle="modal" data-target="#myModal">Add Territory</a></li>-->
			<li><a href="#Observimo-Add-Member" data-toggle="modal" data-backdrop="true">Member</a>
			</li>
			<li><a href="#Observimo-Create-New-Region" data-toggle="modal" data-backdrop="true">Créer une nouvelle Région</a>
			</li>
		</ul>
	</div>