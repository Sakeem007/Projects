</main>
<!-- End: middle wrapper -->

<!-- Being: footer wrapper-->
<footer id="footerWrapper">
		
	<!-- Being: footer box -->
	<article class="copyBox">
		<div class="container">
			<div class="copy">
				<p>© 2018 espaceo.com	| <a href="#">Terms of Use</a> | <a href="#">Privacy Policy</a></p>
			</div>
		</div>
	</article>
	<!-- End: footer box -->	
</footer>
<!-- End: footer wrapper -->
</div>
<?php include('modal.php');?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
<!--script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script-->
<!--script src="js/kendo.all.min.js"></script-->
<script src="js/bootstrap.min.js"></script>
<script src="js/owl.carousel.js"></script>
<script type="text/javascript" src="js/interactions.min.js"></script>
<script type="text/javascript" src="js/select2.min.js"></script>
<script type="text/javascript" src="js/form_select2.js"></script>
<script src="js/global.js"></script>          <script>            $(document).ready(function() {              var owl = $('.owl-carousel');              owl.owlCarousel({                loop: false,                margin: 10,                nav: true,                navRewind: false,				slideBy: 1,                responsive: {                  0: {                    items: 1                  },                  480: {                    items: 1                  },                  767: {                    items: 2                  },                  1000: {                    items: 3                  }                }              })            }) 				</script>
</body>
</html>