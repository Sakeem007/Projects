<div class="evalueo">
	<div class="row">
		<aside class="item col-xs-12 col-sm-8 col-md-9 col-lg-9">
			<div id="all-repport-pdf" class="repport-pdf">
				<!-- Start: page 1 -->
				<div class="page">
					<!-- water mark -->
					<div class="whater-mark top">
						<span class="pull-left">05/12/2017</span>
						app.espaceo.net/client/evalueo/go_print/restore/308
					</div>
					<!-- water mark -->
					<div class="top">
						<div class="logo"><img src="images/logo1.png"/></div>
						<div class="rightText">
							<h2>
								<span>MARCHE IMMOBILIER</span>
								<em>NOTER AVIS DE VALEUR</em>
								<em> EVALUE<sup>&copy;</sup></em>
							</h2>
						</div>
					</div>
					<div class="photo-upload" id="photo_du_bien">
						<div class="photo">
							<label><input type="file" /></label>
							<div class="left-border">
								<h6>Votre bien:</h6>
								<p>maison - 291m<sup>2</sup> 74140, massongy</p>
							</div>
						</div>
						<div class="bottom-arrow-bg">
							<div class="left-border">
								<ul>
									<li>A la demande de:</li>
									<li>Votre Home Conseiller: Mr. Philips Soulie</li>
									<li>Fait le: 5 Decembre 2017</li>
								</ul>
							</div>
						</div>
					</div>
					<!-- water mark -->
					<div class="whater-mark bottom">
						<span class="pull-left">http://app.espaceo.net/client/evalueo/go_print/restore/308</span>
						<span class="pull-right">01/09</span>
					</div>
					<!-- water mark -->
				</div>
				<!-- End: page 1 -->
				<!-- Start: page 2 -->
				<div class="page">
					<!-- water mark -->
					<div class="whater-mark top">
						<span class="pull-left">05/12/2017</span>
						app.espaceo.net/client/evalueo/go_print/restore/308
					</div>
					<!-- water mark -->
					
					<div class="titles active">
						<span>1</span>
						Sommaire
					</div>
					<div class="sommaire">
						<h1>Sommaire</h1>
					</div>
					
					<div class="titles">
						<span>1</span>
						Sommaire
					</div>
					<div class="titles">
						<span>2</span>
						Les applications qui composent EVALUEO
					</div>
					<div class="titles">
						<span>3</span>
						Notre application EVALUEO
					</div>
					<div class="titles">
						<span>4</span>
						Les données indiquées pour votre bien
					</div>
					<div class="titles">
						<span>5</span>
						Tout savoir sur votre ville grâce à OBSERVIMO
					</div>
					<div class="titles">
						<span>6</span>
						Le résultat de notre évaluation "le meilleur prix du marché en temps réel"
					</div>
					<div class="titles">
						<span>7</span>
						Liste des biens comprebles moins chers
					</div>
					<div class="titles">
						<span>8</span>
						Notre proposition commerciale
					</div>
					<div class="titles">
						<span>9</span>
						Solucimo
					</div>		
					<!-- water mark -->
					<div class="whater-mark bottom">
						<div class="home-conseiller">
							<div class="col col-xs-12 col-sm-2 col-md-2 col-lg-2">
								<img src="pdf/limmolier.png"/>
							</div>
							<div class="col col-xs-12 col-sm-5 col-md-6 col-lg-6">
								<ul>
									<li>Votre Home Conseiller</li>
									<li>Mr.Philippe Soulie</li>
									<li>Tél : 06457430050</li>
									<li>Email : philippe.soulie@limmobilier.net</li>
								</ul>
							</div>
							<div class="col col-xs-12 col-sm-5 col-md-4 col-lg-4">
								<ul>
									<li>Notre Réseau</li>
									<li>Tél. : 06457430050</li>
									<li>E-mail : contact@limmobilier.net</li>
									<li>Site web : https://www.limmobilier.net</li>
									<li>Adresse : 2 Avenue du Lac 74140 Douvaine</li>
								</ul>
							</div>
						</div>
						<span class="pull-left">http://app.espaceo.net/client/evalueo/go_print/restore/308</span>
						<span class="pull-right">02/09</span>
					</div>
					<!-- water mark -->
				</div>
				<!-- End: page 2 -->
				<!-- Start: page 3 -->
				<div class="page">
					<!-- water mark -->
					<div class="whater-mark top">
						<span class="pull-left">05/12/2017</span>
						app.espaceo.net/client/evalueo/go_print/restore/308
					</div>
					<!-- water mark -->
					
					<div class="titles active">
						<span>2</span>
						Les applications qui composent EVALUEO
					</div>
					
					<div class="title-blue">
						<span>ETUDEO</span>
						Votre étude de marché
					</div>
					<div class="row">
						<div class="etudeo">
							<p>Nous pouvons étudier votre marché local grâce aux applications:</p>
							<p> </p>
							<p><strong>OFFRIMO© </strong> :Nous visualisons toute l’offre immobilière de votre secteur en temps réel</p>
							<p><strong>RANKIMO© </strong> :Nous classons toute l’offre immobilière,</p>
							<p><strong>COMPARIMO© </strong> :Nous comparons toute l’offre immobilière comparable à votre bien,</p>
							<p><strong>OBSERVIMO© </strong> :Nous valorisons l’environnement de votre bien</p>
						</div>
					</div>
					
					<div class="title-blue">
						<span>DECOUVRIMO VENDEUR</span>
						Tout savoir sur votre bien
					</div>
					<div class="row">
						<div class="etudeo">
							<p>Nous avons noté lors de notre premier RDV, toutes les caractéristiques de votre bien, ce qui nous permet de personnaliser votre EVALUEO©</p>
						</div>
						<div class="col col-xs-12 col-sm-4 col-md-4 col-lg-4">
							<img src="pdf/pic7.png"/>
						</div>
						<div class="col col-xs-12 col-sm-8 col-md-8 col-lg-8">
							<div class="blue-bg">
								<p>Nous plaçons votre logement au centre de notre évaluation, en tenons compte des caractéristiques de votre habitation.</p>
							</div>
						</div>
					</div>
						
					<div class="title-blue">
						<span>URBANIMO©</span>
						Tout savoir sur l’environnement de votre bien
					</div>
					<div class="row">
						<div class="etudeo">
							<p>Nous plaçons également votre logement au cœur de son environnement, en tenant compte des caractéristiques et des spéci×cités de votre ville, et de votre quartier.</p>
						</div>
						<div class="col col-xs-12 col-sm-4 col-md-4 col-lg-4">
							<img src="pdf/pic1.png"/>
						</div>
						<div class="col col-xs-12 col-sm-8 col-md-8 col-lg-8">
							<div class="blue-bg">
								<p>Nous prenons en compte les données environnementales de votre bien, avec les spéci×cités de votre ville, et de votre quartier. Ces données tiennent compte des 4 grandes thématiques:</p>
								<ul>
									<li>Mobilité</li>
									<li>Commerces</li>
									<li>Loisirs</li>
									<li>Services et équipements</li>
								</ul>
							</div>
						</div>
					</div>
					<!-- water mark -->
					<div class="whater-mark bottom">
						<div class="home-conseiller">
							<div class="col col-xs-12 col-sm-2 col-md-2 col-lg-2">
								<img src="pdf/limmolier.png"/>
							</div>
							<div class="col col-xs-12 col-sm-6 col-md-6 col-lg-6">
								<ul>
									<li>Votre Home Conseiller</li>
									<li>Mr.Philippe Soulie</li>
									<li>Tél : 06457430050</li>
									<li>Email : philippe.soulie@limmobilier.net</li>
								</ul>
							</div>
							<div class="col col-xs-12 col-sm-4 col-md-4 col-lg-4">
								<ul>
									<li>Notre Réseau</li>
									<li>Tél. : 06457430050</li>
									<li>E-mail : contact@limmobilier.net</li>
									<li>Site web : https://www.limmobilier.net</li>
									<li>Adresse : 2 Avenue du Lac 74140 Douvaine</li>
								</ul>
							</div>
						</div>
						<span class="pull-left">http://app.espaceo.net/client/evalueo/go_print/restore/308</span>
						<span class="pull-right">03/09</span>
					</div>
					<!-- water mark -->
				</div>
				<!-- End: page 3 -->
				<!-- Start: page 4 -->
				<div class="page">
					<!-- water mark -->
					<div class="whater-mark top">
						<span class="pull-left">05/12/2017</span>
						app.espaceo.net/client/evalueo/go_print/restore/308
					</div>
					<!-- water mark -->
					
					<div class="titles active">
						<span>3</span>
						Notre application EVALUEO©
					</div>
					
					<div class="title-blue">
						<span>L'application EVALUEO©</span>
					</div>
					<div class="row">
						<div class="etudeo">
							<p>Cette application nous permet d’utiliser un puissant systéme de calculs et de comparaisons, s’appuyant sur les données du marché immobilier (toute l’offre) en temps reel. Nos avis de valuers, utilisent les données les plus fiables et les plus pertinentes du marché immobilier, actualisées en temps réel.</p>
						</div>
					</div>
					
					<div class="title-blue">
						<span>Principe de EVALUEO©</span>
					</div>
					<div class="row">
						<div class="etudeo">
							<p>EVALUEO© va réaliser une évaluation, en tenant compte des données et caractéristiques propres à votre bien, de l’environnement de votre bien, à savoir votre ville et votre quartier, mais aussi des tendances du marché actuel et des biens comparables au votre, en vente actuellement.</p>
						</div>
					</div>
						
					<div class="title-blue">
						<span>Methodologie de EVALUEO©</span>
					</div>
					<div class="row">
						<div class="text-center">
							<div class="methodologie col-xs-12 col-sm-3 col-md-3 col-lg-3">
								<div class="blue-header">
									Valeur<br> Indicative
								</div>
								<div class="gray-bg">
									<div class="img">
										<img src="pdf/icon14.png"/>
									</div>
									<p>5 chemin des grands conches, 74140 massongy,france à massongy 3207 €/m2 Prix m² indiqué par ville</p>
								</div>
							</div>
							<div class="methodologie col-xs-12 col-sm-3 col-md-3 col-lg-3">
								<div class="blue-header">
									Valeur<br> Technique
								</div>
								<div class="gray-bg">
									<div class="img">
										<img src="pdf/icon13.png"/>
									</div>
									<p>Sol + Construction <br><br> Valeur de reconstruction à neuf</p>
								</div>
							</div>
							<div class="methodologie col-xs-12 col-sm-3 col-md-3 col-lg-3">
								<div class="blue-header">
									Valeur<br> par Capitalisation
								</div>
								<div class="gray-bg">
									<div class="img">
										<img src="pdf/icon12.png"/>
									</div>
									<p>Rentabilité Locative <br><br> Valeur suivant le  rendement</p>
								</div>
							</div>
							<div class="methodologie col-xs-12 col-sm-3 col-md-3 col-lg-3">
								<div class="blue-header">
									Valeur par <br>Comparaison
								</div>
								<div class="gray-bg">
									<div class="img">
										<img src="pdf/icon11.png"/>
									</div>
									<p>Biens Comparable au votre Valeur suivant l’offre comparable</p>
								</div>
							</div>
							<div class="methodologie col-xs-12 col-sm-3 col-md-3 col-lg-3">
								<div class="blue-header">
									Valeur <br>Estimée
								</div>
								<div class="gray-bg">
									<div class="img">
										<img src="pdf/icon10.png"/>
									</div>
									<h5>Notre avis de valeur</h5>
								</div>
							</div>
						</div>
					</div>
					<h6>“Notre avis de valeur est la moyenne de 4 moyennes, pondérée par les caractéristiques de votre bien et de son environnement.”</h6>
					<!-- water mark -->
					<div class="whater-mark bottom">
						<div class="home-conseiller">
							<div class="col col-xs-12 col-sm-2 col-md-2 col-lg-2">
								<img src="pdf/limmolier.png"/>
							</div>
							<div class="col col-xs-12 col-sm-6 col-md-6 col-lg-6">
								<ul>
									<li>Votre Home Conseiller</li>
									<li>Mr.Philippe Soulie</li>
									<li>Tél : 06457430050</li>
									<li>Email : philippe.soulie@limmobilier.net</li>
								</ul>
							</div>
							<div class="col col-xs-12 col-sm-4 col-md-4 col-lg-4">
								<ul>
									<li>Notre Réseau</li>
									<li>Tél. : 06457430050</li>
									<li>E-mail : contact@limmobilier.net</li>
									<li>Site web : https://www.limmobilier.net</li>
									<li>Adresse : 2 Avenue du Lac 74140 Douvaine</li>
								</ul>
							</div>
						</div>
						<span class="pull-left">http://app.espaceo.net/client/evalueo/go_print/restore/308</span>
						<span class="pull-right">04/09</span>
					</div>
					<!-- water mark -->
				</div>
				<!-- End: page 4 -->
				<!-- Start: page 5 -->
				<div class="page">
					<!-- water mark -->
					<div class="whater-mark top">
						<span class="pull-left">05/12/2017</span>
						app.espaceo.net/client/evalueo/go_print/restore/308
					</div>
					<!-- water mark -->					
					<div class="titles active">
						<span>4</span>
						Les données indiquées pour votre bien
					</div>					
					<div class="title-blue">
						<em>OFFRIMO</em>
						Toute l'offre
						<label><input type="checkbox"/><em></em></label>
					</div>
					<div class="etudeo">
						<ul>
							<li>Il y a 0 s pièces en vente à</li>
							<li>Il y en a 5 biens en vente dans un rayon de 5 Km et 22 dans un rayon de 10 Km</li>
							<li>Il y a 0 s pièces moins chers que la votre à ,il y en 3 moins chers dans un rayon de 5 Km et 15 dans un rayon de 10km</li>
						</ul>
					</div>					
					<div class="title-blue">
						<span>RANKIMO</span>
						Classement de l’offre
						<label><input type="checkbox"/><em></em></label>
					</div>
					<div class="etudeo">
						<ul>
							<li>Votre bien et classé :</li>
							<li><img src="pdf/icon9.png"/> - par rapport au biens comparables dans la meme ville</li>
							<li><img src="pdf/icon9.png"/> 3/5 dans un rayon de 5 KMs</li>
							<li><img src="pdf/icon9.png"/> 15/22 dans 10 KMs</li>
						</ul>
					</div>						
					<div class="title-blue">
						<span>COMPARIMO</span>
						Comparer l’offre
						<label><input type="checkbox"/><em></em></label>
					</div>
					<div class="etudeo">
						<div class="row">
							<div class="comparimo col-xs-12 col-sm-6 col-md-6 col-lg-6">
								<div class="blue-header">L'offre des biens comparables :</div>
								<div class="border">
									<ul>
										<li>Offre des biens comparables PAP : 0 biens, représente 0% de l’offre totale </li>
										<li>Offre des biens comparables PRO : 0 biens, représente 0% de l’offre totale</li>
										<li>Prix moyen des biens online comparables : 0€</li>
										<li>Prix moyen des biens ofØine comparables : 471875€</li>
										<li>Depuis le 01/01/2017 il y a un nombre de biens comparables de 0 biens </li>
										<li>Délai moyen de mise en ligne des biens comparabes : 0 jours</li>
										<li>En moyenne mensuelle, il y a en moyenne mensuelle 0 biens comparables, mis en ligne</li>
									</ul>
								</div>
							</div>
							
							<div class="comparimo col-xs-12 col-sm-6 col-md-6 col-lg-6">
								<div class="blue-header">Votre bien par rapport aux biens comparables :</div>
								<div class="border">
									<ul>
										<li>Nombre de biens comparables : 0 biens</li>
										<li>Meilleur prix du bien comparable online : €</li>
										<li>Meilleur prix du bien comparable ofØine : 410000€</li>
										<li>Prix du bien comparable online le plus élevé : € mis en ligne depuis jours:</li>
										<li>Votre bien est - des biens comparables</li>
										<li>Le prix de votre bien apparait
											<ul>
												<li>-100% supérieur à la moyenne des biens comparables online soit -712514€</li>
												<li>50% supérieur à la moyenne des biens comparables ofØine soit -240639€</li>
											</ul>
										</li>
									</ul>
								</div>
							</div>
						</div>
					</div>
					<div class="title-blue" id="decouvrimo">
						<em>DÉCOUVRIMO</em>
						Description de votre bien
					</div>
					<div class="row">
						<div class="col col-xs-12 col-sm-4 col-md-4 col-lg-4">
							<img src="pdf/pic7.png"/>
						</div>
						<div class="col col-xs-12 col-sm-8 col-md-8 col-lg-8">
							<div class="description">
								<ul>
									<li>
										<span>Type =</span>
										<span><input type="text" value="" /></span>
									</li>
									<li>
										<span>Année de construction =</span>
										<span><input type="text" value="" /></span>
									</li>
									<li>
										<span>Source de chaleur =</span>
										<span><input type="text" value="" /></span>
									</li>
									<li>
										<span>Type de chauffage =</span>
										<span><input type="text" value="" /></span>
									</li>
									<li>
										<span>Surface utile =</span>
										<span><input type="text" value="291m²" /></span>
									</li>
									<li>
										<span>Nombre de pièces =</span>
										<span><input type="text" value="7 piece" /></span>
									</li>
									<li>
										<span>Nombre de CHB =</span>
										<span><input type="text" value="6 chambres" /></span>
									</li>
									<li>
										<span>Surface du terrain =</span>
										<span><input type="text" value="2350m²" /></span>
									</li>
								</ul>
							</div>
						</div>
					</div>
					<div class="title-blue">
						<em>OBSERVIMO</em>
						Géolocalisation de votre bien
						<label><input type="checkbox"/><em></em></label>
					</div>
					<div class="observimo">
						<ul>
							<li><i class="fa fa-map-marker"></i> 0</li>
							<li><i class="fa fa-train"></i> 0</li>
							<li><i class="fa fa-bus"></i> 0</li>
							<li><i class="fa"><img src="pdf/icon5.png"/></i> 0</li>
							<li><i class="fa fa-graduation-cap"></i> 0</li>
							<li><i class="fa fa-user-md"></i> 0</li>
							<li><i class="fa fa-hospital-o"></i> 0</li>
						</ul>
					</div>
					<!-- water mark -->
					<div class="whater-mark bottom">
						<div class="home-conseiller">
							<div class="col col-xs-12 col-sm-2 col-md-2 col-lg-2">
								<img src="pdf/limmolier.png"/>
							</div>
							<div class="col col-xs-12 col-sm-6 col-md-6 col-lg-6">
								<ul>
									<li>Votre Home Conseiller</li>
									<li>Mr.Philippe Soulie</li>
									<li>Tél : 06457430050</li>
									<li>Email : philippe.soulie@limmobilier.net</li>
								</ul>
							</div>
							<div class="col col-xs-12 col-sm-4 col-md-4 col-lg-4">
								<ul>
									<li>Notre Réseau</li>
									<li>Tél. : 06457430050</li>
									<li>E-mail : contact@limmobilier.net</li>
									<li>Site web : https://www.limmobilier.net</li>
									<li>Adresse : 2 Avenue du Lac 74140 Douvaine</li>
								</ul>
							</div>
						</div>
						<span class="pull-left">http://app.espaceo.net/client/evalueo/go_print/restore/308</span>
						<span class="pull-right">05/09</span>
					</div>
					<!-- water mark -->
				</div>
				<!-- End: page 5 -->				
				<!-- Start: page 6 -->
				<div class="page">
					<!-- water mark -->
					<div class="whater-mark top">
						<span class="pull-left">05/12/2017</span>
						app.espaceo.net/client/evalueo/go_print/restore/308
					</div>
					<!-- water mark -->
					
					<div class="titles active">
						<span>5</span>
						Tout savoir sur votre ville
					</div>
					<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d11022.134475797046!2d6.324635246625228!3d46.319099115924466!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x478c6a43223ab387%3A0xcccaf95c6830ae0e!2sVers+la+Croix%2C+74140+Massongy%2C+France!5e0!3m2!1sen!2sin!4v1532347047708" width="100%" height="320" frameborder="0" style="border:0" allowfullscreen></iframe>
					<div class="savoir">
						<ul>
							<li>
								<div class="blue-header">SUPERFICIE DE LA VILLE</div>
								<div class="gray-bg">
									9.9
									<small>km2</small>
								</div>
							</li>
							<li>
								<div class="blue-header">POPULATION DE LA VILLE</div>
								<div class="gray-bg">
									1498
									<small>Habitans</small>
								</div>
							</li>
							<li>
								<div class="blue-header">POPULATION ACTIVE</div>
								<div class="gray-bg">
									1742
									<small>personnes</small>
								</div>
							</li>
							<li>
								<div class="blue-header">SUPERFICIE DE LA VILLE</div>
								<div class="gray-bg">
									50744
									<small>€/an</small>
								</div>
							</li>
							<li>
								<div class="blue-header">NOMBRE DE LOGEMENTS</div>
								<div class="gray-bg">
									673
									<small>logements</small>
								</div>
							</li>
							<li>
								<div class="blue-header">RÉSIDENCES PRINCIPALES</div>
								<div class="gray-bg">
									<small>logements</small>
								</div>
							</li>
							<li>
								<div class="blue-header">RÉSIDENCES SECONDAIRES</div>
								<div class="gray-bg">
									<small>logements</small>
								</div>
							</li>
							<li>
								<div class="blue-header">LOGEMENTS VACANT</div>
								<div class="gray-bg">
									<small>logements</small>
								</div>
							</li>
						</ul>
					</div>
					<!-- water mark -->
					<div class="whater-mark bottom">
						<div class="home-conseiller">
							<div class="col col-xs-12 col-sm-2 col-md-2 col-lg-2">
								<img src="pdf/limmolier.png"/>
							</div>
							<div class="col col-xs-12 col-sm-6 col-md-6 col-lg-6">
								<ul>
									<li>Votre Home Conseiller</li>
									<li>Mr.Philippe Soulie</li>
									<li>Tél : 06457430050</li>
									<li>Email : philippe.soulie@limmobilier.net</li>
								</ul>
							</div>
							<div class="col col-xs-12 col-sm-4 col-md-4 col-lg-4">
								<ul>
									<li>Notre Réseau</li>
									<li>Tél. : 06457430050</li>
									<li>E-mail : contact@limmobilier.net</li>
									<li>Site web : https://www.limmobilier.net</li>
									<li>Adresse : 2 Avenue du Lac 74140 Douvaine</li>
								</ul>
							</div>
						</div>
						<span class="pull-left">http://app.espaceo.net/client/evalueo/go_print/restore/308</span>
						<span class="pull-right">06/09</span>
					</div>
					<!-- water mark -->
				</div>
				<!-- End: page 6 -->
				<!-- Start: page 7 -->
				<div class="page">
					<!-- water mark -->
					<div class="whater-mark top">
						<span class="pull-left">05/12/2017</span>
						app.espaceo.net/client/evalueo/go_print/restore/308
					</div>
					<!-- water mark -->
					<div class="titles active">
						<span>6</span>
						Notre proposition commerciale "votre bien mieux vu et moins négocié
					</div>
					<div class="text-center">
						<h3>Résultat de notre estimation Evalueo©</h3>
						<p>5 chemin des grands conches, 74140 massongy,france, 6pieces de 291m²</p>
						
						<div class="scale">
							<p>
								<span>Evaluation Basse
									<i class="fa fa-map-marker"></i>
									169000 &euro;
								</span>
								<span>EVALUEO
									<i class="fa fa-map-marker"></i>
									<span id="offer-result3">180000 &euro;</span>
								</span>
								<span>Evaluation Haute
									<i class="fa fa-map-marker"></i>
									198000 &euro;
								</span>
							</p>
							<em><input id="offer-price3" type="range" min="169000" max="198000" value=""/></em>
						</div>
					</div>
					<div class="row">
						<div class="text-center scales">
							<div class="methodologie col-xs-12 col-sm-3 col-md-3 col-lg-3">
								<div class="blue-header">
									Valeur<br> Indicative
								</div>
								<div class="gray-bg">
									<div class="img">
										<img src="pdf/icon14.png"/>
									</div>
									<h3>642091 €</h3>
								</div>
							</div>
							<div class="methodologie col-xs-12 col-sm-3 col-md-3 col-lg-3">
								<div class="blue-header">
									Valeur<br> Technique
								</div>
								<div class="gray-bg">
									<div class="img">
										<img src="pdf/icon13.png"/>
									</div>
									<h3>665600 €</h3>
								</div>
							</div>
							<div class="methodologie col-xs-12 col-sm-3 col-md-3 col-lg-3">
								<div class="blue-header">
									Valeur<br> par Capitalisation
								</div>
								<div class="gray-bg">
									<div class="img">
										<img src="pdf/icon12.png"/>
									</div>
									<h3>712368 €</h3>
								</div>
							</div>
							<div class="methodologie col-xs-12 col-sm-3 col-md-3 col-lg-3">
								<div class="blue-header">
									Valeur par <br>Comparaison
								</div>
								<div class="gray-bg">
									<div class="img">
										<img src="pdf/icon11.png"/>
									</div>
									<h3>788500 €</h3>
								</div>
							</div>
							<div class="methodologie col-xs-12 col-sm-3 col-md-3 col-lg-3">
								<div class="blue-header">
									Valeur <br>Estimée
								</div>
								<div class="gray-bg">
									<div class="img">
										<img src="pdf/icon10.png"/>
									</div>
									<h3>712514€</h3>
								</div>
							</div>
						</div>
					</div>
					<div class="titles">
						<span>7</span>
						Liste des biens comprebles moins chers
						<label><input type="checkbox"/><em></em></label>
					</div>
					<div class="title-blue">
						<em>Recherch Motor</em>
					</div>
					<div class="row">
						<div class="recherch">
							<div class="col col-xs-12 col-sm-4 col-md-4 col-lg-4">
								<label style="background-image: url(pdf/pic1.png);"><input type="checkbox"/><em></em></label>
							</div>
							<div class="col col-xs-12 col-sm-4 col-md-4 col-lg-4">
								<label style="background-image: url(pdf/pic2.png);"><input type="checkbox"/><em></em></label>
							</div>
							<div class="col col-xs-12 col-sm-4 col-md-4 col-lg-4">
								<label style="background-image: url(pdf/pic1.png);"><input type="checkbox"/><em></em></label>
							</div>
						</div>
					</div>
					<!-- water mark -->
					<div class="whater-mark bottom">
						<div class="home-conseiller">
							<div class="col col-xs-12 col-sm-2 col-md-2 col-lg-2">
								<img src="pdf/limmolier.png"/>
							</div>
							<div class="col col-xs-12 col-sm-6 col-md-6 col-lg-6">
								<ul>
									<li>Votre Home Conseiller</li>
									<li>Mr.Philippe Soulie</li>
									<li>Tél : 06457430050</li>
									<li>Email : philippe.soulie@limmobilier.net</li>
								</ul>
							</div>
							<div class="col col-xs-12 col-sm-4 col-md-4 col-lg-4">
								<ul>
									<li>Notre Réseau</li>
									<li>Tél. : 06457430050</li>
									<li>E-mail : contact@limmobilier.net</li>
									<li>Site web : https://www.limmobilier.net</li>
									<li>Adresse : 2 Avenue du Lac 74140 Douvaine</li>
								</ul>
							</div>
						</div>
						<span class="pull-left">http://app.espaceo.net/client/evalueo/go_print/restore/308</span>
						<span class="pull-right">07/09</span>
					</div>
					<!-- water mark -->
				</div>
				<!-- End: page 7 -->
				<!-- Start: page 8 -->
				<div class="page">
					<!-- water mark -->
					<div class="whater-mark top">
						<span class="pull-left">05/12/2017</span>
						app.espaceo.net/client/evalueo/go_print/restore/308
					</div>
					<!-- water mark -->
					<div class="titles active">
						<span>8</span>
						Notre proposition commerciale
					</div>	
					<div class="title-blue">
						<em>Notre Mandat AKTIFIMO©</em>Pour booster la mise en vente de votre bien.
					</div>
					<div class="col col-xs-12 col-sm-12 col-md-12 col-lg-12">
						<p>Nous vous proposons d'etre le seul professionnel pour s'occuper de la vente de votre bien, pour qu'il soit mieux vu, moins négocié, et pour que nous puissions utiliser notre technique de vente en tout sérénité. Nous vous proposons un mandat AKTIFIMO© au prix de 200 000 € honoraires agence de 6% TTC inclus, soit un prix net vendeur de 188 679 €</p>
					</div>
					<div class="title-blue">
						<em>OPTIMEO©</em>Votre bien mieux présenter pour augmenter les contacts acheteurs.
					</div>
					<div class="col col-xs-12 col-sm-12 col-md-12 col-lg-12">
						<p>Nous allons tout metter en œuvre pour présenter le mieux possible votre bien. Pour cela, nous devons prendre les photos les plus représentatives, rédiger le texte publicitaire le plus pertinent possible, réaliser si possible des plans 2D et 3D, visites virtuelles à 360°, séquences par drone, tout cela pour créer le coup de cœur, car votre bien n’est pas à vendre il est à acheter !...</p>
					</div>
					<div class="title-blue">
						<em>MARKETIMO©</em>Votre bien plus diffuser pour augmenter les contacts acheteurs
					</div>
					<div class="col col-xs-12 col-sm-12 col-md-12 col-lg-12">
						<p>Après OPTIMEO© qui prépare la mise en commercialisation de votre bien, MARKETIMO© permet la diffusion massive de votre bien:</p>
					</div>
					<div class="row">
						<aside class="marketimo col-xs-12 col-sm-6 col-md-6 col-lg-6">
							<div class="img"><img src="pdf/pic5.png"/></div>
							<h6>Retrouvez votre bien en ligne sur les site principaux</h6>
						</aside>
						<aside class="marketimo col-xs-12 col-sm-6 col-md-6 col-lg-6">
							<div class="img"><img src="pdf/pic4.png"/></div>
							<h6>Nous créons un site dédié à votre bien</h6>
						</aside>
						<aside class="marketimo col-xs-12 col-sm-6 col-md-6 col-lg-6">
							<div class="img"><img src="pdf/pic6.png"/></div>
							<h6>Votre bien diffusé et partage dans les réseaux sociaux</h6>
						</aside>
						<aside class="marketimo col-xs-12 col-sm-6 col-md-6 col-lg-6">
							<div class="img"><img src="pdf/pic3.png"/></div>
							<h6>Parution de votre bien dans notre journal <strong>MONIMO</strong></h6>
						</aside>
					</div>
					<!-- water mark -->
					<div class="whater-mark bottom">
						<div class="home-conseiller">
							<div class="col col-xs-12 col-sm-2 col-md-2 col-lg-2">
								<img src="pdf/limmolier.png"/>
							</div>
							<div class="col col-xs-12 col-sm-6 col-md-6 col-lg-6">
								<ul>
									<li>Votre Home Conseiller</li>
									<li>Mr.Philippe Soulie</li>
									<li>Tél : 06457430050</li>
									<li>Email : philippe.soulie@limmobilier.net</li>
								</ul>
							</div>
							<div class="col col-xs-12 col-sm-4 col-md-4 col-lg-4">
								<ul>
									<li>Notre Réseau</li>
									<li>Tél. : 06457430050</li>
									<li>E-mail : contact@limmobilier.net</li>
									<li>Site web : https://www.limmobilier.net</li>
									<li>Adresse : 2 Avenue du Lac 74140 Douvaine</li>
								</ul>
							</div>
						</div>
						<span class="pull-left">http://app.espaceo.net/client/evalueo/go_print/restore/308</span>
						<span class="pull-right">08/09</span>
					</div>
					<!-- water mark -->
				</div>
				<!-- End: page 8 -->
				<!-- Start: page 9 -->
				<div class="page">
					<!-- water mark -->
					<div class="whater-mark top">
						<span class="pull-left">05/12/2017</span>
						app.espaceo.net/client/evalueo/go_print/restore/308
					</div>
					<!-- water mark -->
					<div class="titles active">
						<span>9</span>
						Solucimo
					</div>
					<div class="text-center col-xs-12 col-sm-12 col-md-12 col-lg-12">
						<img src="pdf/pic2.png"/>
					</div>
					<nav class="nav-arrow">
						<ul>
							<li class="active"><a data-toggle="tab" href="#pdf-etudeo">ETUDEO</a></li>
							<li><a data-toggle="tab" href="#pdf-evalueo">EVALUEO</a></li>
							<li><a data-toggle="tab" href="#pdf-solucimo">Solucimo</a></li>
						</ul>
					</nav>
					<div class="tab-content">					
						<div id="pdf-etudeo" class="tab-pane fade in active">
							<div class="text-center">
								<label>
									<img src="pdf/icon1.png"/>
									<h6>Nous démarrons la commercialisation de votre bien !</h6>
								</label>
								<h5>"Pour réussir votre projet de mise en vente et la vente de votre bien, nous vous proposons de signer un mandat de vente Solucimo. "</h5>
							</div>
						</div>
						<div id="pdf-evalueo" class="tab-pane fade">
							<div class="text-center">
								<label>
									<img src="pdf/icon1.png"/>
									<h6>Nous démarrons la commercialisation de votre bien !</h6>
								</label>
								<h5>"Pour réussir votre projet de mise en vente et la vente de votre bien, nous vous proposons de signer un mandat de vente Solucimo. "</h5>
							</div>
						</div>
						<div id="pdf-solucimo" class="tab-pane fade">
							<div class="text-center">
								<label>
									<img src="pdf/icon1.png"/>
									<h6>Nous démarrons la commercialisation de votre bien !</h6>
								</label>
								<h5>"Pour réussir votre projet de mise en vente et la vente de votre bien, nous vous proposons de signer un mandat de vente Solucimo. "</h5>
							</div>
						</div>
					</div>
					<!-- water mark -->
					<div class="whater-mark bottom">
						<div class="home-conseiller">
							<div class="col col-xs-12 col-sm-2 col-md-2 col-lg-2">
								<img src="pdf/limmolier.png"/>
							</div>
							<div class="col col-xs-12 col-sm-6 col-md-6 col-lg-6">
								<ul>
									<li>Votre Home Conseiller</li>
									<li>Mr.Philippe Soulie</li>
									<li>Tél : 06457430050</li>
									<li>Email : philippe.soulie@limmobilier.net</li>
								</ul>
							</div>
							<div class="col col-xs-12 col-sm-4 col-md-4 col-lg-4">
								<ul>
									<li>Notre Réseau</li>
									<li>Tél. : 06457430050</li>
									<li>E-mail : contact@limmobilier.net</li>
									<li>Site web : https://www.limmobilier.net</li>
									<li>Adresse : 2 Avenue du Lac 74140 Douvaine</li>
								</ul>
							</div>
						</div>
						<span class="pull-left">http://app.espaceo.net/client/evalueo/go_print/restore/308</span>
						<span class="pull-right">09/09</span>
					</div>
					<!-- water mark -->
				</div>
				<!-- End: page 9 -->
			</div>
		</aside>
		<aside class="item col-xs-12 col-sm-4 col-md-3 col-lg-3">
			<div class="repport-btns">
				
				<ul>
					<span class="btns">Action</span>
					<li><a href="#">Share</a><li>
					<li><a href="#">Print</a><li>
					<li><a href="#">Save</a><li>
				</ul>
				
				<ul>
					<span class="btns">Edition report</span>
					<li><a id="" href="#photo_du_bien">Photo du bien</a><li>
					<li><a href="#decouvrimo">Im le Propertier</a><li>
					<li><a href="#">Save</a><li>
				</ul>
			</div>
		</aside>		
	</div>
</div>