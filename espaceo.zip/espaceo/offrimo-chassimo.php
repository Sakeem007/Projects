<div class="OffrimoChassimo">	
	<div class="col-xs-12 col-sm-5 col-md-5 col-lg-5 Chassimo_tableColum">
		<div class="chassimTitle_Box" style="background-image: url(http://52.47.202.232/assets/images/research-motor-img.png); background-position:bottom;">
			<div class="Banners_TxT">
			<h3>Chassimo</h3>
			<h5>"Si tu me cherches, tu me trouves"</h5>
			</div>
		</div>
	</div>
	<form id="Chassimosearchform">			
		<div class="col-xs-12 col-sm-7 col-md-7 col-lg-7 Chassimo_tableColum">
		<div class="Banners_TxT">
			<p class="topfilter_box">
				<button class="" type="text">URL ciblée</button><input type="text" id="field-chaddress"> <a href="#ChassimoPlussde" data-toggle="modal" data-backdrop="true" class="ChassimoPlussBox"> <i class="fa fa-plus"></i> de criteres</a>
			</p>
			<div class="clearfix"></div>
			<p class="Rfr_Btnbox"><button type="submit">Valider</button><a class="refreshchasearch" href="javascript:void(0);">&nbsp;</a></p>
		</div>
		</div>
		<div class="clr"></div>
	</form>
</div>
