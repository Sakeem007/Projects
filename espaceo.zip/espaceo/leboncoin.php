<?php include('header.php');?>
<div class="LebonMainWrapper">
	<div class="LboncoinWrapper">
		<h1>Leboncoin</h1>
		<div class="LboncoinSliderBox">
			<div class="img slider_Section">
				<div class="carousel slide" data-ride="carousel" data-type="multi" data-interval="false" id="leboncoinSlide">
					<div class="carousel-inner">
						<div class="item active" style="background:url(images/offerimg1.jpg)"></div>
						<div class="item" style="background:url(images/offerimg2.jpg)"></div>							
						<div class="item" style="background:url(images/offerimg3.jpg)"></div>
					</div>
					<a class="left carousel-control" href="#leboncoinSlide" data-slide="prev">
					  <span class="glyphicon glyphicon-chevron-left"></span>
					  <span class="sr-only">Previous</span>
					</a>
					<a class="right carousel-control" href="#leboncoinSlide" data-slide="next">
					  <span class="glyphicon glyphicon-chevron-right"></span>
					  <span class="sr-only">Next</span>
					</a>
				</div>
			</div>
		</div>
		<div class="TitlPriceBox">
			<h3>Villa 5 pièces 125 m²</h3>
			<p><strong>445 000 €</strong>
			14/03/2020 à 00h53</p>
		</div>
		<div class="CriteriaBox">
			<h6>Critères</h6>
			<ul>
				<li><strong>Type de bien</strong> Maison</li>
				<li><strong>Surface</strong> 125 m²</li>
				<li><strong>Pièces</strong> 5</li>
				<li><strong>Localisation</strong> Non renseigné</li>
				<li><strong>GES</strong> Non renseigné</li>
				<li><strong>Référence</strong> ip_8857</li>
				<div class="clearfix"></div>
			</ul>
		</div>
		<div class="lebconDescription">
			<h6>Description</h6>
			<p>Maison type 5 pièces à Sciez</p>
			<p>Belle opportunité pour cette villa située à Sciez, à seulement 30 minutes de Genève et 25 minutes de Thonon les Bains. Maison d'une superficie de 125 m2 et jardin de 500 m2. Vous apprécierez le bel espace de vie de 30 m2, avec un accès direct sur la terrasse et l'espace jardin, ainsi que son bureau. A l'étage, vous retrouverez une suite parentale, 2 chambres et une salle d'eau. Les prestations proposées sont soignées et modernes. Un garage de 20 m2 complète ce bien.<br>
			Contact Guillaume GAULTIER au 06.01.49.33.10 / g.gaultier@i-particuliers.com - Annonce rédigée et publiée par un Agent Mandataire -
			Référence annonce : IP_8857
			Non soumis  au DPE<span class="DoutPoint">...</span> <a class="ReadMore" href="javascript:void(0)">lire plus</a></p>
			<p id="ReadMoreTxt" style="display:none">Les honoraires sont à la charge du vendeur</p>
		</div>
		<div class="AdvisersBox">
			<div class="TopbgBox"></div>
			<div class="LogoBox"><img src="https://img3.leboncoin.fr/bo-logo/142810092412333.jpg"></div>
			<span class="LebTitle">I-PARTICULIER GAULTIER</span>
			<ul>
				<li><b>Achetez, louez et vendez avec les conseillers</b></li>
				<li><i class="fa fa-map-marker"></i> 1 RUE CONRAD KILIAN 38950 Saint-Martin-Le-Vinoux</li>
			</ul>
		</div>
	</div>
</div>

<?php include('footer.php');?>

