<div id="interOffrimoWrapper" class="offrimo">
	<div class="offrimoBox MesInvitation">
		<div class="repter">
			<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
				<div class="row MesPartenersLeft">
					<input type="" placeholder="Recherche par mot clefs...">
				</div>
			</div>
			<div class="tablebox">
				<div class="box">
					<div class="img slider_Section">
						<div class="carousel slide" data-ride="carousel" data-type="multi" data-interval="false" id="myCarousel5">
							<div class="carousel-inner">
							  <div class="item active">
								<img src="images/chassimo1.jpg" alt="Los Angeles" style="width:100%;height:220px">
							  </div>
							  <div class="item">
								<img src="images/chassimo2.jpg" alt="Chicago" style="width:100%;height:220px">
							  </div>							
							  <div class="item">
								<img src="images/chassimo3.jpg" alt="New york" style="width:100%;height:220px">
							  </div>
							</div>							
							<a class="left carousel-control" href="#myCarousel5" data-slide="prev">
							  <span class="glyphicon glyphicon-chevron-left"></span>
							  <span class="sr-only">Previous</span>
							</a>
							<a class="right carousel-control" href="#myCarousel5" data-slide="next">
							  <span class="glyphicon glyphicon-chevron-right"></span>
							  <span class="sr-only">Next</span>
							</a>
					    </div>
					</div>
				</div>
				<div class="box">
					<div class="headerTop">Annonce <span>90 000 &euro;</span></div>
					<div class="contents">
						<div class="padRight">
							<p>4 pieces de 87 m²</p>
							<h6 class="locBtn">Amberieu-en-Bugey 01500</h6>
							<p>when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries,</p>
						</div>						
						<ul class="AddbBuyer">
							<li><a href="javascript:voed(0)" class="blueBtn">Annonce</a></li>
						</ul>
					</div>
				</div>
				<div class="box">
					<div class="headerTop">Agence</div>					
					<div class="appreciation">
						<ul class="RecordedDetails">
							<li><strong>Nom:</strong> <span>Justin Jons</span></li>
							<li><strong>Addresse:</strong> <span>2 Avenue du Lac 74140 Douvaine</span></li>
							<li><strong>Ville:</strong> <span></span></li>
						</ul>	
						<ul class="AddbBuyer">
							<li><a href="javascript:voed(0)" class="blueBtn">Tel</a></li>
							<li><a href="javascript:voed(0)" class="blueBtn">Mail</a></li>
						</ul>
					</div>
				</div>
				<div class="box">
					<div class="headerTop">Etat</div>
					<div class="contents">
						<p class="DateDemande">Invitarion envoyée le ...........</p>						
						<p class="DateDemande">Invitation acceptée / refusee</p>						
						<div class="InterBottomBox">
							<ul>
								<li><a href="#" class="blueBtn">Créer partenaire</a></li>
								<li><a href="#" class="blueBtn">Renvoyer invitation</a></li>
								<li><a href="#" class="blueBtn">Supprimer invitation</a></li>
							</ul>
						</div>
					</div>
				</div>				
			</div>
		</div>
		<div class="repter">
			<div class="tablebox">
				<div class="box">
					<div class="img slider_Section">
						<div class="carousel slide" data-ride="carousel" data-type="multi" data-interval="false" id="myCarousel6">
							<div class="carousel-inner">
							  <div class="item active">
								<img src="images/chassimo4.jpg" alt="Los Angeles" style="width:100%;height:220px">
							  </div>
							  <div class="item">
								<img src="images/chassimo5.jpg" alt="Chicago" style="width:100%;height:220px">
							  </div>							
							  <div class="item">
								<img src="images/chassimo6.jpg" alt="New york" style="width:100%;height:220px">
							  </div>
							</div>							
							<a class="left carousel-control" href="#myCarousel6" data-slide="prev">
							  <span class="glyphicon glyphicon-chevron-left"></span>
							  <span class="sr-only">Previous</span>
							</a>
							<a class="right carousel-control" href="#myCarousel6" data-slide="next">
							  <span class="glyphicon glyphicon-chevron-right"></span>
							  <span class="sr-only">Next</span>
							</a>
					    </div>
					</div>
				</div>
				<div class="box">
					<div class="headerTop">Annonce <span>90 000 &euro;</span></div>
					<div class="contents">
						<div class="padRight">
							<p>4 pieces de 87 m²</p>
							<h6 class="locBtn">Amberieu-en-Bugey 01500</h6>
							<p>when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries,</p>
						</div>						
						<ul class="AddbBuyer">
							<li><a href="javascript:voed(0)" class="blueBtn">Annonce</a></li>
						</ul>
					</div>
				</div>
				<div class="box">
					<div class="headerTop">Agence</div>					
					<div class="appreciation">
						<ul class="RecordedDetails">
							<li><strong>Nom:</strong> <span>Justin Jons</span></li>
							<li><strong>Addresse:</strong> <span>2 Avenue du Lac 74140 Douvaine</span></li>
							<li><strong>Ville:</strong> <span></span></li>
						</ul>	
						<ul class="AddbBuyer">
							<li><a href="javascript:voed(0)" class="blueBtn">Tel</a></li>
							<li><a href="javascript:voed(0)" class="blueBtn">Mail</a></li>
						</ul>
					</div>
				</div>
				<div class="box">
					<div class="headerTop">Etat</div>
					<div class="contents">
						<p class="DateDemande">Invitarion envoyée le ...........</p>						
						<p class="DateDemande">Invitation acceptée / refusee</p>						
						<div class="InterBottomBox">
							<ul>
								<li><a href="#" class="blueBtn">Créer partenaire</a></li>
								<li><a href="#" class="blueBtn">Renvoyer invitation</a></li>
								<li><a href="#" class="blueBtn">Supprimer invitation</a></li>
							</ul>
						</div>
					</div>
				</div>				
			</div>
		</div>
	</div>
	
</div>