<?php include('header.php');?>
<div class="evalueoBox">
<div class="evalueo">
	<div class="container">
		<div class="row">
			<aside class="item col-xs-12 col-sm-8 col-md-9 col-lg-9">
				<div id="all-repport-pdf" class="repport-pdf">
					<!-- Start: page 1 -->						<div class="page" id="html-2-pdfwrapper">					<!-- water mark -->					<div class="whater-mark top">						<span class="pull-left"><?php echo date("d/m/Y"); ?></span>					</div>					<!-- water mark -->					<div class="top">						<div class="logo"><img src="images/logo1.png"/></div>						<div class="rightText">							<h2>								<span>MARCHE IMMOBILIER</span>								<em>NOTER AVIS DE VALEUR</em>								<em>ETUDEO<sup>&copy;</sup></em>							</h2>						</div>					</div>					<div class="photo-upload" id="photo_du_bien">						<div class="photo">							<label><!--input type="file" onChange="showPreview(this);"/-->								<div id="targetLayer">									<input name="image_url1" accept="image/png,image/jpeg" id="image_url1" type="file" class="inputFile" onChange="showPreview(this);" />								</div>							</label>							<div class="left-border" id="propertyInfo">								<h6>Votre bien:</h6>								<p><!--{{BienType}} - {{surfaceValue}}-->m<sup>2</sup><!-- {{cityName}}--></p>							</div>						</div>						<div class="bottom-arrow-bg info_details_BoX">							<div class="left-border"> 								<h3><span class="section-title"> A la demande de</span></h3>								<ul>									<li><i class="fa fa-user"></i> <!--{{propertyUserTitre}} {{propertyUser}}--></li>									<li><i class="fa fa-phone"></i> <!--{{propertyPhone}}--></li>									<li><i class="fa fa-envelope"></i> <!--{{propertyEmailID}}--></li>									<li><i class="fa fa-map-marker"></i> <!--{{propertyAddress}}--></li>								</ul>							</div>						</div>						<!-- water mark -->						<!-- water mark -->					</div>                    </div>
					<!--<div class="picBg">
						<div class="etudeoMain">
							<div class="etudeoText">
								<div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
									<div class="left-border">
										<h6>Votre bien:</h6>
										<span>Maison - 150m<sup>2</sup> 74140, Douvaine</span>
									</div>
								</div>
								<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
									<img src="pdf/logo1.png"/>
								</div>
								<h3></h3>
							</div>
							<div class="bottom-arrow-bg">
								<div class="left-border">
									<ul>
										<li>A la demande de : Mme et Mr Soulié</li>
										<li>Votre Home Conseiller : Mr Philippe Soulié</li>
										<li>Fait le: Lundi 01 Mai 2017</li>
									</ul>
								</div>							</div>						</div>										</div>-->								
					<!-- End: page 1 -->
					<!-- Start: page 2 -->
					<div class="page">
						<div class="titles active">
							<span>1</span>
							Sommaire
						</div>
						<div class="sommaire">
							<h1>Sommaire</h1>
						</div>						
						<div class="titles">
							<span>1</span>
							Sommaire
						</div>
						<div class="titles">
							<span>2</span>
							Présentation de notre Agence
						</div>
						<div class="titles">
							<span>3</span>
							Notre application ETUDEO©
						</div>
						<div class="titles">
							<span>4</span>
							Tout sur votre annonce mise en ligne
						</div>
						<div class="titles">
							<span>5</span>
							Synthése de notre étude immobiliere
						</div>
						<div class="titles">
							<span>6</span>
							Les bénéﬁces de ETUDEO© et EVALUEO©
						</div>	
						<div class="sommaire">
							<div class="clear"><br><br><br></div>
							<h2>Prét pour la prochaine étape ...?</h2>
						</div>
						<!-- water mark -->
						<div class="whater-mark bottom">
							<div class="home-conseiller">
								<div class="col col-xs-12 col-sm-2 col-md-2 col-lg-2">
									<img src="pdf/limmolier.png"/>
								</div>
								<div class="col col-xs-12 col-sm-6 col-md-6 col-lg-6">
									<ul>
										<li>Votre Home Conseiller</li>
										<li>Mr.Philippe Soulie</li>
										<li>Tél : 06 50 65 68 78</li>
										<li>Email : philippe.soulie@limmobilier.net</li>
									</ul>
								</div>
								<div class="col col-xs-12 col-sm-4 col-md-4 col-lg-4">
									<ul>
										<li>Notre Réseau</li>
										<li>Tél. : 04 57 43 00 50 / 04 57 43 00 49</li>
										<li>E-mail : contact@limmobilier.net</li>
										<li>Site web : https://www.limmobilier.net</li>
										<li>Adresse : 2 Avenue du Lac 74140 Douvaine</li>
									</ul>
								</div>
							</div>
						</div>
						<!-- water mark -->
					</div>
					<!-- End: page 2 -->
					<!-- Start: page 3 -->
					<div class="page">
						<div class="titles active">
							<span>2</span>
							Présentation de notre société
						</div>
						
						<div class="title-blue">
							<span><span>Notre histoire</span></span>
						</div>
						<div class="paddLeft">
							<p>Depuis 1998, les fondateurs de <strong>L'IMMOBILIER</strong>, spécialisés dans les métiers de l'immobilier, ont toujours développé un esprit de qualité, d’exigence et de réussite. Ce qui guide le groupe, c’est la passion : la passion des autres, la passion de son métier, l'immobilier, avec en plus, une vision global de son activité. Cette passion c’est le ﬁl conducteur de son histoire, elle ne s’est jamais démentie, elle est le moteur pour atteindre son objectif: votre satisfaction.</p>
						</div>
						
						<div class="title-blue">
							<span><span>Nos valeurs</span></span>
						</div>
						<div class="paddLeft">
							<p>Notre groupe cultive avant tout l’excellence, cette démarche se traduit concretement par une recherche constante des meilleures performances, dans les métiers de l’immobilier. Notre groupe privilégie en effet, depuis sa création, les valeurs d’avant—garde, que sont la dimension humaine, la famille, la durabilité, le respect de l'environnement.</p>
							<p> << La valeur d'une entreprise est déterminée par la valeur des gens qui la compose >>.</p>
						</div>
						
						<div class="title-blue">
							<span><span>Notre savoir faire</span></span>
						</div>
						<div class="paddLeft">
							<p><strong>L'IMMOBILIER</strong> est au coeur de notre savoir faire, et plus particuliérement la vente immobiliere. Nous avons développé une application inédite appelée <strong>EVALUEO©</strong>, qui est une application capable d'analyseren temps réeltoutes les données du marché immobilier régional et local, de comparer les biens en vente, tout en tenant compte des caractéristiques de votre bien.</p>
						</div>
						
						<div class="title-blue">
							<span><span>Notre objectif</span></span>
						</div>
						<div class="paddLeft">
							<p>Nous souhaitons vous donner le meilleur prix de vente, c'est a dire le prix du marché actuel, et vous proposer la meilleur stratégie commerciale, car nous souhaitons vendre votre bien au meilleur prix, et dans les meilleurs délais.</p>
						</div>
						<div class="text-center col-xs-12 col-sm-12 col-md-12 col-lg-12">
							<img src="pdf/pic13.png"/>
						</div>
						<!-- water mark -->
						<div class="whater-mark bottom">
							<div class="home-conseiller">
								<div class="col col-xs-12 col-sm-2 col-md-2 col-lg-2">
									<img src="pdf/limmolier.png"/>
								</div>
								<div class="col col-xs-12 col-sm-6 col-md-6 col-lg-6">
									<ul>
										<li>Votre Home Conseiller</li>
										<li>Mr.Philippe Soulie</li>
										<li>Tél : 06 50 65 68 78</li>
										<li>Email : philippe.soulie@limmobilier.net</li>
									</ul>
								</div>
								<div class="col col-xs-12 col-sm-4 col-md-4 col-lg-4">
									<ul>
										<li>Notre Réseau</li>
										<li>Tél. : 04 57 43 00 50 / 04 57 43 00 49</li>
										<li>E-mail : contact@limmobilier.net</li>
										<li>Site web : https://www.limmobilier.net</li>
										<li>Adresse : 2 Avenue du Lac 74140 Douvaine</li>
									</ul>
								</div>
							</div>
						</div>
						<!-- water mark -->
					</div>
					<!-- End: page 3 -->
					<!-- Start: page 4 -->
					<div class="page">
						<div class="titles active">
							<span>3</span>
							Notre application ETUDEO©
						</div>
						<div class="etudeo">
							<p><strong>ETUDEO©</strong> vient de la fusion des mots ETUDE et IMMOBILIER, ce rapport utilise 4 applications qui sont les suivantes:</p>
						</div>
						<div class="title-blue">
							<span>OFFRIMO©</span> Visualiser l'offre immobiliére
						</div>
						<div class="etudeo">
							<p><strong>OFFRIMO©</strong> vient de la fusion des mots <strong>OFFRE</strong> et <strong>IMMOBILIER</strong>, nous utilisons cette application qui nous permet d’étre informés de toutes les annonces de l'offre immobiliere, données par tous les sites d’annonces, pour tous les biens publiés par les particuliers et les agences, et cela, en temps réel.</p>
							<p>Cette offre peut étre consultée par défaut, suivant les annonces données par les sites immobilier, mais peut également étre affinée suivant un moteur de recherche intelligent.</p>
						</div>
						
						<div class="title-blue">
							<span>RANKIMO©</span> Classer l'offre immobiliére
						</div>
						<div class="etudeo">
							<p><strong>RANKIMO©</strong> vient de la fusion du mot anglais <strong>"RANK"</strong> qui signiﬁe <strong>"CLASSER"</strong> et de <strong>IMMOBILIER</strong>, car nous utilisons cette application qui nous permet de classer les annonces de l'offre immobiliére données par tous les sites d'annonces, pour tous les biens publiés par les particuliers et les agences, et cela, en temps réel.</p>
							<p>Ce classement se fait par défaut, suivant les informations données par les sites d'annonces immobilieres, mais peut également étre paramétréer pour affiner le classement.</p>
						</div>
						
						<div class="title-blue">
							<span>COMPARIMO©</span> Comparer l'offre immobiliére
						</div>
						<div class="etudeo">
							<p><strong>COMPARIMO©</strong> vient de la fusion des mots <strong>COMPARER et IMMOBILIER</strong>, nous utilisons cette application qui nous permet de comparer les annonces de l'offre immobiliere données par tous les sites d'annonces, pour tous les biens publiés par les particuliers et les agences, et cela, en temps réel.</p>
							<p>Cette comparaison se fait par défaut, suivant les informations données par les sites d'annonces immobilieres, mais peut également étre paramétréer pour affiner la comparaison.</p>
						</div>
						
						<div class="title-blue">
							<span>OBSERVIMO©</span> Qualiﬁer l'offre immobiliére
						</div>
						<div class="etudeo">
							<p><strong>OBSERVIMO©</strong> vient de la fusion des mots <strong>OBSERVER et IMMOBILIER</strong>, nous utilisons cette application qui nous permet de qualiﬁer un département, une ville, un quartier ou une rue, en identiﬁant ses points forts et ses points faibles, cette qualiﬁcation se fait sur des indicateurs démographiques, sociaux, environnementaux, de commodités, transports...</p>
							<p>Nous pouvons ainsi qualiﬁer une adresse a 360°, nous savons 00 se situe votre bien.</p>
						</div>
						
						<!-- water mark -->
						<div class="whater-mark bottom">
							<div class="home-conseiller">
								<div class="col col-xs-12 col-sm-2 col-md-2 col-lg-2">
									<img src="pdf/limmolier.png"/>
								</div>
								<div class="col col-xs-12 col-sm-6 col-md-6 col-lg-6">
									<ul>
										<li>Votre Home Conseiller</li>
										<li>Mr.Philippe Soulie</li>
										<li>Tél : 06 50 65 68 78</li>
										<li>Email : philippe.soulie@limmobilier.net</li>
									</ul>
								</div>
								<div class="col col-xs-12 col-sm-4 col-md-4 col-lg-4">
									<ul>
										<li>Notre Réseau</li>
										<li>Tél. : 04 57 43 00 50 / 04 57 43 00 49</li>
										<li>E-mail : contact@limmobilier.net</li>
										<li>Site web : https://www.limmobilier.net</li>
										<li>Adresse : 2 Avenue du Lac 74140 Douvaine</li>
									</ul>
								</div>
							</div>
						</div>
						<!-- water mark -->
					</div>
					<!-- End: page 4 -->
					
				</div>
			</aside>
			<aside class="item col-xs-12 col-sm-4 col-md-3 col-lg-3">
				<div class="repport-btns">				
					<ul>
						<span class="btns">Action</span>
						<li><a href="#">Share</a><li>
						<li><a href="#">Print</a><li>
						<li><a href="#">Save</a><li>
					</ul>
					
					<ul>
						<span class="btns">Edition report</span>
						<li><a href="#photo_du_bien">Photo du bien</a><li>
						<li><a href="#">Im  le Propertier</a><li>
						<li><a href="#">Save</a><li>
					</ul>
				</div>
			</aside>		
		</div>
	</div>
</div>
</div>
<?php include('footer.php');?>