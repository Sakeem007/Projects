<div id="SellreMyoffer">
	<div class="SellerTxtWrapper">
		<div class="SellerNewOffer"><a href="javascript:void(0)"><i class="fa fa-plus-circle"></i> Nouvelle Offre</a></div>
		<form action="">	
			<div class="row SellreMyofferWrapper">				
				<div class="col-xs-12 col-sm-12 col-md-4 col-lg-5 SellerMapBox">
					<div class="MapBox">
						<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d5662657.196432931!2d-2.4342999142223554!3d46.131440726910405!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd54a02933785731%3A0x6bfd3f96c747d9f7!2sFrance!5e0!3m2!1sen!2sin!4v1583925246079!5m2!1sen!2sin" width="100%" height="400" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
					</div>
				</div>
				<div class="col-xs-12 col-sm-12 col-md-8 col-lg-7">
					<div class="SituationBox">
						<h6>Situation</h6>
						<div class="form-group">
							<input class="tenpBox" type="text" placeholder="N°">
							<input class="AddressBox" type="text" placeholder="Adresse">
						</div>
						<div class="form-group">
							<input class="postCode" type="text" placeholder="Code postale">
							<input class="CommuneBox" type="text" placeholder="Commune">
						</div>
						<div class="clearfix"></div>
						<h6>Critères Primaires</h6>
						<div class="form-group">
							<label class="LblText First">Type:</label>
							<label class="cusCheckbox">
								<input type="radio" checked="checked" name="radio">
								<span class="checkmark"></span>
								<b>Maison</b>
							</label>
							<label class="cusCheckbox">
								<input type="radio" name="radio">
								<span class="checkmark"></span>
								<b>Appartement</b>
							</label>
						</div>
						<div class="PrimairesBoxs">
							<div class="form-group">
								<label class="LblText">Surface:</label>
								<input class="form-control" type="text"><span>m²</span>
							</div>
							<div class="form-group">
								<label class="LblText">Nombre de chambre(s):</label>
								<input class="form-control" type="text">
							</div>
							<div class="form-group">
								<label class="LblText">Terrain:</label>
								<input class="form-control" type="text"><span>m²</span>
							</div>
							<div class="form-group">
								<label class="LblText">Prix:</label>
								<input class="form-control" type="text"><span>€</span>
							</div>
						</div>
					</div>
				</div>
				<div class="col-xs-12 col-lg-12 SecondaryCriteria">					
					<h6>Critères Secondaires</h6>
					<div class="form-group">
						<label class="LblText First">Type:</label>
						<label class="cusCheckbox">
							<input type="radio" checked="checked" name="Second">
							<span class="checkmark"></span>
							<b>Individuelle</b>
						</label>
						<label class="cusCheckbox">
							<input type="radio" name="Second">
							<span class="checkmark"></span>
							<b>Mitoyenne</b>
						</label>
						<label class="cusCheckbox">
							<input type="radio" name="Second">
							<span class="checkmark"></span>
							<b>Plein-pieds</b>
						</label>
						<label class="cusCheckbox">
							<input type="radio" name="Second">
							<span class="checkmark"></span>
							<b>Village</b>
						</label>
						<em>*</em>
					</div>
					<div class="form-group">
						<label class="LblText First">Les plus:</label>
						<label class="cusCheckbox">
							<input type="radio" name="plus">
							<span class="checkmark"></span>
							<b>Cave</b>
						</label>
						<label class="cusCheckbox">
							<input type="radio" name="plus">
							<span class="checkmark"></span>
							<b>Garage</b>
						</label>
						<label class="cusCheckbox">
							<input type="radio" name="plus">
							<span class="checkmark"></span>
							<b>Parking</b>
						</label>
						<label class="cusCheckbox">
							<input type="radio" name="plus">
							<span class="checkmark"></span>
							<b>Sous-sol</b>
						</label>
						<label class="cusCheckbox">
							<input type="radio" name="plus">
							<span class="checkmark"></span>
							<b>Combles</b>
						</label>
						<label class="cusCheckbox">
							<input type="radio" name="plus">
							<span class="checkmark"></span>
							<b>Piscine</b>
						</label>
					</div>
					<div class="form-group">
						<label class="LblText First">Environnement:</label>
						<select class="selectView">
							<option>Vue +</option>
						</select>
						<label class="cusCheckbox">
							<input type="radio" name="environnement">
							<span class="checkmark"></span>
							<b>Calme</b>
						</label>
						<label class="cusCheckbox">
							<input type="radio" name="environnement">
							<span class="checkmark"></span>
							<b>Campagne</b>
						</label>
						<label class="cusCheckbox">
							<input type="radio" name="environnement">
							<span class="checkmark"></span>
							<b>Centre</b>
						</label>
						<label class="cusCheckbox">
							<input type="radio" name="environnement">
							<span class="checkmark"></span>
							<b>Ville</b>
						</label>
					</div>
					<div class="form-group">
						<label class="LblText First">Style:</label>
						<label class="cusCheckbox">
							<input type="radio" name="style">
							<span class="checkmark"></span>
							<b>Moderne</b>
						</label>
						<label class="cusCheckbox">
							<input type="radio" name="style">
							<span class="checkmark"></span>
							<b>Ancien</b>
						</label>
						<label class="cusCheckbox">
							<input type="radio" name="style">
							<span class="checkmark"></span>
							<b>Neuf</b>
						</label>
						<label class="cusCheckbox">
							<input type="radio" name="style">
							<span class="checkmark"></span>
							<b>Contemporain</b>
						</label>
					</div>
					<div class="form-group">
						<label class="LblText First">Etat général:</label>
						<label class="cusCheckbox">
							<input type="radio" name="etat">
							<span class="checkmark"></span>
							<b>Rien à faire</b>
						</label>
						<label class="cusCheckbox">
							<input type="radio" name="etat">
							<span class="checkmark"></span>
							<b>A Rafraichir</b>
						</label>
						<label class="cusCheckbox">
							<input type="radio" name="etat">
							<span class="checkmark"></span>
							<b>A renover</b>
						</label>
						<label class="cusCheckbox">
							<input type="radio" name="etat">
							<span class="checkmark"></span>
							<b>Contemporain</b>
						</label>
					</div>
					<h6>Description:</h6>
					<div class="form-group">
						<label>Décrivez nous votre bien</label>
						<textarea class="form-control" name="" cols="" rows="5" placeholder="Exemple : Maison contemporaine, de 145m2 sur 950m2, cuisine ouverte sur séjour, cheminée, terrasses, piscines, 5 chambres, 1 suite parentale, vue lac, abri voitures, garage, terrain clos et arboré, calme, proche du centre."></textarea>
					</div>
					<h6>If 'Appartement':</h6>
					<div class="form-group">
						<label class="LblText First">Type:</label>
						<label class="cusCheckbox">
							<input type="radio" name="appartement">
							<span class="checkmark"></span>
							<b>Rez-de-chaussée</b>
						</label>
						<label class="cusCheckbox">
							<input type="radio" name="appartement">
							<span class="checkmark"></span>
							<b>Dernier étage</b>
						</label>
						<label class="cusCheckbox">
							<input type="radio" name="appartement">
							<span class="checkmark"></span>
							<b>Attique</b>
						</label>
						<label class="cusCheckbox">
							<input type="radio" name="appartement">
							<span class="checkmark"></span>
							<b>Contemporain</b>
						</label>
						<label class="cusCheckbox">
							<input type="radio" name="appartement">
							<span class="checkmark"></span>
							<b>Loft</b>
						</label>
						<label class="cusCheckbox">
							<input type="radio" name="appartement">
							<span class="checkmark"></span>
							<b>Duplex</b>
						</label>
						<em>*</em>					
					</div>
				</div>
			</div>
		</form>
	</div>
</div>