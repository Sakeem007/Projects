<div id="Sectorimo" class="item tab-pane fade in active">
	<div class="row">
	<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 Obj_sectorimo_Wrapper">
		<div class="col-xs-12 col-sm-5 col-md-5 col-lg-5">
			<div class="map-sectorimo">
				<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d11379754.90301434!2d-6.929476864819009!3d45.86609808040356!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd54a02933785731%3A0x6bfd3f96c747d9f7!2sFrance!5e0!3m2!1sen!2sin!4v1534584981505" width="100%" height="464" frameborder="0" style="border:0" allowfullscreen></iframe>			
			</div>
			<div class="col-xs-12 maison-bottom-list">
				<ul class="Obj_sectorimo_map_Box sectorimoActive">
					<li class="green_icon"><a href="#"><i class="green-btn fa fa-circle"></i> Activée(s)</a></li>
					<li class="red_icon"><a href="#"><i class="red-btn fa fa-circle"></i> A activer</a></li>
				</ul>
			</div>
		</div>
		
		<div class="col-xs-12 col-sm-7 col-md-7 col-lg-7 Tableau_bord_right">
			<div class="sliderArrowBox"><a href="#CitiesPopup" data-toggle="modal"><i class="fa fa-angle-left"></i></a> Retour Tableau de Board <!--<i class="fa fa-angle-left"></i>--></div>
			
			<ul>
				<li class="Infos_TxTbox"><span>Infos</span></li>
				<li><strong>Ma Région:</strong> <span class="paramiter_Box"> </span></li>
				
				<li><strong>Mon Développeur:</strong>
				<a> <i class="fa fa-envelope"></i></a> écrire un message</li>				
				<li><strong>Mon Leader:</strong>
			
				<a><i class="fa fa-envelope"></i></a> écrire un message
				
				</li>
				
				<li><strong>Mon Manager:</strong> 
				
				<a><i class="fa fa-envelope"></i></a> écrire un message
				
				</li>								
				<li class="Infos_TxTbox"><span>Caractéristiques</span></li>
				<li class="annoncesBox"><strong>Mon Territoire représente:</strong><span></span>km² <a href="#terivillesdatamodal" data-toggle="modal" data-backdrop="true" ><i class="fa fa-eye"></i></a> Voir les villes</li>
				<li class="annoncesBox"><strong>Mon Secteur Secondaire représente:</strong><span></span>km² avec <span></span> BALs <a href="#ssvillesdatamodal" data-toggle="modal" data-backdrop="true" ><i class="fa fa-eye"></i></a> Voir les villes</li>
				<li class="annoncesBox"><strong>Mon Secteur Prioritaire représente:</strong><span></span>km² avec <span></span> BALs <a href="#spvillesdatamodal" data-toggle="modal" data-backdrop="true" ><i class="fa fa-eye"></i></a> Voir les villes</li>
				<li class="Infos_TxTbox"><span>Offrimo</span></li>
				<div id="offirimo_character_stics">
				<li class="annoncesBox"><strong>Mon Territoire:</strong><span></span>annonces  PRO:<span></span>|  PAP:<span></span>|  M:<span></span>|  A:<span></span>|  T:<span></span></li>
				<li class="annoncesBox"><strong>Mon Secteur Secondaire:</strong><span></span>annonces  PRO:<span></span>|  PAP:<span></span>|  M:<span></span>|  A:<span></span>|  T:<span></span></li>
				<li class="annoncesBox"><strong>Mon Secteur Prioritaire:</strong><span></span>annonces  PRO:<span></span>|  PAP:<span></span>|  M:<span></span>|  A:<span></span>|  T:<span></span></li>
				</div>
				
			</ul>
		</div>
	</div>

	</div>
</div>
<!-- Modal -->
<div id="CitiesPopup" class="modal fade" role="dialog">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Liste des villes Rhône-Alpes</h4>
			</div>
			<div class="modal-body">
				<div class="CitiesPopup_top">Nombre de villes <span>367</span>    
					<select>
						<option>Export</option>
						<option>Export1</option>
					</select>
				</div>
				<div class="filter">
					<form class="CitiesFilter_form" action="#" method="post">
						<ul>
							<li>Filtre :</li>
							<!--<li>
								<input class="first_intp" name="" placeholder="Mots clefs mean key words i can note in box" type="text">
								<button class="first_Btn">Submit</button>
							</li>-->
							<li>
								<select name="">
									<option>Tri villes par</option>
									<option>Alphabetique A vers Z</option>
									<option>Alphabétique Z vers A</option>
								</select>
							</li>
							<li>
								<select name="">
									<option>Villes par habitants</option>
									<option>De______hab</option>
									<option>+ de ______hab</option>
									<option>Entre_____et___</option>
								</select>
							</li>
							<li>
								<select name="">
									<option>Villes par densité</option>
									<option>Nb croissant hab/km2</option>
									<option>Nb décroissant hab/km2</option>
								</select>
							</li>
							<li>
								<select name="">
									<option>Villes par niveau de vie</option>
									<option>Par revenu décroissant</option>
									<option>Par revenu croissant</option>
								</select>
							</li>
							<li>
								<select name="">
									<option>Villes par classement national</option>
									<option>Par classement décroissant</option>
									<option>Par classement croissant</option>
								</select>
							</li>
						</ul>
					</form>
				</div>
				<div class="Cities_wrapper">
					<div class="CitiesRepeatBox">
						<h5>Liste des villes</h5>
						<ul>
							<li>Ambronay</li>
							<li>Montluel</li>
						</ul>
					</div>
					<div class="CitiesRepeatBox">
						<h5>Nombre d'habitants</h5>
						<ul>
							<li>4972</li>
							<li>1893</li>
						</ul>
					</div>
					<div class="CitiesRepeatBox">
						<h5>Densité (Hab/Km2)</h5>
						<ul>
							<li>561 Hab/Km2</li>
							<li>211 Hab/Km2</li>
						</ul>
					</div>
					<div class="CitiesRepeatBox">
						<h5>Revenu moyen/Hab</h5>
						<ul>
							<li>2512 &euro;</li>
							<li>3088 &euro;</li>
						</ul>
					</div>
					<div class="CitiesRepeatBox">
						<h5>Classement de la ville</h5>
						<ul>
							<li>540</li>
							<li>840</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>