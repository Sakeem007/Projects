<div class="banners" style="background-image: url(images/research-motor-img.png);">
	<div class="Banners_TxT">	
		<h2>Alertimo</h2>
		<h5>
		<p>"Je veux consulter mes requêtes
			<select>
				<option>Vente</option>
				<option>location</option>
			</select>
		<p/>
		<p>concernant les
			<select>
				<option>PRO</option>
				<option>PAP</option>
			</select> pour  
			<select>
				<option>Maison</option>
				<option>Appartement</option>
				<option>Terrain</option>
			</select>
		"</p>
	</div>
</div>
<div class="offrimo">
	<div class="filter diffusimo">
		<form action="#" method="post">
			<ul>
				<li>Filtre :</li>
				<li>
					<input type="date" placeholder="Date requête" />
				</li>
				<li>
					<input type="text" placeholder="Par agent" />
				</li>
				<li>
					<input type="text" placeholder="Nots" />
				</li>
				<li class="btns">
					<button class="submit" type="submit"></button>            
				</li>
				<li class="btns">
					<a class="resetlast" href="#"></a> 
				</li>
			</ul>
		</form>
	</div>
	<div class="listing">
		<form action="#" method="post">
			<ul>
				<li> Listing des requêtes:</li>
				<li><span>27</span></li>
				<li>
					<select>
						<option>Affichage</option>
						<option>List</option>
						<option>Mosaic</option>
					</select>
				</li>
				<li>
					<select>
						<option>Requêtes</option>
						<option>1</option>
						<option>2</option>
					</select>
				</li>
			</ul>
		</form>
	</div>
	<div class="Alertimo_containtWrapper">
		<div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
			<div class="Alertimo_repBox">
				<div class="Alertimo_repBox_header">
					<div class="agentPic"><img src="images/pro1.png" /></div>
					<div class="agentLogo"><img src="images/offrimo-logo.png" /></div>
					<div class="agentclosBtn"><a href="#deletConfor" data-toggle="modal" data-backdrop="true" class="fa fa-times"></a></div>					
				</div>
				<div class="Alertimo_repBox_body">
					<label>Fréquence d'envoie des mails</label>
					<select>
						<option>Temps réel </option>
						<option>Une fois jour</option>
					</select>
					<label>Flux à surveiller</label>
					<select>
						<option>Nouveaux</option>
						<option>Prix en baisse</option>
					</select>
					<label>Critères requête</label>
					<span>Maison</span><span>3P</span><span>300-400 000</span><span>PAP</span><span>Douvaine-Chens</span>
				</div>
				<div class="Alertimo_repBox_footer"><a href="#">Voir les biens envoyés</a></div>
				<div class="clr"></div>
			</div>
		</div>
		<div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
			<div class="Alertimo_repBox">
				<div class="Alertimo_repBox_header">
					<div class="agentPic"><img src="images/pro1.png" /></div>
					<div class="agentLogo"><img src="images/offrimo-logo.png" /></div>
					<div class="agentclosBtn"><a href="#deletConfor" data-toggle="modal" data-backdrop="true" class="fa fa-times"></a></div>					
				</div>
				<div class="Alertimo_repBox_body">
					<label>Fréquence d'envoie des mails</label>
					<select>
						<option>Temps réel </option>
						<option>Une fois jour</option>
					</select>
					<label>Flux à surveiller</label>
					<select>
						<option>Nouveaux</option>
						<option>Prix en baisse</option>
					</select>
					<label>Critères requête</label>
					<span>Maison</span><span>3P</span><span>300-400 000</span><span>PAP</span><span>Douvaine-Chens</span>
				</div>
				<div class="Alertimo_repBox_footer"><a href="#">Voir les biens envoyés</a></div>
				<div class="clr"></div>
			</div>
		</div>
		<div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
			<div class="Alertimo_repBox">
				<div class="Alertimo_repBox_header">
					<div class="agentPic"><img src="images/pro1.png" /></div>
					<div class="agentLogo"><img src="images/offrimo-logo.png" /></div>
					<div class="agentclosBtn"><a href="#deletConfor" data-toggle="modal" data-backdrop="true" class="fa fa-times"></a></div>					
				</div>
				<div class="Alertimo_repBox_body">
					<label>Fréquence d'envoie des mails</label>
					<select>
						<option>Temps réel </option>
						<option>Une fois jour</option>
					</select>
					<label>Flux à surveiller</label>
					<select>
						<option>Nouveaux</option>
						<option>Prix en baisse</option>
					</select>
					<label>Critères requête</label>
					<span>Maison</span><span>3P</span><span>300-400 000</span><span>PAP</span><span>Douvaine-Chens</span>
				</div>
				<div class="Alertimo_repBox_footer"><a href="#">Voir les biens envoyés</a></div>
				<div class="clr"></div>
			</div>
		</div>
		<div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
			<div class="Alertimo_repBox">
				<div class="Alertimo_repBox_header">
					<div class="agentPic"><img src="images/pro1.png" /></div>
					<div class="agentLogo"><img src="images/offrimo-logo.png" /></div>
					<div class="agentclosBtn"><a href="#deletConfor" data-toggle="modal" data-backdrop="true" class="fa fa-times"></a></div>					
				</div>
				<div class="Alertimo_repBox_body">
					<label>Fréquence d'envoie des mails</label>
					<select>
						<option>Temps réel </option>
						<option>Une fois jour</option>
					</select>
					<label>Flux à surveiller</label>
					<select>
						<option>Nouveaux</option>
						<option>Prix en baisse</option>
					</select>
					<label>Critères requête</label>
					<span>Maison</span><span>3P</span><span>300-400 000</span><span>PAP</span><span>Douvaine-Chens</span>
				</div>
				<div class="Alertimo_repBox_footer"><a href="#">Voir les biens envoyés</a></div>
				<div class="clr"></div>
			</div>
		</div>
		<div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
			<div class="Alertimo_repBox">
				<div class="Alertimo_repBox_header">
					<div class="agentPic"><img src="images/pro1.png" /></div>
					<div class="agentLogo"><img src="images/offrimo-logo.png" /></div>
					<div class="agentclosBtn"><a href="#deletConfor" data-toggle="modal" data-backdrop="true" class="fa fa-times"></a></div>					
				</div>
				<div class="Alertimo_repBox_body">
					<label>Fréquence d'envoie des mails</label>
					<select>
						<option>Temps réel </option>
						<option>Une fois jour</option>
					</select>
					<label>Flux à surveiller</label>
					<select>
						<option>Nouveaux</option>
						<option>Prix en baisse</option>
					</select>
					<label>Critères requête</label>
					<span>Maison</span><span>3P</span><span>300-400 000</span><span>PAP</span><span>Douvaine-Chens</span>
				</div>
				<div class="Alertimo_repBox_footer"><a href="#">Voir les biens envoyés</a></div>
				<div class="clr"></div>
			</div>
		</div>
		<div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
			<div class="Alertimo_repBox">
				<div class="Alertimo_repBox_header">
					<div class="agentPic"><img src="images/pro1.png" /></div>
					<div class="agentLogo"><img src="images/offrimo-logo.png" /></div>
					<div class="agentclosBtn"><a href="#deletConfor" data-toggle="modal" data-backdrop="true" class="fa fa-times"></a></div>					
				</div>
				<div class="Alertimo_repBox_body">
					<label>Fréquence d'envoie des mails</label>
					<select>
						<option>Temps réel </option>
						<option>Une fois jour</option>
					</select>
					<label>Flux à surveiller</label>
					<select>
						<option>Nouveaux</option>
						<option>Prix en baisse</option>
					</select>
					<label>Critères requête</label>
					<span>Maison</span><span>3P</span><span>300-400 000</span><span>PAP</span><span>Douvaine-Chens</span>
				</div>
				<div class="Alertimo_repBox_footer"><a href="#">Voir les biens envoyés</a></div>
				<div class="clr"></div>
			</div>
		</div>
		<div class="clr"></div>
	</div>
	<div id="deletConfor" class="modal fade deletConfor" role="dialog">
    <div class="modal-dialog">
		<div class="modal-content">
          <div class="clr"></div>
          <h3>Confirmer la demande de suppression?</h3>
		  <p>Voulez-vous que nous demandions votre confirmation de suppression?</p>
		  <div class="BtnBoxsec">
		  <button type="button" class="btn btn-default">Confirm</button>
		  <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
		  </div>
        </div>
    </div>
</div>
</div>