<div class="rankimo">
	<div class="totalRankMap">
		<div class="repter simulateur_Search_wrapper">
			<div class="tablebox">
				<div class="box">
				  <div class="headerTop">Découvrimo (Mon annonce virtuelle)</div>
				  <div class="contents">
					<ul>
						<li><strong>Appartement 3P de 70m²</strong></li>
						<li><i class="fa fa-map-marker"></i> Annemasse</li>
						<li>99 appartements 3P en ligne</li>
						<li><a href="#">Voir l'annonce simulée</a></li>
						<li>Délais moyen de mise en ligne des biens comparables:_____jrs </li>
					</ul>	
				  </div>
				</div>
				<div class="box">
				  <div class="headerTop">Rankimo ( Mon classement virtuel)</div>
				  <div class="contents">					
					<ul>
						<li><strong>Rank de mon offre simulée: 99/99</strong></li>
						<li><label>Prix Top Rank n°1:</label> <address class="Rank_right_Box"><input name="" type="text" /><span>€</span></address>
						</li>
						<li><label>Prix moyen du Top Rank 5:<br>(les 5 meilleurs prix)</label><address class="Rank_right_Box"><input name="" type="text" /><span>€</span></address>
						</li>
						<li><label>Prix moyen du Top Rank:<br>(les 10 meilleurs prix)</label><address class="Rank_right_Box"><input name="" type="text" /><span>€</span></address>
						</li>
						<li><label>Prix moyen du m² des biens comparables:</label><address class="Rank_right_Box"><input name="" type="text" /><span>€</span> m²</address>
						</li>
					</ul>       
				  </div>
				</div>
				<div class="box">
					<div class="headerTop">Comparimo ( Comparer mon annonce)</div>
					<div class="contents">
						<ul>
							<li><strong>Les écarts constatés sont avec mon offre simulée:</strong></li>
							<li>
							<label>Ecart avec le prix Top Rank n°1:</label><address class="Rank_right_Box"><strong>+/- <b>2000</b></strong><span>€</span></address>
							</li>
							<li>
							<label>Ecart avec le prix moyen du Top Rank 5:</label>
								<address class="Rank_right_Box"><strong>+/- <b>2000</b></strong><span>€</span></address>
							</li>
							<li>
							<label>Ecart avec le prix moyen du top Rank 10:</label>
								<address class="Rank_right_Box"><strong>+/- <b>2000</b></strong><span>€</span></address>
							</li>
							<li>
							<label>Ecart avec le prix moyen du m² des biens comparables:</label>
								<address class="Rank_right_Box"><strong>+/- <b>2000</b></strong><span>€</span></address>
							</li>
						</ul>           
					</div>
				</div>
				<div class="box">
					<div class="headerTop">Synthèse</div>
					<div class="contents">
						<ul>
							<li><strong>Si je veux que mon prix de vente soit:</strong></li>
							<li><label>N°1 des prix en ligne:</label><address class="Rank_right_Box"><input name="" type="text" /><span>€</span></address></li>
							<li><label>Au prix moyen des 5 premiers:</label><address class="Rank_right_Box"><input name="" type="text" /><span>€</span></address></li>
							<li><label>Au prix moyen des 10 premiers:</label><address class="Rank_right_Box"><input name="" type="text" /><span>€</span></address></li>
							<li><label>Au prix moyen du m² comparable:</label><address class="Rank_right_Box"><input name="" type="text" /><span>€</span></address></li>
						</ul>       
				   </div>        
				</div>
			</div>
		</div>
	</div>
</div>
