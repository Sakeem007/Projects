<?php include('header.php');?>

<!-- Being: middle wrapper -->
<main id="middleWrapper">
	
	<!-- Being: home page -->
	<article class="homePage">
		<div class="container">			
			<div class="box">				
				<div class="tableBox hom-es">				
					<!--<div class="img" style="background-image: url(images/bg-2.jpg);">
						<h1>Cela ne s'arrete jamais de commencer... "Je suis convaincu que la croyance et l'excitation pour un objectif, amene la  reussite."</h1>
						<span class="name">Philippe Soulie</span>
					</div>-->
					<div class="col-md-6">
						<div class="row">
						<div class="col-md-6">
							<div class="es-bx1">
								<h3>Offrimo</h3>
							<form action="form">
								<h6>L'offre sur mon territoire</h6>
							<div class="form-group1">
							<label>Maison</label>
							<input type="text" value="">
							</div>
								
								<div class="form-group1">
							<label>Appt</label>
							<input type="text" value="">
							</div>
								
								<div class="form-group1">
							<label>Tenni</label>
							<input type="text" value="">
							</div>
								<div class="clearfix"></div>
								<h6>L'offre sur mon SP</h6>
								<div class="form-group1">
							<label>Surface</label>
							<input type="text" value="">
							</div>
								
								<div class="form-group1">
							<label>Sector</label>
							<input type="text" value="">
							</div>
								
								<div class="form-group1">
							<label>Properties</label>
							<input type="text" value="">
							</div>
								
								<div class="clearfix"></div>
								<h6>L'offre sur mon SS</h6>
								<div class="form-group1">
							<label>Maison</label>
							<input type="text" value="">
							</div>
								<div class="form-group1">
							<label>Appt</label>
							<input type="text" value="">
							</div>
								
								<div class="form-group1">
							<label>Tenni</label>
							<input type="text" value="">
							</div>
								
								
								
							</form>
							</div>
							</div>
							<div class="col-md-6">
								<div class="es-bx2">
								<h3>Observimo</h3>
									<div class="obserbimo-bx">
									<div class="first-cl">
										<h5>Non territory eqmpe=
											<span>-Km<sup>2</sup></span>
										<span>-BAl</span>
										</h5>
										</div>
										<div class="first-cl">
										<h5>Mon SP=
										<span>-Km   + (ville)</span>
										<span>-BAL older-men men identities</span>
										</h5>
										</div>
										<div class="first-cl">
										<h5>Mon SS=
										<span>-Km</span>
										<span>-BAl</span>
										</h5>
										</div>
									</div>
								</div>
							</div>
						</div>
					
					</div>
					<div class="col-md-6">
					<div class="text">
						<h3>Info Flash</h3>
						<p>Vous etes dans votre espace Home Conseiller personnalise et dedie a votre activite. Espaceo est concu pour ameliorer et faciliter votre travail, grace aux differentes applications qui composent cet espace. Ces applications sont interactives, c'est a dire qu'elles s'ameliorent de vos idees et remarques.</p>
						<div class="bottomText">
							<h5>"Notre reussite n'est pas une destination mais un voyage"</h5>
							<div class="companyName">
								<strong>Espaceo</strong>
								<small>Recherche&Developpement</small>
							</div>
						</div>
					</div>
					</div>
				</div>			<div class="socialBox">          <div class="social" ng-controller="usefulCtrl">            <h6 class="accordion">Mes liens utiles </h6>            <ul class="panal">              <li class="S_fst_Line"><a href="{{usefullink.facebook_link}}" class="fb"><span><img src="http://espaceo.ch/assets/images/social1.png" data-pagespeed-url-hash="2317573496" onload="pagespeed.CriticalImages.checkImageForCriticality(this);"/></span> Facebook</a></li>              <li class="S_fst_Line"><a href="{{usefullink.twitter_link}}" class="tw"><span><img src="http://espaceo.ch/assets/images/social2.png" data-pagespeed-url-hash="2612073417" onload="pagespeed.CriticalImages.checkImageForCriticality(this);"/></span> Twitter</a></li>              <li class="S_fst_Line"><a href="{{usefullink.linkedin_link}}" class="in"><span><img src="http://espaceo.ch/assets/images/social3.png" data-pagespeed-url-hash="2906573338" onload="pagespeed.CriticalImages.checkImageForCriticality(this);"/></span> Linkedin</a></li>              <li class="S_scd_Line"><a href="{{usefullink.cadastral_link}}" class="pc"><span><img src="http://espaceo.ch/assets/images/social6.png" data-pagespeed-url-hash="3790073101" onload="pagespeed.CriticalImages.checkImageForCriticality(this);"/></span> Plan Cadastral</a></li>              <li class="S_scd_Line"><a href="{{usefullink.google_map_link}}" class="gm"><span><img src="http://espaceo.ch/assets/images/social7.png" data-pagespeed-url-hash="4084573022" onload="pagespeed.CriticalImages.checkImageForCriticality(this);"/></span> Google Maps</a></li>			    <li class="S_trd_Line"><a href="{{usefullink.limmobilier_link}}" class="sl"><span><img src="http://espaceo.ch/assets/images/social5.png" data-pagespeed-url-hash="3495573180" onload="pagespeed.CriticalImages.checkImageForCriticality(this);"/></span> Site L'immobilier</a></li>							              </ul>          </div>        </div>
			</div>			
		</div>
	</article>
	<!-- End: welcome box -->
	
	
</main>
<!-- End: middle wrapper -->

<?php include('footer.php');?>