<div class="formGrid">
	<div class="tableColum">
		<div class="profile">
			<div class="img" style="background-image: url(images/camraicon.jpg);">
				<div class="overlay">
					<div class="overlay__text">
						<div class="upload-btn-wrapper">
						  <button class="btn"><img src="images/upload.png" width="30px" /></button>
						  <input type="file" name="myfile" />
						</div>					 
					  <div>Upload Image</div>
					</div>
				</div>
			</div>	
			<div class="text">
				<h5>User name</h5>
				<small>User title</small>			</div>
		</div>
		<div class="MySpaceSettings">
			<div class="title">Mes informations:</div>
			<form action="#" method="post">
				<div class="form-group">
					<label>Identifiants de connexion :</label>
					<div class="input-field">
						<input type="text" name="" value=""/>
					</div>
				</div>
				<div class="form-group">
					<label>Mot de passe :</label>
					<div class="input-field">
						<input type="text" name="" value=""/>
					</div>
				</div>
				<div class="form-group">
					<label>Titre :</label>
					<div class="input-field">
						<input type="text" name="" value=""/>
					</div>				</div>
				<div class="form-group">
					<label>Nom :</label>
					<div class="input-field">
						<input type="text" name="" value=""/>
					</div>
				</div>
				<div class="form-group">
					<label>Prénom :</label>
					<div class="input-field">
						<input type="text" name="" value=""/>
					</div>
				</div>
				<div class="form-group">
					<label>Tel :</label>
					<div class="input-field">
						<input type="text" name="" value=""/>
					</div>
				</div>
				<div class="form-group">
					<label>Mail :</label>
					<div class="input-field">
						<input type="text" name="" value=""/>
					</div>
				</div>
				<div class="form-group">
					<input type="button" value="Modifier Paramètres" class="submit"/>
				</div>
			</form>
		</div>
	</div></div>