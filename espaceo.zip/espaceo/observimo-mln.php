<div class="row">
	<div class="mlnBody_wrapper">
	<div class="row">
		<div class="col-xs-12 col-sm-5 col-md-5 col-lg-5">
			<div class="mlnLeftBox">
				<div class="mln_topBox">
				<h5>Règlement MLN<span> « Multi niveaux »</span></h5>
				</div>
			</div>
		</div>
		
		<div class="col-xs-12 col-sm-7 col-md-7 col-lg-7">
			<div class="mlnRightBox">
				<div class="mln_topBox">
				<h5>Mon MLN<span> « Mon équipe »</span></h5>
				<nav class="nav nav-tab">
					<ul>
						<li class="active"><a href="#mlnArborescence" data-toggle="tab">Arborescence </a></li>
					</ul>
				</nav>
				</div>
				<div class="tab-content">			
					<div id="mlnArborescence" class="item tab-pane fade in active">
						<!--<?php //include('observimo-mln-arborescence.php');?>-->
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
</div>