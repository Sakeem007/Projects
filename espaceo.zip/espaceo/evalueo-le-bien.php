<div class="evalueo">
	<div class="row">
		<aside class="item col-xs-12 col-sm-6 col-md-6 col-lg-6">
			<div id="owl-le-bien" class="slider owl-carousel">
				<a href="#" class="img" style="background-image: url(images/pic1.jpg);"></a>
				<a href="#" class="img" style="background-image: url(images/pic2.jpg);"></a>
			</div>
		</aside>
		<aside class="item col-xs-12 col-sm-6 col-md-6 col-lg-6">
			<h6>Type de bien à évaluer </h6>
			<div class="maisonAppart">
				<div class="pics">
					<div class="img">
						<div>
							<img src="images/icon12.png"/>Maison
						</div>
					</div>
				</div>
				<div class="pics">
					<div class="img">
						<div>
							<img src="images/icon13.png"/>Appartment
						</div>
					</div>
				</div>
			</div>
			<div class="form1">
				<form action="#" method="post">
					<div class="input-field">
						<label>Nombre de piéces<span id="spanrequired">*</span></label>
						<label>
							<div class="range2"> 
								<input disabled="" type="text" id="lebienselect1" min="0" max="6" value="0">
								<span class="plusMinus minus" id="lebienselect1_decr_Btn"></span>
								<span class="plusMinus" id="lebienselect1_incr_Btn"></span>
							</div>
						</label>
					</div>
					<div class="input-field">
						<label>Nombre de chambres<span id="spanrequired">*</span></label>
						<label>
							<div class="range2"> 
								<input disabled="" type="text" id="lebienselect1" min="0" max="6" value="0">
								<span class="plusMinus minus" id="lebienselect1_decr_Btn"></span>
								<span class="plusMinus" id="lebienselect1_incr_Btn"></span>
							</div>
						</label>
					</div>
					<div class="input-field">
						<label>Nombre de salles de bain<span id="spanrequired">*</span></label>
						<label>
							<div class="range2"> 
								<input disabled="" type="text" id="lebienselect1" min="0" max="6" value="0">
								<span class="plusMinus minus" id="lebienselect1_decr_Btn"></span>
								<span class="plusMinus" id="lebienselect1_incr_Btn"></span>
							</div>
						</label>
					</div>
					<div class="input-field">
						<label>Nombre de salles d’eau<span id="spanrequired">*</span></label>
						<label>
							<div class="range2"> 
								<input disabled="" type="text" id="lebienselect1" min="0" max="6" value="0">
								<span class="plusMinus minus" id="lebienselect1_decr_Btn"></span>
								<span class="plusMinus" id="lebienselect1_incr_Btn"></span>
							</div>
						</label>
					</div>
				</form>
			</div>
			<div class="form2">
				<label><input type="text" ng-model="cityName" id="home_place" placeholder="Entrez une adresse" class="ng-pristine ng-valid ng-empty ng-touched" autocomplete="off">
				<span id="spanrequired">*</span>	
				</label>
				<label><input type="text" placeholder="Section"></label>
				<label><input type="text" placeholder="N Parcelle"></label>
			</div>
		</aside>		
	</div>
	<div class="map">
		<aside class="map col-xs-12 col-sm-6 col-md-6 col-lg-6">
			<img src="images/map4.jpg">
		</aside>
		<aside class="map col-xs-12 col-sm-6 col-md-6 col-lg-6">
			<img src="images/map5.jpg">
		</aside>
	</div>
</div>