<!doctype html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=0," />
<meta name="SKYPE_TOOLBAR" content="SKYPE_TOOLBAR_PARSER_COMPATIBLE"/>

<title>Espaceo</title>

	<link rel="icon" type="image/png" href="images/favicon.png">
	<link href="https://fonts.googleapis.com/css?family=Raleway:300,400,500,600,700" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css?family=Josefin+Sans:300,400,600" rel="stylesheet">  
	<!--link rel="stylesheet" href="css/kendo.common-material.min.css" /-->
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/owl.carousel.min.css">
	<!--link rel="stylesheet" href="css/icomoon.css"-->
	<!--link rel="stylesheet" href="css/components.css"-->
	<!--link rel="stylesheet" href="css/nouislider.css"-->
	<link rel="stylesheet" href="css/global.css">
	<link rel="stylesheet" href="css/device.css">
	<link rel="stylesheet" href="print.css" type="text/css" media="print" />
	  <style>
  /* Note: Try to remove the following lines to see the effect of CSS positioning */
  .affix {
    top: 0;
    width: 100%;
    z-index: 9999 !important;
  }

  </style>
</head>

<body>
<div id="wrapper">
<!-- Being: header wrapper -->
<header id="headerWrapper" data-spy="affix" data-offset-top="200">
	<div class="header">
		<div class="container">
			<div class="topHeader">
				<div class="container">
					<div class="leftLogo">
						<a href="#" method="post"><img src="images/logo1.png"/></a>
					</div>					
					<!-- Being: logo box -->
					<div class="logo">
						<a href="index.php"><img src="images/logo2.png"/></a>
					</div>
					<!-- End: logo box -->					
					<!-- Being: form -->
					<div class="form">
						<form action="#" method="post">
							<input type="text" placeholder="Recherche Tel / Reference / Nom / etc..." class="search"/>
							<input type="submit" value="" class="search_btn"/>
						</form>
					</div>
					<!-- End: form -->
					<!-- Being: form -->
					<div class="timeProfile">					
						<div class="dateTime">
							<img src="images/icon5.png"/> Time : 10 March 2018 | 18h 58s 15min
						</div>
						<div class="profile">							
							<a href="javascript:void();">
								<span class="img" style="background-image: url(images/justin.png);"></span>
								Justin Adams
								<small>LI100318</small>
							</a>
							<ul>
								<li><a href="#">Login</a></li>
							</ul>
							<span class="mobileBtn"><i class="fa fa-bars"></i></span>
						</div>						
					</div>
					<!-- End: form -->
					
				</div>
			</div>
			<div class="bottomHeader">
				<div class="container">
					<?php $url= explode('/', $_SERVER['SCRIPT_NAME']);
					//print_r($url);
					?>
					<!-- Being: menu box -->
					<nav class="menuBox">
						<ul class="navbar-nav">
							<li><a href="javascript:void(0)"><strong>My space<small></small></strong></a></li>
							<li><a href="javascript:void(0)"><strong>Etudeo<small></small></strong></a></li>
							<li><a href="buyer-my-request.php"><strong>Ma Demande<small></small></strong></a></li>
							<li><a href="javascript:void(0)"><strong>Offrimo<small></small></strong></a></li>
						</ul>
					</nav>
					<!-- Being: menu box -->					
				</div>
			</div>
			<a class="scrolTop" href="javascript:void();"></a>
		</div>
	</div>
</header>
<!-- End: header wrapper -->
<!-- Being: middle wrapper -->
<main id="middleWrapper">