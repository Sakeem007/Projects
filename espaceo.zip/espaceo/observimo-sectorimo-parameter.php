<article class="Prospectimo">
	<div class="container">
		<nav class="nav nav-tab">
			<ul>
				<li class="active"><a href="#parametrem1" data-toggle="tab">Sectorimo parametrem1</a></li>
				<li><a href="#parametrem2" data-toggle="tab">Sectorimo parametrem2</a></li>
				<li><a href="#parametrem3" data-toggle="tab">Sectorimo parametrem3</a></li>
			</ul>
		</nav>
		<div class="tab-content">			
			<div id="parametrem1" class="item tab-pane fade in active">
				<div class="row">	
					<div class="tab-content">
						<?php include('observimo-sectorimo1.php');?>
					</div>
				</div>
			</div>
			<div id="parametrem2" class="item tab-pane fade">
				<div class="row">	
					<div class="tab-content">
						<?php include('observimo-sectorimo2.php');?>
					</div>
				</div>
			</div>
			<div id="parametrem3" class="item tab-pane fade">
				<div class="row">	
					<div class="tab-content">
						<?php include('observimo-sectorimo3.php');?>
					</div>
				</div>
			</div>
		</div>
	</div>
</article>