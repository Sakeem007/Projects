	<div class="SellerMyOffers">
		<div class="banners" style="background-image: url(images/searvhBannerbg.jpg);">
			<h2>Chercher un bien <span>(Maison & Appartement)</span></h2>
			<h5>Je veux consulter l'offre 
			<select>
				<option>Vente</option>
				<option>Location</option>
			</select> pour les  
			<select data-placeholder="ville,code postal" multiple="" name="address[]" class="select select2-hidden-accessible" tabindex="-1" aria-hidden="true">
				<option value="">Maisons / Appartements / Terrains </option>
			</select>  avec un rayon de  
			<input type="text" name="distance" placeholder="Kms" id="distance" value=""> et je peux ajouter <span class="SellerMonForm">+ de criteres</span>  et en utilisant 
			<select name="image_type" class="CategorieImages">
				<option value="">l’imagerie</option>
				<option value="office">Bureau</option> 
				<option value="bedroom">Chambre</option> 
				<option value="kitchen">Cuisine</option> 
				<option value="outdoor_building">Façade immeuble</option> 
				<option value="water_view">Vue sur l'eau</option> 
				<option value="front_house">Façade maison</option> 
				<option value="backyard">Arrière-cour</option> 
				<option value="dining_area">Salle à manger</option> 
				<option value="bathroom">Salle de bains</option> 
				<option value="living_room">Salon</option> 
				<option value="mountain_view">Vue sur la montagne</option> 
				<option value="foyer_entrance">Entrée_du_foyer</option> 
				<option value="gym">Gym</option> 
				<option value="garage">Garage</option> 
				<option value="wine_room">Cave à vin</option> 
				<option value="cinema_room">Salle de cinéma</option> 
				<option value="plan">Plan</option> 
			</select></h5>
			<a href="#" class="whiteBtn">Lancer recherche</a>
			<a href="#" class="whiteBtn">Lancer recherche et creer une requete</a>
			
			<div id="seller_de_criteres_form" class="expend-form">
				<div class="maisonsFormMain_Wrapper"> 
					<a href="javascript:void();" class="SellerClose"><i class="fa fa-times" ></i></a>
					<h4>"Critère(s) supplémentaires"</h4>
					<div class="Field_Wrapper">
					  <label>Nb de pièce(s):</label>
					  <select name="pices">
						<option value=""></option>
						<option value="1">1</option>
						<option value="2">2</option>
						<option value="3">3</option>
						<option value="4">4</option>
						<option value="5">5</option>
						<option value="6">6</option>
						<option value="7">7</option>
						<option value="8">8</option>
						<option value="9">9</option>
						<option value="10">10</option>
						<option value="11">11</option>
						<option value="12">12</option>
						<option value="13">13</option>
						<option value="14">14</option>
						<option value="15">15</option>
					  </select>
					  <span>ou entre</span>
					  <select name="pices_min">
						<option value=""></option>
						<option value="1">1</option>
						<option value="2">2</option>
						<option value="3">3</option>
						<option value="4">4</option>
						<option value="5">5</option>
						<option value="6">6</option>
						<option value="7">7</option>
						<option value="8">8</option>
						<option value="9">9</option>
						<option value="10">10</option>
						<option value="11">11</option>
						<option value="12">12</option>
						<option value="13">13</option>
						<option value="14">14</option>
						<option value="15">15</option>
					  </select>
					  <span>et</span>
					  <select name="pices_max">
						<option value=""></option>
						<option value="1">1</option>
						<option value="2">2</option>
						<option value="3">3</option>
						<option value="4">4</option>
						<option value="5">5</option>
						<option value="6">6</option>
						<option value="7">7</option>
						<option value="8">8</option>
						<option value="9">9</option>
						<option value="10">10</option>
						<option value="11">11</option>
						<option value="12">12</option>
						<option value="13">13</option>
						<option value="14">14</option>
						<option value="15">15</option>
					  </select>
					</div>
					<div class="clearfix"></div>
					<div class="Field_Wrapper">
					  <label>Surface habitable:</label>
					  <input type="text" name="surface" value="">
					  <span>ou entre</span>
					  <input type="text" name="surface_min" value="">
					  <span>et</span>
					  <input type="text" name="surface_max" value="">
					</div>
					<div class="clearfix"></div>
					<div class="Field_Wrapper">
					  <label>Surface du terrain:</label>
					  <input type="text" name="surface_land" value="">
					  <span>ou entre</span>
					  <input type="text" name="surface_land_min" value="">
					  <span>et</span>
					  <input type="text" name="surface_land_max" value="">
					</div>
					<div class="clearfix"></div>
					<div class="Field_Wrapper">
					  <label>Nb de chambre(s):</label>
					  <select name="nbchambres">
						<option value=""></option>
						<option value="1">1</option>
						<option value="2">2</option>
						<option value="3">3</option>
						<option value="4">4</option>
						<option value="5">5</option>
						<option value="6">6</option>
						<option value="7">7</option>
						<option value="8">8</option>
						<option value="9">9</option>
						<option value="10">10</option>
						<option value="11">11</option>
						<option value="12">12</option>
						<option value="13">13</option>
						<option value="14">14</option>
						<option value="15">15</option>
					  </select>
					  <span>ou entre</span>
					  <select name="nbchambres_min">
						<option value=""></option>
						<option value="1">1</option>
						<option value="2">2</option>
						<option value="3">3</option>
						<option value="4">4</option>
						<option value="5">5</option>
						<option value="6">6</option>
						<option value="7">7</option>
						<option value="8">8</option>
						<option value="9">9</option>
						<option value="10">10</option>
						<option value="11">11</option>
						<option value="12">12</option>
						<option value="13">13</option>
						<option value="14">14</option>
						<option value="15">15</option>
					  </select>
					  <span>et</span>
					  <select name="nbchambres_max">
						<option value=""></option>
						<option value="1">1</option>
						<option value="2">2</option>
						<option value="3">3</option>
						<option value="4">4</option>
						<option value="5">5</option>
						<option value="6">6</option>
						<option value="7">7</option>
						<option value="8">8</option>
						<option value="9">9</option>
						<option value="10">10</option>
						<option value="11">11</option>
						<option value="12">12</option>
						<option value="13">13</option>
						<option value="14">14</option>
						<option value="15">15</option>
					  </select>
					</div>
					<div class="clearfix"></div>
					<div class="Field_Wrapper">
					  <label>Nb de SDB:</label>
					  <input type="text" name="bathroom" value="">
					  <span>ou entre</span>
					  <input type="text" name="bathroom_min" value="">
					  <span>et</span>
					  <input type="text" name="bathroom_max" value="">
					</div>
					<div class="clearfix"></div>
					<div class="Field_Wrapper last">
					  <label>Prix de vente:</label>
					  <span>entre </span>
					  <input type="text" name="price_min" value="">
					  <b>€</b> <span>et</span>
					  <input type="text" name="price_max" value="">
					  <b>€</b> </div>
					<div class="clearfix"></div>
					<div class="Valider_Box">
					  <input type="submit" class="whiteBtn" value="Valider">
					  <a class="resetlast" href=""></a></div>
					<div class="clearfix"></div>
				</div>
			</div>
		</div>
		<div class="filter">
			<form action="#" method="post">
				<ul>
					<li>Filtre :</li>
					<li><select>
						<option>En-ligne/Expirees</option>
						<option>En-ligne/Expirees</option>
						<option>En-ligne/Expirees</option>
					</select></li>
					<li><select>
						<option>Date de parution</option>
						<option>Date de parution</option>
						<option>Date de parution</option>
					</select></li>
					<li><select>
						<option>PRO/PAP</option>
						<option>PRO/PAP</option>
						<option>PRO/PAP</option>
					</select></li>
					<li>
						<select>
							<option>Par agence</option>
						</select>
					</li>
					<li>
						<select>
							<option>Tri par prix</option>
							<option>Tri par prix</option>
							<option>Tri par prix</option>
						</select>
					</li>
					<li>
						<select name="announcer">
							<option value="">Tri annonceurs</option>
							<option value="all">Tous</option>
							<option value="leboncoin">LBC</option>
							<option value="seloger">Seloger</option>
							<option value="logicimmo">Logicimmo</option>
						</select>
					</li>
					<li>
						<select name="rankimo">
							<option value="">Tri Rankimo</option>
							<option value="1">N°1</option>
							<option value="5">5 premiers</option>
							<option value="10">10 premiers</option>
							<option value="20">20 premiers</option>
						</select>
					</li>
					<li>
						<select name="orderbydate">
							<option value="">Neuf/Ancien</option>
							<option value="desc">Neuf</option>
							<option value="asc">Ancien</option>
						</select>
					</li>
					<li>
						<select name="chassimo">
							<option value="">Chassimo</option>
							<option value="vert">Vert</option>
							<option value="rouge">Rouge</option>
						</select>
					</li>
					<li>
						<select name="chassimo_user"><option value="">Chassimo team</option>			
							<option value="1">Philippe Soulié</option>
							<option value="5">Philippe Soulié</option>
							<option value="6">Philippe Soulié</option>
							<option value="10"> Clément</option>
							<option value="16">BONNET Alex</option>
							<option value="18">KINCHE Stéphanie</option>
							<option value="19">GROSJEAN Laurence</option>
							<option value="23">ROL Sébastien</option>
						</select>
					</li>
					<li class="btns">
						<button class="submit" type="submit"></button>            
					</li>
					<li class="btns">
						<a class="resetlast" href="javascript:void(0)"></a> 
					</li>
				</ul>
			</form>
		</div>
	</div>
<div class="offrimo">
	<div class="listing">
		<form action="#" method="post">
			<ul>
				<li><em> Listing  des biens :</em></li>
				<li><span>4 biens</span></li>
				<li><a href="#">Exporter</a></li>
				<li>
					<select>
						<option>Affichage</option>
						<option>List</option>
					</select>
				</li>
				<li>
					<select>
						<option>10 biens</option>
						<option>20 biens</option>
						<option>30 biens</option>
					</select>
				</li>
			</ul>
		</form>
	</div>
	<div class="affichageBox">
			<div class="ComparateurBox"><a href="offrimo-maisons-offerlist.php"><i class="fa fa-eye first_home"></i><label>0</label><span>/</span><i class="fa fa-eye Last_home"></i> <b class="ComparateurTXT">Comparateur</b></a></div>
		<div class="repter">
			<div class="tablebox">
				<div class="box">
					<div class="img slider_Section">
							<div class="carousel slide" data-ride="carousel" data-type="multi" data-interval="false" id="myCarousel">
							<!-- Wrapper for slides -->
							<div class="carousel-inner">
							  <div class="item active">
								<img src="images/offrimo1.png" alt="Los Angeles" style="width:100%;">
							  </div>
							  <div class="item">
								<img src="images/offrimo2.png" alt="Chicago" style="width:100%;">
							  </div>							
							  <div class="item">
								<img src="images/offrimo3.png" alt="New york" style="width:100%;">
							  </div>
							</div>
							<!-- Left and right controls -->
							<a class="left carousel-control" href="#myCarousel" data-slide="prev">
							  <span class="glyphicon glyphicon-chevron-left"></span>
							  <span class="sr-only">Previous</span>
							</a>
							<a class="right carousel-control" href="#myCarousel" data-slide="next">
							  <span class="glyphicon glyphicon-chevron-right"></span>
							  <span class="sr-only">Next</span>
							</a>
						  </div>
						  <div class="offrimoHomeIcon"><a href="#" class="active"><i class="fa fa-eye first_home"></i><span>/</span><i class="fa fa-eye Last_home"></i></a></div>
					     <span class="pro_Rebon"><img src="images/mandar_agennce_reban.png"/></span>
						<span class="topBtn">PRO</span>
						<span class="locBtn">Douvaine</span>
					</div>
				</div>
				<div class="box">
					<div class="headerTop">Annonce <span>892 500 &euro;</span></div>
					<div class="contents">
						<div class="padRight">
							<span class="plus"></span>
							<h6>Appartement duplex T4</h6>
							<p>Cove + goroge double en sous-sol + porking privotif.<br>Acces facile outoroute Annecy Nord et Allozier (Bordonnex a 20 min) Chouffoge individuel goz.<br>Charges copro. 100 &euro; / mois</p>
						</div>
						<a href="#" class="blueBtn">Suivre le prix</a>
						<a href="#" class="blueBtn">Voir l'annonce</a>
						<h6>Publiee par Poirier Immobilier 04 57 43 50 12</h6>
					</div>
				</div>
				<div class="box">
					<div class="headerTop">Historique</div>
					<div class="contents">
						<ul>
							<li>Creation Annonce : 25/12/2017 a 15h</li>
							<li>En ligne depuis : 83 jours</li>
							<li>Dernieres modifications prix :
								<span>25/01/2017 : <strike>395000</strike> a 377000 &euro;</span>
								<span>22/03/2017 : <strike>377000</strike> a 370000 &euro;</span>
							</li>
							<li>Portails :</li>
						</ul>
						<div class="colorBtns">
							<ul>
								<li><a href="#">leBonCoin</a></li>
								<li><a href="#">PAP</a></li>
								<li><a href="#">VivaStreet</a></li>
								<li><a href="#">Seloger</a></li>
							</ul>
						</div>
					</div>
				</div>
				<div class="box">
					<div class="headerTop">Appreciation</div>
					<div class="appreciation">
						<span class="title">Selon vous?</span>
						<ul class="selon">
							<li>Pas chers</li>
							<li>Au prix</li>
							<li>Trop chers</li>
						</ul>
						<h6>Rankimo</h6>
						<span class="rank">59/203</span>
						<p>Votre bien est classe 59/203 a Ambilly "74100" (3 pieces).</p>
						<a href="#" class="blueBtn">Evalueo</a>
					</div>
				</div>
				<div class="box">
					<div class="headerTop">priorite</div>
					<div class="contents">
						<label><input type="checkbox"/><span></span> Coll</label>
						<label><input type="checkbox"/><span></span> Moi</label>
						<a href="chassimo.php">Chassimo</a>
					</div>
				</div>
				
			</div>
			<div class="bottomMenu">
				<ul>
					<li><a href="#">Mandat agence</a></li>
					<li><a href="#">Ancien Mandat</a></li>
					<li><a href="#">Vendu & Archive</a></li>
					<li><a href="#">Agence Partenaire</a></li>
					<li><a href="#Chassimo" data-toggle="modal" data-backdrop="true">Chassimo</a></li>
					<li><a href="#">Imprimer PDF</a></li>
				</ul>
			</div>
		</div>
		<div class="repter">
			<div class="tablebox">
				<div class="box">
					<div class="img slider_Section">
						  <div id="myCarousel1" class="carousel slide" data-ride="carousel">
							<!-- Wrapper for slides -->
							<div class="carousel-inner">
							  <div class="item active">
								<img src="images/offrimo1.png" alt="Los Angeles" style="width:100%;">
							  </div>
							  <div class="item">
								<img src="images/offrimo2.png" alt="Chicago" style="width:100%;">
							  </div>							
							  <div class="item">
								<img src="images/offrimo3.png" alt="New york" style="width:100%;">
							  </div>
							</div>
							<!-- Left and right controls -->
							<a class="left carousel-control" href="#myCarousel1" data-slide="prev">
							  <span class="glyphicon glyphicon-chevron-left"></span>
							  <span class="sr-only">Previous</span>
							</a>
							<a class="right carousel-control" href="#myCarousel1" data-slide="next">
							  <span class="glyphicon glyphicon-chevron-right"></span>
							  <span class="sr-only">Next</span>
							</a>
						  </div>
					<span class="pro_Rebon"><img src="images/ancien_mandar_rebun.png"/></span>
						  <div class="offrimoHomeIcon"><a href="#"><i class="fa fa-eye first_home"></i><span>/</span><i class="fa fa-eye Last_home"></i></a></div>
						<span class="topBtn">PRO</span>
						<span class="locBtn">Douvaine</span>
					</div>
				</div>
				<div class="box">
					<div class="headerTop">Annonce <span>892 500 &euro;</span></div>
					<div class="contents">
						<div class="padRight">
							<span class="plus"></span>
							<h6>Appartement duplex T4</h6>
							<p>Cove + goroge double en sous-sol + porking privotif.<br>Acces facile outoroute Annecy Nord et Allozier (Bordonnex a 20 min) Chouffoge individuel goz.<br>Charges copro. 100 &euro; / mois</p>
						</div>
						<a href="#" class="blueBtn">Suivre le prix</a>
						<a href="#" class="blueBtn">Voir l'annonce</a>
						<h6> Publiée par Mr CARON 06 63 68 13 17</h6>
					</div>
				</div>
				<div class="box">
					<div class="headerTop">Historique</div>
					<div class="contents">
						<ul>
							<li>Creation Annonce : 25/12/2017 a 15h</li>
							<li>En ligne depuis : 83 jours</li>
							<li>Dernieres modifications prix :
								<span>25/01/2017 : <strike>395000</strike> a 377000 &euro;</span>
								<span>22/03/2017 : <strike>377000</strike> a 370000 &euro;</span>
							</li>
							<li>Portails :</li>
						</ul>
						<div class="colorBtns">
							<ul>
								<li><a href="#">leBonCoin</a></li>
								<li><a href="#">PAP</a></li>
								<li><a href="#">VivaStreet</a></li>
							</ul>
						</div>
					</div>
				</div>
				<div class="box">
					<div class="headerTop">Appreciation</div>
					<div class="appreciation">
						<span class="title">Selon vous?</span>
						<ul class="selon">
							<li>Pas chers</li>
							<li>Au prix</li>
							<li>Trop chers</li>
						</ul>
						<h6>Rankimo</h6>
						<span class="rank">59/203</span>
						<p>Votre bien est classe 59/203 a Ambilly "74100" (3 pieces).</p>
						<a href="#" class="blueBtn">Evalueo</a>
					</div>
				</div>
				<div class="box">
					<div class="headerTop">priorite</div>
					<div class="contents">
						<label><input type="checkbox"/><span></span> Coll</label>
						<label><input type="checkbox"/><span></span> Moi</label>
						<a href="chassimo.php">Chassimo</a>
					</div>
				</div>
			</div>
			<div class="bottomMenu">
				<ul>
					<li><a href="#">Mandat agence</a></li>
					<li><a href="#">Ancien Mandat</a></li>
					<li><a href="#">Vendu & Archive</a></li>
					<li><a href="#">Agence Partenaire</a></li>
					<li><a href="#Chassimo" data-toggle="modal" data-backdrop="true">Chassimo</a></li>
					<li><a href="#"></a></li>
				</ul>
			</div>
		</div>
		<div class="repter">
			<div class="tablebox">
				<div class="box">
					<div class="img" style="background-image: url(images/offrimo2.png)"></div>
				</div>
				<div class="box">
					<div class="headerTop">Annonce <span>892 500 &euro;</span></div>
					<div class="contents">
						<div class="padRight">
							<span class="plus"></span>
							<h6>Appartement duplex T4</h6>
							<p>Pringy secteur Promery, proche ecoles et service bus, appertement T3 de 64m2 en parfait etat dans residence recente securisee, calme et arboree.<br>
							Entree ovec rangement, 2 chambres avec placards, salle de bain double vasques, wc separes, cuisine equipee ouverte sur sejour lumineux, ouvrant sur un agreable balcon de + 9m2 expose plein sud avec vue montagnes.</p>
							<p>Cove + goroge double en sous-sol + porking privotif.<br>Acces facile outoroute Annecy Nord et Allozier (Bordonnex a 20 min) Chouffoge individuel goz.<br>Charges copro. 100 &euro; / mois</p>					
						</div>
					</div>
				</div>
				<div class="box">
					<div class="headerTop">Historique</div>
					<div class="contents">
						<ul>
							<li>Creation Annonce : 25/12/2017 a 15h</li>
							<li>En ligne depuis : 83 jours</li>
							<li>Dernieres modifications prix :
								<span>25/01/2017 : <strike>395000</strike> a 377000 &euro;</span>
								<span>22/03/2017 : <strike>377000</strike> a 370000 &euro;</span>
							</li>
							<li>Portails :</li>
						</ul>
						<div class="colorBtns">
							<ul>
								<li><a href="#">leBonCoin</a></li>
								<li><a href="#">PAP</a></li>
								<li><a href="#">VivaStreet</a></li>
								<li><a href="#">Seloger</a></li>
							</ul>
						</div>
					</div>
				</div>
				<div class="box">
					<div class="headerTop">Appreciation</div>
					<div class="appreciation">
						<h6>Rankimo</h6>
						<span class="rank">59/203</span>
						<p>Votre bien est classe 59/203 a Ambilly "74100" (3 pieces).</p>
						<h6>Evalueo en ligne</h6>
						<div class="range"><em><input id="offer-price1" type="range" min="169000" max="198000" value=""/></em>
						<p><span>169000 &euro;</span><span id="offer-result1">180000 &euro;</span><span>198000 &euro;</span></p></div>
						<ul>
							<li>Prix m<sup>2</sup> Evalueo : 2937 &euro;</li>
							<li>Prix m<sup>2</sup> Annonce : 3137 &euro;</li>
							<li>Appreciation prix m<sup>2</sup> Annonce : + 200 &euro;</li>
						</ul>
					</div>
				</div>
				<div class="box">
					<div class="headerTop">priorite</div>
					<div class="contents">
						<label><input type="checkbox"/><span></span> Coll</label>
						<label><input type="checkbox"/><span></span> Moi</label>
						<a href="chassimo.php">Chassimo</a>
					</div>
				</div>
			</div>
			<div class="bottomMenu">
				<ul>
					<li><a href="#">Mandat agence</a></li>
					<li><a href="#">Ancien Mandat</a></li>
					<li><a href="#">Vendu & Archive</a></li>
					<li><a href="#">Agence Partenaire</a></li>
					<li><a href="#Chassimo" data-toggle="modal" data-backdrop="true">Chassimo</a></li>
					<li><a href="#"></a></li>
				</ul>
			</div>
		</div>
		<div class="repter">
			<div class="tablebox">
				<div class="box">
					<div class="img" style="background-image: url(images/offrimo2.png)"></div>
				</div>
				<div class="box">
					<div class="headerTop">Annonce <span>892 500 &euro;</span></div>
					<div class="contents">
						<div class="padRight">
							<span class="plus"></span>
							<h6>Appartement duplex T4</h6>
							<p>Pringy secteur Promery, proche ecoles et service bus, appertement T3 de 64m2 en parfait etat dans residence recente securisee, calme et arboree.<br>
							Entree ovec rangement, 2 chambres avec placards, salle de bain double vasques, wc separes, cuisine equipee ouverte sur sejour lumineux, ouvrant sur un agreable balcon de + 9m2 expose plein sud avec vue montagnes.</p>
							<p>Cove + goroge double en sous-sol + porking privotif.<br>Acces facile outoroute Annecy Nord et Allozier (Bordonnex a 20 min) Chouffoge individuel goz.<br>Charges copro. 100 &euro; / mois</p>					
						</div>
					</div>
				</div>
				<div class="box">
					<div class="headerTop">Historique</div>
					<div class="contents">
						<ul>
							<li>Creation Annonce : 25/12/2017 a 15h</li>
							<li>En ligne depuis : 83 jours</li>
							<li>Dernieres modifications prix :
								<span>25/01/2017 : <strike>395000</strike> a 377000 &euro;</span>
								<span>22/03/2017 : <strike>377000</strike> a 370000 &euro;</span>
							</li>
							<li>Portails :</li>
						</ul>
						<div class="colorBtns">
							<ul>
								<li><a href="#">leBonCoin</a></li>
								<li><a href="#">PAP</a></li>
								<li><a href="#">VivaStreet</a></li>
								<li><a href="#">Seloger</a></li>
							</ul>
						</div>
					</div>
				</div>
				<div class="box">
					<div class="headerTop">Appreciation</div>
					<div class="appreciation">
						<h6>Rankimo</h6>
						<span class="rank">59/203</span>
						<p>Votre bien est classe 59/203 a Ambilly "74100" (3 pieces).</p>
						<h6>Evalueo en ligne</h6>
						<div class="range"><em><input id="offer-price2" type="range" min="169000" max="198000" value=""/></em>
						<p><span>169000 &euro;</span><span id="offer-result2">180000 &euro;</span><span>198000 &euro;</span></p></div>
						<ul>
							<li>Prix m<sup>2</sup> Evalueo : 2937 &euro;</li>
							<li>Prix m<sup>2</sup> Annonce : 3137 &euro;</li>
							<li>Appreciation prix m<sup>2</sup> Annonce : + 200 &euro;</li>
						</ul>
					</div>
				</div>
				<div class="box">
					<div class="headerTop">priorite</div>
					<div class="contents">
						<label><input type="checkbox"/><span></span> Coll</label>
						<label><input type="checkbox"/><span></span> Moi</label>
						<a href="chassimo.php">Chassimo</a>
					</div>
				</div>
			</div>
			<div class="bottomMenu">
				<ul>
					<li><a href="#">Mandat agence</a></li>
					<li><a href="#">Ancien Mandat</a></li>
					<li><a href="#">Vendu & Archive</a></li>
					<li><a href="#">Agence Partenaire</a></li>
					<li><a href="#Chassimo" data-toggle="modal" data-backdrop="true">Chassimo</a></li>
					<li><a href="#"></a></li>
				</ul>
			</div>
		</div>
	</div>
	<div class="listGridBox">
		<div class="row">
			<div class="box col-xs-12 col-sm-3 col-md-3 col-lg-3">
				<a href="#" class="img" style="background-image: url(images/offrimo1.png)">
					<span class="topBtn">PRO</span>
					<span class="locBtn">Douvaine</span>
					<div class="text">
						<h6>Appartement duplex T4</h6>
						<p>Cove + goroge double en sous-sol + porking privotif.Acces facile outoroute Annecy Nord et Allozier (Bordonnex a 20 min) Chouffoge individuel goz. Charges copro. 100 € / mois</p>
						<span class="rate">892 500 €</span>
					</div>
				</a>
			</div>
			<div class="box col-xs-12 col-sm-3 col-md-3 col-lg-3">
				<a href="#" class="img" style="background-image: url(images/offrimo1.png)">
					<span class="topBtn">PRO</span>
					<span class="locBtn">Douvaine</span>
					<div class="text">
						<h6>Appartement duplex T4</h6>
						<p>Cove + goroge double en sous-sol + porking privotif.Acces facile outoroute Annecy Nord et Allozier (Bordonnex a 20 min) Chouffoge individuel goz. Charges copro. 100 € / mois</p>
						<span class="rate">892 500 €</span>
					</div>
				</a>
			</div>
			<div class="box col-xs-12 col-sm-3 col-md-3 col-lg-3">
				<a href="#" class="img" style="background-image: url(images/offrimo1.png)">
					<span class="topBtn">PRO</span>
					<span class="locBtn">Douvaine</span>
					<div class="text">
						<h6>Appartement duplex T4</h6>
						<p>Cove + goroge double en sous-sol + porking privotif.Acces facile outoroute Annecy Nord et Allozier (Bordonnex a 20 min) Chouffoge individuel goz. Charges copro. 100 € / mois</p>
						<span class="rate">892 500 €</span>
					</div>
				</a>
			</div>
			<div class="box col-xs-12 col-sm-3 col-md-3 col-lg-3">
				<a href="#" class="img" style="background-image: url(images/offrimo1.png)">
					<span class="topBtn">PRO</span>
					<span class="locBtn">Douvaine</span>
					<div class="text">
						<h6>Appartement duplex T4</h6>
						<p>Cove + goroge double en sous-sol + porking privotif.Acces facile outoroute Annecy Nord et Allozier (Bordonnex a 20 min) Chouffoge individuel goz. Charges copro. 100 € / mois</p>
						<span class="rate">892 500 €</span>
					</div>
				</a>
			</div>
			<div class="box col-xs-12 col-sm-3 col-md-3 col-lg-3">
				<a href="#" class="img" style="background-image: url(images/offrimo1.png)">
					<span class="topBtn">PRO</span>
					<span class="locBtn">Douvaine</span>
					<div class="text">
						<h6>Appartement duplex T4</h6>
						<p>Cove + goroge double en sous-sol + porking privotif.Acces facile outoroute Annecy Nord et Allozier (Bordonnex a 20 min) Chouffoge individuel goz. Charges copro. 100 € / mois</p>
						<span class="rate">892 500 €</span>
					</div>
				</a>
			</div>
			<div class="box col-xs-12 col-sm-3 col-md-3 col-lg-3">
				<a href="#" class="img" style="background-image: url(images/offrimo1.png)">
					<span class="topBtn">PRO</span>
					<span class="locBtn">Douvaine</span>
					<div class="text">
						<h6>Appartement duplex T4</h6>
						<p>Cove + goroge double en sous-sol + porking privotif.Acces facile outoroute Annecy Nord et Allozier (Bordonnex a 20 min) Chouffoge individuel goz. Charges copro. 100 € / mois</p>
						<span class="rate">892 500 €</span>
					</div>
				</a>
			</div>
			<div class="box col-xs-12 col-sm-3 col-md-3 col-lg-3">
				<a href="#" class="img" style="background-image: url(images/offrimo1.png)">
					<span class="topBtn">PRO</span>
					<span class="locBtn">Douvaine</span>
					<div class="text">
						<h6>Appartement duplex T4</h6>
						<p>Cove + goroge double en sous-sol + porking privotif.Acces facile outoroute Annecy Nord et Allozier (Bordonnex a 20 min) Chouffoge individuel goz. Charges copro. 100 € / mois</p>
						<span class="rate">892 500 €</span>
					</div>
				</a>
			</div>
			<div class="box col-xs-12 col-sm-3 col-md-3 col-lg-3">
				<a href="#" class="img" style="background-image: url(images/offrimo1.png)">
					<span class="topBtn">PRO</span>
					<span class="locBtn">Douvaine</span>
					<div class="text">
						<h6>Appartement duplex T4</h6>
						<p>Cove + goroge double en sous-sol + porking privotif.Acces facile outoroute Annecy Nord et Allozier (Bordonnex a 20 min) Chouffoge individuel goz. Charges copro. 100 € / mois</p>
						<span class="rate">892 500 €</span>
					</div>
				</a>
			</div>
		</div>
		<div class="bottomMenu">
			<ul>
				<li><a href="#">Mandat agence</a></li>
				<li><a href="#">Ancien Mandat</a></li>
				<li><a href="#">Vendu & Archive</a></li>
				<li><a href="#">Agence Partenaire</a></li>
				<li><a href="#Chassimo" data-toggle="modal" data-backdrop="true">Chassimo</a></li>
				<li><a href="#">Imprimer PDF</a></li>
			</ul>
		</div>
	</div>
	<div class="pagination">
		<strong>1</strong>
		<a href="#">2</a>
		<a href="#">3</a>
		<a href="#">></a>
		<a href="#">Last ›</a>			
	</div>
	
</div>