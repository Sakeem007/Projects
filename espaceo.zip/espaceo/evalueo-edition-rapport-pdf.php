<?php include('header.php');?>
<style>
label input[type="checkbox"] {

    margin: 0px;
    width: 20px;
    height: 20px;
    position: absolute;
    left: 0px;
    top: 0px;
    opacity: 0;

}
label input[type="checkbox"] + em {

    width: 18px;
    height: 18px;
    border: 1px solid #666;
    position: absolute;
    left: 0px;
    top: 5px;

}
label input[type="checkbox"]:checked + em::after {

    content: '';
    width: 11px;
    height: 7px;
    border-left: 2px solid #314961;
    border-bottom: 2px solid #314961;
    position: absolute;
    left: 4px;
    top: 4px;
    transform: rotate(-45deg);
    -moz-transform: rotate(-45deg);
    -webkit-transform: rotate(-45deg);

}
.nav-arrow ul li a::after {

    content: '';
    width: 0px;
    height: 0;
    position: absolute;
    z-index: -1;
    top: 0px;
    right: -17px;
    border-top: 17px solid transparent;
    border-bottom: 17px solid transparent;
    border-left: 17px solid #3ec2fe;
        border-left-color: rgb(62, 194, 254);

}
.nav-arrow ul li.active a {

    color: #fff;
    background-color: #0b46a0 !important;

}
.nav-arrow ul li.active a::after {

    border-left-color: #0b46a0;

}
</style>			
<div class="container">
	<div class="row">
		<!--<aside class="item col-xs-12 col-sm-8 col-md-9 col-lg-9">-->
			<div style="border:1px solid #ccc;padding:10px;margin:10px 0;">				
				<!-- Header page Strat -->
				<div style="page-break-before:always">
					<div style="font-size: 16px;color: #000;font-weight:500;padding-bottom:10px">14/03/2019</div>
					<table width="100%" border="0" cellspacing="10" cellpadding="0">
						<tr>
							<td align="left" valign="top" width="50%"><img src="http://52.47.202.232/assets/images/logo1.png"></td>
							<td align="left" valign="top" width="50%">
								<span style="font-size:2.3em;color: #b8b8b8;display: block;font-family: 'Raleway', sans-serif;font-weight: 600; border-left:5px solid #294760;padding:0 0 5px 20px;">MARCHE IMMOBILIER</span>
								<em style="font-style: normal;font-size:3.6em;color: #294760;font-family: 'Raleway', sans-serif;font-weight: 600; border-left:5px solid #294760;padding-left:20px;display:block;line-height:1em">NOTER AVIS DE VALEUR</em>
								<em style="font-size:3.6em;display: block;color: #294760;text-align: right;font-family: 'Raleway', sans-serif;font-weight: 600;font-style: inherit;padding-top: 17px;"> EVALUEO<sup>&copy;</sup></em>
							</td>
						</tr>
					</table>	
					<div style="margin-top:40px; padding: 170px 0 0 0;width: 100%;height: 100%;background: url(pdf/pic8.png) no-repeat top right;background-size: auto;background-size: 100% 100%;">
						<div style="padding: 0px 8% 10px 37%;width: 100%;position: relative;z-index: 11;"><img src="https://img2.leboncoin.fr/ad-image/d130792f81efd380a785f6b561d7463894a4d6d5.jpg" class="upload-preview" width="520" height="475px">
							<div style="padding-left: 11px;border-left: 6px solid #294760;font-size: 17px;line-height: 34px;margin-top:20px;color: #314961;font-size:18px;font-weight:500;">
								<h6>Votre bien:</h6>
								<h6 >Appartement - 57m<sup>2</sup> Belley</h6>
							</div>
						</div>
						<div style="padding: 14px 20px 14px 25px;border: 2px dashed #2f4860;margin-bottom: 10px;left: 12%;position: relative;width: 88% !important;margin-top: 15px;">
							<div style="padding-left: 11px;border-left: 6px solid #294760;font-size: 17px;line-height: 34px;margin-top: 15px;padding-top:10px;"> 
								<h3 style="margin-top:0px;margin-bottom: 20px;"><span style="background: #2a4860;color: #fff;padding: 7px 20px;font-size:28px;text-transform: uppercase"> A la demande de</span></h3>
								<ul style="list-style-type:none;margin:0;padding:0;">
									<li style="font-size: 14px;font-weight: 400;color: #767676;margin-bottom: 15px;"><i class="fa fa-user" style="margin-right: 10px;"></i></li>
									<li style="font-size: 14px;font-weight: 400;color: #767676;margin-bottom: 15px;"><i class="fa fa-phone" style="margin-right: 10px;"></i> </li>
									<li style="font-size: 14px;font-weight: 400;color: #767676;margin-bottom: 15px;"><i class="fa fa-envelope" style="margin-right: 10px;"></i> </li>
									<li style="font-size: 14px;font-weight: 400;color: #767676;margin-bottom: 15px;"><i class="fa fa-map-marker" style="margin-right: 10px;"></i> </li>
								</ul>
							</div>
						</div>
					</div>
				</div>
				<!-- Header page Ends -->
				<!-- Start: page 1 -->
				<div style="border:1px solid #ccc;padding:10px;margin-bottom:30px;page-break-before:always;">
					<div style="font-size: 16px;color: #000;font-weight:500;padding-bottom:10px">15/03/2019</div>
					<div style="padding: 0px;margin-bottom: 18px;width: 100%;font-size: 16px;color: #314961;font-weight: 500;line-height:40px;position: relative;background-color: #314961;">
					<span style="color: #fff;line-height: 40px;width: 44px;display: inline-block;text-align: center;">1</span><span style="background:#e9e8e7;line-height: 40px;display: inline-block;width: 85%;padding-left: 15px;">Sommaire</span>
					</div>
					<div style="padding: 20px 0px 35px;width: 100%;text-align: center;margin-bottom: 10px;font-size: 480%;font-weight: 400;
					line-height: initial;color:#294760;">Sommaire</div>
					<div style="padding: 0px;margin-bottom: 18px;width: 100%;font-size: 16px;color: #314961;font-weight: 500;line-height:40px;position: relative;background:#e9e8e7;">
					<span style="color: #fff;line-height: 40px;width: 44px;display: inline-block;text-align:center;background-color: #314961;">1</span><span style="line-height: 40px;display: inline-block;padding-left: 15px;">Sommaire</span>
					</div>
					<div style="padding: 0px;margin-bottom: 18px;width: 100%;font-size: 16px;color: #314961;font-weight: 500;line-height:40px;position: relative;background:#e9e8e7;">
					<span style="color: #fff;line-height: 40px;width: 44px;display: inline-block;text-align:center;background-color: #314961;">2</span><span style="line-height: 40px;display: inline-block;padding-left: 15px;">Les applications qui composent EVALUEO</span>
					</div>
					<div style="padding: 0px;margin-bottom: 18px;width: 100%;font-size: 16px;color: #314961;font-weight: 500;line-height:40px;position: relative;background:#e9e8e7;">
					<span style="color: #fff;line-height: 40px;width: 44px;display: inline-block;text-align:center;background-color: #314961;">3</span><span style="line-height: 40px;display: inline-block;padding-left: 15px;">Notre application EVALUEO</span>
					</div>
					<div style="padding: 0px;margin-bottom: 18px;width: 100%;font-size: 16px;color: #314961;font-weight: 500;line-height:40px;position: relative;background:#e9e8e7;">
					<span style="color: #fff;line-height: 40px;width: 44px;display: inline-block;text-align:center;background-color: #314961;">4</span><span style="line-height: 40px;display: inline-block;padding-left: 15px;">Les données indiquées pour votre bien</span>
					</div>
					<div style="padding: 0px;margin-bottom: 18px;width: 100%;font-size: 16px;color: #314961;font-weight: 500;line-height:40px;position: relative;background:#e9e8e7;">
					<span style="color: #fff;line-height: 40px;width: 44px;display: inline-block;text-align:center;background-color: #314961;">5</span><span style="line-height: 40px;display: inline-block;padding-left: 15px;">Tout savoir sur votre ville grâce à OBSERVIMO </span>
					</div>
					<div style="padding: 0px;margin-bottom: 18px;width: 100%;font-size: 16px;color: #314961;font-weight: 500;line-height:40px;position: relative;background:#e9e8e7;">
					<span style="color: #fff;line-height: 40px;width: 44px;display: inline-block;text-align:center;background-color: #314961;">6</span><span style="line-height: 40px;display: inline-block;padding-left: 15px;"> Résultat de l’estimation EVALUEO </span>
					</div>
					<div style="padding: 0px;margin-bottom: 18px;width: 100%;font-size: 16px;color: #314961;font-weight: 500;line-height:40px;position: relative;background:#e9e8e7;">
					<span style="color: #fff;line-height: 40px;width: 44px;display: inline-block;text-align:center;background-color: #314961;">7</span><span style="line-height: 40px;display: inline-block;padding-left: 15px;">Liste des biens comparables </span>
					</div>
					<div style="padding: 0px;margin-bottom: 18px;width: 100%;font-size: 16px;color: #314961;font-weight: 500;line-height:40px;position: relative;background:#e9e8e7;">
					<span style="color: #fff;line-height: 40px;width: 44px;display: inline-block;text-align:center;background-color: #314961;">8</span><span style="line-height: 40px;display: inline-block;padding-left: 15px;">Notre proposition commerciale</span>
					</div>
					<div style="padding: 0px;margin-bottom: 18px;width: 100%;font-size: 16px;color: #314961;font-weight: 500;line-height:40px;position: relative;background:#e9e8e7;">
					<span style="color: #fff;line-height: 40px;width: 44px;display: inline-block;text-align:center;background-color: #314961;">9</span><span style="line-height: 40px;display: inline-block;padding-left: 15px;">Mandat de vente Solucimo</span>
					</div>
					<div style="padding: 5px 0px;margin:20px auto 10px;width: 96%;font-size: 12.5px;border: 3px solid #ababab;color: #314961;text-align: left;background-color: #efefef;">
						<div style="width: 14%; display:inline-block;padding-left:10px;float:left;">
							<img src="http://52.47.202.232/assets/images/logo1.png">
						</div>
						<div style="width: 50%; display:inline-block;float:left;">
							<ul>
								<li style="margin: 4px 0px 3px;width: 100%;padding-left: 5px;line-height: 18px;font-weight: 500;">Votre Home Conseiller</li>
								<li style="margin: 4px 0px 3px;width: 100%;padding-left: 5px;line-height: 18px;font-weight: 500;">Mr.Philippe Soulié</li>
								<li style="margin: 4px 0px 3px;width: 100%;padding-left: 5px;line-height: 18px;font-weight: 500;">Email : developer@espceo.com</li>
							</ul>
						</div>
						<div  style="width: 36%; display:inline-block;">
							<ul>
								<li style="margin: 4px 0px 3px;width: 100%;padding-left: 5px;line-height: 18px;font-weight: 500;">Notre Réseau</li>
								<li style="margin: 4px 0px 3px;width: 100%;padding-left: 5px;line-height: 18px;font-weight: 500;">Tél. : 0457430050</li>
								<li style="margin: 4px 0px 3px;width: 100%;padding-left: 5px;line-height: 18px;font-weight: 500;">E-mail : contact@limmobilier.net</li>
								<li style="margin: 4px 0px 3px;width: 100%;padding-left: 5px;line-height: 18px;font-weight: 500;">Site web : https://www.limmobilier.net</li>
								<li style="margin: 4px 0px 3px;width: 100%;padding-left: 5px;line-height: 18px;font-weight: 500;">Adresse : 2 Avenue du Lac 74140 Douvaine</li>
							</ul>
						</div>
					</div>
				</div>
				<!-- End: page 1 -->
				<!-- Start: page 2 -->
				<div style="border:1px solid #ccc;padding:10px;margin-bottom:30px;page-break-before:always;">
					<div style="font-size: 16px;color: #000;font-weight:500;padding-bottom:10px">15/03/2019</div>
					<div style="padding: 0px;margin-bottom: 18px;width: 100%;font-size: 16px;color: #314961;font-weight: 500;line-height:40px;position: relative;background-color: #314961;">
					<span style="color: #fff;line-height: 40px;width: 44px;display: inline-block;text-align: center;">2</span><span style="background:#e9e8e7;line-height: 40px;display: inline-block;width: 85%;padding-left: 15px;">Les applications qui composent EVALUEO</span>
					</div>
					<div style="padding:0px;margin:5px 0 13px;width:100%;font-size:16px;color:#314961;font-weight:500;line-height:40px;position: relative;background-color:#e6e9ea;">
					<span style="color:#fff;line-height:40px;width:auto;display:inline-block;text-align:center;background:#314961;padding:0 15px;font-size:16px;font-weight: 500;">ETUDEO</span><span style="line-height:40px;display:inline-block;width:auto;padding-left: 15px;">Votre étude de marché</span>
					</div>
					<p style="color:#294760;font-weight:500;margin-bottom:6px;">Nous pouvons étudier votre marché local grâce aux applications:</p>
					<p style="color:#294760;font-weight:500;margin-bottom:6px;"><strong>OFFRIMO© </strong> :Nous visualisons toute l’offre immobilière de votre secteur en temps réel</p>
					<p style="color:#294760;font-weight:500;margin-bottom:6px;"><strong>RANKIMO© </strong> :Nous classons toute l’offre immobilière,</p>
					<p style="color:#294760;font-weight:500;margin-bottom:6px;"><strong>COMPARIMO© </strong> :Nous comparons toute l’offre immobilière comparable à votre bien,</p>
					<p style="color:#294760;font-weight:500;margin-bottom:6px;"><strong>OBSERVIMO© </strong> :Nous valorisons l’environnement de votre bien</p>
					<div style="padding:0px;margin:15px 0 15px;width:100%;font-size:16px;color:#314961;font-weight:500;line-height:40px;position: relative;background-color:#e6e9ea;">
					<span style="color:#fff;line-height:40px;width:auto;display:inline-block;text-align:center;background:#314961;padding:0 15px;font-size:16px;font-weight: 500;">DECOUVRIMO VENDEUR</span><span style="line-height:40px;display:inline-block;width:auto;padding-left: 15px;">Tout savoir sur votre bien </span>
					</div>
					<p style="color:#294760;font-weight:500;margin-bottom:15px;">Nous avons noté lors de notre premier RDV, toutes les caractéristiques de votre bien, ce qui nous permet de personnaliser votre EVALUEO©</p>					
					<div style="width:33%;float:left;margin-bottom:15px;">
						<img src="http://52.47.202.232/assets/pdf/pic7.png">
					</div>
					<div style="width:67%;float:right">
						<p style="color:#294760;font-weight:500;padding: 8px 10px;margin-bottom: 15px;line-height: 20px;background-color: #e6e9ea;">Nous plaçons votre logement au centre de notre évaluation, en tenons compte des caractéristiques de votre habitation.</p>
					</div>
					<div style="width:100%;clear:both"></div>					
					<div style="padding:0px;margin:15px 0 15px;width:100%;font-size:16px;color:#314961;font-weight:500;line-height:40px;position: relative;background-color:#e6e9ea;">
					<span style="color:#fff;line-height:40px;width:auto;display:inline-block;text-align:center;background:#314961;padding:0 15px;font-size:16px;font-weight: 500;">URBANIMO©</span><span style="line-height:40px;display:inline-block;width:auto;padding-left: 15px;">Tout savoir sur l’environnement de votre bien</span>
					</div>
					<p style="color:#294760;font-weight:500;margin-bottom:15px;">Nous plaçons également votre logement au cœur de son environnement, en tenant compte des caractéristiques et des spéci×cités de votre ville, et de votre quartier.</p>
					<div style="width:33%;float:left;margin-bottom:15px;">
						<img src="http://52.47.202.232/assets/pdf/pic1.png">
					</div>
					<div style="width:64%;float:right;background-color: #e6e9ea;padding: 8px 10px;">
						<p style="color:#294760;font-weight:500;padding:0px;margin-bottom: 15px;line-height: 20px;">Nous prenons en compte les données environnementales de votre bien, avec les spéci×cités de votre ville, et de votre quartier. Ces données tiennent compte des 4 grandes thématiques:</p>
						<ul style="margin:0 0 0 15px;padding:0;">
							<li style="color:#294760;font-weight:500;padding:0px;margin-bottom: 5px;line-height: 15px;">Mobilité</li>
							<li style="color:#294760;font-weight:500;padding:0px;margin-bottom: 5px;line-height: 15px;">Commerces</li>
							<li style="color:#294760;font-weight:500;padding:0px;margin-bottom: 5px;line-height: 15px;">Loisirs</li>
							<li style="color:#294760;font-weight:500;padding:0px;margin-bottom: 5px;line-height: 15px;">Services et équipements</li>
						</ul>
					</div>
					<div style="width:100%;clear:both"></div>
					<div style="padding: 5px 0px;margin:20px auto 10px;width: 96%;font-size: 12.5px;border: 3px solid #ababab;color: #314961;text-align: left;background-color: #efefef;">
						<div style="width: 14%; display:inline-block;padding-left:10px;float:left;">
							<img src="http://52.47.202.232/assets/images/logo1.png">
						</div>
						<div style="width: 50%; display:inline-block;float:left;">
							<ul>
								<li style="margin: 4px 0px 3px;width: 100%;padding-left: 5px;line-height: 18px;font-weight: 500;">Votre Home Conseiller</li>
								<li style="margin: 4px 0px 3px;width: 100%;padding-left: 5px;line-height: 18px;font-weight: 500;">Mr.Philippe Soulié</li>
								<li style="margin: 4px 0px 3px;width: 100%;padding-left: 5px;line-height: 18px;font-weight: 500;">Email : developer@espceo.com</li>
							</ul>
						</div>
						<div  style="width: 36%; display:inline-block;">
							<ul>
								<li style="margin: 4px 0px 3px;width: 100%;padding-left: 5px;line-height: 18px;font-weight: 500;">Notre Réseau</li>
								<li style="margin: 4px 0px 3px;width: 100%;padding-left: 5px;line-height: 18px;font-weight: 500;">Tél. : 0457430050</li>
								<li style="margin: 4px 0px 3px;width: 100%;padding-left: 5px;line-height: 18px;font-weight: 500;">E-mail : contact@limmobilier.net</li>
								<li style="margin: 4px 0px 3px;width: 100%;padding-left: 5px;line-height: 18px;font-weight: 500;">Site web : https://www.limmobilier.net</li>
								<li style="margin: 4px 0px 3px;width: 100%;padding-left: 5px;line-height: 18px;font-weight: 500;">Adresse : 2 Avenue du Lac 74140 Douvaine</li>
							</ul>
						</div>
					</div>
				</div>				
				<!-- End: page 2 -->
				
				<!-- Start: page 3 -->
				<div style="border:1px solid #ccc;padding:10px;margin-bottom:30px;page-break-before:always;">
					<div style="font-size: 16px;color: #000;font-weight:500;padding-bottom:10px">15/03/2019</div>
					<div style="padding: 0px;margin-bottom: 18px;width: 100%;font-size: 16px;color: #314961;font-weight: 500;line-height:40px;position: relative;background-color: #314961;">
					<span style="color: #fff;line-height: 40px;width: 44px;display: inline-block;text-align: center;">3</span><span style="background:#e9e8e7;line-height: 40px;display: inline-block;width: 85%;padding-left: 15px;">Notre application EVALUEO©</span>
					</div>
					<div style="padding:0px;margin:15px 0 15px;width:100%;font-size:16px;color:#314961;font-weight:500;line-height:40px;position: relative;background-color:#e6e9ea;">
					<span style="color:#fff;line-height:40px;width:auto;display:inline-block;text-align:center;background:#314961;padding:0 15px;font-size:16px;font-weight: 500;">L'application EVALUEO©</span>
					</div>
					<p style="color:#294760;font-weight:500;margin-bottom:15px;">Cette application nous permet d’utiliser un puissant systéme de calculs et de comparaisons, s’appuyant sur les données du marché immobilier (toute l’offre) en temps reel. Nos avis de valuers, utilisent les données les plus fiables et les plus pertinentes du marché immobilier, actualisées en temps réel.</p>	
					<div style="padding:0px;margin:15px 0 15px;width:100%;font-size:16px;color:#314961;font-weight:500;line-height:40px;position: relative;background-color:#e6e9ea;">
					<span style="color:#fff;line-height:40px;width:auto;display:inline-block;text-align:center;background:#314961;padding:0 15px;font-size:16px;font-weight: 500;">Principe de EVALUEO©</span>
					</div>
					<p style="color:#294760;font-weight:500;margin-bottom:15px;">EVALUEO© va réaliser une évaluation, en tenant compte des données et caractéristiques propres à votre bien, de l’environnement de votre bien, à savoir votre ville et votre quartier, mais aussi des tendances du marché actuel et des biens comparables au votre, en vente actuellement.</p>	
					<div style="padding:0px;margin:15px 0 15px;width:100%;font-size:16px;color:#314961;font-weight:500;line-height:40px;position: relative;background-color:#e6e9ea;">
					<span style="color:#fff;line-height:40px;width:auto;display:inline-block;text-align:center;background:#314961;padding:0 15px;font-size:16px;font-weight: 500;">Methodologie de EVALUEO©</span>
					</div>
					<div>
						<div style="width:23%;text-align:center;background:#e6e6e9;float:left;">
							<div style="padding: 4px 6px 5px;width: 100%;min-height: 56px;font-size: 16px;line-height: 22px;color: #fff;background-color: #314961;">
								Valeur<br> Indicative
							</div>
							<div style="padding: 3px 6px;min-height: 190px;">
								<div style="height:85px;margin: 15px 0px 0px;"><img src="http://52.47.202.232/assets/pdf/icon14.png" style="width: auto;max-width: 100%;height: auto;max-height: 87%;"></div>
								<p style="color: #294760;font-weight: 500;line-height: normal;">4 chemin des grands conches, Belley,france à Belley 1,625 euros/m² Prix m² indiqué par ville</p>
							</div>
						</div>
						<i class="fa fa-plus" style="padding:3px 6px;width:3%;min-height:247px;float:left;font-size: 22px;font-weight: 400;color: #999;text-align:center;display:flex;justify-content:center;align-items:center;"></i>
						<div style="width:23%;text-align:center;background:#e6e6e9;float:left;">
							<div style="padding: 4px 6px 5px;width: 100%;min-height: 56px;font-size: 16px;line-height: 22px;color: #fff;background-color: #314961;">
								Valeur<br> Technique
							</div>
							<div style="padding: 3px 6px;min-height: 190px;">
								<div style="height:85px;margin: 15px 0px 0px;"><img src="http://52.47.202.232/assets/pdf/icon13.png" style="width: auto;max-width: 100%;height: auto;max-height: 87%;"></div>
								<p style="color: #294760;font-weight: 500;line-height: normal;">Sol + Construction <br><br> Valeur de reconstruction à neuf</p>
							</div>
						</div>
						<i class="fa fa-plus" style="padding:3px 6px;width:3%;min-height:247px;float:left;font-size: 22px;font-weight: 400;color: #999;text-align:center;display:flex;justify-content:center;align-items:center;"></i>
						<div style="width:23%;text-align:center;background:#e6e6e9;float:left;">
							<div style="padding: 4px 6px 5px;width: 100%;min-height: 56px;font-size: 16px;line-height: 22px;color: #fff;background-color: #314961;">
								Valeur<br>par Capitalisation 
							</div>
							<div style="padding: 3px 6px;min-height: 190px;">
								<div style="height:85px;margin: 15px 0px 0px;"><img src="http://52.47.202.232/assets/pdf/icon12.png" style="width: auto;max-width: 100%;height: auto;max-height: 87%;"></div>
								<p style="color: #294760;font-weight: 500;line-height: normal;">Rentabilité Locative  <br><br> Valeur suivant le rendement</p>
							</div>
						</div>
						<i class="fa fa-plus" style="padding:3px 6px;width:3%;min-height:247px;float:left;font-size: 22px;font-weight: 400;color: #999;text-align:center;display:flex;justify-content:center;align-items:center;"></i>						
						<div style="width:22%;text-align:center;background:#e6e6e9;float:left;">
							<div style="padding: 4px 6px 5px;width: 100%;min-height: 56px;font-size: 16px;line-height: 22px;color: #fff;background-color: #314961;">
								Valeur par<br>Comparaison 
							</div>
							<div style="padding: 3px 6px;min-height: 190px;">
								<div style="height:85px;margin: 15px 0px 0px;"><img src="http://52.47.202.232/assets/pdf/icon11.png" style="width: auto;max-width: 100%;height: auto;max-height: 87%;"></div>
								<p style="color: #294760;font-weight: 500;line-height: normal;">Biens Comparable au votre Valeur suivant l’offre comparable</p>
							</div>
						</div>
						<div style="width:100%;clear:both"></div>
						<p style="padding:3px 6px;width:100%;font-size: 42px;font-weight:bold;color: #999;text-align:center;text-align:center;display:block;">=</p>
						<div style="width:25%;text-align:center;background:#e6e6e9;margin:0 auto;">
							<div style="padding: 4px 6px 5px;width: 100%;min-height: 56px;font-size: 16px;line-height: 22px;color: #fff;background-color: #314961;">
								Valeur<br>Estimée 
							</div>
							<div style="padding: 3px 6px;min-height: 190px;">
								<div style="height:85px;margin: 15px 0px 0px;"><img src="http://52.47.202.232/assets/pdf/icon10.png" style="width: auto;max-width: 100%;height: auto;max-height: 87%;"></div>
								<p style="color: #294760;font-weight: 500;line-height: normal;font-size: 22px;">Notre avis de valeur</p>
							</div>
						</div>
						<p style="font-style: normal;color: #444;line-height: 25px;padding:15px 0;font-size: 18px;">"Notre avis de valeur est la moyenne de 4 moyennes, pondérée par les caractéristiques de votre bien et de son environnement."</p>
					</div>
					<div style="width:100%;clear:both;"></div>					
					<div style="padding: 5px 0px;margin:20px auto 10px;width: 96%;font-size: 12.5px;border: 3px solid #ababab;color: #314961;text-align: left;background-color: #efefef;">
						<div style="width: 14%; display:inline-block;padding-left:10px;float:left;">
							<img src="http://52.47.202.232/assets/images/logo1.png">
						</div>
						<div style="width: 50%; display:inline-block;float:left;">
							<ul>
								<li style="margin: 4px 0px 3px;width: 100%;padding-left: 5px;line-height: 18px;font-weight: 500;">Votre Home Conseiller</li>
								<li style="margin: 4px 0px 3px;width: 100%;padding-left: 5px;line-height: 18px;font-weight: 500;">Mr.Philippe Soulié</li>
								<li style="margin: 4px 0px 3px;width: 100%;padding-left: 5px;line-height: 18px;font-weight: 500;">Email : developer@espceo.com</li>
							</ul>
						</div>
						<div  style="width: 36%; display:inline-block;">
							<ul>
								<li style="margin: 4px 0px 3px;width: 100%;padding-left: 5px;line-height: 18px;font-weight: 500;">Notre Réseau</li>
								<li style="margin: 4px 0px 3px;width: 100%;padding-left: 5px;line-height: 18px;font-weight: 500;">Tél. : 0457430050</li>
								<li style="margin: 4px 0px 3px;width: 100%;padding-left: 5px;line-height: 18px;font-weight: 500;">E-mail : contact@limmobilier.net</li>
								<li style="margin: 4px 0px 3px;width: 100%;padding-left: 5px;line-height: 18px;font-weight: 500;">Site web : https://www.limmobilier.net</li>
								<li style="margin: 4px 0px 3px;width: 100%;padding-left: 5px;line-height: 18px;font-weight: 500;">Adresse : 2 Avenue du Lac 74140 Douvaine</li>
							</ul>
						</div>
					</div>
				</div>	
				<!-- End: page 3 -->
				
				<!-- Start: page 4 -->
				<div style="border:1px solid #ccc;padding:10px;margin-bottom:30px;page-break-before:always;">
					<div style="font-size: 16px;color: #000;font-weight:500;padding-bottom:10px">15/03/2019</div>
					<div style="padding: 0px;margin-bottom: 18px;width: 100%;font-size: 16px;color: #314961;font-weight: 500;line-height:40px;position: relative;background-color: #314961;">
					<span style="color: #fff;line-height: 40px;width: 44px;display: inline-block;text-align: center;">4</span><span style="background:#e9e8e7;line-height: 40px;display: inline-block;width: 85%;padding-left: 15px;">Les données indiquées pour votre bien </span>
					</div>					
					<div style="padding:0px;margin:5px 0 13px;width:100%;font-size:16px;color:#314961;font-weight:500;line-height:40px;position: relative;background-color:#e6e9ea;">
						<span style="color:#fff;line-height:40px;width:auto;display:inline-block;text-align:center;background:#314961;padding:0 15px;font-size:16px;font-weight: 500;">OFFRIMO</span><span style="line-height:40px;display:inline-block;width:auto;padding-left: 15px;">Toute l'offre comparable et similaire</span><label style="padding: 0px; padding-right: 0px;margin: 0px 0px 0px;position: absolute;top: 5px;right: 25px;width: auto;"><input type="checkbox"><em></em></label>
					</div>
					<div>
						<h3 style="text-align: center;font-size: 25px;color: #294760;padding:10px 0 15px">Votre Maison 4 Pièces et l’offre concurrente </h3>						
						<table width="100%" cellspacing="10" cellpadding="0" border="0">
							<tbody>
							<tr>
							<th width="33.33%">&nbsp;</th>
							<th width="26%" style="padding: 2px 10px;border: 1px solid #d5d5d5;color: #294760;font-weight: 700;text-align:center;line-height:normal;padding: 10px;">Belley<br>(La ville)</th>
							<th width="20%" style="padding: 2px 10px;border: 1px solid #d5d5d5;color: #294760;font-weight: padding: 10px;700;text-align:center;line-height:normal;">3 kms<br>(Rayon proche*)</th>
							<th width="20%" style="padding: 2px 10px;border: 1px solid #d5d5d5;color: #294760;font-weight: padding: 10px;700;text-align:center;line-height:normal;">6 kms<br>(Rayon large**)</th>
							</tr>
							<tr>
							<td style="padding: 2px 10px;border: 1px solid #d5d5d5;color: #294760;font-style: normal;font-weight: 500;padding: 10px;background: #f8f8f8;">Offre de biens comparables</td>
							<td style="padding: 2px 10px;border: 1px solid #d5d5d5;text-align:center;color: #294760;font-style: normal;font-weight: 500;padding: 10px;">3</td>
							<td style="padding: 2px 10px;border: 1px solid #d5d5d5;text-align:center;color: #294760;font-style: normal;font-weight: 500;padding: 10px;">4</td>
							<td style="padding: 2px 10px;border: 1px solid #d5d5d5;text-align:center;color: #294760;font-style: normal;font-weight: 500;padding: 10px;">4</td>
							</tr>
							<tr>
							<td style="padding: 2px 10px;border: 1px solid #d5d5d5;color: #294760;font-style: normal;font-weight: 500;padding: 10px;background: #f8f8f8;">Offre de biens similaires)</td>
							<td style="padding: 2px 10px;border: 1px solid #d5d5d5;text-align:center;color: #294760;font-style: normal;font-weight: 500;padding: 10px;" align="left">1</td>
							<td style="padding: 2px 10px;border: 1px solid #d5d5d5;text-align:center;color: #294760;font-style: normal;font-weight: 500;padding: 10px;" align="left">1</td>
							<td  style="padding: 2px 10px;border: 1px solid #d5d5d5;text-align:center;color: #294760;font-style: normal;font-weight: 500;padding: 10px;" align="left">1</td>
							</tr>
							</tbody>
						</table>
					</div>
					<div>
						<p style="margin-top:20px;color: #294760;font-style: normal;font-weight: 500;-webkit-text-stroke: .1px;"><strong>* Villes du rayon proche : </strong><span>Yenne</span></p>
						<p  style="color: #294760;font-style: normal;font-weight: 500;-webkit-text-stroke: .1px;"><strong>** Villes du rayon large : </strong><span>Yenne</span></p>				
						<div style="padding:0px;margin:5px 0 13px;width:100%;font-size:16px;color:#314961;font-weight:500;line-height:40px;position: relative;background-color:#e6e9ea;">
							<span style="color:#fff;line-height:40px;width:auto;display:inline-block;text-align:center;background:#314961;padding:0 15px;font-size:16px;font-weight: 500;">RANKIMO</span><span style="line-height:40px;display:inline-block;width:auto;padding-left: 15px;">Classement de l’offre comparable et similaire </span><label style="padding: 0px; padding-right: 0px;margin: 0px 0px 0px;position: absolute;top: 5px;right: 25px;width: auto;"><input type="checkbox"><em></em></label>
						</div>
						<h3 style="text-align: center;font-size: 25px;color: #294760;padding:10px 0 15px">Votre bien est classé </h3>				
						<table width="100%" cellspacing="10" cellpadding="0" border="0">
							<tbody>
							<tr>
							<th width="33.33%">&nbsp;</th>
							<th width="33.33%" style="border: 1px solid #d5d5d5;color: #294760;font-weight: 700;text-align:center;line-height:normal;padding:15px 10px;">Par rapport à l’offre comparable</th>
							<th width="33.33%" style="border: 1px solid #d5d5d5;color:#294760;font-weight:padding:15px 10px;700;  text-align:center; line-height:normal;">Par rapport à l’offre similaire</th>
							</tr>
							<tr>
							<td style="padding:10px;border: 1px solid #d5d5d5;color: #294760;font-style: normal;font-weight: 500;padding: 10px;text-align: left;background: #f8f8f8;">Dans la ville de Gaillard</td>
							<td style="border: 1px solid #d5d5d5;text-align:left;color: #294760;font-style: normal;font-weight: 500;padding: 10px;"><span style="display: inline-block;width: 160px;float: left;text-align: right;margin-right: 10px;"><img src="http://52.47.202.232/assets/images/rankimoPink.png"></span> 46/74</td>
							<td style="border: 1px solid #d5d5d5;text-align:left;color: #294760;font-style: normal;font-weight: 500;padding: 10px;"><span style="display: inline-block;width: 160px;float: left;text-align: right;margin-right: 10px;"><img src="http://52.47.202.232/assets/images/rankimoGreen.png"></span> 46/74</td>													
							</tr>
							<tr>
							<td style="border: 1px solid #d5d5d5;color: #294760;font-style: normal;font-weight: 500;padding: 10px;text-align: left;background: #f8f8f8;">3 kms autour</td>
							<td style="border: 1px solid #d5d5d5;text-align:left;color: #294760;font-style: normal;font-weight: 500;padding: 10px;"><span style="display: inline-block;width: 160px;float: left;text-align: right;margin-right: 10px;"><img src="http://52.47.202.232/assets/images/rankimoPink.png"></span> 46/74</td>
							<td style="border: 1px solid #d5d5d5;text-align:left;color: #294760;font-style: normal;font-weight: 500;padding: 10px;"><span style="display: inline-block;width: 160px;float: left;text-align: right;margin-right: 10px;"><img src="http://52.47.202.232/assets/images/rankimoGreen.png"></span> 46/74</td>
							</tr>
							<tr>
							<td style="border: 1px solid #d5d5d5;color: #294760;font-style: normal;font-weight: 500;padding: 10px;text-align: left;background: #f8f8f8;">6 kms autour</td>
							<td style="border: 1px solid #d5d5d5;text-align:left;color: #294760;font-style: normal;font-weight: 500;padding: 10px;"><span style="display: inline-block;width: 160px;float: left;text-align: right;margin-right: 10px;"><img src="http://52.47.202.232/assets/images/rankimoPink.png"></span> 46/74</td>
							<td style="border: 1px solid #d5d5d5;text-align:left;color: #294760;font-style: normal;font-weight: 500;padding: 10px;"><span style="display: inline-block;width: 160px;float: left;text-align: right;margin-right: 10px;"><img src="http://52.47.202.232/assets/images/rankimoGreen.png"></span> 46/74</td>
							</tr>
							</tbody>
						</table>
					</div>
					<div style="">										
						<div style="margin:20px 0 10px;width:100%; font-size:16px;color:#314961;font-weight:500;line-height:40px;position: relative; background-color:#e6e9ea;">
							<span style="color:#fff;line-height:40px;width:auto;display:inline-block;text-align:center;background:#314961;padding:0 15px;font-size:16px;font-weight: 500;">COMPARIMO</span><span style="line-height:40px; display:inline-block; width:auto; padding-left: 15px;">Analyser l’offre comparable et similaire  </span><label style="padding: 0px; padding-right: 0px;margin: 0px 0px 0px;position: absolute;top: 5px;right: 25px;width: auto;"><input type="checkbox"><em></em></label>
						</div>
						<h3 style="text-align: center;font-size: 25px;color: #294760;padding:10px 0 15px">Structure de l’offre</h3>
						<table width="100%" cellspacing="10" cellpadding="0" border="0">
							<tbody>
							<tr>
							<th width="33.33%">&nbsp;</th>
							<th width="26%" style="border: 1px solid #d5d5d5;color: #294760;font-weight: 700; text-align:center; line-height:normal; padding: 10px;">PAP</th>
							<th width="20%" style="border: 1px solid #d5d5d5;color: #294760;font-weight: padding: 10px;700; text-align:center; line-height:normal;">PRO</th>
							<th width="20%" style="border: 1px solid #d5d5d5;color: #294760;font-weight: padding: 10px;700; text-align:center; line-height:normal;">TOTAL</th>
							</tr>
							<tr>
							<td style="padding: 2px 10px;border: 1px solid #d5d5d5;color: #294760;font-style: normal;font-weight: 500;padding: 10px;background: #f8f8f8;">Nombre de Appartement(s) 3P </td>
							<td style="padding: 2px 10px;border: 1px solid #d5d5d5;text-align:center;color: #294760;font-style: normal;font-weight: 500;padding: 10px;">0 (0%)</td>
							<td style="padding: 2px 10px;border: 1px solid #d5d5d5;text-align:center;color: #294760;font-style: normal;font-weight: 500;padding: 10px;">0 (0%)</td>
							<td style="padding: 2px 10px;border: 1px solid #d5d5d5;text-align:center;color: #294760;font-style: normal;font-weight: 500;padding: 10px;">0 (100%)</td>
							</tr>
							<tr>
							<td style="padding: 2px 10px;border: 1px solid #d5d5d5;color: #294760;font-style: normal;font-weight: 500;padding: 10px;background: #f8f8f8;">Nombre de Appartement(s) comparable(s) 3P</td>
							<td style="padding: 2px 10px;border: 1px solid #d5d5d5;text-align:center;color: #294760;font-style: normal;font-weight: 500;padding: 10px;" align="left">0 (0%)</td>
							<td style="padding: 2px 10px;border: 1px solid #d5d5d5;text-align:center;color: #294760;font-style: normal;font-weight: 500;padding: 10px;" align="left">0 (0%)</td>
							<td  style="padding: 2px 10px;border: 1px solid #d5d5d5;text-align:center;color: #294760;font-style: normal;font-weight: 500;padding: 10px;" align="left">74 (100%)</td>
							</tr>
							<tr>
							<td style="padding: 2px 10px;border: 1px solid #d5d5d5;color: #294760;font-style: normal;font-weight: 500;padding: 10px;background: #f8f8f8;">Nombre de Appartement(s) similaire(s) 3P</td>
							<td style="padding: 2px 10px;border: 1px solid #d5d5d5;text-align:center;color: #294760;font-style: normal;font-weight: 500;padding: 10px;" align="left">0 (0%)</td>
							<td style="padding: 2px 10px;border: 1px solid #d5d5d5;text-align:center;color: #294760;font-style: normal;font-weight: 500;padding: 10px;" align="left">0 (0%)</td>
							<td  style="padding: 2px 10px;border: 1px solid #d5d5d5;text-align:center;color: #294760;font-style: normal;font-weight: 500;padding: 10px;" align="left">1 (100%)</td>
							</tr>
							</tbody>
						</table>
						<h3 style="text-align: center;font-size: 25px;color: #294760;padding:10px 0 0px">Les prix</h3>
						<h3 style="text-align: center;font-size: 20px;color: #294760;padding:0px 0 10px">Les prix moyens de vente</h3>
						<table width="100%" cellspacing="10" cellpadding="0" border="0">
							<tbody>
							<tr>
							<th width="33.33%">&nbsp;</th>
							<th width="26%" style="border: 1px solid #d5d5d5;color: #294760;font-weight: 700; text-align:center; line-height:normal; padding: 10px;">PAP</th>
							<th width="20%" style="border: 1px solid #d5d5d5;color: #294760;font-weight: padding: 10px;700; text-align:center; line-height:normal;">PRO</th>
							<th width="20%" style="border: 1px solid #d5d5d5;color: #294760;font-weight: padding: 10px;700; text-align:center; line-height:normal;">Moyen PAP/PRO</th>
							</tr>
							<tr>
							<td style="padding: 2px 10px;border: 1px solid #d5d5d5;color: #294760;font-style: normal;font-weight: 500;padding: 10px;background: #f8f8f8;">Appartement(s) 3P comparable(s)</td>
							<td style="padding: 2px 10px;border: 1px solid #d5d5d5;text-align:center;color: #294760;font-style: normal;font-weight: 500;padding: 10px;">224795 €</td>
							<td style="padding: 2px 10px;border: 1px solid #d5d5d5;text-align:center;color: #294760;font-style: normal;font-weight: 500;padding: 10px;">0 €</td>
							<td style="padding: 2px 10px;border: 1px solid #d5d5d5;text-align:center;color: #294760;font-style: normal;font-weight: 500;padding: 10px;">0 €</td>
							</tr>
							<tr>
							<td style="padding: 2px 10px;border: 1px solid #d5d5d5;color: #294760;font-style: normal;font-weight: 500;padding: 10px;background: #f8f8f8;">Appartement(s) 3P similaire(s)</td>
							<td style="padding: 2px 10px;border: 1px solid #d5d5d5;text-align:center;color: #294760;font-style: normal;font-weight: 500;padding: 10px;" align="left">0 €</td>
							<td style="padding: 2px 10px;border: 1px solid #d5d5d5;text-align:center;color: #294760;font-style: normal;font-weight: 500;padding: 10px;" align="left">0 €</td>
							<td  style="padding: 2px 10px;border: 1px solid #d5d5d5;text-align:center;color: #294760;font-style: normal;font-weight: 500;padding: 10px;" align="left">0 €</td>
							</tr>
							</tbody>
						</table>
						<h3 style="text-align: center;font-size: 25px;color: #294760;padding:10px 0 0px">Les prix</h3>
						<h3 style="text-align: center;font-size: 20px;color: #294760;padding:0px 0 10px">Les meilleurs prix</h3>
						<table width="100%" cellspacing="10" cellpadding="0" border="0">
							<tbody>
							<tr>
							<th width="33.33%">&nbsp;</th>
							<th width="26%" style="border: 1px solid #d5d5d5;color: #294760;font-weight: 700; text-align:center; line-height:normal; padding: 10px;">PAP</th>
							<th width="20%" style="border: 1px solid #d5d5d5;color: #294760;font-weight: padding: 10px;700; text-align:center; line-height:normal;">PRO</th>
							<th width="20%" style="border: 1px solid #d5d5d5;color: #294760;font-weight: padding: 10px;700; text-align:center; line-height:normal;">Px Moyen PAP/PRO</th>
							</tr>
							<tr>
							<td style="padding: 2px 10px;border: 1px solid #d5d5d5;color: #294760;font-style: normal;font-weight: 500;padding: 10px;background: #f8f8f8;">Meilleur prix Maison(s) 3P comparable(s)</td>
							<td style="padding: 2px 10px;border: 1px solid #d5d5d5;text-align:center;color: #294760;font-style: normal;font-weight: 500;padding: 10px;">159570 €</td>
							<td style="padding: 2px 10px;border: 1px solid #d5d5d5;text-align:center;color: #294760;font-style: normal;font-weight: 500;padding: 10px;">0 €</td>
							<td style="padding: 2px 10px;border: 1px solid #d5d5d5;text-align:center;color: #294760;font-style: normal;font-weight: 500;padding: 10px;">159,570 €</td>
							</tr>
							<tr>
							<td style="padding: 2px 10px;border: 1px solid #d5d5d5;color: #294760;font-style: normal;font-weight: 500;padding: 10px;background: #f8f8f8;">Meilleur prix Maison(s) 3P similaire(s)</td>
							<td style="padding: 2px 10px;border: 1px solid #d5d5d5;text-align:center;color: #294760;font-style: normal;font-weight: 500;padding: 10px;" align="left">0 €</td>
							<td style="padding: 2px 10px;border: 1px solid #d5d5d5;text-align:center;color: #294760;font-style: normal;font-weight: 500;padding: 10px;" align="left">0 €</td>
							<td  style="padding: 2px 10px;border: 1px solid #d5d5d5;text-align:center;color: #294760;font-style: normal;font-weight: 500;padding: 10px;" align="left">0 €</td>
							</tr>
							</tbody>
						</table>
						<h3 style="text-align: center;font-size: 25px;color: #294760;padding:10px 0 0px">Les prix</h3>
						<h3 style="text-align: center;font-size: 20px;color: #294760;padding:0px 0 10px">Les plus élevés</h3>
						<table width="100%" cellspacing="10" cellpadding="0" border="0">
							<tbody>
							<tr>
							<th width="33.33%">&nbsp;</th>
							<th width="26%" style="border: 1px solid #d5d5d5;color: #294760;font-weight: 700; text-align:center; line-height:normal; padding: 10px;">PAP</th>
							<th width="20%" style="border: 1px solid #d5d5d5;color: #294760;font-weight: padding: 10px;700; text-align:center; line-height:normal;">PRO</th>
							<th width="20%" style="border: 1px solid #d5d5d5;color: #294760;font-weight: padding: 10px;700; text-align:center; line-height:normal;">Px Moyen PAP/PRO</th>
							</tr>
							<tr>
							<td style="padding: 2px 10px;border: 1px solid #d5d5d5;color: #294760;font-style: normal;font-weight: 500;padding: 10px;background: #f8f8f8;">Prix le plus élevé Maison(s) 3P comparable(s)</td>
							<td style="padding: 2px 10px;border: 1px solid #d5d5d5;text-align:center;color: #294760;font-style: normal;font-weight: 500;padding: 10px;">270000 €</td>
							<td style="padding: 2px 10px;border: 1px solid #d5d5d5;text-align:center;color: #294760;font-style: normal;font-weight: 500;padding: 10px;">0 €</td>
							<td style="padding: 2px 10px;border: 1px solid #d5d5d5;text-align:center;color: #294760;font-style: normal;font-weight: 500;padding: 10px;">270,000 €</td>
							</tr>
							<tr>
							<td style="padding: 2px 10px;border: 1px solid #d5d5d5;color: #294760;font-style: normal;font-weight: 500;padding: 10px;background: #f8f8f8;">Prix le plus élevé Maison(s) 3P similaire(s)</td>
							<td style="padding: 2px 10px;border: 1px solid #d5d5d5;text-align:center;color: #294760;font-style: normal;font-weight: 500;padding: 10px;" align="left">0 €</td>
							<td style="padding: 2px 10px;border: 1px solid #d5d5d5;text-align:center;color: #294760;font-style: normal;font-weight: 500;padding: 10px;" align="left">0 €</td>
							<td  style="padding: 2px 10px;border: 1px solid #d5d5d5;text-align:center;color: #294760;font-style: normal;font-weight: 500;padding: 10px;" align="left">0 €</td>
							</tr>
							</tbody>
						</table>
						<div style="margin:20px 0 10px;width:100%; font-size:16px;color:#314961;font-weight:500;line-height:40px;position: relative; background-color:#e6e9ea;">
							<span style="color:#fff;line-height:40px;width:auto;display:inline-block;text-align:center;background:#314961;padding:0 15px;font-size:16px;font-weight: 500;">SYNTHESE</span><span style="line-height:40px; display:inline-block; width:auto; padding-left: 15px;">Voir bien dans l’offre immobilière en temps réel</span>
						</div>
						<h3 style="text-align: center;font-size: 25px;color: #294760;padding:10px 0 0px">Synthèse</h3>
						<h3 style="text-align: center;font-size: 20px;color: #294760;padding:0px 0 10px">L’offre immobilière</h3>
						<ul style="margin:0;padding:0 0 0 30px;">
							<li style="margin: 4px 0px 3px;width: 100%;padding-left: 5px;line-height: 20px;font-weight: 500;font-size:15px;color: #294760;">En 2018 il y a eu 0 Appartement(s) 3P comparables et 0 similaires mise(s) en vente</li>	
							<li style="margin: 4px 0px 3px;width: 100%;padding-left: 5px;line-height: 20px;font-weight: 500;font-size:15px;color: #294760;">Depuis le 01/01/2019 il y a eu 68 Appartement(s) 3P comparable(s) et 0 similaire(s)mise(s) en vente</li>
							<li style="margin: 4px 0px 3px;width: 100%;padding-left: 5px;line-height: 20px;font-weight: 500;font-size:15px;color: #294760;">Délai moyen de mise en ligne des Appartement(s) 3P comparables : <strong>jours</strong> </li>
							<li style="margin: 4px 0px 3px;width: 100%;padding-left: 5px;line-height: 20px;font-weight: 500;font-size:15px;color: #294760;">Délai moyen de mise en ligne des Appartement(s) 3P similaires : <strong>jours</strong></li>
						</ul>
						<h3 style="text-align: center;font-size: 20px;color: #294760;padding:20px 0 10px">Comment se situe votre Maison 5P dans l’offre immobilière ?</h3>
						<table width="100%" cellspacing="10" cellpadding="0" border="0">
								<tbody><tr>
								<th width="33.33%">&nbsp;</th>
								<th colspan="2" width="33.33%" style="border: 1px solid #d5d5d5;color: #294760;font-weight: 700; text-align:center; line-height:normal; padding: 10px;">Meilleur Px de vente</th>
								<th colspan="2" width="33.33%" style="border: 1px solid #d5d5d5;color: #294760;font-weight: 700; text-align:center; line-height:normal; padding: 10px;">Moyen Px de vente</th>
								</tr>
								<tr>
								<th width="28%">&nbsp;</th>
								<th width="17%" style="border: 1px solid #d5d5d5;color: #294760;font-weight: 700; text-align:center; line-height:normal; padding: 10px;">Comparable</th>
								<th width="17%" style="border: 1px solid #d5d5d5;color: #294760;font-weight: 700; text-align:center; line-height:normal; padding: 10px;">Similaire</th>
								<th width="17%" style="border: 1px solid #d5d5d5;color: #294760;font-weight: 700; text-align:center; line-height:normal; padding: 10px;">Comparable</th>
								<th width="17%" style="border: 1px solid #d5d5d5;color: #294760;font-weight: 700; text-align:center; line-height:normal; padding: 10px;">Similaire</th>
								</tr>
								<tr>
								<td style="width:32%;border: 1px solid #d5d5d5;color: #294760;font-style: normal;font-weight: 500;padding: 10px;background: #f8f8f8;">Votre prix actuel online</td>
								<td style="width:17%;padding: 2px 10px;border: 1px solid #d5d5d5;text-align:center;color: #294760;font-style: normal;font-weight: 500;padding: 10px;">115430 €   (72%)</td>
								<td style="width:17%;padding: 2px 10px;border: 1px solid #d5d5d5;text-align:center;color: #294760;font-style: normal;font-weight: 500;padding: 10px;">275000 €   (∞%)</td>
								<td style="width:17%;padding: 2px 10px;border: 1px solid #d5d5d5;text-align:center;color: #294760;font-style: normal;font-weight: 500;padding: 10px;">11864 €   (5%)</td>
								<td style="width:17%;padding: 2px 10px;border: 1px solid #d5d5d5;text-align:center;color: #294760;font-style: normal;font-weight: 500;padding: 10px;">275000 €   (∞%)</td>
								</tr>
								<tr>
								<td style="border: 1px solid #d5d5d5;color: #294760;font-style: normal;font-weight: 500;padding: 10px;background: #f8f8f8;">Notre prix Evalueo FAI inclus</td>
								<td style="padding: 2px 10px;border: 1px solid #d5d5d5;text-align:center;color: #294760;font-style: normal;font-weight: 500;padding: 10px;"> €   (%)</td>
								<td style="padding: 2px 10px;border: 1px solid #d5d5d5;text-align:center;color: #294760;font-style: normal;font-weight: 500;padding: 10px;"> €   (%)</td>
								<td style="padding: 2px 10px;border: 1px solid #d5d5d5;text-align:center;color: #294760;font-style: normal;font-weight: 500;padding: 10px;"> €   (%)</td>
								<td style="padding: 2px 10px;border: 1px solid #d5d5d5;text-align:center;color: #294760;font-style: normal;font-weight: 500;padding: 10px;"> €   (%)</td>
								</tr>
							</tbody>
						</table>						
						<div style="margin:20px 0 10px;width:100%; font-size:16px;color:#314961;font-weight:500;line-height:40px;position: relative; background-color:#e6e9ea;">
							<span style="color:#fff;line-height:40px;width:auto;display:inline-block;text-align:center;background:#314961;padding:0 15px;font-size:16px;font-weight: 500;">DÉCOUVRIMO</span><span style="line-height:40px; display:inline-block; width:auto; padding-left: 15px;">Description de votre bien</span>
						</div>
						<div style="">
							<div style="width:33%;float:left;">
								<img src="http://52.47.202.232/assets/pdf/pic7.png">
							</div>
							<div style="width:65%;float:right;">
								<ul style="list-style-type:none;">
									<li style="float:left;width:100%;list-style-type:none;position: relative;"><b style="position: absolute;left: -15px;top: 8px;width: 7px;height: 7px;background: #314961;border-radius: 50%;display: inline-block;"></b>
										<span style="width: 55%;float: left;font-weight: 500;font-size:15px;color: #294760;line-height: 23px;">Type =</span>
										<span style="width: 45%;float: left;border: 1px solid #bbb;margin:5px 0"><input style="width: 100%;font-style: normal;border:none;padding: 5px 12px;"type="text" value="" readonly=""></span>
									</li>
									<li style="float:left;width:100%;list-style-type:none;position: relative;"><b style="position: absolute;left: -15px;top: 8px;width: 7px;height: 7px;background: #314961;border-radius: 50%;display: inline-block;"></b>
										<span style="width: 55%;float: left;font-weight: 500;font-size:15px;color: #294760;line-height: 23px;">Année de construction =</span>
										<span style="width: 45%;float: left;border: 1px solid #bbb;margin:5px 0">
										<input style="width: 100%;font-style: normal;border:none;padding: 5px 12px;"type="text" value="" readonly=""></span>
									</li>
									<li style="float:left;width:100%;list-style-type:none;position: relative;"><b style="position: absolute;left: -15px;top: 8px;width: 7px;height: 7px;background: #314961;border-radius: 50%;display: inline-block;"></b>
										<span style="width: 55%;float: left;font-weight: 500;font-size:15px;color: #294760;line-height: 23px;">Source de chaleur =</span>
										<span style="width: 45%;float: left;border: 1px solid #bbb;margin:5px 0">
										<input style="width: 100%;font-style: normal;border:none;padding: 5px 12px;"type="text" value="" readonly=""></span>
									</li>
									<li style="float:left;width:100%;list-style-type:none;position: relative;"><b style="position: absolute;left: -15px;top: 8px;width: 7px;height: 7px;background: #314961;border-radius: 50%;display: inline-block;"></b>
										<span style="width: 55%;float: left;font-weight: 500;font-size:15px;color: #294760;line-height: 23px;">Type de chauffage =</span>
										<span style="width: 45%;float: left;border: 1px solid #bbb;margin:5px 0">
										<input style="width: 100%;font-style: normal;border:none;padding: 5px 12px;"type="text" value="" readonly=""></span>
									</li>
									<li style="float:left;width:100%;list-style-type:none;position: relative;"><b style="position: absolute;left: -15px;top: 8px;width: 7px;height: 7px;background: #314961;border-radius: 50%;display: inline-block;"></b>
										<span style="width: 55%;float: left;font-weight: 500;font-size:15px;color: #294760;line-height: 23px;">Surface utile =</span>
										<span style="width: 45%;float: left;border: 1px solid #bbb;margin:5px 0">
										<input style="width: 100%;font-style: normal;border:none;padding: 5px 12px;"type="text" value="" readonly=""></span>
									</li>
									<li style="float:left;width:100%;list-style-type:none;position: relative;"><b style="position: absolute;left: -15px;top: 8px;width: 7px;height: 7px;background: #314961;border-radius: 50%;display: inline-block;"></b>
										<span style="width: 55%;float: left;font-weight: 500;font-size:15px;color: #294760;line-height: 23px;">Nombre de pièces =</span>
										<span style="width: 45%;float: left;border: 1px solid #bbb;margin:5px 0">
										<input style="width: 100%;font-style: normal;border:none;padding: 5px 12px;"type="text" value="" readonly=""></span>
									</li>
									<li style="float:left;width:100%;list-style-type:none;position: relative;"><b style="position: absolute;left: -15px;top: 8px;width: 7px;height: 7px;background: #314961;border-radius: 50%;display: inline-block;"></b>
										<span style="width: 55%;float: left;font-weight: 500;font-size:15px;color: #294760;line-height: 23px;">Nombre de CHB =</span>
										<span style="width: 45%;float: left;border: 1px solid #bbb;margin:5px 0">
										<input style="width: 100%;font-style: normal;border:none;padding: 5px 12px;"type="text" value="" readonly=""></span>
									</li>
									<li style="float:left;width:100%;list-style-type:none;position: relative;"><b style="position: absolute;left: -15px;top: 8px;width: 7px;height: 7px;background: #314961;border-radius: 50%;display: inline-block;"></b>
										<span style="width: 55%;float: left;font-weight: 500;font-size:15px;color: #294760;line-height: 23px;">Surface du terrain =</span>
										<span style="width: 45%;float: left;border: 1px solid #bbb;margin:5px 0">
										<input style="width: 100%;font-style: normal;border:none;padding: 5px 12px;"type="text" value="" readonly=""></span>
									</li>
								</ul>
							</div>
							<div style="width:100%;clear:both;"></div>
						</div>
						
					</div>
					
					
					<div style="padding: 5px 0px;margin:20px auto 10px;width: 96%;font-size: 12.5px;border: 3px solid #ababab;color: #314961;text-align: left;background-color: #efefef;">
						<div style="width: 14%; display:inline-block;padding-left:10px;float:left;">
							<img src="http://52.47.202.232/assets/images/logo1.png">
						</div>
						<div style="width: 50%; display:inline-block;float:left;">
							<ul>
								<li style="margin: 4px 0px 3px;width: 100%;padding-left: 5px;line-height: 18px;font-weight: 500;">Votre Home Conseiller</li>
								<li style="margin: 4px 0px 3px;width: 100%;padding-left: 5px;line-height: 18px;font-weight: 500;">Mr.Philippe Soulié</li>
								<li style="margin: 4px 0px 3px;width: 100%;padding-left: 5px;line-height: 18px;font-weight: 500;">Email : developer@espceo.com</li>
							</ul>
						</div>
						<div  style="width: 36%; display:inline-block;">
							<ul>
								<li style="margin: 4px 0px 3px;width: 100%;padding-left: 5px;line-height: 18px;font-weight: 500;">Notre Réseau</li>
								<li style="margin: 4px 0px 3px;width: 100%;padding-left: 5px;line-height: 18px;font-weight: 500;">Tél. : 0457430050</li>
								<li style="margin: 4px 0px 3px;width: 100%;padding-left: 5px;line-height: 18px;font-weight: 500;">E-mail : contact@limmobilier.net</li>
								<li style="margin: 4px 0px 3px;width: 100%;padding-left: 5px;line-height: 18px;font-weight: 500;">Site web : https://www.limmobilier.net</li>
								<li style="margin: 4px 0px 3px;width: 100%;padding-left: 5px;line-height: 18px;font-weight: 500;">Adresse : 2 Avenue du Lac 74140 Douvaine</li>
							</ul>
						</div>
					</div>
				</div>					
				<!-- End: page 4 -->
				
				<!-- Start: page 5 -->
				<div style="border:1px solid #ccc;padding:10px;margin-bottom:30px;page-break-before:always;">
					<div style="font-size: 16px;color: #000;font-weight:500;padding-bottom:10px">16/03/2019</div>
					<div style="padding: 0px;margin-bottom: 18px;width: 100%;font-size: 16px;color: #314961;font-weight: 500;line-height:40px;position: relative;background-color: #314961;">
					<span style="color: #fff;line-height: 40px;width: 44px;display: inline-block;text-align: center;">5</span><span style="background:#e9e8e7;line-height: 40px;display: inline-block;width: 85%;padding-left: 15px;">Tout savoir sur votre ville </span>
					</div>
					<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d11022.134475797046!2d6.324635246625228!3d46.319099115924466!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x478c6a43223ab387%3A0xcccaf95c6830ae0e!2sVers+la+Croix%2C+74140+Massongy%2C+France!5e0!3m2!1sen!2sin!4v1532347047708" style="border:0" allowfullscreen="" width="100%" height="320" frameborder="0"></iframe>
					<div>
						<div style="width:24%;text-align:center;background:#e6e6e9;float:left;margin-right:1.33%">
							<div style="padding: 10px 6px;width:100%;font-size: 19px;line-height: 22px; color: #fff; background-color: #314961;text-transform: uppercase;">
								SUPERFICIE DE LA VILLE
							</div>
							<div style="padding: 3px 6px;min-height: 95px;">
								<p style="color: #294760;font-weight: 600;line-height: normal;font-size: 34px;">4.02 </p>
								<small style="display: block;font-size: 16px;line-height: 38px;font-weight: 500;color: #294760;">km2</small>
							</div>
						</div>
						<div style="width:24%;text-align:center;background:#e6e6e9;float:left;margin-right:1.33%">
							<div style="padding: 10px 6px;width:100%;font-size: 19px;line-height: 22px; color: #fff; background-color: #314961;text-transform: uppercase;">
								POPULATION DE LA VILLE
							</div>
							<div style="padding: 3px 6px;min-height: 95px;">
								<p style="color: #294760;font-weight: 600;line-height: normal;font-size: 34px;">11302 </p>
								<small style="display: block;font-size: 16px;line-height: 38px;font-weight: 500;color: #294760;">Habitans</small>
							</div>
						</div>
						<div style="width:24%;text-align:center;background:#e6e6e9;float:left;margin-right:1.33%">
							<div style="padding: 10px 6px;width:100%;font-size: 19px;line-height: 22px; color: #fff; background-color: #314961;text-transform: uppercase;">
								POPULATION ACTIVE
							</div>
							<div style="padding: 3px 6px;min-height: 95px;">
								<p style="color: #294760;font-weight: 600;line-height: normal;font-size: 34px;">19%</p>
								<small style="display: block;font-size: 16px;line-height: 38px;font-weight: 500;color: #294760;">personnes</small>
							</div>
						</div>					
						<div style="width:24%;text-align:center;background:#e6e6e9;float:left;">
							<div style="padding: 10px 6px;width:100%;font-size: 19px;line-height: 22px; color: #fff; background-color: #314961;text-transform: uppercase;">
								Revenus moyen par foyer
							</div>
							<div style="padding: 3px 6px;min-height: 95px;">
								<p style="color: #294760;font-weight: 600;line-height: normal;font-size: 34px;">2360</p>
								<small style="display: block;font-size: 16px;line-height: 38px;font-weight: 500;color: #294760;">€/mois</small>
							</div>
						</div>
						<div style="width:100%;clear:both"></div>						
						<div style="width:24%;text-align:center;background:#e6e6e9;float:left;margin-right:1.33%;margin-top:15px">
							<div style="padding: 10px 6px;width:100%;font-size: 19px;line-height: 22px; color: #fff; background-color: #314961;text-transform: uppercase;">NOMBRE DE LOGEMENTS</div>
							<div style="padding: 3px 6px;min-height: 95px;">
								<p style="color: #294760;font-weight: 600;line-height: normal;font-size: 34px;">26</p>
								<small style="display: block;font-size: 16px;line-height: 38px;font-weight: 500;color: #294760;">logements</small>
							</div>
						</div>
						<div style="width:24%;text-align:center;background:#e6e6e9;float:left;margin-right:1.33%;margin-top:15px">
							<div style="padding: 10px 6px;width:100%;font-size: 19px;line-height: 22px; color: #fff; background-color: #314961;text-transform: uppercase;">RÉSIDENCES PRINCIPALES</div>
							<div style="padding: 3px 6px;min-height: 95px;">
								<p style="color: #294760;font-weight: 600;line-height: normal;font-size: 34px;">18%</p>
								<small style="display: block;font-size: 16px;line-height: 38px;font-weight: 500;color: #294760;">logements</small>
							</div>
						</div>
						<div style="width:24%;text-align:center;background:#e6e6e9;float:left;margin-right:1.33%;margin-top:15px">
							<div style="padding: 10px 6px;width:100%;font-size: 19px;line-height: 22px; color: #fff; background-color: #314961;text-transform: uppercase;">RÉSIDENCES SECONDAIRES</div>
							<div style="padding: 3px 6px;min-height: 95px;">
								<p style="color: #294760;font-weight: 600;line-height: normal;font-size: 34px;">22%</p>
								<small style="display: block;font-size: 16px;line-height: 38px;font-weight: 500;color: #294760;">logements</small>
							</div>
						</div>					
						<div style="width:24%;text-align:center;background:#e6e6e9;float:left;margin-top:15px">
							<div style="padding: 10px 6px;width:100%;font-size: 19px;line-height: 22px; color: #fff; background-color: #314961;text-transform: uppercase;">LOGEMENTS VACANT</div>
							<div style="padding: 3px 6px;min-height: 95px;">
								<p style="color: #294760;font-weight: 600;line-height: normal;font-size: 34px;">6%</p>
								<small style="display: block;font-size: 16px;line-height: 38px;font-weight: 500;color: #294760;">logements</small>
							</div>
						</div>
					</div>
					<div style="width:100%;clear:both"></div>				
					<div style="padding: 5px 0px;margin:20px auto 10px;width: 96%;font-size: 12.5px;border: 3px solid #ababab;color: #314961;text-align: left;background-color: #efefef;">
						<div style="width: 14%; display:inline-block;padding-left:10px;float:left;">
							<img src="http://52.47.202.232/assets/images/logo1.png">
						</div>
						<div style="width: 50%; display:inline-block;float:left;">
							<ul>
								<li style="margin: 4px 0px 3px;width: 100%;padding-left: 5px;line-height: 18px;font-weight: 500;">Votre Home Conseiller</li>
								<li style="margin: 4px 0px 3px;width: 100%;padding-left: 5px;line-height: 18px;font-weight: 500;">Mr.Philippe Soulié</li>
								<li style="margin: 4px 0px 3px;width: 100%;padding-left: 5px;line-height: 18px;font-weight: 500;">Email : developer@espceo.com</li>
							</ul>
						</div>
						<div  style="width: 36%; display:inline-block;">
							<ul>
								<li style="margin: 4px 0px 3px;width: 100%;padding-left: 5px;line-height: 18px;font-weight: 500;">Notre Réseau</li>
								<li style="margin: 4px 0px 3px;width: 100%;padding-left: 5px;line-height: 18px;font-weight: 500;">Tél. : 0457430050</li>
								<li style="margin: 4px 0px 3px;width: 100%;padding-left: 5px;line-height: 18px;font-weight: 500;">E-mail : contact@limmobilier.net</li>
								<li style="margin: 4px 0px 3px;width: 100%;padding-left: 5px;line-height: 18px;font-weight: 500;">Site web : https://www.limmobilier.net</li>
								<li style="margin: 4px 0px 3px;width: 100%;padding-left: 5px;line-height: 18px;font-weight: 500;">Adresse : 2 Avenue du Lac 74140 Douvaine</li>
							</ul>
						</div>
					</div>
				</div>					
				<!-- End: page 5 -->
				
				<!-- Start: page 6 -->
				<div style="border:1px solid #ccc;padding:10px;margin-bottom:30px;page-break-before:always;">
					<div style="font-size: 16px;color: #000;font-weight:500;padding-bottom:10px">15/03/2019</div>
					<div style="padding: 0px;margin-bottom: 18px;width: 100%;font-size: 16px;color: #314961;font-weight: 500;line-height:40px;position: relative;background-color: #314961;">
					<span style="color: #fff;line-height: 40px;width: 44px;display: inline-block;text-align: center;">6</span><span style="background:#e9e8e7;line-height: 40px;display: inline-block;width: 85%;padding-left: 15px;">Résultat de l’estimation EVALUEO </span>
					</div>
					<h3 style="text-align:center;font-size:25px; color:#294760;padding:10px 0 15px">Résultat de notre estimation Evalueo©</h3>
					<div style="margin: 10px 0px 20px;width: 100%;font-size: 100%;font-style: normal;text-align: center;position: relative;">
						<span style=" color:#294760;width: 33.33%;float: left;font-size: 20px;font-weight: 500;">Evaluation Basse
							<i class="fa fa-map-marker" style=" color:#294760;padding: 20px 0px 1px;width: 100%;display: block;font-size: 28px;line-height: 25px;"></i>
							<span class="ng-binding">246,108 €</span>
						</span>
						<span style=" color:#294760;width: 33.33%;float: left;font-size: 20px;font-weight: 500;">EVALUEO
							<i class="fa fa-map-marker" class="fa fa-map-marker" style=" color:#294760;padding: 20px 0px 1px;width: 100%;display: block;font-size: 28px;line-height: 25px;"></i>
							<span class="ng-binding">273,453 €</span>
						</span>
						<span style=" color:#294760;width: 33.33%;float: left;font-size: 20px;font-weight: 500;">Evaluation Haute
							<i class="fa fa-map-marker" class="fa fa-map-marker" style=" color:#294760;padding: 20px 0px 1px;width: 100%;display: block;font-size: 28px;line-height: 25px;"></i>
							<span class="ng-binding">300,798 €</span>
						</span>
						<b style="position:relative;left:-35%;top:24px;width:10px;height:10px;background: #314961;border-radius: 50%; display:inline-block;margin-left: 3px;"></b><em style="margin:10px 15% 20px;width:70%;float:left;position:relative; background-color:#314961;">
						<input id="offer-price3" type="range" min="169000" max="198000" value="" style="width: 100%;position: relative;-webkit-appearance: none;height: 3px;background-color: #314961;outline: none;opacity: 1;-webkit-transition: .2s;transition: opacity .2s;"></em><b style="position:relative;right:-35%;top:24px;width:10px;height:10px;background: #314961;border-radius: 50%;display:inline-block;margin-left: -3px;"></b>
					</div>
					<div style="width:100%;clear:both;"></div>
					<div style="margin-top:20px;">
						<div style="width:23%;text-align:center;background:#e6e6e9;float:left;">
							<div style="padding: 4px 6px 0px;width: 100%;min-height: 56px;font-size: 16px;line-height: 22px;color: #fff; background-color: #314961;">
								Valeur<br> Indicative
							</div>
							<div style="padding: 3px 6px;min-height: 190px;">
								<div style="height:85px;margin: 15px 0px 0px;"><img src="http://52.47.202.232/assets/pdf/icon14.png" style="width: auto;max-width: 100%;height: auto;max-height: 87%;"></div>
								<p style="color: #294760;font-weight: 600;line-height: normal;font-size: 34px;">300,146 €</p>						
							</div>
							<p style="padding: 4px 6px 5px;width: 100%;min-height: 56px;font-size: 16px;line-height: 22px;color: #fff; background-color: #314961; margin-bottom:0; font-weight:500;">V1</p>
						</div>
						<i class="fa fa-plus" style="padding:3px 6px;width:3%;min-height:247px;float:left;font-size: 22px;font-weight: 400;color: #999;text-align:center;display:flex;justify-content:center;align-items:center;"></i>
						<div style="width:23%;text-align:center;background:#e6e6e9;float:left;">
							<div style="padding: 4px 6px 5px;width: 100%;min-height: 56px;font-size: 16px;line-height: 22px;color: #fff;background-color: #314961;">
								Valeur<br> Technique
							</div>
							<div style="padding: 3px 6px;min-height: 190px;">
								<div style="height:85px;margin: 15px 0px 0px;"><img src="http://52.47.202.232/assets/pdf/icon13.png" style="width: auto;max-width: 100%;height: auto;max-height: 87%;"></div>
								<p style="color: #294760;font-weight: 600;line-height: normal;font-size: 34px;">115,500 €</p>
							</div>
							<p style="padding: 4px 6px 5px;width: 100%;min-height: 56px;font-size: 16px;line-height: 22px;color: #fff; background-color: #314961; margin-bottom:0; font-weight:500;">V2</p>
						</div>
						<i class="fa fa-plus" style="padding:3px 6px;width:3%;min-height:247px;float:left;font-size: 22px;font-weight: 400;color: #999;text-align:center;display:flex;justify-content:center;align-items:center;"></i>
						<div style="width:23%;text-align:center;background:#e6e6e9;float:left;">
							<div style="padding: 4px 6px 5px;width: 100%;min-height: 56px;font-size: 16px;line-height: 22px;color: #fff;background-color: #314961;">
								Valeur par<br> Capitalisation 
							</div>
							<div style="padding: 3px 6px;min-height: 190px;">
								<div style="height:85px;margin: 15px 0px 0px;"><img src="http://52.47.202.232/assets/pdf/icon12.png" style="width: auto;max-width: 100%;height: auto;max-height: 87%;"></div>
								<p style="color: #294760;font-weight: 600;line-height: normal;font-size: 34px;">241,440 €</p>
							</div>
							<p style="padding: 4px 6px 5px;width: 100%;min-height: 56px;font-size: 16px;line-height: 22px;color: #fff; background-color: #314961; margin-bottom:0; font-weight:500;">V3</p>
						</div>
						<i class="fa fa-plus" style="padding:3px 6px;width:3%;min-height:247px;float:left;font-size: 22px;font-weight: 400;color: #999;text-align:center;display:flex;justify-content:center;align-items:center;"></i>						
						<div style="width:22%;text-align:center;background:#e6e6e9;float:left;">
							<div style="padding: 4px 6px 5px;width: 100%;min-height: 56px;font-size: 16px;line-height: 22px;color: #fff;background-color: #314961;">
								Valeur par<br>Comparaison 
							</div>
							<div style="padding: 3px 6px;min-height: 190px;">
								<div style="height:85px;margin: 15px 0px 0px;"><img src="http://52.47.202.232/assets/pdf/icon11.png" style="width: auto;max-width: 100%;height: auto;max-height: 87%;"></div>
								<p style="color: #294760;font-weight: 600;line-height: normal;font-size: 34px;">275,000 €</p>
							</div>
							<p style="padding: 4px 6px 5px;width: 100%;min-height: 56px;font-size: 16px;line-height: 22px;color: #fff; background-color: #314961; margin-bottom:0; font-weight:500;">V4</p>
						</div>
						<div style="width:100%;clear:both"></div>
						<p style="padding:3px 6px;width:100%;font-size: 42px;font-weight:bold;color: #999;text-align:center;text-align:center;display:block;">=</p>
						<div style="width:25%;text-align:center;background:#e6e6e9;margin:0 auto;">
							<div style="padding: 4px 6px 5px;width: 100%;min-height: 56px;font-size: 16px;line-height: 22px;color: #fff;background-color: #314961;">
								Valeur<br>Estimée 
							</div>
							<div style="padding: 3px 6px;min-height: 190px;">
								<div style="height:85px;margin: 15px 0px 0px;"><img src="http://52.47.202.232/assets/pdf/icon10.png" style="width: auto;max-width: 100%;height: auto;max-height: 87%;"></div>
								<p style="color: #294760;font-weight: 600;line-height: normal;font-size: 34px;">273,453 €</p>
							</div>
						</div>						
					</div>
					<div style="margin:20px 0 10px;width:100%; font-size:16px;color:#314961;font-weight:500;line-height:40px;position: relative; background-color:#e6e9ea;">
						<span style="color:#fff;line-height:40px;width:auto;display:inline-block;text-align:center;background:#314961;padding:0 15px;font-size:16px;font-weight: 500;">7</span><span style="line-height:40px; display:inline-block; width:auto; padding-left: 15px;">Liste des biens comparables </span><label style="padding: 0px; padding-right: 0px;margin: 0px 0px 0px;position: absolute;top: 5px;right: 25px;width: auto;"><input type="checkbox"><em></em></label>
					</div>
					
					
					<div style="padding: 5px 0px;margin:20px auto 10px;width: 96%;font-size: 12.5px;border: 3px solid #ababab;color: #314961;text-align: left;background-color: #efefef;">
						<div style="width: 14%; display:inline-block;padding-left:10px;float:left;">
							<img src="http://52.47.202.232/assets/images/logo1.png">
						</div>
						<div style="width: 50%; display:inline-block;float:left;">
							<ul>
								<li style="margin: 4px 0px 3px;width: 100%;padding-left: 5px;line-height: 18px;font-weight: 500;">Votre Home Conseiller</li>
								<li style="margin: 4px 0px 3px;width: 100%;padding-left: 5px;line-height: 18px;font-weight: 500;">Mr.Philippe Soulié</li>
								<li style="margin: 4px 0px 3px;width: 100%;padding-left: 5px;line-height: 18px;font-weight: 500;">Email : developer@espceo.com</li>
							</ul>
						</div>
						<div  style="width: 36%; display:inline-block;">
							<ul>
								<li style="margin: 4px 0px 3px;width: 100%;padding-left: 5px;line-height: 18px;font-weight: 500;">Notre Réseau</li>
								<li style="margin: 4px 0px 3px;width: 100%;padding-left: 5px;line-height: 18px;font-weight: 500;">Tél. : 0457430050</li>
								<li style="margin: 4px 0px 3px;width: 100%;padding-left: 5px;line-height: 18px;font-weight: 500;">E-mail : contact@limmobilier.net</li>
								<li style="margin: 4px 0px 3px;width: 100%;padding-left: 5px;line-height: 18px;font-weight: 500;">Site web : https://www.limmobilier.net</li>
								<li style="margin: 4px 0px 3px;width: 100%;padding-left: 5px;line-height: 18px;font-weight: 500;">Adresse : 2 Avenue du Lac 74140 Douvaine</li>
							</ul>
						</div>
					</div>
				</div>					
				<!-- End: page 6 -->
				
				<!-- Start: page 7 -->
				<div style="border:1px solid #ccc;padding:10px;margin-bottom:30px;page-break-before:always;">
					<div style="font-size: 16px;color: #000;font-weight:500;padding-bottom:10px">15/03/2019</div>
					<div style="padding: 0px;margin-bottom: 18px;width: 100%;font-size: 16px;color: #314961;font-weight: 500;line-height:40px;position: relative;background-color: #314961;">
					<span style="color: #fff;line-height: 40px;width: 44px;display: inline-block;text-align: center;">8</span><span style="background:#e9e8e7;line-height: 40px;display: inline-block;width: 85%;padding-left: 15px;">Notre proposition commerciale </span>
					</div>
					<div style="padding:0px;margin:15px 0 15px;width:100%;font-size:16px;color:#314961;font-weight:500;line-height:40px;position: relative;background-color:#e6e9ea;">
					<span style="color:#fff;line-height:40px;width:auto;display:inline-block;text-align:center;background:#314961;padding:0 15px;font-size:16px;font-weight: 500;">Notre Mandat SOLUCIMO©</span><span style="line-height:40px;display:inline-block;width:auto;padding-left: 15px;">Pour booster la mise en vente de votre bien. </span>
					</div>
					<p style="color:#294760;font-weight:500;margin-bottom:15px;">Nous vous proposons d'être le seul professionnel pour s'occuper de la vente de votre bien, pour qu'il soit mieux vu, moins négocié, et pour que nous puissions utiliser notre technique de vente en tout sérénité. Nous vous proposons un mandat SOLUCIMO© au prix de honoraires agence de % TTC inclus, soit un prix net vendeur de </p>
					<div style="padding:0px;margin:15px 0 15px;width:100%;font-size:16px;color:#314961;font-weight:500;line-height:40px;position: relative;background-color:#e6e9ea;">
					<span style="color:#fff;line-height:40px;width:auto;display:inline-block;text-align:center;background:#314961;padding:0 15px;font-size:16px;font-weight: 500;">OPTIMEO©</span><span style="line-height:40px;display:inline-block;width:auto;padding-left: 15px;">Votre bien mieux présenter pour augmenter les contacts acheteurs. </span>
					</div>
					<p style="color:#294760;font-weight:500;margin-bottom:15px;">Nous allons tout metter en œuvre pour présenter le mieux possible votre bien. Pour cela, nous devons prendre les photos les plus représentatives, rédiger le texte publicitaire le plus pertinent possible, réaliser si possible des plans 2D et 3D, visites virtuelles à 360°, séquences par drone, tout cela pour créer le coup de cœur, car votre bien n’est pas à vendre il est à acheter !... </p>
					<div style="padding:0px;margin:15px 0 15px;width:100%;font-size:16px;color:#314961;font-weight:500;line-height:40px;position: relative;background-color:#e6e9ea;">
					<span style="color:#fff;line-height:40px;width:auto;display:inline-block;text-align:center;background:#314961;padding:0 15px;font-size:16px;font-weight: 500;">MARKETIMO©</span><span style="line-height:40px;display:inline-block;width:auto;padding-left: 15px;">Votre bien plus diffuser pour augmenter les contacts acheteurs </span>
					</div>
					<p style="color:#294760;font-weight:500;margin-bottom:15px;">Après OPTIMEO© qui prépare la mise en commercialisation de votre bien, MARKETIMO© permet la diffusion massive de votre bien:</p>
					<div style="width:50%;padding:15px;text-align:center;float:left;">
						<div style="img"><img src="http://52.47.202.232/assets/pdf/pic5.png"></div>
						<h6 style="color: #314961;line-height: 26px;font-size:18px;padding-top:20px">Retrouvez votre bien en ligne sur les site principaux</h6>
					</div>
					<div style="width:50%;padding:15px;text-align:center;float:left;">
						<div style="img"><img src="http://52.47.202.232/assets/pdf/pic4.png"></div>
						<h6 style="color: #314961;line-height: 26px;font-size:18px;padding-top:20px">Nous créons un site dédié à votre bien</h6>
					</div>
					<div style="width:50%;padding:15px;text-align:center;float:left;">
						<div style="img"><img src="http://52.47.202.232/assets/pdf/pic6.png"></div>
						<h6 style="color: #314961;line-height: 26px;font-size:18px;padding-top:20px">Votre bien diffusé et partage dans les réseaux sociaux</h6>
					</div>
					<div style="width:50%;padding:15px;text-align:center;float:left;">
						<div style="img"><img src="http://52.47.202.232/assets/pdf/pic3.png"></div>
						<h6 style="color: #314961;line-height: 26px;font-size:18px;padding-top:20px">Parution de votre bien dans notre journal <strong>MONIMO</strong></h6>
					</div>
					<div style="clear:both;width:100%"></div>
					
					
					<div style="padding: 5px 0px;margin:20px auto 10px;width: 96%;font-size: 12.5px;border: 3px solid #ababab;color: #314961;text-align: left;background-color: #efefef;">
						<div style="width: 14%; display:inline-block;padding-left:10px;float:left;">
							<img src="http://52.47.202.232/assets/images/logo1.png">
						</div>
						<div style="width: 50%; display:inline-block;float:left;">
							<ul>
								<li style="margin: 4px 0px 3px;width: 100%;padding-left: 5px;line-height: 18px;font-weight: 500;">Votre Home Conseiller</li>
								<li style="margin: 4px 0px 3px;width: 100%;padding-left: 5px;line-height: 18px;font-weight: 500;">Mr.Philippe Soulié</li>
								<li style="margin: 4px 0px 3px;width: 100%;padding-left: 5px;line-height: 18px;font-weight: 500;">Email : developer@espceo.com</li>
							</ul>
						</div>
						<div  style="width: 36%; display:inline-block;">
							<ul>
								<li style="margin: 4px 0px 3px;width: 100%;padding-left: 5px;line-height: 18px;font-weight: 500;">Notre Réseau</li>
								<li style="margin: 4px 0px 3px;width: 100%;padding-left: 5px;line-height: 18px;font-weight: 500;">Tél. : 0457430050</li>
								<li style="margin: 4px 0px 3px;width: 100%;padding-left: 5px;line-height: 18px;font-weight: 500;">E-mail : contact@limmobilier.net</li>
								<li style="margin: 4px 0px 3px;width: 100%;padding-left: 5px;line-height: 18px;font-weight: 500;">Site web : https://www.limmobilier.net</li>
								<li style="margin: 4px 0px 3px;width: 100%;padding-left: 5px;line-height: 18px;font-weight: 500;">Adresse : 2 Avenue du Lac 74140 Douvaine</li>
							</ul>
						</div>
					</div>
				</div>					
				<!-- End: page 7 -->
				
				<!-- Start: page 8 -->
				<div style="border:1px solid #ccc;padding:10px;margin-bottom:30px;page-break-before:always;">
					<div style="font-size: 16px;color: #000;font-weight:500;padding-bottom:10px">15/03/2019</div>
					<div style="padding: 0px;margin-bottom: 18px;width: 100%;font-size: 16px;color: #314961;font-weight: 500;line-height:40px;position: relative;background-color: #314961;">
					<span style="color: #fff;line-height: 40px;width: 44px;display: inline-block;text-align: center;">9</span><span style="background:#e9e8e7;line-height: 40px;display: inline-block;width: 85%;padding-left: 15px;">Mandat de vente Solucimo </span>
					</div>
					<div style="width:100%;text-align:center;margin-top:30px;">
						<img src="http://52.47.202.232/assets/pdf/pic2.png">
					</div>
					<nav class="nav-arrow" style="padding: 30px 15px 20px;margin: 0px auto;width: 100%;float: left;text-align: center;line-height: 10px;overflow: hidden;position: relative;z-index: 0;">
						<ul>
							<li class="active" style="padding: 0px 0px;margin: 0px;width: auto;float: none;display: inline-block;list-style: none;line-height: 24px;position: relative;z-index: 1;cursor: pointer;">
							<a style="padding: 4px 14px;margin: 0px 23px 0px 0px;float: left;color: #fff;font-size: 17px;line-height: 26px;font-weight: 600;font-family: 'Raleway', sans-serif;text-transform: uppercase;text-decoration: none;border-top: 0px solid #3ec2fe;background-color: #3ec2fe;position: relative;z-index: 1;transition: ease-in-out 0s;-moz-transition: ease-in-out 0s;-webkit-transition: ease-in-out 0s;" data-toggle="tab" href="#pdf-etudeo" aria-expanded="true">ETUDEO</a></li>
							<li class="" style="padding: 0px 0px;margin: 0px;width: auto;float: none;display: inline-block;list-style: none;line-height: 24px;position: relative;z-index: 1;cursor: pointer;">
							<a style="padding: 4px 14px;margin: 0px 23px 0px 0px;float: left;color: #fff;font-size: 17px;line-height: 26px;font-weight: 600;font-family: 'Raleway', sans-serif;text-transform: uppercase;text-decoration: none;border-top: 0px solid #3ec2fe;background-color: #3ec2fe;position: relative;z-index: 1;transition: ease-in-out 0s;-moz-transition: ease-in-out 0s;-webkit-transition: ease-in-out 0s;" data-toggle="tab" href="#pdf-evalueo" aria-expanded="false">EVALUEO</a></li>
							<li class="" style="padding: 0px 0px;margin: 0px;width: auto;float: none;display: inline-block;list-style: none;line-height: 24px;position: relative;z-index: 1;cursor: pointer;">
							<a style="padding: 4px 14px;margin: 0px 23px 0px 0px;float: left;color: #fff;font-size: 17px;line-height: 26px;font-weight: 600;font-family: 'Raleway', sans-serif;text-transform: uppercase;text-decoration: none;border-top: 0px solid #3ec2fe;background-color: #3ec2fe;position: relative;z-index: 1;transition: ease-in-out 0s;-moz-transition: ease-in-out 0s;-webkit-transition: ease-in-out 0s;" data-toggle="tab" href="#pdf-solucimo" aria-expanded="false">Solucimo</a></li>
						</ul>
					</nav>
					<div class="tab-content" style="width:96%;margin:0 2% 20px;padding:25px 0;">					
						<div id="pdf-etudeo" class="tab-pane fade active in">
							<div style="padding: 0px 18%;width: 100%; text-align:center;">
								<label>
									<img src="http://52.47.202.232/assets/pdf/icon1.png">
									<h6 style="margin: 15px 0px 40px;font-size:18px;color: #0089d4;">Nous démarrons la commercialisation de votre bien !</h6>
								</label>
								<h5 style="color: #294760;font-style: normal;font-weight: 400; font-size:22pxline-height: 28px;">"Pour réussir votre projet de mise en vente et la vente de votre bien, nous vous proposons de signer un mandat de vente Solucimo. "</h5>
							</div>
						</div>
						<div id="pdf-evalueo" class="tab-pane fade">
							<div style="padding: 0px 18%;width: 100%; text-align:center;">
								<label>
									<img src="http://52.47.202.232/assets/pdf/icon1.png">
									<h6 style="margin: 15px 0px 40px;font-size:18px;color: #0089d4;">Nous démarrons la commercialisation de votre bien !</h6>
								</label>
								<h5 style="color: #294760;font-style: normal;font-weight: 400; font-size:22pxline-height: 28px;">"Pour réussir votre projet de mise en vente et la vente de votre bien, nous vous proposons de signer un mandat de vente Solucimo. "</h5>
							</div>
						</div>
						<div id="pdf-solucimo" class="tab-pane fade">
							<div style="padding: 0px 18%;width: 100%; text-align:center;">
								<label>
									<img src="http://52.47.202.232/assets/pdf/icon1.png">
									<h6 style="margin: 15px 0px 40px;font-size:18px;color: #0089d4;">Nous démarrons la commercialisation de votre bien !</h6>
								</label>
								<h5 style="color: #294760;font-style: normal;font-weight: 400; font-size:22pxline-height: 28px;">"Pour réussir votre projet de mise en vente et la vente de votre bien, nous vous proposons de signer un mandat de vente Solucimo. "</h5>
							</div>
						</div>
					</div>
					<div style="clear:both;width:100%"></div>
					
					
					<div style="padding: 5px 0px;margin:20px auto 10px;width: 96%;font-size: 12.5px;border: 3px solid #ababab;color: #314961;text-align: left;background-color: #efefef;">
						<div style="width: 14%; display:inline-block;padding-left:10px;float:left;">
							<img src="http://52.47.202.232/assets/images/logo1.png">
						</div>
						<div style="width: 50%; display:inline-block;float:left;">
							<ul>
								<li style="margin: 4px 0px 3px;width: 100%;padding-left: 5px;line-height: 18px;font-weight: 500;">Votre Home Conseiller</li>
								<li style="margin: 4px 0px 3px;width: 100%;padding-left: 5px;line-height: 18px;font-weight: 500;">Mr.Philippe Soulié</li>
								<li style="margin: 4px 0px 3px;width: 100%;padding-left: 5px;line-height: 18px;font-weight: 500;">Email : developer@espceo.com</li>
							</ul>
						</div>
						<div  style="width: 36%; display:inline-block;">
							<ul>
								<li style="margin: 4px 0px 3px;width: 100%;padding-left: 5px;line-height: 18px;font-weight: 500;">Notre Réseau</li>
								<li style="margin: 4px 0px 3px;width: 100%;padding-left: 5px;line-height: 18px;font-weight: 500;">Tél. : 0457430050</li>
								<li style="margin: 4px 0px 3px;width: 100%;padding-left: 5px;line-height: 18px;font-weight: 500;">E-mail : contact@limmobilier.net</li>
								<li style="margin: 4px 0px 3px;width: 100%;padding-left: 5px;line-height: 18px;font-weight: 500;">Site web : https://www.limmobilier.net</li>
								<li style="margin: 4px 0px 3px;width: 100%;padding-left: 5px;line-height: 18px;font-weight: 500;">Adresse : 2 Avenue du Lac 74140 Douvaine</li>
							</ul>
						</div>
					</div>
				</div>					
				<!-- End: page 8 -->
				
			</div>
		<!--</aside>-->
	</div>
</div>
<?php include('footer.php');?>