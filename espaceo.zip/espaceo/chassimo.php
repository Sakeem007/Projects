<?php include('header.php');?>
	<article class="Chassimo_contener">
		<div class="container">			
			<div class="tab-content Chassimo_Main_wrapper">
				<div class="Chassimo_tableColum col-xs-12 col-sm-5 col-md-5 col-lg-5">
					<div class="chassim_Left_Box">
						<div class="chassimTitle_Box">
							<h2>Chassimo</h2> 
							<h5>"Si tu me cherches, tu me trouves"</h5>
						</div>
						<div class="chassiomMap_slide">
							<div id="chassiomMap" class="carousel slide" data-ride="carousel">
								<!-- Wrapper for slides -->
								<div class="carousel-inner">
									<div class="item active">
										<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d11379754.90301434!2d-6.929476864819009!3d45.86609808040356!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd54a02933785731%3A0x6bfd3f96c747d9f7!2sFrance!5e0!3m2!1sen!2sin!4v1534584981505" style="border:0" allowfullscreen="" width="100%" height="540" frameborder="0"></iframe>
									</div>
									<div class="item">
										<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d11379754.90301434!2d-6.929476864819009!3d45.86609808040356!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd54a02933785731%3A0x6bfd3f96c747d9f7!2sFrance!5e0!3m2!1sen!2sin!4v1534584981505" style="border:0" allowfullscreen="" width="100%" height="540" frameborder="0"></iframe>
									</div>
								</div>
								<!-- Left and right controls -->
								<a class="left carousel-control" href="#chassiomMap" data-slide="prev"> <span class="glyphicon glyphicon-chevron-left"></span>  <span class="sr-only">Previous</span> 
								</a>
								<a class="right carousel-control" href="#chassiomMap" data-slide="next"> <span class="glyphicon glyphicon-chevron-right"></span>  <span class="sr-only">Next</span> 
								</a>
							</div>
<p class="OffrimoChassimoAdd"><i class="fa fa-map-marker"></i> = 4A Street du Lue 74140 Douvain </p>							
						</div>
					</div>
				</div>
				<div class="Chassimo_tableColum col-xs-12 col-sm-7 col-md-7 col-lg-7">
					<div class="banners" style="background-image: url(http://52.47.202.232/assets/images/research-motor-img.png); background-position:bottom;">
						<div class="Banners_TxT">
							<p class="topfilter_box">Paramètrage <input type="text" placeholder="Code, postal, ville" /><button class="" type="text"><i class="fa fa-search"></i></button></p>
							<ul class="Chassim_filter_box">							
								<li>
									<select name="" >
									  <option value="" hidden>Infos sur le terrain</option>
									  <option value="">Surface terrain:__m2 ou entre__m2 et__m2</option>
									  <option value="">Surf. terrain:__m2 ou entre__m2 et__m2</option>
									</select>								
								</li>
								<li>									
									<select name="" >
									  <option value="" hidden>Piscine</option>
									  <option value="">Choice Oui</option>
									  <option value="">NON</option>
									</select>
								</li>
							</ul>
							<ul class="Chassim_filter_box">
								<li>
									<select name="" >
									  <option value="" hidden>Infos sur le bât</option>
									  <option value="">Surface au sol:__m2 ou entre__m2 et __m2</option>
									  <option value="">Surf. terrain:__m2 ou entre__m2 et__m2</option>
									</select>
								</li>								
							</ul>
							<div class="clearfix"></div>
							<p class="Rfr_Btnbox"><button type="button">Valider</button><a href="#">&nbsp;</a></p>
						</div>
					</div>
					<div class="col-md-12 col-sm-12 col-xs-12 Chassimo_right_Wprapper">					
						<div class="majbals-box-1">
							<div class="col-xs-12 ChassimoAngTop">
								<ul>
									<li><a href="#maison-box" data-toggle="modal"  data-backdrop="true"><i class="fa fa-map-marker"></i></a>
									</li>
									<li class="big-view">
										<a  href="#OfferCadastreLand" data-toggle="modal"  data-backdrop="true">
											<img src="images/capture_icon.png">
										</a>
									</li>
								</ul>
							</div>
							<div class="Inbox_Box">
							<div class="Inbox_pik_Box">
								<img src="images/mailbox-full.png" class="img-responsive center-block" alt="mailbox" />	
								</div>                       
							</div>                    
							<div class="col-xs-12 maison-bottom-list">
								<ul class="Obj_sectorimo_map_Box">
									<li class="active"><a href="#">Cadastre</a> </li>
									<li><a href="#">Google</a> </li>
									<li><a href="#">Street View</a> </li>
								</ul>
							</div>
						</div>											
						<div class="majbals-box-1">
							<div class="col-xs-12 ChassimoAngTop">
								<ul>
									<li><a href="#maison-box" data-toggle="modal"  data-backdrop="true"><i class="fa fa-map-marker"></i></a>
									</li>
									<li class="big-view">
										<a  href="#OfferCadastreLand" data-toggle="modal"  data-backdrop="true">
											<img src="images/capture_icon.png">
										</a>
									</li>
								</ul>
							</div>
							<div class="Inbox_Box">
							<div class="Inbox_pik_Box">
								<img src="images/mailbox-full.png" class="img-responsive center-block" alt="mailbox" />	
								</div>                       
							</div>                    
							<div class="col-xs-12 maison-bottom-list">
								<ul class="Obj_sectorimo_map_Box">
									<li class="active"><a href="#">Cadastre</a> </li>
									<li><a href="#">Google</a> </li>
									<li><a href="#">Street View</a> </li>
								</ul>
							</div>
						</div>	
					</div>
				</div>
			</div>			
		</div>
	</article>
	<!-- End: my space box -->
	
	<!-- Chassimo offrimo Offer Cadastre Land-->
	<div id="OfferCadastreLand" class="modal fade ChassimoOfferCadastreLand" role="dialog">
    <div class="modal-dialog">
		<div class="modal-content">
			<button type="button" class="close" data-dismiss="modal"><i class="fa fa-times"></i></button>
			<div class="clr"></div>
			<div class="ChassimoBox">
				<div class="firstbox">				
					<div class="ChassimoCadastre">
						<img src="images/cadastreMap.png">
					</div>
					<div class="slider_Section"  style="display:none;">
						<a href="#maison-box" data-toggle="modal"  data-backdrop="true"><i class="fa fa-map-marker"></i></a>
						<div class="carousel slide" data-ride="carousel" data-type="multi" data-interval="false" id="chassimo_offer">
						<!-- Wrapper for slides -->
						<div class="carousel-inner">
						  <div class="item active" style="background:url(images/offrimo1.png);">
						  </div>
						  <div class="item" style="background:url(images/offrimo2.png);">
						  </div>							
						  <div class="item" style="background:url(images/offrimo3.png);">
						  </div>
						</div>
						<!-- Left and right controls -->
						<a class="left carousel-control" href="#chassimo_offer" data-slide="prev">
						  <span class="glyphicon glyphicon-chevron-left"></span>
						  <span class="sr-only">Previous</span>
						</a>
						<a class="right carousel-control" href="#chassimo_offer" data-slide="next">
						  <span class="glyphicon glyphicon-chevron-right"></span>
						  <span class="sr-only">Next</span>
						</a>
						</div>
					</div>
					<div class="MatchUnmatch">
						<select>
							<option value="">Match</option>
							<option value="">Unmatch</option>
						</select>
						<button class="vali_Btnbox" type="submit">Maj Bals</button>
					</div>
				</div>
			</div>
				
		</div>
    </div>
</div>
	
<?php include('footer.php');?>