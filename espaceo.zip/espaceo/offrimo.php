<?php include('header.php');?>
	
	<!-- Being: offrimo box -->
	<article class="offrimoBox">
		<div class="container">			
			
			<nav class="nav nav-tab">
				<ul>
					<li class="active"><a href="#Toute_loffre" data-toggle="tab">Toute l'offre<small>"Voir les annonces"</small></a></li>
					<li><a href="#Suivreannonces" data-toggle="tab">Suivi<small>"Suivre les annonces"</small></a></li>
					<li><a href="#Alertimo" data-toggle="tab">Alertimo<small>"Suivre mes requêtes"</small></a></li>
					<li><a href="#Diffusimo" data-toggle="tab">Diffusimo<small>"Performance&tracking"</small></a></li>
				</ul>
			</nav>
			<div class="tab-content">
				<div id="Toute_loffre" class="item tab-pane fade in active">
					<!--<div class="row">
						<nav class="nav nav-tab">
							<ul>
								<li class="active"><a href="#Maisons_Appartements" data-toggle="tab">Maisons & Appartements</a></li>
								<li><a href="#Terrains" data-toggle="tab">Terrains</a></li>
								<li><a href="#LofferChassimo" data-toggle="tab">Chassimo</a></li>
							</ul>
						</nav>
						<div class="tab-content">-->
							<div id="Maisons_Appartements" class="item tab-pane fade in active">
								<div class="row">
									<?php include('offrimo-maisons.php');?>
								</div>
							</div>
							<!--<div id="Terrains" class="item tab-pane fade">
								<div class="row">
									<?php //include('offrimo-terrains.php');?>
								</div>
							</div>	
							<div id="LofferChassimo" class="item tab-pane fade">
								<div class="row">
									<?php //include('offrimo-chassimo.php');?>
								</div>
							</div>				
						</div>
					</div>-->
				</div>
				<div id="Suivreannonces" class="item tab-pane fade">
					<div class="row">
						<?php include('offrimo-suivi.php');?>
					</div>
				</div>
				<div id="Alertimo" class="item tab-pane fade">
					<div class="row">
						<?php include('offrimo-alertimo.php');?>
					</div>
				</div>
				<div id="Diffusimo" class="item tab-pane fade">
					<div class="row">
						<nav class="nav nav-tab">
							<ul>
								<li class="active"><a href="#DiffusimoMesannonces" data-toggle="tab">Mes annonces</a></li>
								<li><a href="#DiffusimoFairerapport" data-toggle="tab">Faire rapport</a></li>
							</ul>
						</nav>
						<div class="tab-content">
							<div id="DiffusimoMesannonces" class="item tab-pane fade in active">
								<div class="row">
									<?php include('offrimo-diffusimo-mesannonces.php');?>
								</div>
							</div>
							<div id="DiffusimoFairerapport" class="item tab-pane fade">
								<div class="row">
									<?php include('offrimo-diffusimo-fairerapport.php');?>
								</div>
							</div>				
						</div>
					</div>
				</div>
			</div>
			
		</div>
	</article>
	<!-- End: offrimo box -->

<?php include('footer.php');?>
<?php include('modal.php');?>