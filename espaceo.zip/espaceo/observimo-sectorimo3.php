<div id="Sectorimo" class="item tab-pane fade in active">
	<div class="row">
	<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 Obj_sectorimo_Wrapper">
		<div class="col-xs-12 col-sm-5 col-md-5 col-lg-5">
			<div class="map-sectorimo">
				<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d11379754.90301434!2d-6.929476864819009!3d45.86609808040356!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd54a02933785731%3A0x6bfd3f96c747d9f7!2sFrance!5e0!3m2!1sen!2sin!4v1534584981505" width="100%" height="464" frameborder="0" style="border:0" allowfullscreen></iframe>			
			</div>
			<div class="col-xs-12 maison-bottom-list">
				<ul class="Obj_sectorimo_map_Box sectorimoActive">
					<li class="green_icon"><a href="#"><i class="green-btn fa fa-circle"></i>  Activée(s)</a></li>
					<li class="red_icon"><a href="#"><i class="red-btn fa fa-circle"></i> A activer</a></li>
				</ul>
			</div>
		</div>
		
		<div class="col-xs-12 col-sm-7 col-md-7 col-lg-7 Tableau_bord_right">
		<div class="sliderArrowBox"><a href="#"><i class="fa fa-angle-left"></i></a> Retour Tableau de Board</div>
			
			<ul class="cecterimoRight_Box">
				<div class="TerritoireList">
				<li class="FirstTerritoireBox">
					<select>
						<option>Paramétrer Un Territoire</option>
						<option>Name</option>
					</select>
				</li>
				<li><i class="fa fa-map-marker"></i><select><option>Ajouter un territoire</option> </select></li>
				<li><i class="fa fa-user"></i><select><option>Associer Un Manager au Territoire</option> </select></li>
				<li><span><img src="images/list_icon.png"/></span><select><option>Synchroniser Territoire/Secteurs/Home Conseiller</option> </select></li>
				</div>
				<li id="ParaListBox1" class="Stxt_box">
					<i class="fa fa-map-marker"></i> Ajouter un territoire: <i class="fa fa-angle-down"></i> 
				</li>
				<div class="ParaDetailsBox1">
					<span class="paraCloseBtn"><i class="fa fa-times"></i></span>
					<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
						<li>
							<input type="text" placeholder="Nom Territory" value=""/><i class="fa fa-times"></i><i class="fa fa-edit"></i> <i class="fa fa-arrow-right"></i>
						</li>
					</div>
					<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
						<li>
							<input type="text" value="Chanson"/><i class="fa fa-times"></i><i class="fa fa-edit"></i>
						</li>
						<li>
							<input type="text" value="Don Mme"/><i class="fa fa-times"></i><i class="fa fa-edit"></i>
						</li>
						<li>
							<input type="text" value="Maison"/><i class="fa fa-times"></i><i class="fa fa-edit"></i>
						</li>
					</div>
					<div class="clr"></div>
					<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
						<li class="ParaSecondint">
							<input type="text" placeholder="Nom Territoire" value=""/><i class="fa fa-plus"></i> <i class="fa fa-arrow-right"></i>
						</li>
					</div>
					<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
						<li>
							<input type="text" value="Adress"/><i class="fa fa-plus"></i>
						</li>
					</div>
					<div class="clr"></div>
				</div>
				<li id="ParaListBox2" class="Stxt_box">
						<i class="fa fa-user"></i> Associer Un Manager au Territoire : <i class="fa fa-angle-down"></i>
				</li>				
				<div class="ParaDetailsBox2">
					<span class="paraCloseBtn"><i class="fa fa-times"></i></span>
					<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
						<li class="">
							<select>
								<option>Nom du Territoire</option>
							</select>							
						</li>
					</div>
					<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6 ParaDetailsBox_Right">
						<li>
							<input type="text" placeholder="Nom Manager " value=""/><i class="fa fa-plus"></i>
						</li>
					</div>
					<div class="clr"></div>					
				</div>
				<div class="clr"></div>
				<li id="ParaListBox"><span><img src="images/list_icon.png"/>Synchroniser Territoire/Secteurs/Home Conseiller(s) <i class="fa fa-angle-down"></i></span>					
				</li>
				<div class="ParaDetailsBox">
					<span class="paraCloseBtn"><i class="fa fa-times"></i></span>
					<li class="">
						<select>
							<option>Nom du Territoire</option>
						</select>							
					</li>
					<div class="col-xs-12 col-sm-5 col-md-5 col-lg-5 ParaDetailsBox_left">
						<h6>Les zones géographiques du Territoire</h6>						
							<li>
								<input type="text" value="Chanson"/><i class="fa fa-times"></i><i class="fa fa-edit"></i>
							</li>
							<li>
								<input type="text" value="Don Mme"/><i class="fa fa-times"></i><i class="fa fa-edit"></i>
							</li>
							<li>
								<input type="text" value="Maison"/><i class="fa fa-times"></i><i class="fa fa-edit"></i>
							</li>
					</div>
					<div class="col-xs-12 col-sm-3 col-md-3 col-lg-3 ParaDetailsBox_middle">						
						<h6>Secteurs Associés </h6>
						<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6 PrioritaireBox">
						<strong>Prioritaire</strong>
						  <label class="customClos">
							<input type="checkbox">
							<span class="checkmark"></span> 
						  </label>						  
						 <label class="customClos">
							<input type="checkbox" checked="checked">
							<span class="checkmark"></span>
						 </label>
						 <label class="customClos">
							<input type="checkbox" checked="checked">
							<span class="checkmark"></span>
						 </label>
						</div>
						<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6 SecondaireBox">
						<strong>Secondaire</strong>
						 <label class="customClos">
							<input type="checkbox" checked="checked">
							<span class="checkmark"></span>
						 </label>
						  <label class="customClos">
							<input type="checkbox">
							<span class="checkmark"></span> 
						  </label>
						  <label class="customClos">
							<input type="checkbox">
							<span class="checkmark"></span> 
						  </label>
						</div>
					</div>
					<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4 ParaDetailsBox_right">
						<h6>Home Conseillé(s)</h6>
						<p>Equipe</p>
						<input type="text" placeholder="Alert" value=""><i class="fa fa-edit"></i>
						<input type="text" placeholder="Sub Alert" value=""><i class="fa fa-edit"></i>
					</div>
					<div class="clr"></div>
				</div>
				
				
				
				
				<!--<li class=""><input type="text" placeholder="Rhone-Alpes" value=""/><i class="fa fa-times"></i><i class="fa fa-edit"></i>
				</li>
				<li class=""><input type="text" value=""/><i class="fa fa-plus"></i> <button>Valider</button><a class="resetlast" href="#"></a></li>
				<li class="Stxt_box">Associer un développeur:</li>
				<li class=""><input type="text" placeholder="Rhone-Alpes" value=""/> <input type="text" placeholder="Philipper Soulie" value=""/><i class="fa fa-edit"></i></li>
				<li class=""><input type="text" value=""/><i class="fa fa-plus"></i> <button>Valider</button><a class="resetlast" href="#"></a></li>
				<li class="Stxt_box1">Région(s) activée(s):1</li>
				<li class="Stxt_box">Région(s) à activer: 12</li>-->

			</ul>
		</div>
	</div>

	</div>
</div>