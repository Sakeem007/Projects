<div class="agendaBox">
	<div class="tableColum col-xs-12 col-sm-4 col-md-4 col-lg-3">
		<h5>Mon agenda</h5>
		<div class="leftCaln">
			
			<div class="calendar">
				<div id="calendar"></div>
			</div>			
			<h6>Mes taches</h6>
			<div class="task">
				<ul>
					<li><a href="#" class="color1">RDV Pris</a></li>
					<li><a href="#" class="color2">Rdv mandat Call sans retour</a></li>
					<li><a href="#" class="color3">Rdv mandat Call avec retour</a></li>
					<li><a href="#" class="color4">RDV estimation</a></li>
					<li><a href="#" class="color5">R1 Visite acheteur</a></li>
					<li><a href="#" class="color6">R2 Visite acheteur</a></li>
					<li><a href="#" class="color7">Prospection terrain</a></li>
					<li><a href="#" class="color8">Absences & Conges</a></li>
					<li><a href="#" class="color9">Notair acte</a></li>
					<li><a href="#" class="color10">Notair compromis</a></li>
					<li><a href="#" class="color11">Administratif & Commercial</a></li>
					<li><a href="#" class="color12">Reunion Commercial</a></li>
					<li><a href="#" class="color13">RDV Partenaires</a></li>
					<li><a href="#" class="color14">RDV mandat prospection</a></li>
					<div class="divider"></div>
					<li><a href="#" class="color15">Reunion</a></li>
					<li><a href="#" class="color16">Formation</a></li>
					<li><a href="#" class="color17">Entretien</a></li>
				</ul>
			</div>
		</div>
	</div>
	<div class="tableColum col-xs-12 col-sm-8 col-md-8 col-lg-9">
		<img src="images/calender2.png" style="width: 100%;"/>
	</div>
</div>