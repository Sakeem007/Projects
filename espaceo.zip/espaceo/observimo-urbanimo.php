<div class="UnbanimotopBox">
	<nav class="nav">
		<ul>
			<li class="active"><a href="#LatestSales" data-toggle="tab">Dernières ventes</a></li>
			<li><a href="#EverythingaboutCity" data-toggle="tab">Tout sur une ville</a></li>
		</ul>
	</nav>
</div>
<div class="tab-content urbanimoTabBox">
	<div id="LatestSales" class="item tab-pane fade in active">
		<?php include('urbanimo-latest-sales.php');?>		
	</div>
	<div id="EverythingaboutCity" class="item tab-pane fade">
	<?php include('urbanimo-city.php');?>
	</div>
</div>





<!--
<div class="row">
	<div class="UnbanimotopBox">
		<p>Dernières ventes <a href="javascript:void(0)">Tout sur une ville</a></p>
	</div>
	<div class="UnbanimobodyBox">
		<div class="UnbanimoTxtbox">
			<h5>Découvrez et évaluez un bien immobilier à 360°</h5>
			<input type="search" placeholder="Ex : '10 rue du Château', 'Paris 15', '69002...' " /><button type="button">Découvrir</button>
			<p>Géodécision immobilière</p>
		</div>
	</div>
</div>
-->