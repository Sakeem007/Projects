<!-- Chassimo Modal -->
<div id="Chassimo" class="modal fade offrimoModal">
	<div class="modal-dialog modal-lg">
		<!-- Modal content-->
		<div class="modal-content">
			
			<div class="modal-body">
				<div class="topHeader">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h3>Tableau de chasse</h3>
					<h5>"Qui me cherche, me trouve !"</h5>
				</div>
				<div class="banners" style="background-image: url(images/research-motor-img.png);">
					<div class="Banners_TxT">
					<h5>
					Je recherche une BAL à géolocaliser sur une parcelle<br>
					de <select>
						<option>surface</option>
						<option>surface</option>
					</select>
					ou entre <select>
						<option>m2</option>
					</select>
					et <select>
						<option>m2</option>
					</select>
					située <select>
						<option>Ville,CP,Quartier</option>
					</select>
					</h5>
					</div>
				</div>
	<div class="clr"></div>			
<div class="chassimo_slider">
  <div class="slider">  
    <div id="owl-chassimo" class="owl-carousel">
      <div class="item wow animated zoomIn delay-03s animated">
        <div class="thumb"><i class="fa fa-times"></i><img src="images/chassimo1.jpg"/></div>
      </div>
      <div class="item wow animated zoomIn delay-03s animated">
        <div class="thumb"><i class="fa fa-times"></i><img src="images/chassimo2.jpg"/></div>
      </div>
      <div class="item wow animated zoomIn delay-03s animated">
        <div class="thumb"><i class="fa fa-times"></i><img src="images/chassimo3.jpg"/></div>
      </div>
      <div class="item wow animated zoomIn delay-03s animated">
        <div class="thumb"><i class="fa fa-times"></i><img src="images/chassimo4.jpg"/></div>
      </div>
      <div class="item wow animated zoomIn delay-03s animated">
        <div class="thumb"><i class="fa fa-times"></i><img src="images/chassimo5.jpg"/></div>
      </div>
      <div class="item wow animated zoomIn delay-03s animated">
        <div class="thumb"><i class="fa fa-times"></i><img src="images/chassimo6.jpg"/></div>
      </div>
    </div>
  </div>
</div>
<div class="chassimo_Ball_BoX">
<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
	<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12  Chassimo_frst_Box">
<div class="col-xs-12 majbals-val">
			<ul>
				<li><a href="#maison-box" data-toggle="modal" data-backdrop="true"><i class="fa fa-eye"></i> Voir</a>
				</li>
				<li><a><i class="green-btn fa fa-circle"></i> Active</a>
				</li>
			</ul>
		</div>
		<div class="Prospectimo_majbal">
			<div id="chass4pieces" class="carousel slide" data-ride="carousel">
				<!-- Wrapper for slides -->
				<div class="carousel-inner">
					<div class="carousel-caption">Maison 4Pièces
						<br>41 aveue du lac
						<br>74140 DOUVAINE</div>
					<div class="item active" style="background:url(images/offrimo1.png)"></div>
					<div class="item" style="background:url(images/offrimo2.png)"></div>
				</div>
				<!-- Left and right controls -->
				<a class="left carousel-control" href="#chass4pieces" data-slide="prev"> <span class="glyphicon glyphicon-chevron-left"></span>  <span class="sr-only">Previous</span> 
				</a>
				<a class="right carousel-control" href="#chass4pieces" data-slide="next"> <span class="glyphicon glyphicon-chevron-right"></span>  <span class="sr-only">Next</span> 
				</a>
			</div>
		</div>
		<div class="col-xs-12 maison-bottom-list">
			<ul>
				<li><a href="#">Identifier </a>
				</li>
				<li><a href="#">Infos</a>
				</li>
				<li><a href="#">Découvrimo</a>
				</li>
				<li><a href="#">Potentiel</a>
				</li>
				<li><a href="#maison-box-Suivi" data-toggle="modal" data-backdrop="true">Suivi</a></li>
			</ul>
		</div>
	</div>
	<div class="col-md-6 col-sm-6 col-xs-12 Chassimo_map_Box">
		<figure class="maping">
			<div class="title">
			<i class="fa fa-times"></i>
			<a href="#" class="focus"></a>
			</div>
			<div class="img" style="background-image: url(images/map3.jpg);"></div>
		</figure>			
		<div class="maison-bottom-list">
			<ul>
				<li><a href="#">Cadastre</a>
				</li>
				<li><a href="#">Google</a>
				</li>
				<li><a href="#">Street View</a>
				</li>
			</ul>
		</div>
	</div>
</div>
<div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
<div class="col-md-6 col-sm-6 col-xs-12  Chassimo_frst_Box">
		<div class="col-xs-12 majbals-val">
			<ul>
				<li><a href="#maison-box" data-toggle="modal"  data-backdrop="true"><i class="fa fa-eye"></i> Voir</a>
				</li>
				<li><a><i class="green-btn fa fa-circle"></i> Active</a>
				</li>
			</ul>
		</div>
		<div class="Prospectimo_majbal">
			<div id="chass4pieces2" class="carousel slide" data-ride="carousel">
				<!-- Wrapper for slides -->
				<div class="carousel-inner">
					<div class="carousel-caption">appartement/terrain</div>
					<div class="item active" style="background:url(images/map1.jpg)"></div>
					<div class="item" style="background:url(images/pic4.png)"></div>
				</div>
				<!-- Left and right controls -->
				<a class="left carousel-control" href="#chass4pieces2" data-slide="prev"> <span class="glyphicon glyphicon-chevron-left"></span>  <span class="sr-only">Previous</span> 
				</a>
				<a class="right carousel-control" href="#chass4pieces2" data-slide="next"> <span class="glyphicon glyphicon-chevron-right"></span>  <span class="sr-only">Next</span> 
				</a>
			</div>
		</div>				
		<div class="maison-bottom-list">
			<ul>
				<li><a href="#">Identifier </a>
				</li>
				<li><a href="#">Infos</a>
				</li>
				<li><a href="#">Découvrimo</a>
				</li>
				<li><a href="#">Potentiel</a>
				</li>
				<li><a href="#maison-box-Suivi" data-toggle="modal" data-backdrop="true">Suivi</a></li>
			</ul>
		</div>
	</div>
<div class="col-md-6 col-sm-6 col-xs-12 Chassimo_map_Box">
		<figure class="maping">
			<div class="title">
			<i class="fa fa-times"></i>
			<a href="#" class="focus"></a></div>
			<div class="img" style="background-image: url(images/map3.jpg);"></div>
		</figure>			
		<div class="maison-bottom-list">
			<ul>
				<li><a href="#">Cadastre</a>
				</li>
				<li><a href="#">Google</a>
				</li>
				<li><a href="#">Street View</a>
				</li>
			</ul>
		</div>
	</div>
	
</div>
</div>				
				


<!--<div class="listing">
					<form action="#" method="post">
						<ul>
							<li>Parcelles</li>
							<li><input type="text" value="17"/></li>
							<li>Filter</li>
							<li>
								<select>
									<option>Affichage</option>
									<option>List</option>
								</select>
							</li>
							<li>
								<select>
									<option>10 biens</option>
									<option>20 biens</option>
									<option>30 biens</option>
								</select>
							</li>
						</ul>
					</form>
				</div>
				<div class="photoGallery">
					<div class="row">
						<aside class="gallery col-xs-12 col-sm-3 col-md-3 col-lg-3">
							<figure style="background-image: url(images/offrimo1.png);">
								<span class="remove"></span>
								<div class="text">
									<h5>Photo annonce</h5>
								</div>
							</figure>
						</aside>
						<aside class="gallery col-xs-12 col-sm-3 col-md-3 col-lg-3">
							<figure style="background-image: url(images/offrimo2.png);">
								<span class="remove"></span>
								<div class="text">
									<h5>Photo annonce</h5>
								</div>
							</figure>
						</aside>
						<aside class="gallery col-xs-12 col-sm-3 col-md-3 col-lg-3">
							<figure style="background-image: url(images/offrimo1.png);">
								<span class="remove"></span>
								<div class="text">
									<h5>Photo annonce</h5>
								</div>
							</figure>
						</aside>
						<aside class="gallery col-xs-12 col-sm-3 col-md-3 col-lg-3">
							<figure style="background-image: url(images/offrimo2.png);">
								<span class="remove"></span>
								<div class="text">
									<h5>Photo annonce</h5>
								</div>
							</figure>
						</aside>
						<aside class="gallery col-xs-12 col-sm-3 col-md-3 col-lg-3">
							<figure style="background-image: url(images/offrimo1.png);">
								<span class="remove"></span>
								<div class="text">
									<h5>Photo annonce</h5>
								</div>
							</figure>
						</aside>
						<aside class="gallery col-xs-12 col-sm-3 col-md-3 col-lg-3">
							<figure style="background-image: url(images/offrimo2.png);">
								<span class="remove"></span>
								<div class="text">
									<h5>Photo annonce</h5>
								</div>
							</figure>
						</aside>
						<aside class="gallery col-xs-12 col-sm-3 col-md-3 col-lg-3">
							<figure style="background-image: url(images/offrimo1.png);">
								<span class="remove"></span>
								<div class="text">
									<h5>Photo annonce</h5>
								</div>
							</figure>
						</aside>
						<aside class="gallery col-xs-12 col-sm-3 col-md-3 col-lg-3">
							<figure style="background-image: url(images/offrimo2.png);">
								<span class="remove"></span>
								<div class="text">
									<h5>Photo annonce</h5>
								</div>
							</figure>
						</aside>
						<aside class="gallery col-xs-12 col-sm-3 col-md-3 col-lg-3">
							<figure style="background-image: url(images/offrimo1.png);">
								<span class="remove"></span>
								<div class="text">
									<h5>Photo annonce</h5>
								</div>
							</figure>
						</aside>						
					</div>
				</div>-->
		<!--    <div class="maping">
					<div class="item col-xs-12 col-sm-4 col-md-4 col-lg-4">
						<figure>
							<div class="title">Plan parcelle <a href="#" class="focus"></a></div>
							<div class="img" style="background-image: url(images/map3.jpg);"></div>
						</figure>
					</div>
					<div class="item col-xs-12 col-sm-4 col-md-4 col-lg-4">
						<figure>
							<div class="title">Carte <a href="#" class="focus"></a></div>
							<div class="img" style="background-image: url(images/map2.jpg);"></div>
						</figure>
					</div>
					<div class="item col-xs-12 col-sm-4 col-md-4 col-lg-4">
						<figure>
							<div class="title">Street View <a href="#" class="focus"></a></div>
							<div class="img" style="background-image: url(images/map1.jpg);"></div>
						</figure>
					</div>
					<div class="bottomMenu">
						<ul>
							<li><a href="#">Associer</a></li>
							<li><a href="#">Supprimer</a></li>
							<li><a href="#">MAJ Prospectimo</a></li>
							<li><a href="#">PDF</a></li>
							<li><a href="#">Adresse :</a></li>
						</ul>
					</div>
				</div>				
				<div class="maping">
					<div class="item col-xs-12 col-sm-4 col-md-4 col-lg-4">
						<figure>
							<div class="title"></div>
							<div class="img" style="background-image: url(images/.jpg);"></div>
						</figure>
					</div>
					<div class="item col-xs-12 col-sm-4 col-md-4 col-lg-4">
						<figure>
							<div class="title"></div>
							<div class="img" style="background-image: url(images/.jpg);"></div>
						</figure>
					</div>
					<div class="item col-xs-12 col-sm-4 col-md-4 col-lg-4">
						<figure>
							<div class="title"></div>
							<div class="img" style="background-image: url(images/.jpg);"></div>
						</figure>
					</div>
					<div class="bottomMenu">
						<ul>
							<li><a href="#">Associer</a></li>
							<li><a href="#">Supprimer</a></li>
							<li><a href="#">MAJ Prospectimo</a></li>
							<li><a href="#">PDF</a></li>
							<li><a href="#">Adresse :</a></li>
						</ul>
					</div>
				</div>
				<div class="maping">-->
					<div class="item col-xs-12 col-sm-4 col-md-4 col-lg-4">
						<figure>
							<div class="title"></div>
							<div class="img" style="background-image: url(images/.jpg);"></div>
						</figure>
					</div>
					<div class="item col-xs-12 col-sm-4 col-md-4 col-lg-4">
						<figure>
							<div class="title"></div>
							<div class="img" style="background-image: url(images/.jpg);"></div>
						</figure>
					</div>
					<div class="item col-xs-12 col-sm-4 col-md-4 col-lg-4">
						<figure>
							<div class="title"></div>
							<div class="img" style="background-image: url(images/.jpg);"></div>
						</figure>
					</div>
					<div class="bottomMenu">
						<ul>
							<li><a href="#">Associer</a></li>
							<li><a href="#">Supprimer</a></li>
							<li><a href="#">MAJ Prospectimo</a></li>
							<li><a href="#">PDF</a></li>
							<li><a href="#">Adresse :</a></li>
						</ul>
					</div>
				</div>
			</div>													
		</div>
	</div>
</div>
<!-- Chassimo Modal -->
<!-- Chassimo Modal -->
<div id="rangeModal" class="modal fade rangeModal">
	<div class="modal-dialog modal-md">
		<div class="modal-content">			
			<div class="modal-body">				
				<button type="button" class="close" data-dismiss="modal">x</button>
				<form action="#" method="post">
				<h6>Je Peux Ponderer La Variable</h6>
				<div class="range2">
					<span class="plusMinus" id="incrementBtn"></span>
					<span class="plusMinus minus" id="decrementBtn"></span>
					<input type="text" value="0" id="incrementValue" min="1" max="10"/>
				</div>
				<div class="range"><em><input id="v1-price" type="range" min="-10" max="10" value=""/></em>
				<!--p><span>1</span><span id="v1-result">5</span><span>10</span></p--></div>
				
				<label>
					<strong>Or</strong>
					<input type="checkbox"/><em></em> Je Choisis UN % <input type="text" name="choisis"/>
				</label>
				<button type="button" data-dismiss="modal" class="saveBtn">Valider</button>
				</form>
			</div>													
		</div>
	</div>
</div>
<!-- Chassimo Modal -->


<!-- Modal suivi > Annonce -->
<div id="suiviannonce" class="modal fade" role="dialog">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-body">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<iframe id="webviewiframe" src="https://www.leboncoin.fr/ventes_immobilieres/1083816591.htm/" seamless="" width="100%" height="400"></iframe>	
			</div>
		</div>
	</div>
</div>													
<!-- Modal Suivi > Suivi-->
<div id="suivisuivi" class="modal fade" role="dialog">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-body">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6 datefield_box">
					<div class="Report_boX">
						<ul>
							<li>03/08/2018</li>
							<li>NRP <i class="fa fa-pencil"></i></li>
							<li>05/08/2018</li>
							<li>Message <i class="fa fa-pencil"></i></li>
						</ul>
					</div>
					<form class="offimo_suivi_form" action="" method="get">
						<input name="" type="date" value="" />
						<select name="">
						<option hidden>Statut v</option>
						<option>NRP</option>
						<option>Message</option>
						<option>Refus</option>
						<option>RDV</option>
						<option>A rappeler</option>
						</select>
						<button class="Ajouter_btn"><i class="fa fa-plus-square"></i> Ajouter action</button>
					</form>
				</div>
				<div class="col-xs-6 col-sm-6 col-md-6 col-lg-6 note_box">
					<h3><span>Bloc note</span></h3>
					<table width="100%" border="0" cellspacing="10" cellpadding="0">
					  <tr>
						<td>&nbsp;</td>
					  </tr>
					  <tr>
						<td>&nbsp;</td>
					  </tr>
					  <tr>
						<td>&nbsp;</td>
					  </tr>
					  <tr>
						<td>&nbsp;</td>
					  </tr>
					  <tr>
						<td>&nbsp;</td>
					  </tr>
					</table>

				</div>
			</div>
		</div>
	</div>
</div>												
<!-- Comparimo > Mes annonces VS offrimo > Accrocher -->

<!-- Observimo > Prospectimo > Majbals > Voir Start -->
<div class="modal fade" id="maison-box" role="dialog">
	<div class="modal-dialog modal-lg">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
			</div>
			<div class="modal-body">
				<div class="prospectimo_Data_wrapper">
					<table width="100%" border="0" cellspacing="10" cellpadding="0">
						<tbody>
							<tr class="turax-percent">
								<td colspan="2" bordercolor="#FFFFFF"></td>
								<td colspan="3">complétude de la BAL = 47%</td>
							</tr>
							<tr>
								<th width="14%">Photos</th>
								<th width="14%">Map&Plan</th>
								<th width="14%">Identifier</th>
								<th width="14%">Infos</th>
								<th width="14%">Découvrimo</th>
								<th width="14%">Potentiel</th>
							</tr>
							<tr>
								<td align="left" valign="top">
									<img src="images/11540.jpg">
									<div class="big-view">
										<a href="#">
											<img src="images/capture_icon.png">
										</a>
									</div>
									<ul class="popup-ul">
										<li><a href="#">Perso </a>
										</li>
										<li><a href="#">Street </a>
										</li>
										<li><a href="#">Pige </a>
										</li>
									</ul>
								</td>
								<td align="left" valign="top">
									<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d11379754.90301434!2d-6.929476864819009!3d45.86609808040356!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd54a02933785731%3A0x6bfd3f96c747d9f7!2sFrance!5e0!3m2!1sen!2sin!4v1534584981505" width="100%" height="100" frameborder="0" style="border:0" allowfullscreen></iframe>
									<div class="big-view">
										<a href="#">
											<img src="images/capture_icon.png">
										</a>
									</div>
									<ul class="maison-map-list">
										<li><a href="#">Cadastre</a>
										</li>
										<li><a href="#">Google map</a>
										</li>
									</ul>
								</td>
								<td align="left" valign="top"></td>
								<td align="left" valign="top"></td>
								<td align="left" valign="top"></td>
								<td align="left" valign="top"></td>
							</tr>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</div>
</div>
<!-- Observimo > Prospectimo > Majbals > Voir Ends -->

<!-- Observimo > Prospectimo > Majbals > Suivi Starts -->
<div class="modal fade" id="maison-box-Suivi" role="dialog">
	<div class="modal-dialog modal-md">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
			</div>
			<div class="modal-body">
				<div class="Suivi-popup-left">
					<div class="suivi-box">
						<ul>
							<li class="datepicker-maison">
								<input name="" value="10/08/2018" type="date" />
							</li>
							<li>Potentiel</li>
						</ul>
					</div>
					<div class="suivi-box">
						<ul>
							<li class="datepicker-maison">
								<input type="date" value="DD/MM/YY" id="dt" onchange="mydate1();" />
								<input type="text" id="ndt"  onclick="mydate();" hidden />
							</li>
							<li>Découvrimo</li>
						</ul>
					</div>
					<div class="suivi-boxdropdown">
						<div class="dropdown">
							<button type="button" data-toggle="dropdown"><i class="fa fa-plus"></i> Offrimo Date</button>
							<ul class="dropdown-menu">
								<li><a href="#">HTML</a>
								</li>
								<li><a href="#">CSS</a>
								</li>
								<li><a href="#">JavaScript</a>
								</li>
							</ul>
						</div>
					</div>
				</div>
				<div class="Suivi-popup-right">
					<h4><i class="fa fa-file"></i>Bloc note <span>15/08/2018</span></h4> 
					<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
				</div>
			</div>
		</div>
	</div>
</div>
<script>
function mydate() {
  //alert("");
  document.getElementById("dt").hidden = false;
  document.getElementById("ndt").hidden = true;
}

function mydate1() {
  d = new Date(document.getElementById("dt").value);
  dt = d.getDate();
  mn = d.getMonth();
  mn++;
  yy = d.getFullYear();
  document.getElementById("ndt").value = dt + "/" + mn + "/" + yy
  document.getElementById("ndt").hidden = false;
  document.getElementById("dt").hidden = true;
}
</script>
<!-- Observimo > Prospectimo > Majbals > Suivi Ends -->

<!-- Observimo > Prospectimo > Apporteur Affaires Ajouter une indication Ends -->
<!--<div class="Apporteur_Affaires_Ajouter">
	<div class="modal fade" id="apporteur-Ajouter-List" role="dialog">
		<div class="modal-dialog modal-md">
			<div class="modal-content">
				<div class="modal-body">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<div class="prospectimo_filter_box p-filter-box">
						<div class="filter">
						  <form class="filter_form" action="#" method="post">
							<ul>
							  <li>Filtre :</li>
							  <li>
								<input class="first_intp" name="" placeholder="Adress" type="text">
							  </li>
							  <li>
								<input name="" placeholder=" Mot-clé(s)" type="text">
							  </li>
							  <li>
								<select name="">
								  <option>Type</option>
								  <option>Type1</option>
								  <option>Type2</option>
								</select>
							  </li>
							  <li class="miN_Box">
								<input name="" placeholder="Min" type="text">
							  </li>
							  <li class="miN_Box">
								<input name="" placeholder="Max" type="text">
							  </li>
							  <li class="euros_sembleBoX">
								<span>€</span>
							  </li>
							</ul>
						  </form>
						</div>
					</div>
					<div class="prospectimo_Data_wrapper">
						<div class="majbals-container">
							<div class="majbals-right">
								<div class="col-md-6 col-sm-6 col-xs-12 majbals-box-1 border-right">
									<div class="col-xs-12 majbals-val">
										<ul>
											<li><a href="#maison-box" data-toggle="modal" data-backdrop="true"><i class="fa fa-eye"></i> Voir</a>
											</li>
											<li><a><i class="green-btn fa fa-circle"></i> Active</a>
											</li>
										</ul>
									</div>
									<div class="col-xs-12 Prospectimo_majbal">
										<div id="maison8pieces" class="carousel slide" data-ride="carousel">
											<div class="carousel-inner">
												<div class="carousel-caption">Maison 4Pièces
													<br>41 aveue du lac
													<br>74140 DOUVAINE</div>
												<div class="item active" style="background:url(images/offrimo1.png)"></div>
												<div class="item" style="background:url(images/offrimo2.png)"></div>
											</div>
											<a class="left carousel-control" href="#maison8pieces" data-slide="prev"> <span class="glyphicon glyphicon-chevron-left"></span>  <span class="sr-only">Previous</span> 
											</a>
											<a class="right carousel-control" href="#maison8pieces" data-slide="next"> <span class="glyphicon glyphicon-chevron-right"></span>  <span class="sr-only">Next</span> 
											</a>
										</div>
									</div>
									<div class="col-xs-12 maison-bottom-list">
										<ul>
											<li><a href="#">Identifier </a>
											</li>
											<li><a href="#">Infos</a>
											</li>
											<li><a href="#">Découvrimo</a>
											</li>
											<li><a href="#">Potentiel</a>
											</li>
											<li><a href="#maison-box-Suivi" data-toggle="modal" data-backdrop="true">Suivi</a></li>
										</ul>
									</div>
								</div>
								<div class="col-md-6 col-sm-6 col-xs-12 majbals-box-1 border-bottom">
									<div class="col-xs-12 majbals-val">
										<ul>
											<li><a href="#maison-box" data-toggle="modal"  data-backdrop="true"><i class="fa fa-eye"></i> Voir</a>
											</li>
											<li><a><i class=" fa fa-circle"></i> Active</a>
											</li>
										</ul>
									</div>
									<div class="col-xs-12">
										<img src="images/mailbox-full.png" class="img-responsive center-block" alt="mailbox">
									</div>
								</div>
								<div class="col-md-6 col-sm-6 col-xs-12 majbals-box-1 border-right">
									<div class="col-xs-12 majbals-val">
										<ul>
											<li><a href="#maison-box" data-toggle="modal"  data-backdrop="true"><i class="fa fa-eye"></i> Voir</a>
											</li>
											<li><a href="#"><i class="fa fa-circle"></i> Active</a>
											</li>
										</ul>
									</div>
									<div class="col-xs-12">
										<img src="images/mailbox-full.png" class="img-responsive center-block" alt="mailbox">
									</div>
								</div>
								<div class="col-md-6 col-sm-6 col-xs-12 majbals-box-1">
									<div class="col-xs-12 majbals-val">
										<ul>
											<li><a href="#maison-box" data-toggle="modal"  data-backdrop="true"><i class="fa fa-eye"></i> Voir</a>
											</li>
											<li><a><i class="green-btn fa fa-circle"></i> Active</a>
											</li>
										</ul>
									</div>
									<div class="col-xs-12 Prospectimo_majbal_2">
										<div id="maison7pieces2" class="carousel slide" data-ride="carousel">
											<div class="carousel-inner">
												<div class="carousel-caption">appartement/terrain</div>
												<div class="item active" style="background:url(images/map1.jpg)"></div>
												<div class="item" style="background:url(images/pic4.png)"></div>
											</div>
											<a class="left carousel-control" href="#maison7pieces2" data-slide="prev"> <span class="glyphicon glyphicon-chevron-left"></span>  <span class="sr-only">Previous</span> 
											</a>
											<a class="right carousel-control" href="#maison7pieces2" data-slide="next"> <span class="glyphicon glyphicon-chevron-right"></span>  <span class="sr-only">Next</span> 
											</a>
										</div>
									</div>									
									<div class="col-xs-12 maison-bottom-list">
										<ul>
											<li><a href="#">Identifier </a>
											</li>
											<li><a href="#">Infos</a>
											</li>
											<li><a href="#">Découvrimo</a>
											</li>
											<li><a href="#">Potentiel</a>
											</li>
											<li><a href="#maison-box-Suivi" data-toggle="modal" data-backdrop="true">Suivi</a></li>
										</ul>
									</div>
								</div>
							</div>
						</div>
					</div>		
				</div>
			</div>
		</div>
	</div>
</div>-->
<div class="Apporteur_Affaires_Ajouter">
	<div class="modal fade" id="apporteur-Ajouter-List" role="dialog">
		<div class="modal-dialog modal-md">
			<div class="modal-content">
				<div class="modal-body">
					<button type="button" class="close" data-dismiss="modal">&times;</button>					
					<div class="prospectimo_Data_wrapper">
						<div class="col-xs-12 col-sm-6 col-md-6 col-sm-6" style="padding-left:0;">
						<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d11379754.90301434!2d-6.929476864819009!3d45.86609808040356!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd54a02933785731%3A0x6bfd3f96c747d9f7!2sFrance!5e0!3m2!1sen!2sin!4v1534584981505" width="100%" height="464" frameborder="0" style="border:0" allowfullscreen></iframe>	
						</div>
						<div class="col-xs-12 col-sm-6 col-md-6 col-sm-6 Apporteur_Affaires_Right">
							<p class="Apporteur_Date_Box"><strong>Date indication:</strong> 20/Now/2018</p>
							<p class="Apporteur_srch_Box"><input name="" placeholder="Adresse du bien indiqué" type="text"><button></button></p>
							<p class="Apporteur_Slt_Box">
								<select name="">
									<option hidden>Type BA</option>
									<option>Maison</option>
									<option>Appartement</option>
									<option>Terrain</option>
									<option>Commerce</option>
									<option>Autre</option>
								</select>
							</p>
							<div class="col-xs-12 col-sm-6 col-md-6 col-sm-6 Apporteur_Cont_Box" style="padding-left:0; border:none;">
								<h3>Contact Apporteur</h3>
								<select name="">
									<option hidden>Occupant</option>
									<option>Proprietaire</option>
									<option>Locataire</option>
								</select>
								<input name="" placeholder="Adresse" type="text">
								<input name="" placeholder="Contact Occupant" type="text">
							</div>
							<div class="col-xs-12 col-sm-6 col-md-6 col-sm-6 Apporteur_Cont_Box" style="padding-right:0;">
								<h3>Contact Occupant BAL</h3>
								<select name="">
									<option hidden>Occupant</option>
									<option>Proprietaire</option>
									<option>Locataire</option>
								</select>
								<input name="" placeholder="Adresse" type="text">
								<input name="" placeholder="Contact Propriétaire" type="text">
								<input name="" placeholder="Contact Locataire" type="text">
							</div>						
						</div>
					</div>		
				</div>
			</div>
		</div>
	</div>
</div>	





<!-- Observimo Add Member Form -->  
  <div id="Observimo-Add-Member" class="modal fade" role="dialog">
    <div class="modal-dialog">       
      <div class="modal-content">
        <div class="login_form">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <div class="clr"></div>
          <h3>Member</h3>
          <form action="" method="get">
            <input  class="user_intp" name="" placeholder="First Name" type="text">
            <input  class="user_intp" name="" placeholder="Last Name" type="text">
            <input  class="email_intp" name="" placeholder="Email Address" type="text">
            <input  class="email_intp" name="" placeholder="Phone" type="text">
            <div class="clr"></div>
            <h5>Date of Birth</h5>
            <div class="col-lg-4 col-md-4 col-sm-4">
              <select name="" class="">
                <option hidden value="Day">Day</option>
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
                <option value="4">4</option>
                <option value="5">5</option>
                <option value="6">6</option>
                <option value="7">7</option>
                <option value="8">8</option>
                <option value="9">9</option>
                <option value="10">10</option>
                <option value="11">11</option>
                <option value="12">12</option>
                <option value="13">13</option>
                <option value="14">14</option>
                <option value="15">15</option>
                <option value="16">16</option>
                <option value="17">17</option>
                <option value="18">18</option>
                <option value="19">19</option>
                <option value="20">20</option>
                <option value="21">21</option>
                <option value="22">22</option>
                <option value="23">23</option>
                <option value="24">24</option>
                <option value="25">25</option>
                <option value="26">26</option>
                <option value="27">27</option>
                <option value="28">28</option>
                <option value="29">29</option>
                <option value="30">30</option>
                <option value="31">31</option>
              </select>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-4">
              <select name="" class="">
                <option hidden value="">Month</option>
                <option value="1">January</option>
                <option value="2">February</option>
                <option value="3">March</option>
                <option value="4">April</option>
                <option value="5">May</option>
                <option value="6">June</option>
                <option value="7">July</option>
                <option value="8">August</option>
                <option value="9">September</option>
                <option value="10">October</option>
                <option value="11">November</option>
                <option value="12">December</option>
              </select>
            </div>
            <div class="col-lg-4 col-md-4 col-sm-4">
              <select name="" class="">
                <option hidden value="Year">Year</option>
                <option value="2018">2018</option>
                <option value="2017">2017</option>
                <option value="2016">2016</option>
                <option value="2015">2015</option>
                <option value="2014">2014</option>
                <option value="2013">2013</option>
                <option value="2012">2012</option>
                <option value="2011">2011</option>
                <option value="2010">2010</option>
                <option value="2009">2009</option>
                <option value="2008">2008</option>
                <option value="2007">2007</option>
                <option value="2006">2006</option>
                <option value="2005">2005</option>
                <option value="2004">2004</option>
                <option value="2003">2003</option>
                <option value="2002">2002</option>
                <option value="2001">2001</option>
                <option value="2000">2000</option>
                <option value="1999">1999</option>
                <option value="1998">1998</option>
                <option value="1997">1997</option>
                <option value="1996">1996</option>
                <option value="1995">1995</option>
                <option value="1994">1994</option>
                <option value="1993">1993</option>
                <option value="1992">1992</option>
                <option value="1991">1991</option>
              </select>
            </div>
            <input  class="email_intp" name="" placeholder="Subject" type="text">
            <div class="login_btn">
              <button data-toggle="modal" data-target="#myModal" >Member</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>

<!-- Observimo Create New Region Form -->  
<div id="Observimo-Create-New-Region" class="modal fade" role="dialog">
    <div class="modal-dialog"> <!-- Modal content-->
      
      <div class="modal-content">
        <div class="login_form">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <div class="clr"></div>
          <h3>Créer une nouvelle Région</h3>
          <form action="" method="get">
            <select name="" class="">
              <option hidden value="">Choisissez une région</option>
              <option value="1">Rhône-Alpes</option>
              <option value="2">Auvergne</option>
              <option value="3">Languedoc-Roussillon....</option>
            </select>           
            <div class="clr"></div>
            <div class="login_btn">
              <button data-toggle="modal" data-target="#myModal" >Créer une nouvelle Région</button>
            </div>
          </form>
        </div>
      </div>
    </div>
</div>

<!-- Observimo > Prospectimo > Identifier -->  
<div id="maison-box-Identifier" class="modal fade" role="dialog">
    <div class="modal-dialog"> 
      <div class="modal-content">
        <div class="Identifier_form_Box">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <div class="clr"></div>
          <h3>Identifier</h3>
          <form action="" method="get">
			<div class="col-xs-12 col-sm-6 col-md-6col-lg-6">
				<label>Adresse</label>
				<input type="text" name="" />
			</div>
			<div class="col-xs-12 col-sm-6 col-md-6col-lg-6">
				<label>Numéro de la BAL</label>
				<select name="" class="">
				  <option value="">Néant</option>
				  <option value="">N°</option>
				</select> 
			</div>  
			<div class="col-xs-12 col-sm-6 col-md-6col-lg-6">
				<label>Statut juridique </label>
				<select name="" class="">
				  <option value="">Cpropriété</option>
				  <option value="">Lotissement</option>
				  <option value="">Hors Lotissement</option>
				</select> 
			</div>  
			<div class="col-xs-12 col-sm-6 col-md-6col-lg-6">
				<label>N° Parcelle</label>
				<input type="text" name="" />
			</div>
			<div class="col-xs-12 col-sm-6 col-md-6col-lg-6">
				<label>Section de la Parcelle</label>
				<input type="text" name="" />
			</div>
			<div class="col-xs-12 col-sm-6 col-md-6col-lg-6">
				<label>Zone de la Parcelle</label>
				<input type="text" name="" />
			</div>
			<div class="col-xs-12 col-sm-6 col-md-6col-lg-6">
				<label>Superficie de la Parcelle</label>
				<input type="text" name="" />
			</div>        
            <div class="clr"></div>
          </form>
        </div>
      </div>
    </div>
</div>

<!-- Observimo > Prospectimo > Infos -->  
<div id="maison-box-Infos" class="modal fade" role="dialog">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="Identifier_form_Box">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <div class="clr"></div>
          <h3>Infos</h3>
          <form action="" method="get">
			<div class="col-xs-12 col-sm-6 col-md-6col-lg-6">
				<label>Style</label>
				<select name="" class="">
				  <option value="">Contemporain</option>
				  <option value="">Traditionel</option>
				  <option value="">Vielles pierres</option>
				  <option value="">Ossature Bois</option>
				</select> 
			</div>
			<div class="col-xs-12 col-sm-6 col-md-6col-lg-6">
				<label>Plain pieds </label>
				<select name="" class="">
				  <option value="">O</option>
				  <option value="">N</option>
				</select> 
			</div>  
			<div class="col-xs-12 col-sm-6 col-md-6col-lg-6">
				<label>Date construction</label>
				<input type="date" name="" />
			</div> 
			<div class="col-xs-12 col-sm-6 col-md-6col-lg-6">
				<label>Date dernier achat</label>
				<input type="date" name="" />
			</div>  
			<div class="col-xs-12 col-sm-6 col-md-6col-lg-6">
				<label>Occupant</label>
				<select name="" class="">
				  <option value="">Proprietaire</option>
				  <option value="">Locataire</option>
				</select>
			</div>
			<div class="col-xs-12 col-sm-6 col-md-6col-lg-6">
				<label>Habitation</label>
				<select name="" class="">
				  <option value="">RP</option>
				  <option value="">RS</option>
				</select>
			</div>
			<div class="col-xs-12 col-sm-6 col-md-6col-lg-6">
				<label>État extérieur de la maison</label>
				<select name="" class="">
				  <option value="">TB</option>
				  <option value="">B</option>
				  <option value="">Moyen</option>
				  <option value="">Mauvais</option>
				</select>
			</div>  
			<div class="col-xs-12 col-sm-6 col-md-6col-lg-6">
				<label>Semble inoccupée</label>
				<select name="" class="">
				  <option value="">O</option>
				  <option value="">N</option>
				</select>
			</div> 
			<div class="col-xs-12 col-sm-6 col-md-6col-lg-6">
				<label>Semble abandonnée</label>
				<select name="" class="">
				  <option value="">O</option>
				  <option value="">N</option>
				</select>
			</div>     
			<div class="col-xs-12 col-sm-6 col-md-6col-lg-6">
				<label class="Contact_Occupant_link">
				<a href="#Infos-contact_occupant" data-toggle="modal" data-dismiss="modal">Contact Occupant</a></label>				
			</div>     
            <div class="clr"></div>
          </form>
        </div>
      </div>
    </div>
</div>

<!-- Observimo > Prospectimo > Infos -->  
<div id="Infos-contact_occupant" class="modal fade" role="dialog">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="Identifier_form_Box">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <div class="clr"></div>
          <h3>Contact Occupant </h3>
          <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
        </div>
      </div>
    </div>
</div>



<div id="sakTest" class="modal fade" role="dialog">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="Identifier_form_Box">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <div class="clr"></div>
          <h3>Contact Occupant </h3>
          <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
        </div>
      </div>
    </div>
</div>


<!-- Modal -->
<div id="VousPouvezImprimer" class="modal fade" role="dialog">
	<div class="modal-dialog">
		<div class="modal-content">	
			<button type="button" class="close" data-dismiss="modal">&times;</button>
			<div class="modal-body">
				<div class="banners" style="background-image: url(images/research-motor-img.png); background-position:bottom;">
					<div class="Banners_TxT">
						<h5>"Vous pouvez imprimer un listing<br> Team par critères"
						</h5> 
					</div>	
				</div>
				<div class="filter">
					<form action="#" method="post">
						<ul>
							<li>Filtre :</li>
							<li>
								<select>
									<option hidden>Ordre Alphabétique</option>
									<option value="">A to Z</option>
									<option value="">Z to A</option>
								</select>
							</li>
							<li>
								<select>
									<option hidden>Par rôle</option>
									<option value="">Développeur</option>
									<option value="">Learder</option>
									<option value="">Manager</option>
									<option value="">Home conseiller</option>
								</select>
							</li>
							<li>
								<select>
									<option hidden>Par zone</option>
									<option value="">Fance</option>
								</select>
							</li>
							<li>
								<select>
									<option hidden>Région </option>
									<option value="">Toutes</option>
									<option value="">Rhone alpes</option>
								</select>
							</li>
							<li>
								<select>
									<option hidden>ZAC</option>
									<option value="">Toutes</option>
									<option value="">Haute Savoie</option>
								</select>
							</li>
							<li>
								<select>
									<option hidden>Territoires</option>
									<option value="">Tous</option>
									<option value="">Douvaine et environs</option>
								</select>
							</li>
						</ul>
					</form>
				</div>	
				<div class="VousPouvezList" style="padding-top:10px;float:left;width:100%; height:600px;overflow:auto;">
					<div style="margin-top:20px;float: left;width: 100%;border-bottom: 1px solid #ccc;padding-bottom:10px;">
						<div style="background:url(images/pro1.png);padding:0;background-repeat:no-repeat;float:left; width:26%; min-height:170px;background-size:cover;"></div>
						<div style="width:70%;float:right;">
							<p style="margin-bottom:4px"><strong style="width:180px; display:inline-block; font-weight:500;">Name:</strong> Alex</p>
							<p style="margin-bottom:4px"><strong style="width:180px; display:inline-block; font-weight:500;">Pays:</strong> France</p>
							<p style="margin-bottom:4px"><strong style="width:180px; display:inline-block; font-weight:500;">Région:</strong> Rhone Alpes</p>
							<p style="margin-bottom:4px"><strong style="width:180px; display:inline-block; font-weight:500;">ZAC:</strong> Haute Savoie</p>
							<p style="margin-bottom:4px"><strong style="width:180px; display:inline-block; font-weight:500;">Territoire:</strong> Douvaine et environs</p>
							<p style="margin-bottom:4px"><strong style="width:180px; display:inline-block; font-weight:500;">Secteur(s) prioritaire(s): </strong> Excenevex-Messery</p>
						</div>						
					</div>
					<div style="margin-top:20px;float: left;width: 100%;border-bottom: 1px solid #ccc;padding-bottom:10px;">
						<div style="background:url(images/pro1.png);padding:0;background-repeat:no-repeat;float:left; width:26%; min-height:170px;background-size:cover;"></div>
						<div style="width:70%;float:right;">
							<p style="margin-bottom:4px"><strong style="width:180px; display:inline-block; font-weight:500;">Name:</strong> Alex</p>
							<p style="margin-bottom:4px"><strong style="width:180px; display:inline-block; font-weight:500;">Pays:</strong> France</p>
							<p style="margin-bottom:4px"><strong style="width:180px; display:inline-block; font-weight:500;">Région:</strong> Rhone Alpes</p>
							<p style="margin-bottom:4px"><strong style="width:180px; display:inline-block; font-weight:500;">ZAC:</strong> Haute Savoie</p>
							<p style="margin-bottom:4px"><strong style="width:180px; display:inline-block; font-weight:500;">Territoire:</strong> Douvaine et environs</p>
							<p style="margin-bottom:4px"><strong style="width:180px; display:inline-block; font-weight:500;">Secteur(s) prioritaire(s): </strong> Excenevex-Messery</p>
						</div>						
					</div>
					<div style="margin-top:20px;float: left;width: 100%;border-bottom: 1px solid #ccc;padding-bottom:10px;">
						<div style="background:url(images/pro1.png);padding:0;background-repeat:no-repeat;float:left; width:26%; min-height:170px;background-size:cover;"></div>
						<div style="width:70%;float:right;">
							<p style="margin-bottom:4px"><strong style="width:180px; display:inline-block; font-weight:500;">Name:</strong> Alex</p>
							<p style="margin-bottom:4px"><strong style="width:180px; display:inline-block; font-weight:500;">Pays:</strong> France</p>
							<p style="margin-bottom:4px"><strong style="width:180px; display:inline-block; font-weight:500;">Région:</strong> Rhone Alpes</p>
							<p style="margin-bottom:4px"><strong style="width:180px; display:inline-block; font-weight:500;">ZAC:</strong> Haute Savoie</p>
							<p style="margin-bottom:4px"><strong style="width:180px; display:inline-block; font-weight:500;">Territoire:</strong> Douvaine et environs</p>
							<p style="margin-bottom:4px"><strong style="width:180px; display:inline-block; font-weight:500;">Secteur(s) prioritaire(s): </strong> Excenevex-Messery</p>
						</div>						
					</div>
				</div>
			</div>
		</div>			
	</div>
</div><!-- Seller New Offer --><div id="SellreMyoffer" class="modal fade" role="dialog">	<div class="modal-dialog">		<div class="modal-content">			<div class="modal-body">				<button type="button" class="close" data-dismiss="modal">&times;</button>					<div class="SellerTxtWrapper">					<!--<div class="SellerNewOffer"><a href="javascript:void(0)"><i class="fa fa-plus-circle"></i> Nouvelle Offre</a></div>-->					<form action="">							<div class="row SellreMyofferWrapper">											<div class="col-xs-12 col-sm-12 col-md-4 col-lg-5 SellerMapBox">								<div class="MapBox">									<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d5662657.196432931!2d-2.4342999142223554!3d46.131440726910405!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd54a02933785731%3A0x6bfd3f96c747d9f7!2sFrance!5e0!3m2!1sen!2sin!4v1583925246079!5m2!1sen!2sin" width="100%" height="400" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>								</div>							</div>							<div class="col-xs-12 col-sm-12 col-md-8 col-lg-7">								<div class="SituationBox">									<h6>Situation</h6>									<div class="form-group">										<input class="tenpBox" type="text" placeholder="N°">										<input class="AddressBox" type="text" placeholder="Adresse">									</div>									<div class="form-group">										<input class="postCode" type="text" placeholder="Code postale">										<input class="CommuneBox" type="text" placeholder="Commune">									</div>									<div class="clearfix"></div>									<h6>Critères Primaires</h6>									<div class="form-group">										<label class="LblText First">Type:</label>										<label id="SellerHouse" class="cusCheckbox">											<input type="radio" checked="checked" name="radio">											<span class="checkmark"></span>											<b>Maison</b>										</label>										<label id="SellerApartment" class="cusCheckbox">											<input type="radio" name="radio">											<span class="checkmark"></span>											<b>Appartement</b>										</label>									</div>									<div class="PrimairesBoxs">										<div class="form-group">											<label class="LblText">Surface:</label>											<input class="form-control" type="text"><span>m²</span>										</div>										<div class="form-group">											<label class="LblText">Nombre de chambre(s):</label>											<input class="form-control" type="text">										</div>										<div class="form-group">											<label class="LblText">Terrain:</label>											<input class="form-control" type="text"><span>m²</span>										</div>										<div class="form-group">											<label class="LblText">Prix:</label>											<input class="form-control" type="text"><span>€</span>										</div>									</div>								</div>							</div>							<div class="col-xs-12 col-lg-12 SecondaryCriteria">													<h6>Critères Secondaires</h6>								<div id="SellerSelectHouse" class="form-group">									<label class="LblText First">Type:</label>									<label class="cusCheckbox">										<input type="radio" checked="checked" name="Second">										<span class="checkmark"></span>										<b>Individuelle</b>									</label>									<label class="cusCheckbox">										<input type="radio" name="Second">										<span class="checkmark"></span>										<b>Mitoyenne</b>									</label>									<label class="cusCheckbox">										<input type="radio" name="Second">										<span class="checkmark"></span>										<b>Plein-pieds</b>									</label>									<label class="cusCheckbox">										<input type="radio" name="Second">										<span class="checkmark"></span>										<b>Village</b>									</label>									<em>*</em>								</div>																<div id="SellerSelectApartment" class="form-group" style="display:none;">									<label class="LblText First">Type:</label>									<label class="cusCheckbox">										<input type="radio" checked="checked" name="appartement">										<span class="checkmark"></span>										<b>Rez-de-chaussée</b>									</label>									<label class="cusCheckbox">										<input type="radio" name="appartement">										<span class="checkmark"></span>										<b>Dernier étage</b>									</label>									<label class="cusCheckbox">										<input type="radio" name="appartement">										<span class="checkmark"></span>										<b>Attique</b>									</label>									<label class="cusCheckbox">										<input type="radio" name="appartement">										<span class="checkmark"></span>										<b>Loft</b>									</label>									<label class="cusCheckbox">										<input type="radio" name="appartement">										<span class="checkmark"></span>										<b>Duplex</b>									</label>									<em>*</em>													</div>								<div class="form-group">									<label class="LblText First">Les plus:</label>									<label class="cusCheckbox">										<input type="radio" name="plus">										<span class="checkmark"></span>										<b>Cave</b>									</label>									<label class="cusCheckbox">										<input type="radio" name="plus">										<span class="checkmark"></span>										<b>Garage</b>									</label>									<label class="cusCheckbox">										<input type="radio" name="plus">										<span class="checkmark"></span>										<b>Parking</b>									</label>									<label class="cusCheckbox">										<input type="radio" name="plus">										<span class="checkmark"></span>										<b>Sous-sol</b>									</label>									<label class="cusCheckbox">										<input type="radio" name="plus">										<span class="checkmark"></span>										<b>Combles</b>									</label>									<label class="cusCheckbox">										<input type="radio" name="plus">										<span class="checkmark"></span>										<b>Piscine</b>									</label>								</div>								<div class="form-group">									<label class="LblText First">Environnement:</label>									<select class="selectView">										<option>Vue +</option>									</select>									<label class="cusCheckbox">										<input type="radio" name="environnement">										<span class="checkmark"></span>										<b>Calme</b>									</label>									<label class="cusCheckbox">										<input type="radio" name="environnement">										<span class="checkmark"></span>										<b>Campagne</b>									</label>									<label class="cusCheckbox">										<input type="radio" name="environnement">										<span class="checkmark"></span>										<b>Centre</b>									</label>									<label class="cusCheckbox">										<input type="radio" name="environnement">										<span class="checkmark"></span>										<b>Ville</b>									</label>								</div>								<div class="form-group">									<label class="LblText First">Style:</label>									<label class="cusCheckbox">										<input type="radio" name="style">										<span class="checkmark"></span>										<b>Moderne</b>									</label>									<label class="cusCheckbox">										<input type="radio" name="style">										<span class="checkmark"></span>										<b>Ancien</b>									</label>									<label class="cusCheckbox">										<input type="radio" name="style">										<span class="checkmark"></span>										<b>Neuf</b>									</label>									<label class="cusCheckbox">										<input type="radio" name="style">										<span class="checkmark"></span>										<b>Contemporain</b>									</label>								</div>								<div class="form-group">									<label class="LblText First">Etat général:</label>									<label class="cusCheckbox">										<input type="radio" name="etat">										<span class="checkmark"></span>										<b>Rien à faire</b>									</label>									<label class="cusCheckbox">										<input type="radio" name="etat">										<span class="checkmark"></span>										<b>A Rafraichir</b>									</label>									<label class="cusCheckbox">										<input type="radio" name="etat">										<span class="checkmark"></span>										<b>A renover</b>									</label>								</div>								<h6>Description:</h6>								<div class="form-group">									<label>Décrivez nous votre bien</label>									<textarea class="form-control" name="" cols="" rows="5" placeholder="Exemple : Maison contemporaine, de 145m2 sur 950m2, cuisine ouverte sur séjour, cheminée, terrasses, piscines, 5 chambres, 1 suite parentale, vue lac, abri voitures, garage, terrain clos et arboré, calme, proche du centre."></textarea>								</div>							</div>						</div>					</form>				</div>			</div>		</div>	</div></div><!-- Buyer My Request --><div id="BuyerMyRequest" class="modal fade" role="dialog">	<div class="modal-dialog">		<div class="modal-content">			<div class="modal-body">				<button type="button" class="close" data-dismiss="modal">&times;</button>					<div class="SellerTxtWrapper">										<form action="">							<div class="row SellreMyofferWrapper">									<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">								<div class="SituationBox BuyerLeft">									<h3>Mes Besoins Primaires</h3>									<div class="form-group">										<label class="LblText First">Type:</label>										<label id="BuyerHouse" class="cusCheckbox">											<input type="radio" name="radio">											<span class="checkmark"></span>											<b>Maison</b>										</label>										<label id="BuyerApartment" class="cusCheckbox">											<input type="radio" checked="checked" name="radio">											<span class="checkmark"></span>											<b>Appartement</b>										</label>									</div>									<div class="PrimairesBoxs MyRequestInpt">										<div class="form-group">											<label class="LblText">Surface:</label>											<input class="form-control" placeholder="min" type="text">											<input class="form-control" placeholder="max" type="text">										</div>										<div class="form-group">											<label class="LblText">Nombre de chambre(s):</label>											<input class="form-control" placeholder="min" type="text">											<input class="form-control" placeholder="max" type="text">										</div>										<div class="form-group">											<label class="LblText">Terrain:</label>											<input class="form-control" placeholder="min" type="text">											<input class="form-control" placeholder="max" type="text">										</div>									</div>																		<div class="form-group">										<label class="LblText">Budget:</label>													<div class="fillter">											<section class="range-slider" id="facet-price-range-slider" data-options='{"output":{"prefix":""},"maxSymbol":""}'>												<input name="range-1" value="500000€" min="0" max="1000000" step="1" type="range">											</section>										</div> 									</div>									<div class="form-group AddBoxs">										<label class="LblText">Commune(s):</label>											<input class="form-control" type="text" placeholder="Villes, Communes...."> <button type="button"><i class="fa fa-plus"></i> Ajouter</button>									</div>									<div class="form-group">										<label class="cusCheckbox">											<input type="radio" name="commune">											<span class="checkmark"></span>											<b>Messery</b>										</label>																			<label class="cusCheckbox">											<input type="radio" name="commune">											<span class="checkmark"></span>											<b>Douvaine</b>										</label>																			<label class="cusCheckbox">											<input type="radio" name="commune">											<span class="checkmark"></span>											<b>Chens-sur-Léman</b>										</label>										</div>								</div>							</div>									<div class="col-xs-12 col-sm-12 col-md-6 col-lg-6">								<div class="SecondaryCriteria">									<h3>Mes Besoins Secondaires</h3>																	<div id="SelectHouse" class="form-group" style="display:none;">									<label class="LblText First">Type:</label>									<label class="cusCheckbox">										<input type="radio" checked="checked" name="house">										<span class="checkmark"></span>										<b>Tous</b>									</label>									<label class="cusCheckbox">										<input type="radio" name="house">										<span class="checkmark"></span>										<b>Individuelle</b>									</label>									<label class="cusCheckbox">										<input type="radio" name="house">										<span class="checkmark"></span>										<b>Mitoyenne</b>									</label>									<label class="cusCheckbox">										<input type="radio" name="house">										<span class="checkmark"></span>										<b>plein_pieds</b>									</label>								</div>																<div id="SelectApartment" class="form-group">									<label class="LblText First">Type:</label>									<label class="cusCheckbox">										<input type="radio" checked="checked" name="apartment">										<span class="checkmark"></span>										<b>Tous</b>									</label>									<label class="cusCheckbox">										<input type="radio" name="apartment">										<span class="checkmark"></span>										<b>Rdc</b>									</label>									<label class="cusCheckbox">										<input type="radio" name="apartment">										<span class="checkmark"></span>										<b>Attique</b>									</label>									<label class="cusCheckbox">										<input type="radio" name="apartment">										<span class="checkmark"></span>										<b>Loft</b>									</label>									<label class="cusCheckbox">										<input type="radio" name="apartment">										<span class="checkmark"></span>										<b>Duplex</b>									</label>								</div>								<div class="form-group">									<label class="LblText First">Les plus:</label>									<label class="cusCheckbox">										<input type="radio" name="plus">										<span class="checkmark"></span>										<b>Cave</b>									</label>									<label class="cusCheckbox">										<input type="radio" name="plus">										<span class="checkmark"></span>										<b>Garage</b>									</label>									<label class="cusCheckbox">										<input type="radio" name="plus">										<span class="checkmark"></span>										<b>Parking</b>									</label>									<label class="cusCheckbox">										<input type="radio" name="plus">										<span class="checkmark"></span>										<b>Combles</b>									</label>									<label class="cusCheckbox">										<input type="radio" name="plus">										<span class="checkmark"></span>										<b>Sous-sol</b>									</label>								</div>								<div class="form-group">									<label class="LblText First">Environnement:</label>									<select class="selectView">										<option>Vue +</option>									</select>									<label class="cusCheckbox">										<input type="radio" name="environnement">										<span class="checkmark"></span>										<b>Calme</b>									</label>									<label class="cusCheckbox">										<input type="radio" name="environnement">										<span class="checkmark"></span>										<b>Ville</b>									</label>									<label class="cusCheckbox">										<input type="radio" name="environnement">										<span class="checkmark"></span>										<b>Centre</b>									</label>								</div>								<div class="form-group">									<label class="LblText First">Style:</label>									<label class="cusCheckbox">										<input type="radio" name="style">										<span class="checkmark"></span>										<b>Moderne</b>									</label>									<label class="cusCheckbox">										<input type="radio" name="style">										<span class="checkmark"></span>										<b>Ancien</b>									</label>									<label class="cusCheckbox">										<input type="radio" name="style">										<span class="checkmark"></span>										<b>Neuf</b>									</label>									<label class="cusCheckbox">										<input type="radio" name="style">										<span class="checkmark"></span>										<b>Contemporain</b>									</label>								</div>								<div class="form-group">									<label class="LblText First">Etat général:</label>									<label class="cusCheckbox">										<input type="radio" name="etat">										<span class="checkmark"></span>										<b>Rien à faire</b>									</label>									<label class="cusCheckbox">										<input type="radio" name="etat">										<span class="checkmark"></span>										<b>A Rafraichir</b>									</label>									<label class="cusCheckbox">										<input type="radio" name="etat">										<span class="checkmark"></span>										<b>A renover</b>									</label>								</div>								</div>							</div>							<div class="BuyerMiddleBoxs">															<div class="col-xs-12 col-sm-12 col-md-6 col-lg-7">									<h3>Mes Référents</h3>																		<div class="form-group AddBoxs">										<input class="form-control" type="text" placeholder="Adresse..."> <button type="button"><i class="fa fa-plus"></i> Ajouter</button>									</div>									<div class="MapBox">										<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d5662657.196432931!2d-2.4342999142223554!3d46.131440726910405!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd54a02933785731%3A0x6bfd3f96c747d9f7!2sFrance!5e0!3m2!1sen!2sin!4v1583925246079!5m2!1sen!2sin" width="100%" height="400" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>									</div>								</div>															<div class="col-xs-12 col-sm-12 col-md-6 col-lg-5">									<h3>Sélectionnez vos Référents</h3>									<div class="SelectReferentsBox">									    <div class="panel-group" id="faqAccordion">											<div class="panel panel-default ">												<div class="panel-heading accordion-toggle question-toggle collapsed" data-toggle="collapse" data-parent="#faqAccordion" data-target="#question0">													 <h4 class="panel-title">														<a href="#" class="ing">TRANSPORT</a> <i class="fa fa-chevron-down"></i><i class="fa fa-chevron-up"></i>													</h4>												</div>												<div id="question0" class="panel-collapse collapse" style="height: 0px;">													<div class="panel-body">														<ul>															<li>																<label class="ReferentsBox">Tout sélectionner / Tout désélectionner 																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>															</li>															<li>																<label class="ReferentsBox">Gare ferroviaire																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Tramway																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Station de taxi																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Vélib'																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Rer																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Arrêt bus																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Terminal de ferry																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Parking à vélo																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Location de vélo																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Aéroport																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Métro																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Parking																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Station service																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Autolib'																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>														</ul>													</div>												</div>											</div>											<div class="panel panel-default ">												<div class="panel-heading accordion-toggle collapsed question-toggle" data-toggle="collapse" data-parent="#faqAccordion" data-target="#question1">													 <h4 class="panel-title">														<a href="#" class="ing">COMMERCE ET SERVICE</a><i class="fa fa-chevron-down"></i><i class="fa fa-chevron-up"></i>													</h4>												</div>												<div id="question1" class="panel-collapse collapse" style="height: 0px;">													<div class="panel-body">														<ul>															<li>																<label class="ReferentsBox">Tout sélectionner / Tout désélectionner 																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>															</li>															<li>																<label class="ReferentsBox">Gare ferroviaire																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Tramway																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Station de taxi																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Vélib'																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Rer																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Arrêt bus																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Terminal de ferry																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Parking à vélo																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Location de vélo																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Aéroport																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Métro																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Parking																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Station service																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Autolib'																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>														</ul>													</div>												</div>											</div>											<div class="panel panel-default ">												<div class="panel-heading accordion-toggle collapsed question-toggle" data-toggle="collapse" data-parent="#faqAccordion" data-target="#question2">													 <h4 class="panel-title">														<a href="#" class="ing">LOISIRS</a><i class="fa fa-chevron-down"></i><i class="fa fa-chevron-up"></i>												  </h4>												</div>												<div id="question2" class="panel-collapse collapse" style="height: 0px;">													<div class="panel-body">														<ul>															<li>																<label class="ReferentsBox">Tout sélectionner / Tout désélectionner 																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>															</li>															<li>																<label class="ReferentsBox">Gare ferroviaire																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Tramway																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Station de taxi																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Vélib'																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Rer																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Arrêt bus																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Terminal de ferry																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Parking à vélo																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Location de vélo																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Aéroport																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Métro																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Parking																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Station service																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Autolib'																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>														</ul>													</div>												</div>											</div>											<div class="panel panel-default ">												<div class="panel-heading accordion-toggle collapsed question-toggle" data-toggle="collapse" data-parent="#faqAccordion" data-target="#question3">													 <h4 class="panel-title">														<a href="#" class="ing">EDUCATION</a><i class="fa fa-chevron-down"></i><i class="fa fa-chevron-up"></i>													</h4>												</div>												<div id="question3" class="panel-collapse collapse" style="height: 0px;">													<div class="panel-body">														<ul>															<li>																<label class="ReferentsBox">Tout sélectionner / Tout désélectionner 																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>															</li>															<li>																<label class="ReferentsBox">Gare ferroviaire																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Tramway																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Station de taxi																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Vélib'																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Rer																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Arrêt bus																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Terminal de ferry																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Parking à vélo																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Location de vélo																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Aéroport																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Métro																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Parking																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Station service																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Autolib'																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>														</ul>													</div>												</div>											</div>											<div class="panel panel-default ">												<div class="panel-heading accordion-toggle collapsed question-toggle" data-toggle="collapse" data-parent="#faqAccordion" data-target="#question4">													 <h4 class="panel-title">														<a href="#" class="ing">CULTURE</a><i class="fa fa-chevron-down"></i><i class="fa fa-chevron-up"></i>													</h4>												</div>												<div id="question4" class="panel-collapse collapse" style="height: 0px;">													<div class="panel-body">														<ul>															<li>																<label class="ReferentsBox">Tout sélectionner / Tout désélectionner 																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>															</li>															<li>																<label class="ReferentsBox">Gare ferroviaire																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Tramway																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Station de taxi																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Vélib'																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Rer																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Arrêt bus																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Terminal de ferry																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Parking à vélo																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Location de vélo																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Aéroport																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Métro																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Parking																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Station service																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Autolib'																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>														</ul>													</div>												</div>											</div>											<div class="panel panel-default ">												<div class="panel-heading accordion-toggle collapsed question-toggle" data-toggle="collapse" data-parent="#faqAccordion" data-target="#question5">													 <h4 class="panel-title">														<a href="#" class="ing">SANTÉ</a><i class="fa fa-chevron-down"></i><i class="fa fa-chevron-up"></i>													</h4>												</div>												<div id="question5" class="panel-collapse collapse" style="height: 0px;">													<div class="panel-body">														<ul>															<li>																<label class="ReferentsBox">Tout sélectionner / Tout désélectionner 																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>															</li>															<li>																<label class="ReferentsBox">Gare ferroviaire																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Tramway																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Station de taxi																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Vélib'																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Rer																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Arrêt bus																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Terminal de ferry																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Parking à vélo																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Location de vélo																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Aéroport																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Métro																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Parking																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Station service																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Autolib'																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>														</ul>													</div>												</div>											</div>											<div class="panel panel-default ">												<div class="panel-heading accordion-toggle collapsed question-toggle" data-toggle="collapse" data-parent="#faqAccordion" data-target="#question6">													 <h4 class="panel-title">														<a href="#" class="ing">PETITE ENFANCE</a><i class="fa fa-chevron-down"></i><i class="fa fa-chevron-up"></i>													</h4>												</div>												<div id="question6" class="panel-collapse collapse" style="height: 0px;">													<div class="panel-body">														<ul>															<li>																<label class="ReferentsBox">Tout sélectionner / Tout désélectionner 																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>															</li>															<li>																<label class="ReferentsBox">Gare ferroviaire																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Tramway																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Station de taxi																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Vélib'																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Rer																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Arrêt bus																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Terminal de ferry																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Parking à vélo																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Location de vélo																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Aéroport																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Métro																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Parking																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Station service																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>															<li>																<label class="ReferentsBox">Autolib'																	<input type="radio" name="commune">																	<span class="checkmark"></span>																</label>																<b>0</b>															</li>														</ul>													</div>												</div>											</div>																					</div>									</div>								</div>							</div>							<div class="col-xs-12 col-lg-12 SecondaryCriteria">									<h6>Description de ma demande:</h6>								<p>Décrivez simplement ce que vous souhaitez </p>								<div class="form-group">									<textarea class="form-control" name="" cols="" rows="5" placeholder="Exemple : maison 120m2 , cuisine ouverte sur séjour avec cheminée, 4 chambres, le de bain, Chambre parentale, piscine, terrain clos, arboré, sécurisé, avec sous-, combles aménageables, vue lac, sans vis à vis, ."></textarea>								</div>								<button class="ValidateBtn" type="button">Valider ma Demande</button>							</div>						</div>					</form>				</div>			</div>		</div>	</div></div>
<!-- Offrimo > Toute l'offre > Chassimo Plussde --><div id="ChassimoPlussde" class="modal fade ChassimoPopup">	<div class="modal-dialog">		<div class="modal-content">			<button type="button" class="close" id="ChassimoPlussclose" data-dismiss="modal">×</button>			<div class="clr"></div>			<div class="ChassimoPluss_Box">				<h3>"Critère(s) supplémentaires"</h3>				<p class="ResultWrapper"> «&nbsp;Je recherche un terrain à Douvaine.&nbsp;»</p>				<div class="Field_Wrapper">					<label>infos sur le terrain:</label>					<input type="text" id="surface" name="surface" value="">   					<span>ou entre</span>					<input type="text" id="surface_min" name="surface_min" value="">   					<span>et</span>					<input type="text" id="surface_max" name="surface_max" value=""> 				</div>							<div class="clearfix"></div>				<div class="Field_Wrapper">					<label>Infos sur le bâti:</label>					<input type="text" name="surface1" value="">   					<span>ou entre</span>					<input type="text" name="surface_min1" value="">   					<span>et</span>					<input type="text" name="surface_max1" value="">    				</div>							<div class="clearfix"></div>				<div class="Field_Wrapper">					<label>Avec une piscine?:</label>					<select name="piscine">					<option value=""></option>					<option value="Oui">Oui</option>					<option value="Non">Non</option>					</select>					</div>				<input type="hidden" id="pagenum" name="pagenum" value="2">   				<div class="clearfix"></div>				<p class="Rfr_Btnbox Chassimo_bottomValider"><button type="submit">Valider</button><a class="refreshchasearch" href="javascript:void(0);">&nbsp;</a></p>			</div>		</div>	</div></div>



