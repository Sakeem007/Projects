<?php include('header2.php');?>
	
	<!-- Being: my space box -->
	<article class="CallimoMainWrapper">
		<div class="container">			
			
			<nav class="nav nav-tab">
				<ul>
					<li class="active"><a href="#CallimoDashboard" data-toggle="tab">Tableau de bord</a></li>
					<li><a href="#CallimoSuiviCall" data-toggle="tab">Suivis call</a></li>
					<li><a href="#CallimoSuiviRapport" data-toggle="tab">Suivis Rappel</a></li>
				</ul>
			</nav>
			<div class="tab-content">
				<div id="CallimoDashboard" class="item tab-pane fade in active">
					<div class="row">
						<?php include('tableau-de-bord.php');?>
					</div>
				</div>
				<div id="CallimoSuiviCall" class="item tab-pane fade">
					<div class="row">
						<?php include('suivi-call.php');?>
					</div>
				</div>
				<div id="CallimoSuiviRapport" class="item tab-pane fade">
					<div class="row">
						<?php include('suivi-rapport.php');?>
					</div>
				</div>				
			</div>
			
		</div>
	</article>
	<!-- End: my space box -->
	
<?php include('footer.php');?>