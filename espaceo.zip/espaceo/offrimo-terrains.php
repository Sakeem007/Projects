<div class="banners" style="background-image: url(images/bg-4.jpg);">
	<h2>Chercher un terrain</h2>
	<p>parmi plus de 65037 annonces immobilières en haute Savoie</p>
	<h5>Je veux consulter les 
	<select>
		<option>Terrains</option>
		<option>Terrains</option>
	</select> à 
	<select>
		<option>ville,code postal</option>
		<option>ville,code postal</option>
	</select>  avec un rayon de 
	<select>
		<option>kms</option>
		<option>kms</option>
	</select>  et je veux ajouter <span class="maisons_de_criteres_btn">+ de critères</span></h5>
	<div id="maisons_de_criteres_form" class="expend-form">
		<form action="#" method="post">
			<div class="col-xs-12 col-sm-4 col-md-3 col-lg-3 form-col">
				<label>Mot-clé</label>
				<input name="address" placeholder="Adresse,ville,code postal" type="text">
			</div>
			<div class="col-xs-12 col-sm-4 col-md-3 col-lg-3 form-col">
				<label> </label>
				<span class="checkbox">
					<input name="mandat_pro" value="1" type="checkbox"><em></em> Mandat Nulle part ailleurs
				</span>
			</div>
			<div class="col-xs-12 col-sm-4 col-md-3 col-lg-3 form-col">
				<label>Num. Mandat</label>
				<input name="reference" placeholder="Num. Mandat">
			</div>
			<div class="col-xs-12 col-sm-4 col-md-3 col-lg-3 form-col">
				<label>Nb. Salles de bains</label>
				<select name="nbsallesdebains">
					<option value=""></option>
					<option value="1">1</option>
					<option value="2">2</option>
					<option value="3">3</option>
					<option value="4">4</option>
					<option value="5">5</option>
					<option value="6">6</option>
					<option value="7">7</option>
					<option value="8">8</option>
					<option value="9">9</option>
					<option value="10">10</option>
				</select>
			</div>
			<div class="col-xs-12 col-sm-4 col-md-3 col-lg-3 form-col">
			<label>Nb. Chambres Min</label>
				<select name="nbchambres_min">
					<option value=""></option>
					<option value="0">0</option>
					<option value="1">1</option>
					<option value="2">2</option>
					<option value="3">3</option>
					<option value="4">4</option>
					<option value="5">5</option>
					<option value="6">6</option>
					<option value="7">7</option>
					<option value="8">8</option>
					<option value="9">9</option>
					<option value="10">10</option>
					<option value="11">11</option>
					<option value="12">12</option>
					<option value="13">13</option>
					<option value="14">14</option>
					<option value="15">15</option>
				</select>
			</div>
			<div class="col-xs-12 col-sm-4 col-md-3 col-lg-3 form-col">
				<label>Nb. Chambres Max</label>
				<select name="nbchambres_max">
					<option value=""></option>
					<option value="0">0</option>
					<option value="1">1</option>
					<option value="2">2</option>
					<option value="3">3</option>
					<option value="4">4</option>
					<option value="5">5</option>
					<option value="6">6</option>
					<option value="7">7</option>
					<option value="8">8</option>
					<option value="9">9</option>
					<option value="10">10</option>
					<option value="11">11</option>
					<option value="12">12</option>
					<option value="13">13</option>
					<option value="14">14</option>
					<option value="15">15</option>
				</select>
			</div>
			<div class="col-xs-12 col-sm-4 col-md-6 col-lg-6 form-col">
				<label></label>
				<span class="checkbox">
					<input name="NEUF_ANCIEN[]" value="Ancien" type="checkbox"><em></em>
					<span>Ancien</span>
				</span>
				<span class="checkbox">
					<input name="NEUF_ANCIEN[]" value="Recent" type="checkbox"><em></em>
					<span>Recent</span>
				</span>
			</div>
			<div class="col-xs-12 col-sm-4 col-md-3 col-lg-3 form-col">
				<label>Prix Min</label>
				<input type="text" name="price_min" placeholder="Prix Min">                                    
			</div>
			<div class="col-xs-12 col-sm-4 col-md-3 col-lg-3 form-col">
				<label>Prix Max</label>
				<input type="text" name="price_max" placeholder="Prix Max">                                    
			</div>
			<div class="col-xs-12 col-sm-4 col-md-3 col-lg-3 form-col">
				<label>Surface min. (m<sup>2</sup>)</label>
				<input type="text" name="surface_min" placeholder="surface Max">   
			</div>
			<div class="col-xs-12 col-sm-4 col-md-3 col-lg-3 form-col">
				<label>Surface max. (m<sup>2</sup>)</label>
				<input type="text" name="surface_max" placeholder="surface max">
			</div>
		</form>
	</div>
</div>
<div class="offrimo">
	<div class="filter">
		<form action="#" method="post">
			<ul>
				<li>Filtre :</li>
				<li><select>
					<option>En-ligne/Expirees</option>
					<option>En-ligne/Expirees</option>
					<option>En-ligne/Expirees</option>
				</select></li>
				<li><select>
					<option>Date de parution</option>
					<option>Date de parution</option>
					<option>Date de parution</option>
				</select></li>
				<li><select>
					<option>PRO/PAP</option>
					<option>PRO/PAP</option>
					<option>PRO/PAP</option>
				</select></li>
				<li><input type="text" value="Par agence"/></li>
				<li><select>
					<option>Tri par prix</option>
					<option>Tri par prix</option>
					<option>Tri par prix</option>
				</select></li>
				<li><button type="submit">Lancer filter</button></li>
			</ul>
		</form>
	</div>
	<div class="listing">
		<form action="#" method="post">
			<ul>
				<li><em> Listing  des biens :</em></li>
				<li><span>4 biens</span></li>
				<li><span>Exporter</span></li>
				<li>
					<select>
						<option>Affichage</option>
						<option>List</option>
					</select>
				</li>
				<li>
					<select>
						<option>10 biens</option>
						<option>20 biens</option>
						<option>30 biens</option>
					</select>
				</li>
			</ul>
		</form>
	</div>
	<div class="affichageBox">
		<div class="repter">
			<div class="tablebox">
				<div class="box">
					<div class="img" style="background-image: url(images/offrimo3.png)">
						<span class="topBtn">PRO</span>
						<span class="locBtn">Douvaine</span>
					</div>
				</div>
				<div class="box">
					<div class="headerTop">Annonce <span>892 500 &euro;</span></div>
					<div class="contents">
						<div class="padRight">
							<span class="plus"></span>
							<h6>Terrain 1000m2</h6>
							<p>Cove + goroge double en sous-sol + porking privotif.<br>Acces facile outoroute Annecy Nord et Allozier (Bordonnex a 20 min) Chouffoge individuel goz.<br>Charges copro. 100 &euro; / mois</p>
						</div>
						<a href="#" class="blueBtn">Suivre le prix</a>
						<a href="#" class="blueBtn">Voir l'annonce</a>
						<h6>Publiee par Poirier Immobilier 04 57 43 50 12</h6>
					</div>
				</div>
				<div class="box">
					<div class="headerTop">Historique</div>
					<div class="contents">
						<ul>
							<li>Creation Annonce : 25/12/2017 a 15h</li>
							<li>En ligne depuis : 83 jours</li>
							<li>Dernieres modifications prix :
								<span>25/01/2017 : <strike>395000</strike> a 377000 &euro;</span>
								<span>22/03/2017 : <strike>377000</strike> a 370000 &euro;</span>
							</li>
							<li>Portails :</li>
						</ul>
						<div class="colorBtns">
							<ul>
								<li><a href="#">leBonCoin</a></li>
								<li><a href="#">PAP</a></li>
								<li><a href="#">VivaStreet</a></li>
								<li><a href="#">Seloger</a></li>
							</ul>
						</div>
					</div>
				</div>
				<div class="box">
					<div class="headerTop">Appreciation</div>
					<div class="appreciation">
						<span class="title">Selon vous?</span>
						<ul class="selon">
							<li>Pas chers</li>
							<li>Au prix</li>
							<li>Trop chers</li>
						</ul>
						<h6>Rankimo</h6>
						<span class="rank">59/203</span>
						<p>Votre bien est classe 59/203 a Ambilly "74100" (3 pieces).</p>
					</div>
				</div>
				<div class="box">
					<div class="headerTop">priorite</div>
					<div class="contents">
						<label><input type="checkbox"/><span></span> Coll</label>
						<label><input type="checkbox"/><span></span> Moi</label>
					</div>
				</div>
				
			</div>
			<div class="bottomMenu">
				<ul>
					<li><a href="#">Mandat agence</a></li>
					<li><a href="#">Ancien Mandat</a></li>
					<li><a href="#">Vendu & Archive</a></li>
					<li><a href="#">Agence Partenaire</a></li>
					<li><a href="#Chassimo" data-toggle="modal" data-backdrop="true">Chassimo</a></li>
					<li><a href="#"></a></li>
				</ul>
			</div>
		</div>
		<div class="repter">
			<div class="tablebox">
				<div class="box">
					<div class="img" style="background-image: url(images/offrimo4.png)">
						<span class="topBtn1">PAP</span>
						<span class="locBtn">Douvaine</span>
					</div>
				</div>
				<div class="box">
					<div class="headerTop">Annonce <span>892 500 &euro;</span></div>
					<div class="contents">
						<div class="padRight">
							<span class="plus"></span>
							<h6>Terrain 1000m2</h6>
							<p>Cove + goroge double en sous-sol + porking privotif.<br>Acces facile outoroute Annecy Nord et Allozier (Bordonnex a 20 min) Chouffoge individuel goz.<br>Charges copro. 100 &euro; / mois</p>
						</div>
						<a href="#" class="blueBtn">Suivre le prix</a>
						<a href="#" class="blueBtn">Voir l'annonce</a>
						<h6> Publiée par Mr CARON 06 63 68 13 17</h6>
					</div>
				</div>
				<div class="box">
					<div class="headerTop">Historique</div>
					<div class="contents">
						<ul>
							<li>Creation Annonce : 25/12/2017 a 15h</li>
							<li>En ligne depuis : 83 jours</li>
							<li>Dernieres modifications prix :
								<span>25/01/2017 : <strike>395000</strike> a 377000 &euro;</span>
								<span>22/03/2017 : <strike>377000</strike> a 370000 &euro;</span>
							</li>
							<li>Portails :</li>
						</ul>
						<div class="colorBtns">
							<ul>
								<li><a href="#">leBonCoin</a></li>
								<li><a href="#">PAP</a></li>
								<li><a href="#">VivaStreet</a></li>
							</ul>
						</div>
					</div>
				</div>
				<div class="box">
					<div class="headerTop">Appreciation</div>
					<div class="appreciation">
						<span class="title">Selon vous?</span>
						<ul class="selon">
							<li>Pas chers</li>
							<li>Au prix</li>
							<li>Trop chers</li>
						</ul>
						<h6>Rankimo</h6>
						<span class="rank">59/203</span>
						<p>Votre bien est classe 59/203 a Ambilly "74100" (3 pieces).</p>
						<a href="#" class="blueBtn">Evalueo</a>
					</div>
				</div>
				<div class="box">
					<div class="headerTop">priorite</div>
					<div class="contents">
						<label><input type="checkbox"/><span></span> Coll</label>
						<label><input type="checkbox"/><span></span> Moi</label>
					</div>
				</div>
			</div>
			<div class="bottomMenu">
				<ul>
					<li><a href="#">Mandat agence</a></li>
					<li><a href="#">Ancien Mandat</a></li>
					<li><a href="#">Vendu & Archive</a></li>
					<li><a href="#">Agence Partenaire</a></li>
					<li><a href="#Chassimo" data-toggle="modal" data-backdrop="true">Chassimo</a></li>
					<li><a href="#"></a></li>
				</ul>
			</div>
		</div>
		<div class="repter">
			<div class="tablebox">
				<div class="box">
					<div class="img" style="background-image: url(images/offrimo2.png)"></div>
				</div>
				<div class="box">
					<div class="headerTop">Annonce <span>892 500 &euro;</span></div>
					<div class="contents">
						<div class="padRight">
							<span class="plus"></span>
							<h6>Appartement duplex T4</h6>
							<p>Pringy secteur Promery, proche ecoles et service bus, appertement T3 de 64m2 en parfait etat dans residence recente securisee, calme et arboree.<br>
							Entree ovec rangement, 2 chambres avec placards, salle de bain double vasques, wc separes, cuisine equipee ouverte sur sejour lumineux, ouvrant sur un agreable balcon de + 9m2 expose plein sud avec vue montagnes.</p>
							<p>Cove + goroge double en sous-sol + porking privotif.<br>Acces facile outoroute Annecy Nord et Allozier (Bordonnex a 20 min) Chouffoge individuel goz.<br>Charges copro. 100 &euro; / mois</p>					
						</div>
					</div>
				</div>
				<div class="box">
					<div class="headerTop">Historique</div>
					<div class="contents">
						<ul>
							<li>Creation Annonce : 25/12/2017 a 15h</li>
							<li>En ligne depuis : 83 jours</li>
							<li>Dernieres modifications prix :
								<span>25/01/2017 : <strike>395000</strike> a 377000 &euro;</span>
								<span>22/03/2017 : <strike>377000</strike> a 370000 &euro;</span>
							</li>
							<li>Portails :</li>
						</ul>
						<div class="colorBtns">
							<ul>
								<li><a href="#">leBonCoin</a></li>
								<li><a href="#">PAP</a></li>
								<li><a href="#">VivaStreet</a></li>
								<li><a href="#">Seloger</a></li>
							</ul>
						</div>
					</div>
				</div>
				<div class="box">
					<div class="headerTop">Appreciation</div>
					<div class="appreciation">
						<h6>Rankimo</h6>
						<span class="rank">59/203</span>
						<p>Votre bien est classe 59/203 a Ambilly "74100" (3 pieces).</p>
						<h6>Evalueo en ligne</h6>
						<div class="range"><em><input id="offer-price3" type="range" min="169000" max="198000" value=""/></em>
						<p><span>169000 &euro;</span><span id="offer-result3">180000 &euro;</span><span>198000 &euro;</span></p></div>
						<ul>
							<li>Prix m<sup>2</sup> Evalueo : 2937 &euro;</li>
							<li>Prix m<sup>2</sup> Annonce : 3137 &euro;</li>
							<li>Appreciation prix m<sup>2</sup> Annonce : + 200 &euro;</li>
						</ul>
					</div>
				</div>
				<div class="box">
					<div class="headerTop">priorite</div>
					<div class="contents">
						<label><input type="checkbox"/><span></span> Coll</label>
						<label><input type="checkbox"/><span></span> Moi</label>
					</div>
				</div>
			</div>
			<div class="bottomMenu">
				<ul>
					<li><a href="#">Mandat agence</a></li>
					<li><a href="#">Ancien Mandat</a></li>
					<li><a href="#">Vendu & Archive</a></li>
					<li><a href="#">Agence Partenaire</a></li>
					<li><a href="#Chassimo" data-toggle="modal" data-backdrop="true">Chassimo</a></li>
					<li><a href="#"></a></li>
				</ul>
			</div>
		</div>
		<div class="repter">
			<div class="tablebox">
				<div class="box">
					<div class="img" style="background-image: url(images/offrimo2.png)"></div>
				</div>
				<div class="box">
					<div class="headerTop">Annonce <span>892 500 &euro;</span></div>
					<div class="contents">
						<div class="padRight">
							<span class="plus"></span>
							<h6>Appartement duplex T4</h6>
							<p>Pringy secteur Promery, proche ecoles et service bus, appertement T3 de 64m2 en parfait etat dans residence recente securisee, calme et arboree.<br>
							Entree ovec rangement, 2 chambres avec placards, salle de bain double vasques, wc separes, cuisine equipee ouverte sur sejour lumineux, ouvrant sur un agreable balcon de + 9m2 expose plein sud avec vue montagnes.</p>
							<p>Cove + goroge double en sous-sol + porking privotif.<br>Acces facile outoroute Annecy Nord et Allozier (Bordonnex a 20 min) Chouffoge individuel goz.<br>Charges copro. 100 &euro; / mois</p>					
						</div>
					</div>
				</div>
				<div class="box">
					<div class="headerTop">Historique</div>
					<div class="contents">
						<ul>
							<li>Creation Annonce : 25/12/2017 a 15h</li>
							<li>En ligne depuis : 83 jours</li>
							<li>Dernieres modifications prix :
								<span>25/01/2017 : <strike>395000</strike> a 377000 &euro;</span>
								<span>22/03/2017 : <strike>377000</strike> a 370000 &euro;</span>
							</li>
							<li>Portails :</li>
						</ul>
						<div class="colorBtns">
							<ul>
								<li><a href="#">leBonCoin</a></li>
								<li><a href="#">PAP</a></li>
								<li><a href="#">VivaStreet</a></li>
								<li><a href="#">Seloger</a></li>
							</ul>
						</div>
					</div>
				</div>
				<div class="box">
					<div class="headerTop">Appreciation</div>
					<div class="appreciation">
						<h6>Rankimo</h6>
						<span class="rank">59/203</span>
						<p>Votre bien est classe 59/203 a Ambilly "74100" (3 pieces).</p>
						<h6>Evalueo en ligne</h6>
						<div class="range"><em><input id="offer-price4" type="range" min="169000" max="198000" value=""/></em>
						<p><span>169000 &euro;</span><span id="offer-result4">180000 &euro;</span><span>198000 &euro;</span></p></div>
						<ul>
							<li>Prix m<sup>2</sup> Evalueo : 2937 &euro;</li>
							<li>Prix m<sup>2</sup> Annonce : 3137 &euro;</li>
							<li>Appreciation prix m<sup>2</sup> Annonce : + 200 &euro;</li>
						</ul>
					</div>
				</div>
				<div class="box">
					<div class="headerTop">priorite</div>
					<div class="contents">
						<label><input type="checkbox"/><span></span> Coll</label>
						<label><input type="checkbox"/><span></span> Moi</label>
					</div>
				</div>
			</div>
			<div class="bottomMenu">
				<ul>
					<li><a href="#">Mandat agence</a></li>
					<li><a href="#">Ancien Mandat</a></li>
					<li><a href="#">Vendu & Archive</a></li>
					<li><a href="#">Agence Partenaire</a></li>
					<li><a href="#Chassimo" data-toggle="modal" data-backdrop="true">Chassimo</a></li>
					<li><a href="#"></a></li>
				</ul>
			</div>
		</div>
	</div>
	<div class="listGridBox">
		<div class="row">
			<div class="box col-xs-12 col-sm-3 col-md-3 col-lg-3">
				<a href="#" class="img" style="background-image: url(images/offrimo3.png)">
					<span class="topBtn">PRO</span>
					<span class="locBtn">Douvaine</span>
					<div class="text">
						<h6>Appartement duplex T4</h6>
						<p>Cove + goroge double en sous-sol + porking privotif.Acces facile outoroute Annecy Nord et Allozier (Bordonnex a 20 min) Chouffoge individuel goz. Charges copro. 100 € / mois</p>
						<span class="rate">892 500 €</span>
					</div>
				</a>				
			</div>
			<div class="box col-xs-12 col-sm-3 col-md-3 col-lg-3">
				<a href="#" class="img" style="background-image: url(images/offrimo3.png)">
					<span class="topBtn">PRO</span>
					<span class="locBtn">Douvaine</span>
					<div class="text">
						<h6>Appartement duplex T4</h6>
						<p>Cove + goroge double en sous-sol + porking privotif.Acces facile outoroute Annecy Nord et Allozier (Bordonnex a 20 min) Chouffoge individuel goz. Charges copro. 100 € / mois</p>
						<span class="rate">892 500 €</span>
					</div>
				</a>
			</div>
			<div class="box col-xs-12 col-sm-3 col-md-3 col-lg-3">
				<a href="#" class="img" style="background-image: url(images/offrimo3.png)">
					<span class="topBtn">PRO</span>
					<span class="locBtn">Douvaine</span>
					<div class="text">
						<h6>Appartement duplex T4</h6>
						<p>Cove + goroge double en sous-sol + porking privotif.Acces facile outoroute Annecy Nord et Allozier (Bordonnex a 20 min) Chouffoge individuel goz. Charges copro. 100 € / mois</p>
						<span class="rate">892 500 €</span>
					</div>
				</a>
			</div>
			<div class="box col-xs-12 col-sm-3 col-md-3 col-lg-3">
				<a href="#" class="img" style="background-image: url(images/offrimo3.png)">
					<span class="topBtn">PRO</span>
					<span class="locBtn">Douvaine</span>
					<div class="text">
						<h6>Appartement duplex T4</h6>
						<p>Cove + goroge double en sous-sol + porking privotif.Acces facile outoroute Annecy Nord et Allozier (Bordonnex a 20 min) Chouffoge individuel goz. Charges copro. 100 € / mois</p>
						<span class="rate">892 500 €</span>
					</div>
				</a>
			</div>
			<div class="box col-xs-12 col-sm-3 col-md-3 col-lg-3">
				<a href="#" class="img" style="background-image: url(images/offrimo3.png)">
					<span class="topBtn">PRO</span>
					<span class="locBtn">Douvaine</span>
					<div class="text">
						<h6>Appartement duplex T4</h6>
						<p>Cove + goroge double en sous-sol + porking privotif.Acces facile outoroute Annecy Nord et Allozier (Bordonnex a 20 min) Chouffoge individuel goz. Charges copro. 100 € / mois</p>
						<span class="rate">892 500 €</span>
					</div>
				</a>
			</div>
			<div class="box col-xs-12 col-sm-3 col-md-3 col-lg-3">
				<a href="#" class="img" style="background-image: url(images/offrimo3.png)">
					<span class="topBtn">PRO</span>
					<span class="locBtn">Douvaine</span>
					<div class="text">
						<h6>Appartement duplex T4</h6>
						<p>Cove + goroge double en sous-sol + porking privotif.Acces facile outoroute Annecy Nord et Allozier (Bordonnex a 20 min) Chouffoge individuel goz. Charges copro. 100 € / mois</p>
						<span class="rate">892 500 €</span>
					</div>
				</a>
			</div>
			<div class="box col-xs-12 col-sm-3 col-md-3 col-lg-3">
				<a href="#" class="img" style="background-image: url(images/offrimo3.png)">
					<span class="topBtn">PRO</span>
					<span class="locBtn">Douvaine</span>
					<div class="text">
						<h6>Appartement duplex T4</h6>
						<p>Cove + goroge double en sous-sol + porking privotif.Acces facile outoroute Annecy Nord et Allozier (Bordonnex a 20 min) Chouffoge individuel goz. Charges copro. 100 € / mois</p>
						<span class="rate">892 500 €</span>
					</div>
				</a>
			</div>
			<div class="box col-xs-12 col-sm-3 col-md-3 col-lg-3">
				<a href="#" class="img" style="background-image: url(images/offrimo3.png)">
					<span class="topBtn">PRO</span>
					<span class="locBtn">Douvaine</span>
					<div class="text">
						<h6>Appartement duplex T4</h6>
						<p>Cove + goroge double en sous-sol + porking privotif.Acces facile outoroute Annecy Nord et Allozier (Bordonnex a 20 min) Chouffoge individuel goz. Charges copro. 100 € / mois</p>
						<span class="rate">892 500 €</span>
					</div>
				</a>
			</div>
		</div>
		<div class="bottomMenu">
			<ul>
				<li><a href="#">Mandat agence</a></li>
				<li><a href="#">Ancien Mandat</a></li>
				<li><a href="#">Vendu & Archive</a></li>
				<li><a href="#">Agence Partenaire</a></li>
				<li><a href="#Chassimo" data-toggle="modal" data-backdrop="true">Chassimo</a></li>
				<li><a href="#">Imprimer PDF</a></li>
			</ul>
		</div>		
	</div>
	<div class="pagination">
		<strong>1</strong>
		<a href="#">2</a>
		<a href="#">3</a>
		<a href="#">></a>
		<a href="#">Last ›</a>			
	</div>
</div>