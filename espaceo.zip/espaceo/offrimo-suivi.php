<div class="banners" style="background-image: url(images/bg-4.jpg);">
	<h2>Research motor Suivre ses actions de pige</h2>
	<p>"Je peux suivre les annonces</p>
	<h5>Sélectionnées par type 
	<select>
		<option>Maisons/Appartements/terrains</option>
		<option>Maisons/Appartements</option>
	</select> v a 
	<input name="" placeholder="ville,code postal" type="text" />
	<!--<select data-placeholder="ville,code postal" multiple="" name="address[]" class="select select2-hidden-accessible" tabindex="-1" aria-hidden="true">
		<option value="">(Toutes les villes) </option>
		<option value=""></option>
		<option value="74000">(Toutes les villes) 74000</option>
		<option value="74100">(Toutes les villes) 74100</option>
		<option value="74120">(Toutes les villes) 74120</option>
		<option value="74140">(Toutes les villes) 74140</option>
		<option value="74170">(Toutes les villes) 74170</option>
		<option value="74190">(Toutes les villes) 74190</option>
		<option value="74210">(Toutes les villes) 74210</option>
		<option value="74270">(Toutes les villes) 74270</option>
	</select>-->  v et de Mon équipe v"
	<!--avec un rayon de  <input type="text" name="distance" placeholder="Kms" id="distance" value=""> et je peux ajouter <span class="maisons_de_criteres_btn">+ de criteres</span></h5>
	<a href="#" class="whiteBtn">Lancer recherche</a>
	<a href="#" class="whiteBtn">Lancer recherche et creer une requete</a>-->
	
	<div id="maisons_de_criteres_form" class="expend-form">
		<form action="#" method="post">
			<div class="col-xs-12 col-sm-4 col-md-3 col-lg-3 form-col">
				<label>Mot-clé</label>
				<input name="address" placeholder="Adresse,ville,code postal" type="text">
			</div>
			<div class="col-xs-12 col-sm-4 col-md-3 col-lg-3 form-col">
				<label> </label>
				<span class="checkbox">
					<input name="mandat_pro" value="1" type="checkbox"><em></em> Mandat Nulle part ailleurs
				</span>
			</div>
			<div class="col-xs-12 col-sm-4 col-md-3 col-lg-3 form-col">
				<label>Num. Mandat</label>
				<input name="reference" placeholder="Num. Mandat">
			</div>
			<div class="col-xs-12 col-sm-4 col-md-3 col-lg-3 form-col">
				<label>Nb. Salles de bains</label>
				<select name="nbsallesdebains">
					<option value=""></option>
					<option value="1">1</option>
					<option value="2">2</option>
					<option value="3">3</option>
					<option value="4">4</option>
					<option value="5">5</option>
					<option value="6">6</option>
					<option value="7">7</option>
					<option value="8">8</option>
					<option value="9">9</option>
					<option value="10">10</option>
				</select>
			</div>
			<div class="col-xs-12 col-sm-4 col-md-3 col-lg-3 form-col">
			<label>Nb. Chambres Min</label>
				<select name="nbchambres_min">
					<option value=""></option>
					<option value="0">0</option>
					<option value="1">1</option>
					<option value="2">2</option>
					<option value="3">3</option>
					<option value="4">4</option>
					<option value="5">5</option>
					<option value="6">6</option>
					<option value="7">7</option>
					<option value="8">8</option>
					<option value="9">9</option>
					<option value="10">10</option>
					<option value="11">11</option>
					<option value="12">12</option>
					<option value="13">13</option>
					<option value="14">14</option>
					<option value="15">15</option>
				</select>
			</div>
			<div class="col-xs-12 col-sm-4 col-md-3 col-lg-3 form-col">
				<label>Nb. Chambres Max</label>
				<select name="nbchambres_max">
					<option value=""></option>
					<option value="0">0</option>
					<option value="1">1</option>
					<option value="2">2</option>
					<option value="3">3</option>
					<option value="4">4</option>
					<option value="5">5</option>
					<option value="6">6</option>
					<option value="7">7</option>
					<option value="8">8</option>
					<option value="9">9</option>
					<option value="10">10</option>
					<option value="11">11</option>
					<option value="12">12</option>
					<option value="13">13</option>
					<option value="14">14</option>
					<option value="15">15</option>
				</select>
			</div>
			<div class="col-xs-12 col-sm-4 col-md-6 col-lg-6 form-col">
				<label></label>
				<span class="checkbox">
					<input name="NEUF_ANCIEN[]" value="Ancien" type="checkbox"><em></em>
					<span>Ancien</span>
				</span>
				<span class="checkbox">
					<input name="NEUF_ANCIEN[]" value="Recent" type="checkbox"><em></em>
					<span>Recent</span>
				</span>
			</div>
			<div class="col-xs-12 col-sm-4 col-md-3 col-lg-3 form-col">
				<label>Prix Min</label>
				<input type="text" name="price_min" placeholder="Prix Min">                                    
			</div>
			<div class="col-xs-12 col-sm-4 col-md-3 col-lg-3 form-col">
				<label>Prix Max</label>
				<input type="text" name="price_max" placeholder="Prix Max">                                    
			</div>
			<div class="col-xs-12 col-sm-4 col-md-3 col-lg-3 form-col">
				<label>Surface min. (m<sup>2</sup>)</label>
				<input type="text" name="surface_min" placeholder="surface Max">   
			</div>
			<div class="col-xs-12 col-sm-4 col-md-3 col-lg-3 form-col">
				<label>Surface max. (m<sup>2</sup>)</label>
				<input type="text" name="surface_max" placeholder="surface max">
			</div>
		</form>
	</div>
</div>
<div class="offrimo">
	<div class="filter suivi_filter">
		<form action="#" method="post">
			<ul>
				<li>Filtre :</li>
				<li><select>
					<option>SP/SSv</option>
					<option>SP</option>
					<option>SSV</option>
				</select></li>
				<li><select>
					<option>Call/Moi</option>
					<option>Call</option>
					<option>Moi</option>
				</select></li>
				<li><select>
					<option>Dernières actions v</option>
					<option>24h</option>
					<option>48h</option>
					<option>-7jrs</option>
					<option>+7jrs</option>
				</select></li>
				<li><select>
					<option>Statut dernière action v</option>
					<option>NRP</option>
					<option>Message</option>
					<option>A rappeler</option>
					<option>Refus</option>
					<option>RDV</option>
				</select></li>
				<li><select>
					<option>Statut annonces v</option>
					<option>Actives</option>
					<option>Archivées</option>
				</select></li>
				<li><select>
					<option>Tel, mots clefs</option>
					<option>Tel</option>
					<option>Mots clefs</option>
				</select></li>
				<li class="btns">
					<button class="submit" type="submit"></button>            
				</li>
				<li class="btns">
					<a class="resetlast" href=""></a> 
				</li>
			</ul>
		</form>
	</div>
	<div class="listing">
		<form action="#" method="post">
			<ul>
				<li><em> Listing  des biens :</em></li>
				<li><span>4 biens</span></li>
				<li><a href="#">Exporter</a></li>
				<li>
					<select>
						<option>Affichage</option>
						<option>List</option>
					</select>
				</li>
				<li>
					<select>
						<option>10 biens</option>
						<option>20 biens</option>
						<option>30 biens</option>
					</select>
				</li>
			</ul>
		</form>
	</div>
	<div class="affichageBox suivi_main_wrapper">
		<div class="repter">
			<div class="tablebox">
				<div class="box">
					<div class="suivi_boX_wrapper">						
						<div class="suivi_btn_boX">
							<ul>
								<li><a href="#suiviannonce" data-toggle="modal" data-backdrop="true"><i class="fa fa-eye"></i> Annonce</a>												
								</li>
								<li><a href="#suivisuivi" data-toggle="modal" data-backdrop="true"><i class="fa fa-bullseye"></i> Suivi</a></li>						
							</ul>												
						</div>
						<div class="img" style="background-image: url(images/pic1.jpg)">
							<span class="topBtn">SP</span>
						</div>
						<div class="land_description"><span>4 pièces de 104m2 with under the city</span></div>
						<div class="suivi_btn_boX">
						<ul>
							<li class="org_Box"><a href=""><i class="fa fa-phone"></i> Call</a></li>
							<li><a href="">Archiver</a></li>						
						</ul>
						</div>
					</div>	
				</div>
				<div class="box">
					
					<div class="suivi_boX_wrapper">						
						<div class="suivi_btn_boX">
							<ul>
								<li><a href="#suiviannonce" data-toggle="modal" data-backdrop="true"><i class="fa fa-eye"></i> Annonce</a>												
								</li>
								<li><a href="#suivisuivi" data-toggle="modal" data-backdrop="true"><i class="fa fa-bullseye"></i> Suivi</a></li>						
							</ul>												
						</div>
						<div class="img" style="background-image: url(images/pic4.png)">
							<span class="topBtn">SS</span>
						</div>
						<div class="land_description"><span>4 pièces de 104m2 with under the city</span></div>				
						<div class="suivi_btn_boX">
						<ul>
							<li class="green_Box"><a href=""><i class="fa fa-phone"></i> Moi</a></li>
							<li><a href="">Archiver</a></li>						
						</ul>
						</div>
					</div>
				</div>
				<div class="box">
					<div class="suivi_boX_wrapper">						
						<div class="suivi_btn_boX">
							<ul>
								<li><a href="#suiviannonce" data-toggle="modal" data-backdrop="true"><i class="fa fa-eye"></i> Annonce</a>												
								</li>
								<li><a href="#suivisuivi" data-toggle="modal" data-backdrop="true"><i class="fa fa-bullseye"></i> Suivi</a></li>						
							</ul>												
						</div>
						<div class="img" style="background-image: url(images/pic1.jpg)">
							<span class="topBtn">SP</span>
						</div>
						<div class="land_description"><span>4 pièces de 104m2 with under the city</span></div>				
						<div class="suivi_btn_boX">
						<ul>
							<li class="org_Box"><a href=""><i class="fa fa-phone"></i> Call</a></li>
							<li><a href="">Archiver</a></li>						
						</ul>
						</div>
					</div>	
				</div>
				<div class="box">					
					<div class="suivi_boX_wrapper">						
						<div class="suivi_btn_boX">
							<ul>
								<li><a href="#suiviannonce" data-toggle="modal" data-backdrop="true"><i class="fa fa-eye"></i> Annonce</a>												
								</li>
								<li><a href="#suivisuivi" data-toggle="modal" data-backdrop="true"><i class="fa fa-bullseye"></i> Suivi</a></li>						
							</ul>												
						</div>
						<div class="img" style="background-image: url(images/pic4.png)">
							<span class="topBtn">SS</span>
						</div>
						<div class="land_description"><span>4 pièces de 104m2 with under the city</span></div>				
						<div class="suivi_btn_boX">
						<ul>
							<li class="green_Box"><a href=""><i class="fa fa-phone"></i> Moi</a></li>
							<li><a href="">Archiver</a></li>						
						</ul>
						</div>
					</div>
				</div>		
			</div>
			<!--<div class="bottomMenu">
				<ul>
					<li><a href="#">Mandat agence</a></li>
					<li><a href="#">Ancien Mandat</a></li>
					<li><a href="#">Vendu & Archive</a></li>
					<li><a href="#">Agence Partenaire</a></li>
					<li><a href="#Chassimo" data-toggle="modal" data-backdrop="true">Chassimo</a></li>
					<li><a href="#">Imprimer PDF</a></li>
				</ul>
			</div>-->
		</div>
		<div class="repter">
			<div class="tablebox">
				<div class="box">
					<div class="suivi_boX_wrapper">						
						<div class="suivi_btn_boX">
							<ul>
								<li><a href="#suiviannonce" data-toggle="modal" data-backdrop="true"><i class="fa fa-eye"></i> Annonce</a>												
								</li>
								<li><a href="#suivisuivi" data-toggle="modal" data-backdrop="true"><i class="fa fa-bullseye"></i> Suivi</a></li>						
							</ul>												
						</div>
						<div class="img" style="background-image: url(images/pic1.jpg)">
							<span class="topBtn">SP</span>
						</div>
						<div class="land_description"><span>4 pièces de 104m2 with under the city</span></div>
						<div class="suivi_btn_boX">
						<ul>
							<li class="org_Box"><a href=""><i class="fa fa-phone"></i> Call</a></li>
							<li><a href="">Archiver</a></li>						
						</ul>
						</div>
					</div>	
				</div>
				<div class="box">
					
					<div class="suivi_boX_wrapper">						
						<div class="suivi_btn_boX">
							<ul>
								<li><a href="#suiviannonce" data-toggle="modal" data-backdrop="true"><i class="fa fa-eye"></i> Annonce</a>												
								</li>
								<li><a href="#suivisuivi" data-toggle="modal" data-backdrop="true"><i class="fa fa-bullseye"></i> Suivi</a></li>						
							</ul>												
						</div>
						<div class="img" style="background-image: url(images/pic4.png)">
							<span class="topBtn">SS</span>
						</div>
						<div class="land_description"><span>4 pièces de 104m2 with under the city</span></div>				
						<div class="suivi_btn_boX">
						<ul>
							<li class="green_Box"><a href=""><i class="fa fa-phone"></i> Moi</a></li>
							<li><a href="">Archiver</a></li>						
						</ul>
						</div>
					</div>
				</div>
				<div class="box">
					<div class="suivi_boX_wrapper">						
						<div class="suivi_btn_boX">
							<ul>
								<li><a href="#suiviannonce" data-toggle="modal" data-backdrop="true"><i class="fa fa-eye"></i> Annonce</a>												
								</li>
								<li><a href="#suivisuivi" data-toggle="modal" data-backdrop="true"><i class="fa fa-bullseye"></i> Suivi</a></li>						
							</ul>												
						</div>
						<div class="img" style="background-image: url(images/pic1.jpg)">
							<span class="topBtn">SP</span>
						</div>
						<div class="land_description"><span>4 pièces de 104m2 with under the city</span></div>				
						<div class="suivi_btn_boX">
						<ul>
							<li class="org_Box"><a href=""><i class="fa fa-phone"></i> Call</a></li>
							<li><a href="">Archiver</a></li>						
						</ul>
						</div>
					</div>	
				</div>
				<div class="box">					
					<div class="suivi_boX_wrapper">						
						<div class="suivi_btn_boX">
							<ul>
								<li><a href="#suiviannonce" data-toggle="modal" data-backdrop="true"><i class="fa fa-eye"></i> Annonce</a>												
								</li>
								<li><a href="#suivisuivi" data-toggle="modal" data-backdrop="true"><i class="fa fa-bullseye"></i> Suivi</a></li>						
							</ul>												
						</div>
						<div class="img" style="background-image: url(images/pic4.png)">
							<span class="topBtn">SS</span>
						</div>
						<div class="land_description"><span>4 pièces de 104m2 with under the city</span></div>				
						<div class="suivi_btn_boX">
						<ul>
							<li class="green_Box"><a href=""><i class="fa fa-phone"></i> Moi</a></li>
							<li><a href="">Archiver</a></li>						
						</ul>
						</div>
					</div>
				</div>		
			</div>
		</div>		
	</div>
	
	<div class="pagination">
		<strong>1</strong>
		<a href="#">2</a>
		<a href="#">3</a>
		<a href="#">></a>
		<a href="#">Last ›</a>			
	</div>
</div>