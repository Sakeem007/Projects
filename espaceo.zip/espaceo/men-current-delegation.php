<div id="interOffrimoWrapper" class="offrimo">
	<div class="offrimoBox">
			<!--<div class="ComparateurBox"><a href="offrimo-maisons-offerlist.php"><i class="fa fa-eye first_home"></i><label>0</label><span>/</span><i class="fa fa-eye Last_home"></i> <b class="ComparateurTXT">Comparateur</b></a></div>-->
		<div class="repter">
			<div class="tablebox">
				<div class="box">
					<div class="img slider_Section">
						<div class="carousel slide" data-ride="carousel" data-type="multi" data-interval="false" id="myCarousel4">
							<div class="carousel-inner">
							  <div class="item active">
								<img src="images/chassimo1.jpg" alt="Los Angeles" style="width:100%;height:220px">
							  </div>
							  <div class="item">
								<img src="images/chassimo2.jpg" alt="Chicago" style="width:100%;height:220px">
							  </div>							
							  <div class="item">
								<img src="images/chassimo3.jpg" alt="New york" style="width:100%;height:220px">
							  </div>
							</div>							
							<a class="left carousel-control" href="#myCarousel4" data-slide="prev">
							  <span class="glyphicon glyphicon-chevron-left"></span>
							  <span class="sr-only">Previous</span>
							</a>
							<a class="right carousel-control" href="#myCarousel4" data-slide="next">
							  <span class="glyphicon glyphicon-chevron-right"></span>
							  <span class="sr-only">Next</span>
							</a>
					    </div>
					</div>
				</div>
				<div class="box">
					<div class="headerTop">Annonce <span>90 000 &euro;</span></div>
					<div class="contents">
						<div class="padRight">
							<p>4 pieces de 87 m²</p>
							<h6 class="locBtn">Amberieu-en-Bugey 01500</h6>
							<p>when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries,</p>
						</div>
						<div class="InterBottomBox">
							<ul>
								<li><a href="#" class="blueBtn">Agence</a></li>
								<li><a href="#" class="blueBtn">Annonce</a></li>
								<li><a href="#" class="blueBtn">0608060708</a></li>
							</ul>
						</div>
					</div>
				</div>
				<div class="box">
					<div class="headerTop">Historique</div>
					<div class="contents">
						<ul class="HistoriqueList">
							<li>Création : </li>
							<li>En ligne depuis : </li>
							<li>Derniéres modifications :</li>
						</ul>	
					</div>
				</div>
				<div class="box">
					<div class="headerTop">Appréciation</div>
					<div class="appreciation">
						<h6>Rankimo: 1/1</h6>
						<p>Votre bien est classe 59/203 a Ambilly "74100" (3 pieces).</p>
						
					</div>
				</div>
				<div class="box">
					<div class="headerTop">Etat</div>
					<div class="contents">
						<p class="DateDemande">Date Demande: 24-02-2020</p>
						<ul class="EtatBtns">
							<li><a href="javascript:voed(0)" class="blueBtn">Relancer</a></li>
							<li><a href="javascript:voed(0)" class="blueBtn">Annuler</a></li>
						</ul>
					</div>
				</div>				
			</div>
		</div>
		<div class="repter">
			<div class="tablebox">
				<div class="box">
					<div class="img slider_Section">
						<div class="carousel slide" data-ride="carousel" data-type="multi" data-interval="false" id="myCarousel3">
							<div class="carousel-inner">
							  <div class="item active">
								<img src="images/offrimo1.png" alt="Los Angeles" style="width:100%;">
							  </div>
							  <div class="item">
								<img src="images/offrimo2.png" alt="Chicago" style="width:100%;">
							  </div>							
							  <div class="item">
								<img src="images/offrimo3.png" alt="New york" style="width:100%;">
							  </div>
							</div>							
							<a class="left carousel-control" href="#myCarousel3" data-slide="prev">
							  <span class="glyphicon glyphicon-chevron-left"></span>
							  <span class="sr-only">Previous</span>
							</a>
							<a class="right carousel-control" href="#myCarousel3" data-slide="next">
							  <span class="glyphicon glyphicon-chevron-right"></span>
							  <span class="sr-only">Next</span>
							</a>
					    </div>
					</div>
				</div>
				<div class="box">
					<div class="headerTop">Annonce <span>90 000 &euro;</span></div>
					<div class="contents">
						<div class="padRight">
							<p>4 pieces de 87 m²</p>
							<h6 class="locBtn">Amberieu-en-Bugey 01500</h6>
							<p>when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries,</p>
						</div>
						<div class="InterBottomBox">
							<ul>
								<li><a href="#" class="blueBtn">Agence</a></li>
								<li><a href="#" class="blueBtn">Annonce</a></li>
								<li><a href="#" class="blueBtn">0608060708</a></li>
							</ul>
						</div>
					</div>
				</div>
				<div class="box">
					<div class="headerTop">Historique</div>
					<div class="contents">
						<ul class="HistoriqueList">
							<li>Création : </li>
							<li>En ligne depuis : </li>
							<li>Derniéres modifications :</li>
						</ul>	
					</div>
				</div>
				<div class="box">
					<div class="headerTop">Appréciation</div>
					<div class="appreciation">
						<h6>Rankimo: 1/1</h6>
						<p>Votre bien est classe 59/203 a Ambilly "74100" (3 pieces).</p>
						
					</div>
				</div>
				<div class="box">
					<div class="headerTop">Etat</div>
					<div class="contents">
						<p class="DateDemande">Date Demande: 24-02-2020</p>
						<ul class="EtatBtns">
							<li><a href="javascript:voed(0)" class="blueBtn">Relancer</a></li>
							<li><a href="javascript:voed(0)" class="blueBtn">Annuler</a></li>
						</ul>
					</div>
				</div>				
			</div>
		</div>
		<div class="repter">
			<div class="tablebox">
				<div class="box">
					<div class="img slider_Section">
						<div class="carousel slide" data-ride="carousel" data-type="multi" data-interval="false" id="myCarousel2">
							<div class="carousel-inner">
							  <div class="item active">
								<img src="images/chassimo4.jpg" alt="Los Angeles" style="width:100%;height:220px">
							  </div>
							  <div class="item">
								<img src="images/chassimo5.jpg" alt="Chicago" style="width:100%;height:220px">
							  </div>							
							  <div class="item">
								<img src="images/chassimo6.jpg" alt="New york" style="width:100%;height:220px">
							  </div>
							</div>							
							<a class="left carousel-control" href="#myCarousel2" data-slide="prev">
							  <span class="glyphicon glyphicon-chevron-left"></span>
							  <span class="sr-only">Previous</span>
							</a>
							<a class="right carousel-control" href="#myCarousel2" data-slide="next">
							  <span class="glyphicon glyphicon-chevron-right"></span>
							  <span class="sr-only">Next</span>
							</a>
					    </div>
					</div>
				</div>
				<div class="box">
					<div class="headerTop">Annonce <span>90 000 &euro;</span></div>
					<div class="contents">
						<div class="padRight">
							<p>4 pieces de 87 m²</p>
							<h6 class="locBtn">Amberieu-en-Bugey 01500</h6>
							<p>when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries,</p>
						</div>
						<div class="InterBottomBox">
							<ul>
								<li><a href="#" class="blueBtn">Agence</a></li>
								<li><a href="#" class="blueBtn">Annonce</a></li>
								<li><a href="#" class="blueBtn">0608060708</a></li>
							</ul>
						</div>
					</div>
				</div>
				<div class="box">
					<div class="headerTop">Historique</div>
					<div class="contents">
						<ul class="HistoriqueList">
							<li>Création : </li>
							<li>En ligne depuis : </li>
							<li>Derniéres modifications :</li>
						</ul>	
					</div>
				</div>
				<div class="box">
					<div class="headerTop">Appréciation</div>
					<div class="appreciation">
						<h6>Rankimo: 1/1</h6>
						<p>Votre bien est classe 59/203 a Ambilly "74100" (3 pieces).</p>
						
					</div>
				</div>
				<div class="box">
					<div class="headerTop">Etat</div>
					<div class="contents">
						<p class="DateDemande">Date Demande: 24-02-2020</p>
						<ul class="EtatBtns">
							<li><a href="javascript:voed(0)" class="blueBtn">Relancer</a></li>
							<li><a href="javascript:voed(0)" class="blueBtn">Annuler</a></li>
						</ul>
					</div>
				</div>				
			</div>
		</div>
	</div>
	
</div>