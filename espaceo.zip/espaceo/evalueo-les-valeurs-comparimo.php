<div class="max-content">
	<div class="row">
		<div class="pinkCont">
			<aside class="leftCol col-xs-12 col-sm-12 col-md-12 col-lg-12 evaleurs_comparimo_wp">	
				<div class="tabContent">					<div id="Maison_Aooartement" class="tabPane fix-top active">						<div class="filter Maison_Aooartement_filter">							<ul>								<li>									<a class="Select_citys"><span id="cityNameForComparimoID">Abondance</span></a>									<ul class="Add_city_dropBox" style="display: none;">										<button class="submit" type="" ></button>										<i class="fa fa-times Add_city_dropBoxClose"></i>										<div class="dropdown_top_sect">											<li><button class="Add_Cty" ><i class="fa fa-plus"></i> Ajouter une ville</button> <button class="Reset_Cty"><i class="fa fa-times"></i> Tout déselectionner</button></li>											<li><span class="input-group-addon">												<span class="fa fa-search"></span>											</span>											<input type="text" autocomplete="off" value="" placeholder="ville,code postal" >											<ul class="suggShow suggDesign" id="suggShowNew">											</ul>											<input style="display:none;" type="text" id="comparimo_place" placeholder="Entrez une adresse" autocomplete="off">																						</li>										</div>										<div class="Added_list">											<ul>												<li><span >Abondance</span> <!--<a><i class="fa fa-times"></i></a>--></li>											</ul>										</div>										<div class="multi_select_item_container">&nbsp;</div>									</ul>								</li>								<li class="mm_Price_Bx">									<input name="" placeholder="Min" type="text" ><input name="" placeholder="Max" type="text"><span>€</span>								</li>								<li class="mm_Price_Bx">									<input name="" placeholder="Min" type="text" ><input name="" placeholder="Max" type="text" ><span>m²</span>								</li>								<li class="mm_Price_Bx">									<select>										<option value="" selected="selected">Min Piéces</option>										<option value="1">1</option>										<option value="2">2</option>										<option value="3">3</option>										<option value="4">4</option>										<option value="5">5</option>									</select>									<select>										<option value="" selected="selected">Max Piéces</option>										<option value="1">1</option>										<option value="2">2</option>										<option value="3">3</option>										<option value="4">4</option>										<option value="5">5</option>										<option value="6">6</option>										<option value="7">7</option>										<option value="8">8</option>										<option value="9">9</option>										<option value="10">10</option>									</select>								</li>								<li class="Keyword_Box"><input name="" placeholder="Mot-cle(s)" type="text" ></li>								<li class="btns">									<button class="submit" type=""></button>            								</li>								<li class="btns">									<a class="resetlast"></a> 								</li>							</ul>						</div>							</div>
				</div>
				<div class="PinkTB_Wrapper">
					<div class="nav-tab">
						<ul>
							<li class="active">
								<a data-toggle="tab" href="#PinkEvalueoComp">0 biens trouves</a>
							</li>
							<li>
								<a data-toggle="tab" href="#GreenEvalueoComp">Sans surfaces</a>
							</li>
						</ul>
					</div>
					<div class="tab-content">
						<div id="PinkEvalueoComp" class="item tab-pane fade in active">
							<div class="listing">
								<ul>
									<li>Liste des biens :</li>
								</ul>
							</div>
							<div class="repater">
								<div class="img" style="background-image: url(images/pic3.png);"><span class="check"></span></div>
								<div class="tblCell">
									<div class="heading">Appartement 2pieces 45<sup>2</sup></div>
									<div class="content">
										<ul>
											<li>Ville: <strong>Seynod 74600</strong></li>
											<li>Type de bien: <strong>Appartement</strong></li>
											<li>Pieces: <strong>2</strong></li>
											<li>Surface: <strong>53 m<sup>3</sup></strong></li>
										</ul>
									</div>
								</div>
								<div class="tblCell">
									<div class="heading">Prix: 219000 &euro;</div>
									<div class="content prix">
										<ul>
											<li><a href="#">Pro</a></li>
											<li><a href="#">Leboncoin</a></li>
										</ul>
									</div>
								</div>
								<div class="tblCell">
									<div class="heading">Appartement 2pieces 45<sup>2</sup></div>
									<div class="content">
										<label><input type="checkbox"/><em></em> <strong>Supprimer du listing</strong></label>
										<label><input type="checkbox"/><em></em> <strong>Selectionner</strong></label>
									</div>
								</div>
							</div>
							<div class="repater">
								<div class="img" style="background-image: url(images/pic3.png);"><span class="check"></span></div>
								<div class="tblCell">
									<div class="heading">Appartement 2pieces 45<sup>2</sup></div>
									<div class="content">
										<ul>
											<li>Ville: <strong>Seynod 74600</strong></li>
											<li>Type de bien: <strong>Appartement</strong></li>
											<li>Pieces: <strong>2</strong></li>
											<li>Surface: <strong>53 m<sup>3</sup></strong></li>
										</ul>
									</div>
								</div>
								<div class="tblCell">
									<div class="heading">Prix: 219000 &euro;</div>
									<div class="content prix">
										<ul>
											<li><a href="#">Pro</a></li>
											<li><a href="#">Leboncoin</a></li>
										</ul>
									</div>
								</div>
								<div class="tblCell">
									<div class="heading">Appartement 2pieces 45<sup>2</sup></div>
									<div class="content">
										<label><input type="checkbox"/><em></em> <strong>Supprimer du listing</strong></label>
										<label><input type="checkbox"/><em></em> <strong>Selectionner</strong></label>
									</div>
								</div>
							</div>
							<div class="resultat" style="background-image: url(images/icon17.png);">
								<h1>Resultat</h1>
								<span>152 500 &euro;</span>
							</div>
						</div>
						<div id="GreenEvalueoComp" class="GreenEvalueoComp item tab-pane fade">
							<div class="listing">
								<ul>
									<li>Liste des biens :</li>
									<li><a href="#">4 biens comparables</a></li>
									<li><a href="#">3 biens sélectionnés</a></li>
									<li><a href="#">1 biens supprimées</a></li>
								</ul>
							</div>
							<div class="repater">
								<div class="img" style="background-image: url(images/pic3.png);"><span class="check"></span></div>
								<div class="tblCell">
									<div class="heading">Appartement  2pieces 45<sup>2</sup></div>
									<div class="content">
										<ul>
											<li>Ville: <strong>Seynod 74600</strong></li>
											<li>Type de bien: <strong>Appartement</strong></li>
											<li>Pieces: <strong>2</strong></li>
											<li>Surface: <strong>53 m<sup>3</sup></strong></li>
										</ul>
									</div>
								</div>
								<div class="tblCell">
									<div class="heading">Prix: 219000 &euro;</div>
									<div class="content prix">
										<ul>
											<li><a href="#">Pro</a></li>
											<li><a href="#">Leboncoin</a></li>
										</ul>
									</div>
								</div>
								<div class="tblCell">
									<div class="heading">Appartement 2pieces 45<sup>2</sup></div>
									<div class="content">
										<label><input type="checkbox"/><em></em> <strong>Supprimer du listing</strong></label>
										<label><input type="checkbox"/><em></em> <strong>Selectionner</strong></label>
									</div>
								</div>
							</div>
							<div class="repater">
								<div class="img" style="background-image: url(images/pic3.png);"><span class="check"></span></div>
								<div class="tblCell">
									<div class="heading">Appartement  2pieces 45<sup>2</sup></div>
									<div class="content">
										<ul>
											<li>Ville: <strong>Seynod 74600</strong></li>
											<li>Type de bien: <strong>Appartement</strong></li>
											<li>Pieces: <strong>2</strong></li>
											<li>Surface: <strong>53 m<sup>3</sup></strong></li>
										</ul>
									</div>
								</div>
								<div class="tblCell">
									<div class="heading">Prix: 219000 &euro;</div>
									<div class="content prix">
										<ul>
											<li><a href="#">Pro</a></li>
											<li><a href="#">Leboncoin</a></li>
										</ul>
									</div>
								</div>
								<div class="tblCell">
									<div class="heading">Appartement 2pieces 45<sup>2</sup></div>
									<div class="content">
										<label><input type="checkbox"/><em></em> <strong>Supprimer du listing</strong></label>
										<label><input type="checkbox"/><em></em> <strong>Selectionner</strong></label>
									</div>
								</div>
							</div>
							<div class="repater">
								<div class="img" style="background-image: url(images/pic3.png);"><span class="check"></span></div>
								<div class="tblCell">
									<div class="heading">Appartement  2pieces 45<sup>2</sup></div>
									<div class="content">
										<ul>
											<li>Ville: <strong>Seynod 74600</strong></li>
											<li>Type de bien: <strong>Appartement</strong></li>
											<li>Pieces: <strong>2</strong></li>
											<li>Surface: <strong>53 m<sup>3</sup></strong></li>
										</ul>
									</div>
								</div>
								<div class="tblCell">
									<div class="heading">Prix: 219000 &euro;</div>
									<div class="content prix">
										<ul>
											<li><a href="#">Pro</a></li>
											<li><a href="#">Leboncoin</a></li>
										</ul>
									</div>
								</div>
								<div class="tblCell">
									<div class="heading">Appartement 2pieces 45<sup>2</sup></div>
									<div class="content">
										<label><input type="checkbox"/><em></em> <strong>Supprimer du listing</strong></label>
										<label><input type="checkbox"/><em></em> <strong>Selectionner</strong></label>
									</div>
								</div>
							</div>
							<div class="resultat" style="background-image: url(images/icon17.png);">
								<h1>Resultat</h1>
								<span>152 500 &euro;</span>
							</div>
						</div>				
					</div>
				</div>
			</aside>			
		</div>
	</div>
</div>