<?php include('header.php');?>
	
	<!-- Being: offrimo box -->
	<article class="offrimoBox">
		<div class="container">	
			<nav class="nav nav-tab">
				<ul>
					<li class="active"><a href="#MarketimoEtudeo" data-toggle="tab">Etudeo<small>"Etude de marché"</small></a></li>
					<li><a href="#MarketimoEvalueo" data-toggle="tab">Evalueo<small>"Avis de valeur"</small></a></li>
				</ul>
			</nav>
			<div class="tab-content">
				<div class="row">
					<div class="tab-content" style="box-shadow:inherit;">
						<div id="MarketimoEtudeo" class="item tab-pane fade in active">
							<div class="row">
								<?php include('etudeo.php');?>
							</div>
						</div>
						<div id="MarketimoEvalueo" class="item tab-pane fade">
							<div class="row">
								<?php include('evalueo.php');?>
							</div>
						</div>			
					</div>
				</div>
			</div>
			
		</div>
	</article>
	<!-- End: offrimo box -->

<?php include('footer.php');?>
<?php include('modal.php');?>