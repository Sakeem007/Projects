<div class="mesAnnonceVsOffrimo">
	<div class="banners" style="background-image: url(images/bg-5.jpg);">		
		<p>"Je veux comparer mes annonces à celles similaires, grâce à l'offre immobilière en temps réel, pour mes annonces de  </p>  
		<h5><select>
			<option>Maisons/Appartements/Terrains</option>
			<option>Maisons/Appartements</option>
		</select>  v situées à &nbsp;
		<input name="" placeholder="Code postal,ville" type="text" /></h5>		
		<p>av , et pouvoir ainsi créer des accroches concurrentielles, avec l'option voir les accroches de Mon équipe v " </p>
	</div>
	
	<div class="row">
		<div class="comparimo_filter">
			<form action="#" method="post">
				<div class="boxs col-xs-4 col-sm-3 col-md-3 col-lg-3">
					<div class="comparimoTxt_boX">
						<span class="heading">Mes annonces</span>
						<ul>
							<li><select>
								<option hidden>Toutes</option>
								<option value="Actives">Actives</option>
								<option value="Acroches">Archivées</option>
								<option value="Archiver">Archiver</option>
							</select></li>
							<li><select>
								<option hidden>Prix</option>
								<option value="">Croissant</option>
								<option value="">Prix décroissant</option>
							</select></li>
							<li>
								<input name="" placeholder="Parution" type="text" />
							</li>
							<li class="btns">
								<button class="submit" type="submit"></button>            
							</li>
							<li class="btns">
								<a class="resetlast" href=""></a> 
							</li>
						</ul>
					</div>
				</div>
				<div class="boxs col-xs-4 col-sm-6 col-md-6 col-lg-6">
					<div class="comparimoTxt_boX comparimoTxt_boX2">					
						<span class="heading">Ofrrimo:"L'offre immobilière en temps réel."</span>
						<ul>
							<li><select>
								<option hidden>PRO/PAP</option>
								<option value="Actives">PRO</option>
								<option value="Acroches">PAP</option>
							</select></li>
							<li><select>
								<option hidden>Par agence</option>
								<option value="">offer</option>
								<option value="">agency</option>
							</select></li>
							<li>
								<input name="" placeholder="Parution" type="text" />
							</li>
							<li class="btns">
								<button class="submit" type="submit"></button>            
							</li>
							<li class="btns">
								<a class="resetlast" href=""></a> 
							</li>
							<li class="btns">
								<label>
									<span>Annonces ignorées</span>
								<div class="switch">
									<input type="checkbox">
									<span class="slider round"></span>
									</div>
								</label>
							</li>
						</ul>
					</div>
				</div>
				<div class="boxs col-xs-4 col-sm-3 col-md-3 col-lg-3">
					<div class="comparimoTxt_boX">
						<span class="heading">Mon ciblage</span>						
					</div>
				</div>
			</form>
		</div>
		<div class="repter">
			<div class="boxs col-xs-12 col-sm-3 col-md-3 col-lg-3">
				<div class="border">
					<div class="Cont_Box_wp">	
						<div class="Vs_arrow_wrapper" onclick="showhide()"><span>0</span></div>	
						<div class="suivi_btn_boX">
							<ul>
								<li>L'immobilier</li>
								<li>490000 &euro;</li>						
							</ul>												
						</div>	
						<div class="whol_wrapper">	
							<div class="text">
							<h6>Appartement duplex T4</h6>
							<p>Cove + goroge double en sous-sol + porking privotif.Acces facile outoroute Annecy Nord et Allozier (Bordonnex a 20 min) Chouffoge individuel goz. Charges copro. 100 € / mois</p>
							<ul>
								<li><a href="#"><i class="fa fa-map-marker"></i> Douvaine</a></li>
								<li><a href="#"><i class="fa fa-external-link"></i> En savoir plus</a></li>
							</ul>
						</div>	
							<div class="img" style="background-image: url(images/pic4.png);">
							</div>
							<div class="Price_clom_Box">
								<div class="Price_clom_firstBox" style="background-image: url(images/offrimo2.png);"></div>
								<div class="Price_clom_lasttBox" style="background-image: url(images/pic2.jpg);"></div>
							</div>
						</div>
						<div class="suivi_btn_boX2">
							<ul class="Offers_list">		
								<li><a href="#"> Archiver</a></li>
								<li class="dropdown"><a href="#" data-toggle="dropdown">Historique</a>
									<div class="dropdown-menu multi-column">
									  <div class="property_compare_wrappers">
										<div class="table_box_wrapper">
										  <table class="table_selected" width="100%" border="0" cellspacing="10" cellpadding="0">
											<thead>
											<p>Evolution du prix</p>
											  <tr>
												<th></th>
												<th class="text-center "> 23/10/2013 </th>
												<th class="text-center "> 25/07/2015 </th>
												<th class="text-center "> 15/10/2015 </th>
												<th class="text-center "> 17/12/2015 </th>
												<th class="text-center "> 18/12/2015 </th>
												<th class="text-center "> 07/01/2016 </th>
												<th class="text-center "> 13/01/2016 </th>
												<th class="text-center "> 11/02/2016 </th>
												<th class="text-center "> 13/02/2016 </th>
												<th class="text-center "> 02/03/2016 </th>
												<th class="text-center "> 13/10/2016 </th>
												<th class="text-center "> 13/02/2018 </th>
												<th class="text-center "> 15/02/2018 </th>
												<th class="text-center "> 16/02/2018 </th>
												<th class="text-center "> 26/02/2018 </th>
												<th class="text-center "> 09/03/2018 </th>
												<th class="text-center "> 10/04/2018 </th>
												<th class="text-center "> 27/04/2018 </th>
												<th class="text-center "> 07/07/2018 </th>
												<th class="text-center "> 13/07/2018 </th>
											  </tr>
											</thead>
											<tbody>
											  <tr class="text-nowrap frst_Tbl_row">
												<td class="ng-binding"><span><i class="fa fa-home"></i></span> L'immobilier </td>
												<td class="text-center " >-</td>
												<td class="text-center " >-</td>
												<td class="text-center " >-</td>
												<td class="text-center " >-</td>
												<td class="text-center " >-</td>
												<td class="text-center " >-</td>
												<td class="text-center " >-</td>
												<td class="text-center " >-</td>
												<td class="text-center " >-</td>
												<td class="text-center " >-</td>
												<td class="text-center " >-</td>
												<td class="text-center " >-</td>
												<td class="text-center " >-</td>
												<td class="text-center " >-</td>
												<td class="text-center " >-</td>
												<td class="text-center " >-</td>
												<td class="text-center " >-</td>
												<td class="text-center " >-</td>
												<td class="text-center " >-</td>
												<td class="text-center " >
												<div class="price_list_offer">
													<div class="label ng-binding label-warning" > 1&nbsp;470&nbsp;000 € </div>
													<div class="ng-binding"><span> 0 %</span>  </div>
												  </div></td>
											  </tr>
											  <tr ng-repeat="dealer in ::dealers" class="text-nowrap ">
												<td class="ng-binding"><span><i class="fa fa-home"></i></span> Lac Et Frontiere Immobilier </td>
												<td class="text-center" >
												<div class="price_list_offer">
													<div class="label ng-binding label-default" > 2&nbsp;750&nbsp;000 € </div>
													<div class="ng-binding"> <span> 0 %</span> </div>
												  </div>
												  </td>
												<td class="text-center" >
												<div class="price_list_offer">
													<div class="label ng-binding label-danger" > 2&nbsp;750&nbsp;000 € </div>
													<div class="ng-binding"><span> 0 %</span> </div>
												  </div>
												  </td>
												<td class="text-center">
												<div class="price_list_offer">
													<div class="label ng-binding label-success" > 2&nbsp;200&nbsp;000 € </div>
													<div class="ng-binding"><i class="fa fa-arrow-down text-success"></i><span> -20,00 %</span> </div>
												  </div>
												  </td>
												<td class="text-center">
												<div class="price_list_offer">
													<div class="label ng-binding label-success" > 2&nbsp;335&nbsp;000 € </div>
													<div class="ng-binding"> <i class="fa fa-arrow-up text-danger"></i><span>+6,14 % </span>  </div>
												  </div></td>
												<td class="text-center">
												<div class="price_list_offer">
													<div class="label ng-binding label-danger" > 2&nbsp;335&nbsp;000 € </div>
													<div class="ng-binding"><span>0 % </span>  </div>
												  </div>
												  </td>
												<td class="text-center " >
												<div class="price_list_offer">
													<div class="label ng-binding label-warning" > 2&nbsp;320&nbsp;000 € </div>
													<div class="ng-binding"><i class="fa fa-arrow-down text-success"></i><span> -0,64 %</span>  </div>
												  </div></td>
												<td class="text-center " >
												<div class="price_list_offer">
													<div class="label ng-binding label-success" > 2&nbsp;320&nbsp;000 € </div>
													<div class="ng-binding"><span>0 % </span>  </div>
												  </div></td>
												<td class="text-center " >
												<div class="price_list_offer">
													<div class="label ng-binding label-danger" > 2&nbsp;320&nbsp;000 € </div>
													<div class="ng-binding"> <span> 0 %</span>  </div>
												  </div></td>
												<td class="text-center " >
												<div class="price_list_offer">
													<div class="label ng-binding label-warning" > 2&nbsp;320&nbsp;000 € </div>
													<div class="ng-binding"> <span> 0 % </span> </div>
												  </div></td>
												<td class="text-center " ><div class="price_list_offer">
													<div class="label ng-binding label-danger" > 2&nbsp;320&nbsp;000 € </div>
													<div class="ng-binding"><span> 0 %</span>  </div>
												  </div></td>
												<td class="text-center " ><div class="price_list_offer">
													<div class="label ng-binding label-danger" > 2&nbsp;320&nbsp;000 € </div>
													<div class="ng-binding"> <span>0 % </span>  </div>
												  </div></td>
												<td class="text-center " ><div class="price_list_offer">
													<div class="label ng-binding label-success" > 1&nbsp;900&nbsp;000 € </div>
													<div class="ng-binding"> <i class="fa fa-arrow-down text-success"></i><span> -18,10 %</span>  </div>
												  </div></td>
												<td class="text-center " ><div class="price_list_offer">
													<div class="label ng-binding label-success" > 1&nbsp;900&nbsp;000 € </div>
													<div class="ng-binding"> <span> 0 %</span>  </div>
												  </div></td>
												<td class="text-center " ><div class="price_list_offer">
													<div class="label ng-binding label-danger" > 1&nbsp;995&nbsp;000 € </div>
													<div class="ng-binding"> <i class="fa fa-arrow-up text-danger"></i><span> +5,00 %</span>  </div>
												  </div></td>
												<td class="text-center " ><div class="price_list_offer">
													<div class="label ng-binding label-warning" > 1&nbsp;995&nbsp;000 € </div>
													<div class="ng-binding"> <span> 0 %</span>  </div>
												  </div></td>
												<td class="text-center">		
												<div class="price_list_offer">
													<div class="label ng-binding label-danger" > 1&nbsp;995&nbsp;000 € </div>
													<div class="ng-binding"> <span> 0 %</span>  </div>
												  </div></td>
												<td class="text-center " ><div class="price_list_offer">
													<div class="label ng-binding label-success" > 1&nbsp;470&nbsp;000 € </div>
													<div class="ng-binding"><i class="fa fa-arrow-down text-success"></i><span> -26,32 %</span>  </div>
												  </div></td>
												<td class="text-center " ><div class="price_list_offer">
													<div class="label ng-binding label-success" > 1&nbsp;470&nbsp;000 € </div>
													<div class="ng-binding"> <span> 0 %</span>  </div>
												  </div></td>
												<td class="text-center " ><div class="price_list_offer">
													<div class="label ng-binding label-warning" > 1&nbsp;470&nbsp;000 € </div>
													<div class="ng-binding"> <span>0 % </span>  </div>
												  </div></td>
												<td class="text-center " ><div class="price_list_offer">
													<div class="label ng-binding label-warning" > 1&nbsp;470&nbsp;000 € </div>
													<div class="ng-binding"><span>0 % </span>  </div>
												  </div></td>
											  </tr>
											  <tr ng-repeat="dealer in ::dealers" class="text-nowrap ">
												<td class="ng-binding"><span><i class="fa fa-home"></i></span> Espaces Atypiques Annecy </td>
												<td class="text-center " >-</td>
												<td class="text-center " ><div class="price_list_offer">
													<div class="label ng-binding label-success" > 2&nbsp;749&nbsp;000 € </div>
													<div class="ng-binding"> <span> 0 %</span>  </div>
												  </div></td>
												<td class="text-center " ><div class="price_list_offer">
													<div class="label ng-binding label-danger" > 2&nbsp;749&nbsp;000 € </div>
													<div class="ng-binding"> <span> 0 %</span>  </div>
												  </div></td>
												<td class="text-center " ><div class="price_list_offer">
													<div class="label ng-binding label-danger" > 2&nbsp;749&nbsp;000 € </div>
													<div class="ng-binding"> <span>0 % </span>  </div>
												  </div></td>
												<td class="text-center " ><div class="price_list_offer">
													<div class="label ng-binding label-success" > 2&nbsp;320&nbsp;000 € </div>
													<div class="ng-binding"> <i class="fa fa-arrow-down text-success"></i><span> -15,61 %</span>  </div>
												  </div></td>
												<td class="text-center " ><div class="price_list_offer">
													<div class="label ng-binding label-warning" > 2&nbsp;320&nbsp;000 € </div>
													<div class="ng-binding"><span> 0 %</span>  </div>
												  </div></td>
												<td class="text-center " ><div class="price_list_offer">
													<div class="label ng-binding label-danger" > 2&nbsp;330&nbsp;000 € </div>
													<div class="ng-binding"><i class="fa fa-arrow-up text-danger"></i><span>+0,43 % </span>  </div>
												  </div></td>
												<td class="text-center " ><div class="price_list_offer">
													<div class="label ng-binding label-success" > 2&nbsp;310&nbsp;000 € </div>
													<div class="ng-binding"> <i class="fa fa-arrow-down text-success"></i><span> -0,86 %</span>  </div>
												  </div></td>
												<td class="text-center " ><div class="price_list_offer">
													<div class="label ng-binding label-warning" > 2&nbsp;320&nbsp;000 € </div>
													<div class="ng-binding"><i class="fa fa-arrow-up text-danger"></i><span> +0,43 %</span>  </div>
												  </div></td>
												<td class="text-center " ><div class="price_list_offer">
													<div class="label ng-binding label-success" > 2&nbsp;310&nbsp;000 € </div>
													<div class="ng-binding"><i class="fa fa-arrow-down text-success"></i><span> -0,43 %</span>  </div>
												  </div></td>
												<td class="text-center " ><div class="price_list_offer">
													<div class="label ng-binding label-success" > 2&nbsp;310&nbsp;000 € </div>
													<div class="ng-binding"><span>0 % </span>  </div>
												  </div></td>
												<td class="text-center " ><div class="price_list_offer">
													<div class="label ng-binding label-danger" > 2&nbsp;310&nbsp;000 € </div>
													<div class="ng-binding"> <span> 0 %</span>  </div>
												  </div></td>
												<td class="text-center " ><div class="price_list_offer">
													<div class="label ng-binding label-danger" > 1&nbsp;995&nbsp;000 € </div>
													<div class="ng-binding"> <i class="fa fa-arrow-down text-success"></i><span> -13,64 %</span>  </div>
												  </div></td>
												<td class="text-center " ><div class="price_list_offer">
													<div class="label ng-binding label-danger" > 1&nbsp;995&nbsp;000 € </div>
													<div class="ng-binding"><span> 0 %</span>  </div>
												  </div></td>
												<td class="text-center" ><div class="price_list_offer">
													<div class="label ng-binding label-warning" > 1&nbsp;995&nbsp;000 € </div>
													<div class="ng-binding"> <span> 0 %</span>  </div>
												  </div></td>
												<td class="text-center " ><div class="price_list_offer">
													<div class="label ng-binding label-success" > 1&nbsp;680&nbsp;000 € </div>
													<div class="ng-binding"><i class="fa fa-arrow-down text-success"></i><span> -15,79 %</span>  </div>
												  </div></td>
												<td class="text-center " ><div class="price_list_offer">
													<div class="label ng-binding label-danger" > 1&nbsp;680&nbsp;000 € </div>
													<div class="ng-binding"> <span> 0 %</span>  </div>
												  </div></td>
												<td class="text-center " ><div class="price_list_offer">
													<div class="label ng-binding label-success" > 1&nbsp;470&nbsp;000 € </div>
													<div class="ng-binding"><i class="fa fa-arrow-down text-success"></i><span> -12,50 %</span>  </div>
												  </div></td>
												<td class="text-center " ><div class="price_list_offer">
													<div class="label ng-binding label-warning" > 1&nbsp;470&nbsp;000 € </div>
													<div class="ng-binding"> <span> 0 %</span>  </div>
												  </div></td>
												<td class="text-center " ><div class="price_list_offer">
													<div class="label ng-binding label-warning" > 1&nbsp;470&nbsp;000 € </div>
													<div class="ng-binding"><span> 0 %</span>  </div>
												  </div></td>
											  </tr>
											  <tr ng-repeat="dealer in ::dealers" class="text-nowrap ">
												<td class="ng-binding"><span><i class="fa fa-home"></i></span> lac leman </td>
												<td class="text-center " >-</td>
												<td class="text-center " >-</td>
												<td class="text-center " >-</td>
												<td class="text-center " >-</td>
												<td class="text-center " >-</td>
												<td class="text-center " >-</td>
												<td class="text-center " >-</td>
												<td class="text-center " >-</td>
												<td class="text-center " >-</td>
												<td class="text-center " >-</td>
												<td class="text-center " ><div class="price_list_offer">
													<div class="label ng-binding label-danger" > 2&nbsp;330&nbsp;000 € </div>
													<div class="ng-binding"> <span> 0 %</span>  </div>
												  </div></td>
												<td class="text-center " ><div class="price_list_offer">
													<div class="label ng-binding label-success" > 1&nbsp;900&nbsp;000 € </div>
													<div class="ng-binding"> <i class="fa fa-arrow-down text-success"></i><span> -18,45 %</span>  </div>
												  </div></td>
												<td class="text-center " ><div class="price_list_offer">
													<div class="label ng-binding label-success" > 1&nbsp;900&nbsp;000 € </div>
													<div class="ng-binding"> <span> 0 %</span>  </div>
												  </div></td>
												<td class="text-center " ><div class="price_list_offer">
													<div class="label ng-binding label-success" > 1&nbsp;900&nbsp;000 € </div>
													<div class="ng-binding"> <span> 0 %</span>  </div>
												  </div></td>
												<td class="text-center " ><div class="price_list_offer">
													<div class="label ng-binding label-warning" > 1&nbsp;995&nbsp;000 € </div>
													<div class="ng-binding"> <i class="fa fa-arrow-up text-danger"></i><span> +5,00 %</span>  </div>
												  </div></td>
												<td class="text-center " ><div class="price_list_offer">
													<div class="label ng-binding label-danger" > 1&nbsp;685&nbsp;000 € </div>
													<div class="ng-binding"> <i class="fa fa-arrow-down text-success"></i><span> -15,54 %</span>  </div>
												  </div></td>
												<td class="text-center " ><div class="price_list_offer">
													<div class="label ng-binding label-danger" > 1&nbsp;685&nbsp;000 € </div>
													<div class="ng-binding"><span> 0 %</span>  </div>
												  </div></td>
												<td class="text-center " ><div class="price_list_offer">
													<div class="label ng-binding label-danger" > 1&nbsp;475&nbsp;000 € </div>
													<div class="ng-binding"> <i class="fa fa-arrow-down text-success"></i><span> -12,46 %</span>  </div>
												  </div></td>
												<td class="text-center " ><div class="price_list_offer">
													<div class="label ng-binding label-warning" > 1&nbsp;470&nbsp;000 € </div>
													<div class="ng-binding"> <i class="fa fa-arrow-down text-success"></i><span> -0,34 %</span>  </div>
												  </div>
												<td class="text-center " ><div class="price_list_offer">
													<div class="label ng-binding label-warning" > 1&nbsp;470&nbsp;000 € </div>
													<div class="ng-binding"><span> 0 %</span>  </div>
												  </div></td>
											  </tr>
											</tbody>
										  </table>
										  </div>
										</div>

									</div>
								</li>	
								<li class="Icon_Wp"><a href="#"><img src="images/capture_icon.png"></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
			<div class="boxs col-xs-12 col-sm-6 col-md-6 col-lg-6">
				<div class="border">
					<span class="heading">Ofrrimo</span>
					<div class="comparimo-annonces-vs-offrimo-1 carousel slide" data-interval="false"  data-ride="carousel">	
						<div class="carousel-inner">
							<div class="item active">
								<div class="wi-50">
									<div class="Cont_Box_wp Cont_Box_wp_second">			
										<div class="suivi_btn_boX">
											<ul>
												<li>L'immobilier</li>
												<li>475000 &euro;</li>						
											</ul>												
										</div>	
										<div class="whol_wrapper">	
											<div class="text">
											<h6>Appartement duplex T4</h6>
											<p>Cove + goroge double en sous-sol + porking privotif.Acces facile outoroute Annecy Nord et Allozier (Bordonnex a 20 min) Chouffoge individuel goz. Charges copro. 100 € / mois</p>
											<ul>
												<li><a href="#"><i class="fa fa-map-marker"></i> Douvaine</a></li>
												<li><a href="#"><i class="fa fa-external-link"></i> En savoir plus</a></li>
											</ul>
										</div>	
											<div class="img" style="background-image: url(images/pic4.png);">
											</div>
											<div class="Price_clom_Box">
												<div class="Price_clom_firstBox" style="background-image: url(images/offrimo2.png);"></div>
												<div class="Price_clom_lasttBox" style="background-image: url(images/pic2.jpg);"></div>
											</div>
										</div>
										<div class="suivi_btn_boX2">
											<ul>
												<li class="Icon_Wp"><a href="#suiviannonce" data-toggle="modal" data-backdrop="true"><i class="fa fa-eye"></i></a></li>	
												<li><a href="#">Accrocher</a></li>
												<li><a href="#">Historique</a></li>							
											</ul>												
										</div>															
									</div>
								</div>
								<div class="wi-50 Cont_Box_wp_third">
									<div class="Cont_Box_wp">			
										<div class="suivi_btn_boX">
											<ul>
												<li>L'immobilier</li>
												<li>475000 &euro;</li>						
											</ul>												
										</div>	
										<div class="whol_wrapper">	
											<div class="text">
											<h6>Appartement duplex T4</h6>
											<p>Cove + goroge double en sous-sol + porking privotif.Acces facile outoroute Annecy Nord et Allozier (Bordonnex a 20 min) Chouffoge individuel goz. Charges copro. 100 € / mois</p>
											<ul>
												<li><a href="#"><i class="fa fa-map-marker"></i> Douvaine</a></li>
												<li><a href="#"><i class="fa fa-external-link"></i> En savoir plus</a></li>
											</ul>
											</div>	
											<div class="img" style="background-image: url(images/pic4.png);">
											</div>
											<div class="Price_clom_Box">
												<div class="Price_clom_firstBox" style="background-image: url(images/offrimo2.png);"></div>
												<div class="Price_clom_lasttBox" style="background-image: url(images/pic2.jpg);"></div>
											</div>
										</div>
									<div class="suivi_btn_boX2">
										<ul>
											<li class="Icon_Wp"><a href="#suiviannonce" data-toggle="modal" data-backdrop="true"><i class="fa fa-eye"></i></a></li>	
											<li><a href="#"><i class="fa fa-times"></i> Ignorer</a></li>
											<li><a href="#">Historique</a></li>							
										</ul>												
									</div>															
									</div>
								</div>
							</div>
							<div class="item">
								<div class="wi-50">
									<div class="Cont_Box_wp Cont_Box_wp_second">			
										<div class="suivi_btn_boX">
											<ul>
												<li>L'immobilier</li>
												<li>475000 &euro;</li>						
											</ul>												
										</div>	
										<div class="whol_wrapper">	
											<div class="text">
											<h6>Appartement duplex T4</h6>
											<p>Cove + goroge double en sous-sol + porking privotif.Acces facile outoroute Annecy Nord et Allozier (Bordonnex a 20 min) Chouffoge individuel goz. Charges copro. 100 € / mois</p>
											<ul>
												<li><a href="#"><i class="fa fa-map-marker"></i> Douvaine</a></li>
												<li><a href="#"><i class="fa fa-external-link"></i> En savoir plus</a></li>
											</ul>
											</div>	
											<div class="img" style="background-image: url(images/pic4.png);">
											</div>
											<div class="Price_clom_Box">
												<div class="Price_clom_firstBox" style="background-image: url(images/offrimo2.png);"></div>
												<div class="Price_clom_lasttBox" style="background-image: url(images/pic2.jpg);"></div>
											</div>
										</div>
									<div class="suivi_btn_boX2">
										<ul>
											<li class="Icon_Wp"><a href="#suiviannonce" data-toggle="modal" data-backdrop="true"><i class="fa fa-eye"></i></a></li>	
											<li><a href="#">Accrocher</a></li>
											<li><a href="#">Historique</a></li>			
										</ul>												
									</div>															
									</div>
								</div>
								<div class="wi-50 Cont_Box_wp_third">
									<div class="Cont_Box_wp">			
										<div class="suivi_btn_boX">
											<ul>
												<li>L'immobilier</li>
												<li>475000 &euro;</li>						
											</ul>												
										</div>	
										<div class="whol_wrapper">	
											<div class="text">
											<h6>Appartement duplex T4</h6>
											<p>Cove + goroge double en sous-sol + porking privotif.Acces facile outoroute Annecy Nord et Allozier (Bordonnex a 20 min) Chouffoge individuel goz. Charges copro. 100 € / mois</p>
											<ul>
												<li><a href="#"><i class="fa fa-map-marker"></i> Douvaine</a></li>
												<li><a href="#"><i class="fa fa-external-link"></i> En savoir plus</a></li>
											</ul>
										</div>	
											<div class="img" style="background-image: url(images/pic4.png);">
											</div>
											<div class="Price_clom_Box">
												<div class="Price_clom_firstBox" style="background-image: url(images/offrimo2.png);"></div>
												<div class="Price_clom_lasttBox" style="background-image: url(images/pic2.jpg);"></div>
											</div>
										</div>
									<div class="suivi_btn_boX2">
										<ul>
											<li class="Icon_Wp"><a href="#suiviannonce" data-toggle="modal" data-backdrop="true"><i class="fa fa-eye"></i></a></li>	
											<li><a href="#"><i class="fa fa-times"></i> Ignorer</a></li>
											<li><a href="#">Historique</a></li>							
										</ul>												
									</div>															
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="boxs col-xs-12 col-sm-3 col-md-3 col-lg-3">
				<div class="border">
					<span class="heading">Fonctions</span>
					<div class="ignorerText">
						<h5>Elargir</h5>
						<div class="slidecontainer">
							<em>
							  <input type="range" min="1" max="100" value="50" class="slider" id="myRange">
							</em>
							<p><span>Non</span><span>&nbsp;</span><span>Large</span></p>					  
						</div>						
						<div class="prevNext">
							<a href=".comparimo-annonces-vs-offrimo-1" data-slide="prev" class="fa fa-angle-left"></a>
							<a href=".comparimo-annonces-vs-offrimo-1" data-slide="next" class="fa fa-angle-right"></a>
							
							<span><em>2/2</em></span>
						</div>
					</div>
					<a href="#" class="yellowBtn">Tout ignorer ( 10 ignorers )</a>
					<span class="ignorée_WP">(0 ignorée) </span>
				</div>
			</div>
	</div>
		<div class="repter">
			<div class="boxs col-xs-12 col-sm-3 col-md-3 col-lg-3">
				<div class="border">
					<div class="Cont_Box_wp">
						<div class="Vs_arrow_wrapper" onclick="showhide()"><span>2</span></div>	
						<div class="suivi_btn_boX">
							<ul>
								<li>L'immobilier</li>
								<li>490000 &euro;</li>						
							</ul>												
						</div>	
						<div class="whol_wrapper">	
							<div class="text">
							<h6>Appartement duplex T4</h6>
							<p>Cove + goroge double en sous-sol + porking privotif.Acces facile outoroute Annecy Nord et Allozier (Bordonnex a 20 min) Chouffoge individuel goz. Charges copro. 100 € / mois</p>
							<ul>
								<li><a href="#"><i class="fa fa-map-marker"></i> Douvaine</a></li>
								<li><a href="#"><i class="fa fa-external-link"></i> En savoir plus</a></li>
							</ul>
						</div>	
							<div class="img" style="background-image: url(images/pic4.png);">
							</div>
							<div class="Price_clom_Box">
								<div class="Price_clom_firstBox" style="background-image: url(images/offrimo2.png);"></div>
								<div class="Price_clom_lasttBox" style="background-image: url(images/pic2.jpg);"></div>
							</div>
						</div>
					<div class="suivi_btn_boX2">
						<ul>		
							<li><a href="#">Archiver</a></li>
							<li><a href="#">Historique</a></li>	
							<li class="Icon_Wp"><a href="#"><img src="images/capture_icon.png"></a></li>						
						</ul>												
					</div>						
					</div>
				</div>
			</div>
			
			
			
			
			<div class="boxs col-xs-12 col-sm-9 col-md-9 col-lg-9">
				<div id="ShowHide_Wrapper" style="display:block">
					<div class="boxs col-xs-12 col-sm-8 col-md-8 col-lg-8">
					<div class="border">
					<span class="heading">Ofrrimo</span>
						<div class="ofrrimo_mes_annonces">
							<div class="owl-carousel owl-theme">					            
								<div class="item">
								  <div class="wi-50">
									<div class="Cont_Box_wp Cont_Box_wp_second">			
										<div class="suivi_btn_boX">
											<ul>
												<li>L'immobilier</li>
												<li>475000 &euro;</li>						
											</ul>												
										</div>	
										<div class="whol_wrapper">	
											<div class="text">
											<h6>Appartement duplex T4</h6>
											<p>Cove + goroge double en sous-sol + porking privotif.Acces facile outoroute Annecy Nord et Allozier (Bordonnex a 20 min) Chouffoge individuel goz. Charges copro. 100 € / mois</p>
											<ul>
												<li><a href="#"><i class="fa fa-map-marker"></i> Douvaine</a></li>
												<li><a href="#"><i class="fa fa-external-link"></i> En savoir plus</a></li>
											</ul>
										</div>	
											<div class="img" style="background-image: url(images/pic4.png);">
											</div>
											<div class="Price_clom_Box">
												<div class="Price_clom_firstBox" style="background-image: url(images/offrimo2.png);"></div>
												<div class="Price_clom_lasttBox" style="background-image: url(images/pic2.jpg);"></div>
											</div>
										</div>
									<div class="suivi_btn_boX2">
										<ul>
											<li class="Icon_Wp"><a href="#suiviannonce" data-toggle="modal" data-backdrop="true"><i class="fa fa-eye"></i></a></li>	
											<li><a href="#">Accrocher</a></li>
											<li><a href="#">Historique</a></li>			
										</ul>												
									</div>															
									</div>
								</div>
								</div>
								<div class="item">
								  <div class="wi-50 Cont_Box_wp_third">
									<div class="Cont_Box_wp">			
										<div class="suivi_btn_boX">
											<ul>
												<li>L'immobilier</li>
												<li>475000 &euro;</li>						
											</ul>												
										</div>	
										<div class="whol_wrapper">	
											<div class="text">
											<h6>Appartement duplex T4</h6>
											<p>Cove + goroge double en sous-sol + porking privotif.Acces facile outoroute Annecy Nord et Allozier (Bordonnex a 20 min) Chouffoge individuel goz. Charges copro. 100 € / mois</p>
											<ul>
												<li><a href="#"><i class="fa fa-map-marker"></i> Douvaine</a></li>
												<li><a href="#"><i class="fa fa-external-link"></i> En savoir plus</a></li>
											</ul>
										</div>	
											<div class="img" style="background-image: url(images/pic4.png);">
											</div>
											<div class="Price_clom_Box">
												<div class="Price_clom_firstBox" style="background-image: url(images/offrimo2.png);"></div>
												<div class="Price_clom_lasttBox" style="background-image: url(images/pic2.jpg);"></div>
											</div>
										</div>
									<div class="suivi_btn_boX2">
										<ul>
											<li class="Icon_Wp"><a href="#suiviannonce" data-toggle="modal" data-backdrop="true"><i class="fa fa-eye"></i></a></li>	
											<li><a href="#"><i class="fa fa-times"></i> Ignorer</a></li>
											<li><a href="#">Historique</a></li>							
										</ul>												
									</div>															
									</div>
								</div>
								</div>
								<div class="item">
									  <div class="wi-50">
										<div class="Cont_Box_wp Cont_Box_wp_second">			
											<div class="suivi_btn_boX">
												<ul>
													<li>L'immobilier</li>
													<li>475000 &euro;</li>						
												</ul>												
											</div>	
											<div class="whol_wrapper">	
												<div class="text">
												<h6>Appartement duplex T4</h6>
												<p>Cove + goroge double en sous-sol + porking privotif.Acces facile outoroute Annecy Nord et Allozier (Bordonnex a 20 min) Chouffoge individuel goz. Charges copro. 100 € / mois</p>
												<ul>
													<li><a href="#"><i class="fa fa-map-marker"></i> Douvaine</a></li>
													<li><a href="#"><i class="fa fa-external-link"></i> En savoir plus</a></li>
												</ul>
											</div>	
												<div class="img" style="background-image: url(images/pic4.png);">
												</div>
												<div class="Price_clom_Box">
													<div class="Price_clom_firstBox" style="background-image: url(images/offrimo2.png);"></div>
													<div class="Price_clom_lasttBox" style="background-image: url(images/pic2.jpg);"></div>
												</div>
											</div>
										<div class="suivi_btn_boX2">
											<ul>
												<li class="Icon_Wp"><a href="#suiviannonce" data-toggle="modal" data-backdrop="true"><i class="fa fa-eye"></i></a></li>	
												<li><a href="#">Accrocher</a></li>
												<li><a href="#">Historique</a></li>			
											</ul>												
										</div>															
										</div>
									</div>
									</div>
									<div class="item">
									  <div class="wi-50 Cont_Box_wp_third">
										<div class="Cont_Box_wp">			
											<div class="suivi_btn_boX">
												<ul>
													<li>L'immobilier</li>
													<li>475000 &euro;</li>						
												</ul>												
											</div>	
											<div class="whol_wrapper">	
												<div class="text">
												<h6>Appartement duplex T4</h6>
												<p>Cove + goroge double en sous-sol + porking privotif.Acces facile outoroute Annecy Nord et Allozier (Bordonnex a 20 min) Chouffoge individuel goz. Charges copro. 100 € / mois</p>
												<ul>
													<li><a href="#"><i class="fa fa-map-marker"></i> Douvaine</a></li>
													<li><a href="#"><i class="fa fa-external-link"></i> En savoir plus</a></li>
												</ul>
											</div>	
												<div class="img" style="background-image: url(images/pic4.png);">
												</div>
												<div class="Price_clom_Box">
													<div class="Price_clom_firstBox" style="background-image: url(images/offrimo2.png);"></div>
													<div class="Price_clom_lasttBox" style="background-image: url(images/pic2.jpg);"></div>
												</div>
											</div>
										<div class="suivi_btn_boX2">
											<ul>
												<li class="Icon_Wp"><a href="#suiviannonce" data-toggle="modal" data-backdrop="true"><i class="fa fa-eye"></i></a></li>	
												<li><a href="#"><i class="fa fa-times"></i> Ignorer</a></li>
												<li><a href="#">Historique</a></li>							
											</ul>												
										</div>															
										</div>
									</div>
									</div>
									</div>	
						</div>
				</div>
			</div>
			<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">		
				<div class="border">
					<span class="heading">Fonctions</span>
					<div class="ignorerText">
						<h5>Elargir</h5>
						<div class="slidecontainer">
							<em>
							  <input type="range" min="1" max="100" value="50" class="slider" id="myRange">
							</em>
							<p><span>Non</span><span>&nbsp;</span><span>Large</span></p>					  
						</div>
						<div class="prevNext">
							<!--<a href=".comparimo-annonces-vs-offrimo-2" data-slide="prev" class="fa fa-angle-left"></a>
							<a href=".comparimo-annonces-vs-offrimo-2" data-slide="next" class="fa fa-angle-right"></a>-->
							
							<span><em>2/2</em></span>
						</div>				
					</div>
					<a href="#" class="yellowBtn">Tout ignorer ( 10 ignorers )</a>
					<span class="ignorée_WP">(0 ignorée) </span>
				</div>
			</div>
				</div>
			<div class="HideShow_Wrapper" style="width:100%;float:left;border: 1px solid #dc6648;margin:20px 0;padding:15px; display:none">
				<div class="boxs col-xs-12 col-sm-8 col-md-8 col-lg-8">
					<div class="border">
						<span class="heading">Ofrrimo</span>
						<div class="comparimo-annonces-vs-offrimo-2">
							<div class="ShowHide_boXes">
									<div class="wi-50">
										<div class="Cont_Box_wp Cont_Box_wp_second">			
											<div class="suivi_btn_boX">
												<ul>
													<li>L'immobilier</li>
													<li>475000 &euro;</li>						
												</ul>												
											</div>	
											<div class="whol_wrapper">	
												<div class="text">
												<h6>Appartement duplex T4</h6>
												<p>Cove + goroge double en sous-sol + porking privotif.Acces facile outoroute Annecy Nord et Allozier (Bordonnex a 20 min) Chouffoge individuel goz. Charges copro. 100 € / mois</p>
												<ul>
													<li><a href="#"><i class="fa fa-map-marker"></i> Douvaine</a></li>
													<li><a href="#"><i class="fa fa-external-link"></i> En savoir plus</a></li>
												</ul>
											</div>	
												<div class="img" style="background-image: url(images/pic4.png);">
												</div>
												<div class="Price_clom_Box">
													<div class="Price_clom_firstBox" style="background-image: url(images/offrimo2.png);"></div>
													<div class="Price_clom_lasttBox" style="background-image: url(images/pic2.jpg);"></div>
												</div>
											</div>
										<div class="suivi_btn_boX2">
											<ul>
												<li class="Icon_Wp"><a href="#suiviannonce" data-toggle="modal" data-backdrop="true"><i class="fa fa-eye"></i></a></li>	
												<li><a href="#">Accrocher</a></li>
												<li><a href="#">Historique</a></li>			
											</ul>												
										</div>															
										</div>
									</div>
									<div class="wi-50 Cont_Box_wp_third">
										<div class="Cont_Box_wp">			
											<div class="suivi_btn_boX">
												<ul>
													<li>L'immobilier</li>
													<li>475000 &euro;</li>						
												</ul>												
											</div>	
											<div class="whol_wrapper">	
												<div class="text">
												<h6>Appartement duplex T4</h6>
												<p>Cove + goroge double en sous-sol + porking privotif.Acces facile outoroute Annecy Nord et Allozier (Bordonnex a 20 min) Chouffoge individuel goz. Charges copro. 100 € / mois</p>
												<ul>
													<li><a href="#"><i class="fa fa-map-marker"></i> Douvaine</a></li>
													<li><a href="#"><i class="fa fa-external-link"></i> En savoir plus</a></li>
												</ul>
											</div>	
												<div class="img" style="background-image: url(images/pic4.png);">
												</div>
												<div class="Price_clom_Box">
													<div class="Price_clom_firstBox" style="background-image: url(images/offrimo2.png);"></div>
													<div class="Price_clom_lasttBox" style="background-image: url(images/pic2.jpg);"></div>
												</div>
											</div>
										<div class="suivi_btn_boX2">
											<ul>
												<li class="Icon_Wp"><a href="#suiviannonce" data-toggle="modal" data-backdrop="true"><i class="fa fa-eye"></i></a></li>	
												<li><a href="#"><i class="fa fa-times"></i> Ignorer</a></li>
												<li><a href="#">Historique</a></li>							
											</ul>												
										</div>															
										</div>
									</div>
								</div>
							<div class="ShowHide_boXes">
									<div class="wi-50">
										<div class="Cont_Box_wp Cont_Box_wp_second">			
											<div class="suivi_btn_boX">
												<ul>
													<li>L'immobilier</li>
													<li>475000 &euro;</li>						
												</ul>												
											</div>											
											<div class="whol_wrapper">	
												<div class="text">
												<h6>Appartement duplex T4</h6>
												<p>Cove + goroge double en sous-sol + porking privotif.Acces facile outoroute Annecy Nord et Allozier (Bordonnex a 20 min) Chouffoge individuel goz. Charges copro. 100 € / mois</p>
												<ul>
													<li><a href="#"><i class="fa fa-map-marker"></i> Douvaine</a></li>
													<li><a href="#"><i class="fa fa-external-link"></i> En savoir plus</a></li>
												</ul>
											</div>	
												<div class="img" style="background-image: url(images/pic4.png);">
												</div>
												<div class="Price_clom_Box">
													<div class="Price_clom_firstBox" style="background-image: url(images/offrimo2.png);"></div>
													<div class="Price_clom_lasttBox" style="background-image: url(images/pic2.jpg);"></div>
												</div>
											</div>
										<div class="suivi_btn_boX2">
											<ul>
												<li class="Icon_Wp"><a href="#suiviannonce" data-toggle="modal" data-backdrop="true"><i class="fa fa-eye"></i></a></li>	
												<li><a href="#">Accrocher</a></li>
												<li><a href="#">Historique</a></li>			
											</ul>												
										</div>															
										</div>
									</div>
									<div class="wi-50 Cont_Box_wp_third">
										<div class="Cont_Box_wp">			
											<div class="suivi_btn_boX">
												<ul>
													<li>L'immobilier</li>
													<li>475000 &euro;</li>						
												</ul>												
											</div>	
											<div class="whol_wrapper">	
												<div class="text">
												<h6>Appartement duplex T4</h6>
												<p>Cove + goroge double en sous-sol + porking privotif.Acces facile outoroute Annecy Nord et Allozier (Bordonnex a 20 min) Chouffoge individuel goz. Charges copro. 100 € / mois</p>
												<ul>
													<li><a href="#"><i class="fa fa-map-marker"></i> Douvaine</a></li>
													<li><a href="#"><i class="fa fa-external-link"></i> En savoir plus</a></li>
												</ul>
											</div>	
												<div class="img" style="background-image: url(images/pic4.png);">
												</div>
												<div class="Price_clom_Box">
													<div class="Price_clom_firstBox" style="background-image: url(images/offrimo2.png);"></div>
													<div class="Price_clom_lasttBox" style="background-image: url(images/pic2.jpg);"></div>
												</div>
												
											</div>
										<div class="suivi_btn_boX2">
											<ul>
												<li class="Icon_Wp"><a href="#suiviannonce" data-toggle="modal" data-backdrop="true"><i class="fa fa-eye"></i></a></li>	
												<li><a href="#"><i class="fa fa-times"></i> Ignorer</a></li>
												<li><a href="#">Historique</a></li>							
											</ul>												
										</div>															
										</div>
									</div>
								</div>
						</div>
					</div>
				</div>
			</div>		
	</div>
		
	</div>
</div>
</div>