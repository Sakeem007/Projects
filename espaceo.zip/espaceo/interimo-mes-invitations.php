<nav class="nav nav-tab">
	<ul>
		<li class="active"><a href="#Toute_loffre" data-toggle="tab">Men Délégations</a></li>
		<li><a href="#Suivreannonces" data-toggle="tab">Mes Invitations</a></li>
	</ul>
</nav>
<article class="offrimoBox">
	<div id="Suivreannonces" class="item tab-pane fade in active">
		<div class="row">
			<div class="tab-content">
				<div id="Maisons_Appartements" class="item tab-pane fade in active">
					<div class="row">
						<?php include('offrimo-maisons.php');?>
					</div>
				</div>
				<div id="Terrains" class="item tab-pane fade">
					<div class="row">
						<?php include('offrimo-terrains.php');?>
					</div>
				</div>	
				<div id="LofferChassimo" class="item tab-pane fade">
					<div class="row">
						<?php include('offrimo-chassimo.php');?>
					</div>
				</div>				
			</div>
		</div>
	</div>
</article>
