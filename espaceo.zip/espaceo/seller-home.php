<?php include('header3.php');?>
	<!-- Being: my space box -->
	<article class="CallimoMainWrapper">
		<div class="container">	
			<nav class="nav nav-tab">
				<ul>
					<li class="active"><a href="#seller-my-scace" data-toggle="tab">My space</a></li>
					<li><a href="#seller-etudeo" data-toggle="tab">Etudeo</a></li>
					<li><a href="#seller-my-offer" data-toggle="tab">Mon offre</a></li>
					<li><a href="#seller-offrimo" data-toggle="tab">Offrimo</a></li>
				</ul>
			</nav>
			<div class="tab-content">				
				<div id="seller-my-scace" class="item tab-pane fade in active">
					<div class="row">
						<?php include('seller-my-space.php');?>
					</div>
				</div>
				<div id="seller-etudeo" class="item tab-pane fade">
					<div class="row">
						Etudeo
					</div>
				</div>
				<div id="seller-my-offer" class="item tab-pane fade">
					<div class="row">
						<?php include('seller-my-offer.php');?>
					</div>
				</div>	
				<div id="seller-offrimo" class="item tab-pane fade">
					<div class="row">
						Offrimo
					</div>
				</div>	
			</div>
		</div>
	</article>
	<!-- End: my space box -->


	
<?php include('footer.php');?>