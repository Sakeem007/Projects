<?php include('header.php');?>
	
	<!-- Being: comparimo box -->
	<article class="comparimoBox">
		<div class="container">
			<nav class="nav nav-tab">
				<ul>
					<li class="active"><a href="#Simulateur_en_ligne" data-toggle="tab">Simulateur en ligne</a></li>
					<li><a href="#Mes_annonces_VS_Offrimo" data-toggle="tab">Mes annonces VS Offrimo</a></li>
					<li><a href="#Scaner_un_bien" data-toggle="tab">Scaner un bien</a></li>				</ul>
			</nav>
			<div class="tab-content">
				<div id="Simulateur_en_ligne" class="item tab-pane fade in active">
					<div class="row">
						<?php include('comparimo-simulateur.php');?>
					</div>
				</div>
				<div id="Mes_annonces_VS_Offrimo" class="item tab-pane fade">
					<div class="row">
						<?php include('comparimo-annonces-VS-offrimo.php');?>
					</div>
				</div>
			</div>
		</div>
	</article>
	<!-- End: comparimo box -->
	
<?php include('footer.php');?>