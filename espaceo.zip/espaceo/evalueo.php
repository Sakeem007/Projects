<!-- Being: evalueo box -->
	<article class="evalueoBox">
		<div class="container">			
			
			<nav class="nav nav-tab arrow">
				<ul>
					<li class="active"><a href="#Le_Bien" data-toggle="tab">Le Bien</a></li>
					<li><a href="#Les_Surfaces" data-toggle="tab">Les Surfaces</a></li>
					<li><a href="#Les_Valeurs" data-toggle="tab">Les Valeurs</a></li>
					<li><a href="#Edition_Rapport_Evalueo" data-toggle="tab">Edition  Rapport  Evalueo</a></li>
					<li><a href="#Evaluations" data-toggle="tab">Evaluations</a></li>
				</ul>
			</nav>
			<div class="tab-content">
				<div id="Le_Bien" class="item tab-pane fade in active">
					<div class="row">
						<?php include('evalueo-le-bien.php');?>
					</div>
				</div>
				<div id="Les_Surfaces" class="item tab-pane fade">
					<div class="row">
						<?php include('evalueo-les-surfaces.php');?>
					</div>
				</div>
				<div id="Les_Valeurs" class="item tab-pane fade">
					<div class="row">
						<?php include('evalueo-les-valeurs.php');?>
					</div>
				</div>
				<div id="Edition_Rapport_Evalueo" class="item tab-pane fade">
					<div class="row">
						<?php include('evalueo-edition-rapport.php');?>
					</div>
				</div>
				<div id="Evaluations" class="item tab-pane fade">
					<div class="row">
						<?php include('evalueo-evaluations.php');?>
					</div>
				</div>
			</div>
			
		</div>
	</article>
