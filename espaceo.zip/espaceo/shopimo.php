<?php include('header.php');?>
	<!-- Being: my space box -->
	<article class="CallimoMainWrapper">
		<div class="container">			
			<div class="tab-content">	
				<img src="images/cominng_soon.jpg" style="width:100%"/>				
			</div>
		</div>
	</article>
	<!-- End: my space box -->


	
<?php include('footer.php');?>