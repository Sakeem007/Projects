<?php include('header.php');?>

<!-- Being: middle wrapper -->
<main id="middleWrapper">
	
	<!-- Being: home page -->
	<article class="homePage">
		<div class="container">			
			<div class="box">				
				<div class="tableBox hom-es">				
					<!--<div class="img" style="background-image: url(images/bg-2.jpg);">
						<h1>Cela ne s'arrete jamais de commencer... "Je suis convaincu que la croyance et l'excitation pour un objectif, amene la  reussite."</h1>
						<span class="name">Philippe Soulie</span>
					</div>-->
					<div class="col-md-6">
						<div class="row">
						<div class="col-md-6">
							<div class="es-bx1">
								<h3>Offrimo</h3>
							<form action="form">
								<h6>L'offre sur mon territoire</h6>
							<div class="form-group1">
							<label>Maison</label>
							<input type="text" value="">
							</div>
								
								<div class="form-group1">
							<label>Appt</label>
							<input type="text" value="">
							</div>
								
								<div class="form-group1">
							<label>Tenni</label>
							<input type="text" value="">
							</div>
								<div class="clearfix"></div>
								<h6>L'offre sur mon SP</h6>
								<div class="form-group1">
							<label>Surface</label>
							<input type="text" value="">
							</div>
								
								<div class="form-group1">
							<label>Sector</label>
							<input type="text" value="">
							</div>
								
								<div class="form-group1">
							<label>Properties</label>
							<input type="text" value="">
							</div>
								
								<div class="clearfix"></div>
								<h6>L'offre sur mon SS</h6>
								<div class="form-group1">
							<label>Maison</label>
							<input type="text" value="">
							</div>
								<div class="form-group1">
							<label>Appt</label>
							<input type="text" value="">
							</div>
								
								<div class="form-group1">
							<label>Tenni</label>
							<input type="text" value="">
							</div>
								
								
								
							</form>
							</div>
							</div>
							<div class="col-md-6">
								<div class="es-bx2">
								<h3>Observimo</h3>
									<div class="obserbimo-bx">
									<div class="first-cl">
										<h5>Non territory eqmpe=
											<span>-Km<sup>2</sup></span>
										<span>-BAl</span>
										</h5>
										</div>
										<div class="first-cl">
										<h5>Mon SP=
										<span>-Km   + (ville)</span>
										<span>-BAL older-men men identities</span>
										</h5>
										</div>
										<div class="first-cl">
										<h5>Mon SS=
										<span>-Km</span>
										<span>-BAl</span>
										</h5>
										</div>
									</div>
								</div>
							</div>
						</div>
					
					</div>
					<div class="col-md-6">
					<div class="text">
						<h3>Info Flash</h3>
						<p>Vous etes dans votre espace Home Conseiller personnalise et dedie a votre activite. Espaceo est concu pour ameliorer et faciliter votre travail, grace aux differentes applications qui composent cet espace. Ces applications sont interactives, c'est a dire qu'elles s'ameliorent de vos idees et remarques.</p>
						<div class="bottomText">
							<h5>"Notre reussite n'est pas une destination mais un voyage"</h5>
							<div class="companyName">
								<strong>Espaceo</strong>
								<small>Recherche&Developpement</small>
							</div>
						</div>
					</div>
					</div>
				</div>
				<div class="socialBox">
					<div class="row">
					<div class="col-md-8">
					<div class="social">
						<h6>Mes liens utiles</h6>
						
						<ul>
							<li><a href="#" class="fb"><span><img src="images/social1.png"/></span></a></li>
							<li><a href="#" class="tw"><span><img src="images/social2.png"/></span></a></li>
							<li><a href="#" class="in"><span><img src="images/social3.png"/></span></a></li>
							<li><a href="#" class="gp"><span><img src="images/social4.png"/></span></a></li>
							<li><a href="#" class="sl"><span><img src="images/social5.png"/></span></a></li>
							<li><a href="#" class="pc"><span><img src="images/social6.png"/></span></a></li>
							<li><a href="#" class="gm"><span><img src="images/social7.png"/></span></a></li>
							<li><a href="#" class="bi"><span><img src="images/social8.png"/></span></a></li>
							<li><a href="#" class="st"><span><img src="images/social9.png"/></span></a></li>
							<li><a href="#" class="ms"><span><img src="images/social10.png"/></span></a></li>
						</ul>
					</div>
						</div>
						<div class="col-md-4">
						<img src="images/facebook.jpg" class="img-responsive">
						</div>
						
						</div>
						
				</div>
			</div>			
		</div>
	</article>
	<!-- End: welcome box -->
	
	
</main>
<!-- End: middle wrapper -->

<?php include('footer.php');?>