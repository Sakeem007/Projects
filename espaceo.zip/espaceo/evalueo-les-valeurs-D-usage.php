<div class="max-content">
	<div class="row">
		<div class="purpalCont">
			<aside class="leftCol col-xs-12 col-sm-12 col-md-12 col-lg-7">			
				<div class="heading">
					<h5>Les 2 Paramètres :</h5>
					le terrain et le bâti
				</div>
				<div class="heading">
					<h5>Valeur du terrain</h5>
				</div>
				<div class="purpalBorder">
					<h6>La valeur par dèfaut</h6>
					<div class="checkBoxes">						
						<label><input type="checkbox"/><em></em> Je prends cette variable</label>
						<label>Je pondère cette valeur</label>
						<label><input type="checkbox"/><em></em> Je connais la valeur du terrain</label>
					</div>
					<div class="formRight">
						<div class="price">
							<div class="euro"> <input type="text" value=""/><span>&euro;</span></div>
						</div>
						<div class="ponderation">
							<ul>
								<li class="active"></li>
								<li></li>
								<li></li>
							</ul>
						</div>
						<div class="price">
							<div class="euro"> <input type="text" value=""/><span>&euro;</span></div>
						</div>
					</div>
				</div>
				<div class="heading">
					<h5>Valeur du bâti à l’identique</h5>
				</div>
				<div class="purpalBorder">
					<h6>La prix du m² de construction par dèfaut est</h6>
					<div class="checkBoxes">						
						<label><input type="checkbox"/><em></em> Je prends cette variable</label>
						<label>Je pondère cette valeur</label>
						<label><input type="checkbox"/><em></em> Je vais utiliser ce prix au m²</label>
					</div>
					<div class="formRight">
						<div class="price">
							<div class="euro"> <input type="text" value=""/><span>&euro;</span></div>
						</div>
						<div class="ponderation">
							<ul>
								<li class="active"></li>
								<li></li>
								<li></li>
							</ul>
						</div>
						<div class="price">
							<div class="euro"> <input type="text" value=""/><span>&euro;</span></div>
						</div>
					</div>
				</div>
			</aside>
			<aside class="rightCol col-xs-12 col-sm-12 col-md-12 col-lg-5">			
				<div class="heading">
					<h5>Simulation en temps rèel de la valeur indicative<h5>
				</div>				
				<div class="textBoxes">
					<h6>Suivant la valeur par dèfaut du terrain et de la reconstruction :</h6>
					<ul>
						<li>Valeur du terrain : 2937 &euro; / m²</li>
						<li>Valeur du bâti : 455000 &euro; </li>
						<li>Valeur du bien : 455000 &euro;</li>
					</ul>
				</div>
				<div class="textBoxes">
					<h6>Suivant la valeur par dèfaut du terrain et de la reconstruction :</h6>
					<ul>
						<li>Valeur du terrain : 2937 &euro; / m²</li>
						<li>Valeur du bâti : 455000 &euro;</li>
						<li>Valeur du bien : 455000 &euro;</li>
					</ul>
				</div>
			</aside>			
		</div>
	</div>
</div>