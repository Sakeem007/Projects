<div class="rankimo">
	<div class="listing">
		<form action="#" method="post">
			<ul>
				<li><em> Listing  des biens :</em></li>
				<li><span>4 biens</span></li>
				<li><span>Exporter</span></li>
				<li>
					<select>
						<option>Affichage</option>
						<option>List</option>
					</select>
				</li>
				<li>
					<select>
						<option>10 biens</option>
						<option>20 biens</option>
						<option>30 biens</option>
					</select>
				</li>
			</ul>
		</form>
	</div>
	<div class="repter">
		<div class="tablebox">
			<div class="box">
				<div class="img" style="background-image: url(images/offrimo2.png)"></div>
			</div>
			<div class="box">
				<div class="headerTop">Annonce <span>892 500 &euro;</span></div>
				<div class="contents">
					<h6>Appartement duplex T4</h6>
					<p>Pringy secteur Promery, proche ecoles et service bus, appertement T3 de 64m2 en parfait etat dans residence recente securisee, calme et arboree.<br>
					Entree ovec rangement, 2 chambres avec placards, salle de bain double vasques, wc separes, cuisine equipee ouverte sur sejour lumineux, ouvrant sur un agreable balcon de + 9m2 expose plein sud avec vue montagnes.</p>
					<p>Cove + goroge double en sous-sol + porking privotif.<br>Acces facile outoroute Annecy Nord et Allozier (Bordonnex a 20 min) Chouffoge individuel goz.<br>Charges copro. 100 &euro; / mois</p>					
				</div>
			</div>
			<div class="box">
				<div class="headerTop">Historique</div>
				<div class="contents">
					<ul>
						<li>Creation Annonce : 25/12/2017 a 15h</li>
						<li>En ligne depuis : 83 jours</li>
						<li>Dernieres modifications prix :
							<span>25/01/2017 : <strike>395000</strike> a 377000 &euro;</span>
							<span>22/03/2017 : <strike>377000</strike> a 370000 &euro;</span>
						</li>
						<li>Portails :</li>
					</ul>
					<div class="colorBtns">
						<ul>
							<li><a href="#">leBonCoin</a></li>
							<li><a href="#">PAP</a></li>
							<li><a href="#">VivaStreet</a></li>
							<li><a href="#">Seloger</a></li>
						</ul>
					</div>
				</div>
			</div>
			<div class="box">
				<div class="headerTop">Appreciation</div>
				<div class="appreciation">
					<h6>Rankimo</h6>
					<span class="rank">1/4</span>
					<p>Votre bien est classe 59/203 a Ambilly "74100" (3 pieces).</p>
					<h6><i class="fa fa-info-circle"></i> Valeur indicative</h6>					
					<div class="range"><em><input id="comparimo-price1" type="range" min="169000" max="198000" value=""/></em>
						<p><span>169000 &euro;</span><span id="comparimo-result1">180000 &euro;</span><span>198000 &euro;</span></p></div>
					<ul>
						<li>Prix m<sup>2</sup> Indique : <strong>2937 &euro;</strong> soit <strong>790 000 &euro;</strong></li>
						<li>Prix m<sup>2</sup> de l'annonce : <strong>3137 &euro;</strong> soit <strong>892 500 &euro;</strong></li>
						<li>Ecart prix constate m<sup>2</sup> : <strong>200 &euro;</strong> soit <strong>5 %</strong></li>
					</ul>
					<p><i class="fa fa-info-circle"></i> <a href="#" class="blueBtn">EVALUEO</a></p>
				</div>
			</div>		
		</div>
	</div>
	<div class="repter">
		<div class="tablebox">
			<div class="box">
				<div class="img" style="background-image: url(images/offrimo2.png)"></div>
			</div>
			<div class="box">
				<div class="headerTop">Annonce <span>892 500 &euro;</span></div>
				<div class="contents">
					<h6>Appartement duplex T4</h6>
					<p>Pringy secteur Promery, proche ecoles et service bus, appertement T3 de 64m2 en parfait etat dans residence recente securisee, calme et arboree.<br>
					Entree ovec rangement, 2 chambres avec placards, salle de bain double vasques, wc separes, cuisine equipee ouverte sur sejour lumineux, ouvrant sur un agreable balcon de + 9m2 expose plein sud avec vue montagnes.</p>
					<p>Cove + goroge double en sous-sol + porking privotif.<br>Acces facile outoroute Annecy Nord et Allozier (Bordonnex a 20 min) Chouffoge individuel goz.<br>Charges copro. 100 &euro; / mois</p>					
				</div>
			</div>
			<div class="box">
				<div class="headerTop">Historique</div>
				<div class="contents">
					<ul>
						<li>Creation Annonce : 25/12/2017 a 15h</li>
						<li>En ligne depuis : 83 jours</li>
						<li>Dernieres modifications prix :
							<span>25/01/2017 : <strike>395000</strike> a 377000 &euro;</span>
							<span>22/03/2017 : <strike>377000</strike> a 370000 &euro;</span>
						</li>
						<li>Portails :</li>
					</ul>
					<div class="colorBtns">
						<ul>
							<li><a href="#">leBonCoin</a></li>
							<li><a href="#">PAP</a></li>
							<li><a href="#">VivaStreet</a></li>
							<li><a href="#">Seloger</a></li>
						</ul>
					</div>
				</div>
			</div>
			<div class="box">
				<div class="headerTop">Appreciation</div>
				<div class="appreciation">
					<h6>Rankimo</h6>
					<span class="rank">1/4</span>
					<p>Votre bien est classe 59/203 a Ambilly "74100" (3 pieces).</p>
					<h6><i class="fa fa-info-circle"></i> Valeur indicative</h6>
					<div class="range"><em><input id="comparimo-price2" type="range" min="169000" max="198000" value=""/></em>
					<p><span>169000 &euro;</span><span id="comparimo-result2">180000 &euro;</span><span>198000 &euro;</span></p></div>
					<ul>
						<li>Prix m<sup>2</sup> Indique : <strong>2937 &euro;</strong> soit <strong>790 000 &euro;</strong></li>
						<li>Prix m<sup>2</sup> de l'annonce : <strong>3137 &euro;</strong> soit <strong>892 500 &euro;</strong></li>
						<li>Ecart prix constate m<sup>2</sup> : <strong>200 &euro;</strong> soit <strong>5 %</strong></li>
					</ul>
					<p><i class="fa fa-info-circle"></i> <a href="#" class="blueBtn">EVALUEO</a></p>
				</div>
			</div>		
		</div>
	</div>
	<div class="repter">
		<div class="tablebox">
			<div class="box">
				<div class="img" style="background-image: url(images/offrimo2.png)"></div>
			</div>
			<div class="box">
				<div class="headerTop">Annonce <span>892 500 &euro;</span></div>
				<div class="contents">
					<h6>Appartement duplex T4</h6>
					<p>Pringy secteur Promery, proche ecoles et service bus, appertement T3 de 64m2 en parfait etat dans residence recente securisee, calme et arboree.<br>
					Entree ovec rangement, 2 chambres avec placards, salle de bain double vasques, wc separes, cuisine equipee ouverte sur sejour lumineux, ouvrant sur un agreable balcon de + 9m2 expose plein sud avec vue montagnes.</p>
					<p>Cove + goroge double en sous-sol + porking privotif.<br>Acces facile outoroute Annecy Nord et Allozier (Bordonnex a 20 min) Chouffoge individuel goz.<br>Charges copro. 100 &euro; / mois</p>					
				</div>
			</div>
			<div class="box">
				<div class="headerTop">Historique</div>
				<div class="contents">
					<ul>
						<li>Creation Annonce : 25/12/2017 a 15h</li>
						<li>En ligne depuis : 83 jours</li>
						<li>Dernieres modifications prix :
							<span>25/01/2017 : <strike>395000</strike> a 377000 &euro;</span>
							<span>22/03/2017 : <strike>377000</strike> a 370000 &euro;</span>
						</li>
						<li>Portails :</li>
					</ul>
					<div class="colorBtns">
						<ul>
							<li><a href="#">leBonCoin</a></li>
							<li><a href="#">PAP</a></li>
							<li><a href="#">VivaStreet</a></li>
							<li><a href="#">Seloger</a></li>
						</ul>
					</div>
				</div>
			</div>
			<div class="box">
				<div class="headerTop">Appreciation</div>
				<div class="appreciation">
					<h6>Rankimo</h6>
					<span class="rank">1/4</span>
					<p>Votre bien est classe 59/203 a Ambilly "74100" (3 pieces).</p>
					<h6><i class="fa fa-info-circle"></i> Valeur indicative</h6>
					<div class="range"><em><input id="comparimo-price3" type="range" min="169000" max="198000" value=""/></em>
					<p><span>169000 &euro;</span><span id="comparimo-result3">180000 &euro;</span><span>198000 &euro;</span></p></div>
					<ul>
						<li>Prix m<sup>2</sup> Indique : <strong>2937 &euro;</strong> soit <strong>790 000 &euro;</strong></li>
						<li>Prix m<sup>2</sup> de l'annonce : <strong>3137 &euro;</strong> soit <strong>892 500 &euro;</strong></li>
						<li>Ecart prix constate m<sup>2</sup> : <strong>200 &euro;</strong> soit <strong>5 %</strong></li>
					</ul>
					<p><i class="fa fa-info-circle"></i> <a href="#" class="blueBtn">EVALUEO</a></p>
				</div>
			</div>		
		</div>
	</div>
	<div class="repter">
		<div class="tablebox">
			<div class="box">
				<div class="img" style="background-image: url(images/offrimo2.png)"></div>
			</div>
			<div class="box">
				<div class="headerTop">Annonce <span>892 500 &euro;</span></div>
				<div class="contents">
					<h6>Appartement duplex T4</h6>
					<p>Pringy secteur Promery, proche ecoles et service bus, appertement T3 de 64m2 en parfait etat dans residence recente securisee, calme et arboree.<br>
					Entree ovec rangement, 2 chambres avec placards, salle de bain double vasques, wc separes, cuisine equipee ouverte sur sejour lumineux, ouvrant sur un agreable balcon de + 9m2 expose plein sud avec vue montagnes.</p>
					<p>Cove + goroge double en sous-sol + porking privotif.<br>Acces facile outoroute Annecy Nord et Allozier (Bordonnex a 20 min) Chouffoge individuel goz.<br>Charges copro. 100 &euro; / mois</p>					
				</div>
			</div>
			<div class="box">
				<div class="headerTop">Historique</div>
				<div class="contents">
					<ul>
						<li>Creation Annonce : 25/12/2017 a 15h</li>
						<li>En ligne depuis : 83 jours</li>
						<li>Dernieres modifications prix :
							<span>25/01/2017 : <strike>395000</strike> a 377000 &euro;</span>
							<span>22/03/2017 : <strike>377000</strike> a 370000 &euro;</span>
						</li>
						<li>Portails :</li>
					</ul>
					<div class="colorBtns">
						<ul>
							<li><a href="#">leBonCoin</a></li>
							<li><a href="#">PAP</a></li>
							<li><a href="#">VivaStreet</a></li>
							<li><a href="#">Seloger</a></li>
						</ul>
					</div>
				</div>
			</div>
			<div class="box">
				<div class="headerTop">Appreciation</div>
				<div class="appreciation">
					<h6>Rankimo</h6>
					<span class="rank">1/4</span>
					<p>Votre bien est classe 59/203 a Ambilly "74100" (3 pieces).</p>
					<h6><i class="fa fa-info-circle"></i> Valeur indicative</h6>
					<div class="range"><em><input id="comparimo-price4" type="range" min="169000" max="198000" value=""/></em>
					<p><span>169000 &euro;</span><span id="comparimo-result4">180000 &euro;</span><span>198000 &euro;</span></p></div>
					<ul>
						<li>Prix m<sup>2</sup> Indique : <strong>2937 &euro;</strong> soit <strong>790 000 &euro;</strong></li>
						<li>Prix m<sup>2</sup> de l'annonce : <strong>3137 &euro;</strong> soit <strong>892 500 &euro;</strong></li>
						<li>Ecart prix constate m<sup>2</sup> : <strong>200 &euro;</strong> soit <strong>5 %</strong></li>
					</ul>
					<p><i class="fa fa-info-circle"></i> <a href="#" class="blueBtn">EVALUEO</a></p>
				</div>
			</div>		
		</div>
	</div>
</div>