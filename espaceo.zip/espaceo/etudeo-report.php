<div class="evalueo">
	<div class="row">
		<aside class="item col-xs-12 col-sm-8 col-md-9 col-lg-9">
			<div id="all-repport-pdf" class="repport-pdf"> 
			<!-- Start: page 1 -->
				<div class="page" id="html-2-pdfwrapper"> 
				  <!-- water mark -->
				  <div class="whater-mark top"> <span class="pull-left"><?php echo date("d/m/Y"); ?></span> </div>
				  <!-- water mark -->
				  <div class="top">
					<!-- <div class="logo"><img src="images/logo1.png"/></div> -->
					<div class="rightText">
					  <h2> <span>MARCHE IMMOBILIER</span> <em>NOTRE AVIS DE VALEUR</em> <em>ETUDEO<sup>&copy;</sup></em> </h2>
					</div>
				  </div>
				  <div class="photo-upload" id="photo_du_bien">
					<div class="logo"><img src="images/L’immobilierlogo1.png"/></div>
					<!--<div class="photo">
					  <label>
					  <div id="targetLayer">
						<input name="image_url1" accept="image/png,image/jpeg" id="image_url1" type="file" class="inputFile" onChange="showPreview(this);" />
					  </div>
					  </label>
					  <div class="left-border" id="propertyInfo">
						<h6>Votre bien:</h6>
						<p>m<sup>2</sup><!-- {{cityName}}</p>
					  </div>
					</div>-->
					<div class="bottom-arrow-bg info_details_BoX">
					  <div class="left-border">
						<h3><span class="section-title"> A la demande de</span></h3>
						<ul>
						  <li><i class="fa fa-user"></i> <!--{{propertyUserTitre}} {{propertyUser}}--></li>
						  <li><i class="fa fa-phone"></i> <!--{{propertyPhone}}--></li>
						  <li><i class="fa fa-envelope"></i> <!--{{propertyEmailID}}--></li>
						  <li><i class="fa fa-map-marker"></i> <!--{{propertyAddress}}--></li>
						</ul>
					  </div>
					</div>
					<!-- water mark --> 
					<!-- water mark --> 
				  </div>
				</div>
			
			<!--<div class="picBg">
						<div class="etudeoMain">
							<div class="etudeoText">
								<div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
									<div class="left-border">
										<h6>Votre bien:</h6>
										<span>Maison - 150m<sup>2</sup> 74140, Douvaine</span>
									</div>
								</div>
								<div class="col-xs-12 col-sm-4 col-md-4 col-lg-4">
									<img src="pdf/logo1.png"/>
								</div>
								<h3></h3>
							</div>
							<div class="bottom-arrow-bg">
								<div class="left-border">
									<ul>
										<li>A la demande de : Mme et Mr Soulié</li>
										<li>Votre Home Conseiller : Mr Philippe Soulié</li>
										<li>Fait le: Lundi 01 Mai 2017</li>
									</ul>
								</div>
							</div>
						</div>					
					</div>--> 
			
			<!-- End: page 1 --> 
			<!-- Start: page 1 -->
			<div class="page">
			  <div class="titles active"> <span>1</span> Sommaire </div>
			  <div class="sommaire">
				<h1>Sommaire</h1>
			  </div>
			  <div class="titles"> <span>1</span> Sommaire </div>
			  <div class="titles"> <span>2</span> Présentation de notre Agence </div>
			  <div class="titles"> <span>3</span> Notre application ETUDEO© </div>
			  <div class="titles"> <span>4</span> Tout sur votre annonce mise en ligne </div>
			  <div class="titles"> <span>5</span> Synthése de notre étude immobiliere </div>
			  <div class="titles"> <span>6</span> Les bénéﬁces de ETUDEO© et EVALUEO© </div>
			  <div class="sommaire">
				<div class="clear"><br>
				  <br>
				  <br>
				</div>
				<h2>Prét pour la prochaine étape ...?</h2>
			  </div>
			  
			  <!-- water mark -->
			  
			  <div class="whater-mark bottom">
				<div class="home-conseiller">
				  <div class="col col-xs-12 col-sm-2 col-md-2 col-lg-2"> <img src="pdf/limmolier.png"/> </div>
				  <div class="col col-xs-12 col-sm-6 col-md-6 col-lg-6">
					<ul>
					  <li>Votre Home Conseiller</li>
					  <li>Mr.Philippe Soulie</li>
					  <li>Tél : 06 50 65 68 78</li>
					  <li>Email : philippe.soulie@limmobilier.net</li>
					</ul>
				  </div>
				  <div class="col col-xs-12 col-sm-4 col-md-4 col-lg-4">
					<ul>
					  <li>Notre Réseau</li>
					  <li>Tél. : 04 57 43 00 50 / 04 57 43 00 49</li>
					  <li>E-mail : contact@limmobilier.net</li>
					  <li>Site web : https://www.limmobilier.net</li>
					  <li>Adresse : 2 Avenue du Lac 74140 Douvaine</li>
					</ul>
				  </div>
				</div>
			  </div>			  
			</div>
			
			<!-- End: page 1 --> 
			
			<!-- Start: page 2 -->
			
			<div class="page">
			  <div class="titles active"> <span>2</span> Présentation de notre société </div>
			  <div class="title-blue"> <span><span>Notre histoire</span></span> </div>
			  <div class="paddLeft">
				<p>Depuis 1998, les fondateurs de <strong>L'IMMOBILIER</strong>, spécialisés dans les métiers de l'immobilier, ont toujours développé un esprit de qualité, d’exigence et de réussite. Ce qui guide le groupe, c’est la passion : la passion des autres, la passion de son métier, l'immobilier, avec en plus, une vision global de son activité. Cette passion c’est le ﬁl conducteur de son histoire, elle ne s’est jamais démentie, elle est le moteur pour atteindre son objectif: votre satisfaction.</p>
			  </div>
			  <div class="title-blue"> <span><span>Nos valeurs</span></span> </div>
			  <div class="paddLeft">
				<p>Notre groupe cultive avant tout l’excellence, cette démarche se traduit concretement par une recherche constante des meilleures performances, dans les métiers de l’immobilier. Notre groupe privilégie en effet, depuis sa création, les valeurs d’avant—garde, que sont la dimension humaine, la famille, la durabilité, le respect de l'environnement.</p>
				<p> << La valeur d'une entreprise est déterminée par la valeur des gens qui la compose >>.</p>
			  </div>
			  <div class="title-blue"> <span><span>Notre savoir faire</span></span> </div>
			  <div class="paddLeft">
				<p><strong>L'IMMOBILIER</strong> est au coeur de notre savoir faire, et plus particuliérement la vente immobiliere. Nous avons développé une application inédite appelée <strong>EVALUEO©</strong>, qui est une application capable d'analyseren temps réeltoutes les données du marché immobilier régional et local, de comparer les biens en vente, tout en tenant compte des caractéristiques de votre bien.</p>
			  </div>
			  <div class="title-blue"> <span><span>Notre objectif</span></span> </div>
			  <div class="paddLeft">
				<p>Nous souhaitons vous donner le meilleur prix de vente, c'est a dire le prix du marché actuel, et vous proposer la meilleur stratégie commerciale, car nous souhaitons vendre votre bien au meilleur prix, et dans les meilleurs délais.</p>
			  </div>
			  <div class="text-center col-xs-12 col-sm-12 col-md-12 col-lg-12"> <img src="pdf/pic13.png"/> </div>
			  
			  <!-- water mark -->
			  
			  <div class="whater-mark bottom">
				<div class="home-conseiller">
				  <div class="col col-xs-12 col-sm-2 col-md-2 col-lg-2"> <img src="pdf/limmolier.png"/> </div>
				  <div class="col col-xs-12 col-sm-6 col-md-6 col-lg-6">
					<ul>
					  <li>Votre Home Conseiller</li>
					  <li>Mr.Philippe Soulie</li>
					  <li>Tél : 06 50 65 68 78</li>
					  <li>Email : philippe.soulie@limmobilier.net</li>
					</ul>
				  </div>
				  <div class="col col-xs-12 col-sm-4 col-md-4 col-lg-4">
					<ul>
					  <li>Notre Réseau</li>
					  <li>Tél. : 04 57 43 00 50 / 04 57 43 00 49</li>
					  <li>E-mail : contact@limmobilier.net</li>
					  <li>Site web : https://www.limmobilier.net</li>
					  <li>Adresse : 2 Avenue du Lac 74140 Douvaine</li>
					</ul>
				  </div>
				</div>
			  </div>
			  
			  <!-- water mark --> 
			  
			</div>
			
			<!-- End: page 2 --> 
			
			<!-- Start: page 3 -->        
			<div class="page">
			  <div class="titles active"> <span>3</span> Notre application ETUDEO© </div>
			  <div class="etudeo">
				<p><strong>ETUDEO©</strong> vient de la fusion des mots ETUDE et IMMOBILIER, ce rapport utilise 4 applications qui sont les suivantes:</p>
			  </div>
			  <div class="title-blue"> <span>OFFRIMO©</span> Visualiser l'offre immobiliére </div>
			  <div class="etudeo">
				<p><strong>OFFRIMO©</strong> vient de la fusion des mots <strong>OFFRE</strong> et <strong>IMMOBILIER</strong>, nous utilisons cette application qui nous permet d’étre informés de toutes les annonces de l'offre immobiliere, données par tous les sites d’annonces, pour tous les biens publiés par les particuliers et les agences, et cela, en temps réel.</p>
				<p>Cette offre peut étre consultée par défaut, suivant les annonces données par les sites immobilier, mais peut également étre affinée suivant un moteur de recherche intelligent.</p>
			  </div>
			  <div class="title-blue"> <span>RANKIMO©</span> Classer l'offre immobiliére </div>
			  <div class="etudeo">
				<p><strong>RANKIMO©</strong> vient de la fusion du mot anglais <strong>"RANK"</strong> qui signiﬁe <strong>"CLASSER"</strong> et de <strong>IMMOBILIER</strong>, car nous utilisons cette application qui nous permet de classer les annonces de l'offre immobiliére données par tous les sites d'annonces, pour tous les biens publiés par les particuliers et les agences, et cela, en temps réel.</p>
				<p>Ce classement se fait par défaut, suivant les informations données par les sites d'annonces immobilieres, mais peut également étre paramétréer pour affiner le classement.</p>
			  </div>
			  <div class="title-blue"> <span>COMPARIMO©</span> Comparer l'offre immobiliére </div>
			  <div class="etudeo">
				<p><strong>COMPARIMO©</strong> vient de la fusion des mots <strong>COMPARER et IMMOBILIER</strong>, nous utilisons cette application qui nous permet de comparer les annonces de l'offre immobiliere données par tous les sites d'annonces, pour tous les biens publiés par les particuliers et les agences, et cela, en temps réel.</p>
				<p>Cette comparaison se fait par défaut, suivant les informations données par les sites d'annonces immobilieres, mais peut également étre paramétréer pour affiner la comparaison.</p>
			  </div>
			  <div class="title-blue"> <span>OBSERVIMO©</span> Qualiﬁer l'offre immobiliére </div>
			  <div class="etudeo">
				<p><strong>OBSERVIMO©</strong> vient de la fusion des mots <strong>OBSERVER et IMMOBILIER</strong>, nous utilisons cette application qui nous permet de qualiﬁer un département, une ville, un quartier ou une rue, en identiﬁant ses points forts et ses points faibles, cette qualiﬁcation se fait sur des indicateurs démographiques, sociaux, environnementaux, de commodités, transports...</p>
				<p>Nous pouvons ainsi qualiﬁer une adresse a 360°, nous savons 00 se situe votre bien.</p>
			  </div>
			  <div class="whater-mark bottom">
				<div class="home-conseiller">
				  <div class="col col-xs-12 col-sm-2 col-md-2 col-lg-2"> <img src="pdf/limmolier.png"/> </div>
				  <div class="col col-xs-12 col-sm-6 col-md-6 col-lg-6">
					<ul>
					  <li>Votre Home Conseiller</li>
					  <li>Mr.Philippe Soulie</li>
					  <li>Tél : 06 50 65 68 78</li>
					  <li>Email : philippe.soulie@limmobilier.net</li>
					</ul>
				  </div>
				  <div class="col col-xs-12 col-sm-4 col-md-4 col-lg-4">
					<ul>
					  <li>Notre Réseau</li>
					  <li>Tél. : 04 57 43 00 50 / 04 57 43 00 49</li>
					  <li>E-mail : contact@limmobilier.net</li>
					  <li>Site web : https://www.limmobilier.net</li>
					  <li>Adresse : 2 Avenue du Lac 74140 Douvaine</li>
					</ul>
				  </div>
				</div>
			  </div>
			</div>
			<!-- End: page 3 --> 
			
			<!-- Start: page 4 -->        
			<div class="page forth_pg">
				<div class="titles active"> <span>4</span> Tout sur votre annonce mise en ligne </div>
				<div class="title-blue"> <span>Vos photos</span></div>
			    <div class="etudeo">
				   <div class="col col-xs-12 col-sm-4 col-md-4 col-lg-4"><img src="images/Vos_photos.jpg" /></div>
				   <div class="col col-xs-12 col-sm-4 col-md-4 col-lg-4"><img src="images/Vos_photos.jpg" /></div>
				   <div class="col col-xs-12 col-sm-4 col-md-4 col-lg-4"><img src="images/Vos_photos.jpg" /></div>
			    </div>
				<div class="title-blue"> <span>Votre texte publicitaire</span> </div>
				<div class="Votre_publicitaire">
					<ul>
						<li>PAP</li>
						<li><p>Appartement de 97 m2 dans quartier recherché 4 Seynod. Proche des commodités, des grands axes et d'Annecy. Cet Ee appartement est orienté Sud-Est Sud et donne sur un parc paysagé au calme.</p>
						</li>
					</ul>
				</div>
				<div class="Votre_publicitaire_pro">
					<ul>
						<li>Pro</li>
						<li>
							<div class="Votre_Pro_Box">
							<h5>Agence SAFTI</h5>
							<p>Appartement de 97 m2 dans quartier recherché 4 Seynod. Proche des commodités, des grands axes et d'Annecy. Cet Ee appartement est orienté Sud-Est Sud et donne sur un parc paysagé au calme.</p>
							</div>
						</li>
						<li>
							<div class="Votre_Pro_Box">
							<h5>Agence POIRIER</h5>
							<p>Appartement de 97 m2 dans quartier recherché 4 Seynod. Proche des commodités, des grands axes et d'Annecy. Cet Ee appartement est orienté Sud-Est Sud et donne sur un parc paysagé au calme.</p>
							</div>
						</li>
						<li>
							<div class="Votre_Pro_Box">
							<h5>Agence CAPIFRANCE</h5>
							<p>Appartement de 97 m2 dans quartier recherché 4 Seynod. Proche des commodités, des grands axes et d'Annecy. Cet Ee appartement est orienté Sud-Est Sud et donne sur un parc paysagé au calme.</p>
							</div>
						</li>
					</ul>
			    </div>
				<div class="title-blue"> <span>Comment est vu votre bien sur internet?</span></div>
			    <div class="etudeo Internet_TBL">
				   <table width="100%" border="0" cellspacing="10" cellpadding="0">
					  <tr>
						<td width="22%" align="center" valign="middle">&nbsp;</td>
						<td width="12%" align="center" valign="middle"><strong>PAP</strong></td>
						<td width="22%" align="center" valign="middle"><strong>Agence SAFTI</strong></td>
						<td width="22%" align="center" valign="middle"><strong>Agence POIRIER</strong></td>
						<td width="22%" align="center" valign="middle"><strong>Agence CAPIFRANCE</strong></td>
					  </tr>
					  <tr>
						<td align="left" valign="middle"><strong>Prix</strong></td>
						<td align="center" valign="middle">305 000 €</td>
						<td align="center" valign="middle">329 000 €</td>
						<td align="center" valign="middle">317 000 €</td>
						<td align="center" valign="middle">341 000 €</td>
					  </tr>
					  <tr>
						<td align="left" valign="middle"><strong>Piéces</strong></td>
						<td align="center" valign="middle">4</td>
						<td align="center" valign="middle">4</td>
						<td align="center" valign="middle">5</td>
						<td align="center" valign="middle">4</td>
					  </tr>
					  <tr>
						<td align="left" valign="middle"><strong>SH</strong></td>
						<td align="center" valign="middle">92m²</td>
						<td align="center" valign="middle">95m²</td>
						<td align="center" valign="middle">97m²</td>
						<td align="center" valign="middle">104m²</td>
					  </tr>
					  <tr>
						<td align="left" valign="middle"><strong>Mise en ligne</strong></td>
						<td align="center" valign="middle">11/07/2017 (30jrs)</td>
						<td align="center" valign="middle">14/07/2017 (27jrs)</td>
						<td align="center" valign="middle">19/07/2017 (21 jrs)</td>
						<td align="center" valign="middle">13/07/2017 (28jrs)</td>
					  </tr>
					</table>
			    </div>
				
				<div class="title-blue"> <span>Historique de votre annonce sur internet</span></div>
			    <div class="etudeo Historique_list">
					<ul>
						<li>Mise enligne le 11/07/2017 et en ligne depuis 30 jours</li>
						<li>Présentée actuellement par 3 agences</li>
						<li>Evolution du prix:</li>
					</ul>
					<div style="clear:both"></div>
					<div class="Graph_main_wrapper">	
					<div id="chartContainer" class="Graph_wrapper_Box"></div>
					<div style="background:#fff;float:left;width:55px;height:20px;position:relative;top:-55px;"></div>
					</div>
					<!--<p><img src="images/grap_img.jpg" /></p>-->					
				</div>
				
				<div class="whater-mark bottom">
					<div class="home-conseiller">
						<div class="col col-xs-12 col-sm-2 col-md-2 col-lg-2"> <img src="pdf/limmolier.png"/> </div>
						<div class="col col-xs-12 col-sm-6 col-md-6 col-lg-6">
							<ul>
							  <li>Votre Home Conseiller</li>
							  <li>Mr.Philippe Soulie</li>
							  <li>Tél : 06 50 65 68 78</li>
							  <li>Email : philippe.soulie@limmobilier.net</li>
							</ul>
						</div>
						<div class="col col-xs-12 col-sm-4 col-md-4 col-lg-4">
							<ul>
							  <li>Notre Réseau</li>
							  <li>Tél. : 04 57 43 00 50 / 04 57 43 00 49</li>
							  <li>E-mail : contact@limmobilier.net</li>
							  <li>Site web : https://www.limmobilier.net</li>
							  <li>Adresse : 2 Avenue du Lac 74140 Douvaine</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
			<!-- End: page 4 --> 
			<!-- Start: page 5 -->        
			<div class="page">				
				<div class="titles active"> <span>5</span> Synthése de notre étude immobiliére</div>
				<div class="title-blue"> <span>OFFRIMO©</span> Toute l’offre</div>
			    <div class="etudeo Historique_list">
					<ul>
						<li>Il ya 17 maisons 4 piéces en vente 3 Douvaine</li>
						<li>Il y en a 41 en vente dans un rayon de 5 km et 57 dans un rayon de 10 km</li>
						<li>Il y a8 maisons 4 piéces moins chers que la votre 4 Douvaine, il yen 17 moins chers dans un rayon de 5 km et 29 dans un rayon de 10 km.</li>
					</ul>
				</div>
				<div class="title-blue"> <span>RANKIMO©</span> Classement de l’offre</div>
			    <div class="etudeo Historique_list">
					<ul>
						<li>Sans filtre votre bien et classé 17/34 dans l’offre immobiliére au moment d’édition</li>
						<li>Apres filtre votre bien et classé 8/34 dans loffre immobiliére au moment d’édition ETUDEO®</li>
					</ul>
				</div>
				<div class="title-blue"> <span>COMPARIMO©</span> Comparer l'offre</div>
			    <div class="etudeo">
					<div class="col col-xs-12 col-sm-6 col-md-6 col-lg-6">
						<div class="Comparer_txt_Box">
							<h4>L'offre des biens comparables :</h4>
							<ul>
								<li>Offre des biens comparables PAP: <strong>52 biens</strong></li>
								<li>Offre des biens comparables PRO: <strong>89 biens</strong></li>
								<li>Prix moyen des biens comparables : <strong>245 500 €</strong></li>
								<li>Délai moyen de mise enligne des biens comparables : <strong>30 jours</strong></li>
								<li>Depuis 01/01/2017 nombre de biens comparable mise en vente : <strong>1800 biens</strong></li>
								<li>En moyenne mensuelle, il y a <strong>165 biens</strong> comparables mise en vente</li>
							</ul>
						</div>
					</div>
					<div class="col col-xs-12 col-sm-6 col-md-6 col-lg-6">
						<div class="Comparer_txt_Box">
							<h4>Votre bien par rapport aux biens comparables :</h4>
							<ul>
								<li>Nombre de biens comparables :</li>
								<li>Meilleur prix du bien comparable :</li>
								<li>Votre bien est 18/89 des biens comparables</li>
								<li>Le prix de votre bien est de</li>
								<ul>
									<li><strong>+23% supérieur a la moyenne des biens comparables soit +12500 €</strong></li>
									<li><strong>+18% supérieur a la moyenne des biens comparables soit +18200 €</strong></li>
								</ul>
							</ul>
						</div>
					</div>
				</div>
				<div class="title-blue"> <span>OBSERVIMO©</span> Valoriser l'environnement de l'offre</div>
			    <div class="etudeo">
					<div class="col col-xs-12 col-sm-4 col-md-4 col-lg-4">
						<img src="images/map_img.jpg" />
					</div>
					<div class="col col-xs-12 col-sm-8 col-md-8 col-lg-8">
						<div class="Valoriser_BoX">
							<ul>
								<li><strong>Ville : Douvaine</strong></li>
								<li><strong>Votre bien par rapport aux transports </strong>
									<ul>
										<li><span>Gare la plus proche</span>: 1</li>
										<li><span>Station de busla plus proche</span>: 3</li>
								    </ul>
								</li>
								<li><strong>Votre bien par rapport aux commodités </strong>
									<ul>
										<li><span>Commerces</span>: 20</li>
										<li><span>Ecoles</span>: 16</li>
										<li><span>Médecin</span>: 6</li>
										<li><span>Hopital</span>: 2</li>
									</ul>
								</li>
							</ul>
						</div>
					</div>
				</div>
				
				<div class="whater-mark bottom">
					<div class="home-conseiller">
						<div class="col col-xs-12 col-sm-2 col-md-2 col-lg-2"> <img src="pdf/limmolier.png"/> </div>
						<div class="col col-xs-12 col-sm-6 col-md-6 col-lg-6">
							<ul>
							  <li>Votre Home Conseiller</li>
							  <li>Mr.Philippe Soulie</li>
							  <li>Tél : 06 50 65 68 78</li>
							  <li>Email : philippe.soulie@limmobilier.net</li>
							</ul>
						</div>
						<div class="col col-xs-12 col-sm-4 col-md-4 col-lg-4">
							<ul>
							  <li>Notre Réseau</li>
							  <li>Tél. : 04 57 43 00 50 / 04 57 43 00 49</li>
							  <li>E-mail : contact@limmobilier.net</li>
							  <li>Site web : https://www.limmobilier.net</li>
							  <li>Adresse : 2 Avenue du Lac 74140 Douvaine</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
			<!-- End: page 5 --> 
			<!-- Start: page 6 -->        
			<div class="page">
				<div class="titles active"> <span>6</span> Les bénéfices de ETUDEO© et EVALUEO©</div>
			    <div class="all_folio_tbs">
					<em class="fnt_phace">L’‘information et une valeur économique, elle permet de prendre la meilleure décision, de suivre l’évaluation de sa décisionet de réussir son projet, dans votre cas c'est de vendre au meilleur prix et dans les meilleurs conditions et délais et de coats.</em>
					<ul>
					<li><strong>OFFRIMO</strong><span>Je vois l'offre proposée Xela Cee e care)</span></li>
					<li><strong>RANKIMO</strong><span>Je classe cette offre aol aeUAaalia</span></li>
					<li><strong>COMPARIMO</strong><span>Je compare mon bien a loffre concurrente</span></li>
					<li><strong>OBSERVIMO</strong><span>Je valorise Uoffre concurrente</span></li>
					<li><strong>EVALUEO</strong><span>J’evalue mon bien au juste prix</span></li>
					<li><strong>SIMULATEUR</strong><span>Je simule mon annonce envisagée</span></li>
					<li><img src="images/Jevends_logo.png" alt="logo" /></li>
					</ul>
					<p class="Pour_réussir_tXt">"Pour réussir votre projet de miseen vente,et la vente de votre bien, nous vous proposons de nous revoir pour vous remettre votre
<strong class="avis_txt">AVIS DE VALEUR EVALUEO<span>©</span> "</strong></p>
				</div>
				
				<div class="whater-mark bottom">
					<div class="home-conseiller">
						<div class="col col-xs-12 col-sm-2 col-md-2 col-lg-2"> <img src="pdf/limmolier.png"/> </div>
						<div class="col col-xs-12 col-sm-6 col-md-6 col-lg-6">
							<ul>
							  <li>Votre Home Conseiller</li>
							  <li>Mr.Philippe Soulie</li>
							  <li>Tél : 06 50 65 68 78</li>
							  <li>Email : philippe.soulie@limmobilier.net</li>
							</ul>
						</div>
						<div class="col col-xs-12 col-sm-4 col-md-4 col-lg-4">
							<ul>
							  <li>Notre Réseau</li>
							  <li>Tél. : 04 57 43 00 50 / 04 57 43 00 49</li>
							  <li>E-mail : contact@limmobilier.net</li>
							  <li>Site web : https://www.limmobilier.net</li>
							  <li>Adresse : 2 Avenue du Lac 74140 Douvaine</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
			<!-- End: page 5 --> 
		  </div>
		</aside>
	
	
		<aside class="item col-xs-12 col-sm-4 col-md-3 col-lg-3">
			<div class="repport-btns">
				<ul>
					<span class="btns">Action</span>
					<li><a href="#">Share</a>
					<li>
					<li><a href="#">Print</a>
					<li>
					<li><a href="#">Save</a>
					<li>
				</ul>
				<ul>
					<span class="btns">Edition report</span>
					<li><a href="#photo_du_bien">Photo du bien</a>
					<li>
					<li><a href="#">Im  le Propertier</a>
					<li>
					<li><a href="#">Save</a>
					<li>
				</ul>
			</div>
		</aside>
	</div>
</div>
  <script type="text/javascript">
  window.onload = function () {
    var chart = new CanvasJS.Chart("chartContainer",
    {
      zoomEnabled: true,      
      
      title:{
       ///text: "Chart With Date-Time Stamps Inputs"       
     },

     data: [
     {   
      type: "area",
      xValueType: "dateTime",
      dataPoints: [                  
              { x: 1088620200000, y :3},
              { x: 1104517800000, y : 10 },
              { x: 1112293800000, y:  50 },
              { x: 1136053800000, y : 10 },
              { x: 1157049000000, y : 5 },
              { x: 1162319400000, y : 10 },
              { x: 1180636200000, y : 60 },
              { x: 1193855400000, y : 10 },
              { x: 1209580200000, y : 90 },
              { x: 1230748200000, y : 10 },
              { x: 1241116200000, y : 50 },
              { x: 1262284200000, y : 0 },
              { x: 1272652200000, y : 20  },
              { x: 1291141800000, y : 10 },
              { x: 1304188200000, y : 3 }
      ]
    }
    ]
  });

    chart.render();
  }
  </script>
  <script type="text/javascript" src="js/canvasjs.min.js"></script>
