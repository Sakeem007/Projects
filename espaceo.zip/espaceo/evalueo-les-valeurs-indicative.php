<div class="max-content">
	<div class="row">
		<div class="greenCont">
			<aside class="leftCol col-xs-12 col-sm-12 col-md-12 col-lg-7">			
				<div class="heading">
					<h5>Les Parametres :</h5>
					le bien, I’environment et les commodités
				</div>
				<div class="greenBorder">
					<div class="heading">
						<h5>1 - Le Bien</h5>
					</div>
					<div class="panel">
						<div class="reapter">
							<h6>Le Standing</h6>
							<div class="textLeft">								
								<p>Valorisation de la variable Pondération valorisation de la variable </p>
							</div>
							<div class="formRight">
								<div class="quantity">
									<input type="number" min="0" max="999" step="1" value="0">
								</div>
								<div class="price">
									<div class="euro"> <input type="text" value=""/><span>&euro;</span></div>
									<div class="percent"><input type="text" value="+"/><span>%</span></div>
								</div>								
							</div>
							<div class="checkBoxes">
								<label><input type="checkbox"/><em></em> Je prends cette variable</label>
							</div>
						</div>
						<div class="reapter">
							<h6>Travaux a prÉvoir</h6>
							<div class="textLeft">								
								<p>Valorisation de la variable Pondération valorisation de la variable </p>
							</div>
							<div class="formRight">
								<div class="quantity">
									<input type="number" min="0" max="999" step="1" value="0">
								</div>
								<div class="price">
									<div class="euro"> <input type="text" value=""/><span>&euro;</span></div>
									<div class="percent"><input type="text" value="+"/><span>%</span></div>
								</div>
							</div>
							<div class="checkBoxes">
								<label><input type="checkbox"/><em></em> Je prends cette variable</label>
								<label><input type="checkbox"/><em></em> Je connais le montant des travaux  à prévoir <div class="euro"> <input type="text" value=""/><span>&euro;</span></div></label>
								<label><input type="checkbox"/><em></em> Je ne prends pas cette variable</label>
							</div>
						</div>
						<div class="reapter">
							<h6>LUMINOSITÉ</h6>
							<div class="textLeft">								
								<p>Valorisation de la variable Pondération valorisation de la variable </p>
							</div>
							<div class="formRight">
								<div class="quantity">
									<input type="number" min="0" max="999" step="1" value="0">
								</div>
								<div class="price">
									<div class="euro"> <input type="text" value=""/><span>&euro;</span></div>
									<div class="percent"><input type="text" value="+"/><span>%</span></div>
								</div>
							</div>
							<div class="checkBoxes">
								<label><input type="checkbox"/><em></em> Je prends cette variable</label>
							</div>
						</div>
						<div class="reapter">
							<h6>MItoyennete</h6>
							<div class="textLeft">								
								<p>Valorisation de la variable Pondération valorisation de la variable </p>
							</div>
							<div class="formRight">
								<div class="quantity">
									<input type="number" min="0" max="999" step="1" value="0">
								</div>
								<div class="price">
									<div class="euro"> <input type="text" value=""/><span>&euro;</span></div>
									<div class="percent"><input type="text" value="+"/><span>%</span></div>
								</div>
							</div>
							<div class="checkBoxes">
								<label><input type="checkbox"/><em></em> Je prends cette variable</label>
							</div>
						</div>
						<div class="reapter">
							<h6>Niveaux</h6>
							<div class="textLeft">								
								<p>Valorisation de la variable Pondération valorisation de la variable </p>
							</div>
							<div class="formRight">
								<div class="quantity">
									<input type="number" min="0" max="999" step="1" value="0">
								</div>
								<div class="price">
									<div class="euro"> <input type="text" value=""/><span>&euro;</span></div>
									<div class="percent"><input type="text" value="+"/><span>%</span></div>
								</div>
							</div>
							<div class="checkBoxes">
								<label><input type="checkbox"/><em></em> Je prends cette variable</label>
							</div>
						</div>
						<div class="reapter">
							<h6>Raccordement Eaux Uses</h6>
							<div class="textLeft">								
								<p>Valorisation de la variable Pondération valorisation de la variable </p>
							</div>
							<div class="formRight">
								<div class="quantity">
									<input type="number" min="0" max="999" step="1" value="0">
								</div>
								<div class="price">
									<div class="euro"> <input type="text" value=""/><span>&euro;</span></div>
									<div class="percent"><input type="text" value="+"/><span>%</span></div>
								</div>
							</div>
							<div class="checkBoxes">
								<label><input type="checkbox"/><em></em> Je prends cette variable</label>
								<label><input type="checkbox"/><em></em> Je connais le montant des travaux variable <div class="euro"> <input type="text" value=""/><span>&euro;</span></div></label>
								<label><input type="checkbox"/><em></em> Je ne prends pas cette variable</label>
							</div>
						</div>
					</div>
				</div>
				<div class="greenBorder">
					<div class="heading">
						<h5>2 - L’environment</h5>
					</div>
					<div class="panel">
						<div class="reapter">
							<h6>Vue dÉgagÉÉ</h6>
							<div class="textLeft">								
								<p>Valorisation de la variable Pondération valorisation de la variable </p>
							</div>
							<div class="formRight">
								<div class="quantity">
									<input type="number" min="0" max="999" step="1" value="0">
								</div>
								<div class="price">
									<div class="euro"> <input type="text" value=""/><span>&euro;</span></div>
									<div class="percent"><input type="text" value="+"/><span>%</span></div>
								</div>
							</div>
							<div class="checkBoxes">
								<label><input type="checkbox"/><em></em> Je prends cette variable</label>
							</div>
						</div>
						<div class="reapter">
							<h6>Calme</h6>
							<div class="textLeft">								
								<p>Valorisation de la variable Pondération valorisation de la variable </p>
							</div>
							<div class="formRight">
								<div class="quantity">
									<input type="number" min="0" max="999" step="1" value="0">
								</div>
								<div class="price">
									<div class="euro"> <input type="text" value=""/><span>&euro;</span></div>
									<div class="percent"><input type="text" value="+"/><span>%</span></div>
								</div>
								<div class="ponderation">
									<ul>
										<li class="active"></li>
										<li></li>
										<li></li>
									</ul>
								</div>
							</div>
							<div class="checkBoxes">
								<label><input type="checkbox"/><em></em> Je prends cette variable</label>
							</div>
						</div>
					</div>
				</div>
				<div class="greenBorder">
					<div class="heading">
						<h5>3 - Les Commodités</h5>
					</div>
					<div class="panel">
						<div class="reapter">
							<h6>Prroche Connerces</h6>
							<div class="textLeft">								
								<p>Valorisation de la variable Pondération valorisation de la variable </p>
							</div>
							<div class="formRight">
								<div class="quantity">
									<input type="number" min="0" max="999" step="1" value="0">
								</div>
								<div class="price">
									<div class="euro"> <input type="text" value=""/><span>&euro;</span></div>
									<div class="percent"><input type="text" value="+"/><span>%</span></div>
								</div>
							</div>
							<div class="checkBoxes">
								<label><input type="checkbox"/><em></em> Je prends cette variable</label>
							</div>
						</div>
						<div class="reapter">
							<h6>proximitÉ des transports</h6>
							<div class="textLeft">								
								<p>Valorisation de la variable Pondération valorisation de la variable </p>
							</div>
							<div class="formRight">
								<div class="quantity">
									<input type="number" min="0" max="999" step="1" value="0">
								</div>
								<div class="price">
									<div class="euro"> <input type="text" value=""/><span>&euro;</span></div>
									<div class="percent"><input type="text" value="+"/><span>%</span></div>
								</div>
							</div>
							<div class="checkBoxes">
								<label><input type="checkbox"/><em></em> Je prends cette variable</label>
							</div>
						</div>
						<div class="reapter">
							<h6>proximitÉ des Écoles</h6>
							<div class="textLeft">								
								<p>Valorisation de la variable Pondération valorisation de la variable </p>
							</div>
							<div class="formRight">
								<div class="quantity">
									<input type="number" min="0" max="999" step="1" value="0">
								</div>
								<div class="price">
									<div class="euro"> <input type="text" value=""/><span>&euro;</span></div>
									<div class="percent"><input type="text" value="+"/><span>%</span></div>
								</div>
							</div>
							<div class="checkBoxes">
								<label><input type="checkbox"/><em></em> Je prends cette variable</label>
							</div>
						</div>
						<div class="reapter">
							<h6>Piscine</h6>
							<div class="textLeft">								
								<p>Valorisation de la variable Pondération valorisation de la variable </p>
							</div>
							<div class="formRight">
								<div class="quantity">
									<input type="number" min="0" max="999" step="1" value="0">
								</div>
								<div class="price">
									<div class="euro"> <input type="text" value=""/><span>&euro;</span></div>
									<div class="percent"><input type="text" value="+"/><span>%</span></div>
								</div>
							</div>
							<div class="checkBoxes">
								<label><input type="checkbox"/><em></em> Je prends cette variable</label>
							</div>
						</div>
						<div class="reapter">
							<h6>Court de tennis</h6>
							<div class="textLeft">								
								<p>Valorisation de la variable Pondération valorisation de la variable </p>
							</div>
							<div class="formRight">
								<div class="quantity">
									<input type="number" min="0" max="999" step="1" value="0">
								</div>
								<div class="price">
									<div class="euro"> <input type="text" value=""/><span>&euro;</span></div>
									<div class="percent"><input type="text" value="+"/><span>%</span></div>
								</div>
							</div>
							<div class="checkBoxes">
								<label><input type="checkbox"/><em></em> Je prends cette variable</label>
							</div>
						</div>
					</div>
				</div>
			</aside>
			<aside class="rightCol col-xs-12 col-sm-12 col-md-12 col-lg-5">
				<div class="heading">Simulation en temps réel de la valeur indicative</div>
				<p><strong>ce que nous indique internet : << Prix m² indiqué à Douvaine>></strong></p>
				<p>Valeur indicative au m² : <strong>2937&euro; / m²</strong></p>
				<p>Valeur indicative du bien : <strong>455000 &euro;</strong></p>
				<p><strong>Ce qui varie suivant les paramétres prisen considération :</strong></p>
				<p>Valeur indicative au m² : <strong>2937&euro; / m²</strong></p>
				<p>Valeur indicative du bien : <strong>455000 &euro;</strong></p>
			</aside>
		</div>
	</div>
</div>