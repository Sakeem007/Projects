<div class="EtudeoNeuf_Wrapper">	
	<div class="row">
		<aside class="item col-xs-12 col-sm-12 col-md-12 col-lg-12">
			<!--<div class="filter">
				<form action="#" method="post">
					<ul>
						<li>Filtre :</li>
						<li><select>
							<option>Type</option>
							<option>Type</option>
							<option>Type</option>
						</select></li>
						<li><select>
							<option>Ville</option>
							<option>Ville</option>
							<option>Ville</option>
						</select></li>
						<li><select>
							<option>Pieus</option>
							<option>Pieus</option>
							<option>Pieus</option>
						</select></li>
						<li><select>
							<option>Euipe</option>
							<option>Euipe</option>
							<option>Euipe</option>
						</select></li>
						<li><input type="text" value="Mof clegr"/></li>
						<li class="btns"><button type="submit" class="submit"></button></li>
					</ul>
				</form>
			</div>-->
			<div class="EtudeoNeuf_container">
				<h3>ETAT DES LIEUX PATRIMONIAL</h3>
				<h5>Coordonnées personnelles et situation familiale :</h5>
				<form action="" class="EtudeoNeuf_form">
					<div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
						<label>1<sup>ère</sup> personne:</label>
						<input class="form-control" type="text" />
					</div>
					<div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
						<label>Né(e) le</label>
						<input class="form-control" type="text" placeholder="dd/mm/yyyy" id="tbDate" />
					</div>
					<div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
						<label>à</label>
						<input class="form-control" type="text" />
					</div>
					<div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
						<label>2<sup>ème</sup> personne:</label>
						<input class="form-control" type="text" />
					</div>
					<div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
						<label>Né(e) le</label>
						<input class="form-control" type="text" placeholder="dd/mm/yyyy" id="emeDate" />
					</div>
					<div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
						<label>à</label>
						<input class="form-control" type="text" />
					</div>
					<div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
						<label>Adresse:</label>
						<input class="form-control" type="text" />
					</div>					
					<div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
						<label>CP:</label>
						<input class="form-control" type="text" />
					</div>				
					<div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
						<label>Ville:</label>
						<input class="form-control" type="text" />
					</div>			
					<div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
						<label>Tél:</label>
						<input class="form-control" type="text" />
					</div>		
					<div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
						<label>E-mail perso:</label>
						<input class="form-control" type="text" />
					</div>	
					<div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
						<label>Régime matrimonial:</label>
						<select onchange="dateCheck(this);">
						<option value="celibataire">Célibataire</option>
						<option value="unionlibre">Union libre </option>
						<option value="pacs">PACS</option>
						<option value="mariage">Mariage </option>
						</select>
						<div id="depuisle" style="display: none;">
							<label >Depuis le:</label> 
						<input class="form-control" type="text" placeholder="dd/mm/yyyy" id="pacsDate" />
						</div>
						<div id="chbox" style="display: none;">
							<label >Depuis le:</label> 
						<input class="form-control" type="text" placeholder="dd/mm/yyyy" id="mariDate" />
							<div class="chack_Fld">
								<p><input onchange="dateCheck(this);" name="" type="checkbox" value="chackfld" /> <span>Sans contrat de mariage</span></p>
								<p><input onchange="dateCheck(this);" name="" type="checkbox" value="chackfld" /> <span>Avec contrat de mariage</span></p>
							</div>
						</div>
					</div>
					<div id="lacommunaute" class="col-xs-12 col-sm-6 col-md-4 col-lg-4" style="display: none;">
						<label>Sous le régime de:</label>
						<select onchange="dateCheck(this);">
							<option value="">La communauté réduite aux acquets</option>
							<option value="other">La séparation de biens</option>
							<option value="">La communauté universelle</option>
							<option value="">La participation aux acquets</option>
						</select>
					</div>						
				</form>
			</div>	
			<div class="SecondWrapper">
				<form action="" class="">
					<h4>Les Revenus / La  Situation Professionnelle</h4>
					<div class="PersonneList">
						<ul>
							<li>&nbsp;</li>
							<li><strong>Personne 1</strong></li>
							<li><strong>Personne 2</strong></li>
							<li>Revenus (régime)</li>
							<li><input type="text" /></li>
							<li><input type="text" /></li>
							<li>Revenus locatifs (régime)</li>
							<li><input type="text" /></li>
							<li><input type="text" /></li>
							<li>Revenus mobiliers</li>
							<li><input type="text" /></li>
							<li><input type="text" /></li>
							<li>Revenus divers</li>
							<li><input type="text" /></li>
							<li><input type="text" /></li>
							<li>Secteur d’activité</li>
							<li><input type="text" /></li>
							<li><input type="text" /></li>
							<li>Ancienneté dans l’activité</li>
							<li><input type="text" /></li>
							<li><input type="text" /></li>
							<li><strong>Total</strong></li>
							<li><strong>=B2+B3+B4+B5</strong></li>
							<li><strong>=C2+C3+C4+C5</strong></li>					
						</ul>
					</div>
				</form>
			</div>
			<div class="ThardWrapper">
					<form action="" class="EtudeoNeuf_form">
					<h4>Comment imaginez-vous l'évolution de votre activité dans 5 ans ?</h4>
					<div class="PersonneList">
						<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
							<label>1<sup>ère</sup> personne:</label>
							<textarea class="form-control" name="" cols="" rows=""></textarea>
						</div>
						<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
							<label>2<sup>ème</sup> personne:</label>
							<textarea class="form-control" name="" cols="" rows=""></textarea>
						</div>
						<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
							<label>Si chef d’entreprise soumise à l’IS, quel est l’IS en moyenne ?</label>
							<input class="form-control" type="text" />
						</div>
						<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
							<label>Quel est le résultat comptable en moyenne ?</label>
							<input class="form-control" type="text" />
						</div>
						
						<div class="clearfix"></div>
						<h3>IMPOTS ET CHARGES</h3>
						<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6 ImpotsBox1">
							<label>Quel est le montant de vos impôts fonciers et/ou habitation ?</label>
							<span>€</span><input class="form-control" type="text" />
						</div>						
						<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
							<div id="choice1" class="col-xs-12 col-sm-6 col-md-6 col-lg-6" style="padding-left:0;">
								<label>Devez vous verser une pension :</label>
								<select class="form-control" onchange="valueCheck(this);">
									<option id="No">Choice</option>
									<option id="Yes" value="yes">OUI</option>
									<option id="No">NON</option>
								</select>
							</div>
							<div id="MontantYes" class="col-xs-12 col-sm-6 col-md-6 col-lg-6" style="display:none; padding-right:0;">
								<label>Montant :</label>
								<span>€</span><input class="form-control" type="text" />
							</div>
						</div>	
						<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6 ImpotsBox2">
							<label>Quel est le montant de votre dernier avis d'imposition ?</label>
							<span>€</span><input class="form-control" type="text" />
						</div>
						<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6 ImpotsBox3">
							<label>A combien évaluez-vous le montant de vos impôts pour l'année à venir ?</label>
							<span>€</span><input class="form-control" type="text" />
						</div>
						<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
							<label>Quelle est votre TMI?</label>
							<input class="form-control" type="text" />
						</div>
						<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
							<label>Nombre de parts du foyer fiscal </label>
							<input class="form-control" type="text" />
						</div>
						<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
							<div id="choice2" class="col-xs-12 col-sm-6 col-md-6 col-lg-6" style="padding-left:0;">
								<label>Avez-vous déjà fait une donation entre époux/ à vos enfants/ un testament : </label>
								<select class="form-control" onchange="dataCheck(this);" >
									<option id="chNo">Choice</option>
									<option id="chy" value="yes">OUI</option>
									<option id="chNo">NON</option>
								</select>
							</div>
							<div id="MontantNo" class="col-xs-12 col-sm-6 col-md-6 col-lg-6 TopSpc" style="display:none; padding-right:0;">
								<label><!-- Montant, le cas échéant -->Montant: </label>
								<span>€</span><input class="form-control" type="text" />
							</div>
						</div>
						<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6 TopSpc">
							<label>Quelles déductions avez-vous réalisées sur vos revenus ?</label>
							<input class="form-control" type="text" />
						</div>
						<div class="clearfix"></div>
						<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
							<label>Qu'avez-vous entrepris jusqu'à ce jour pour diminuer vos impôts ? </label>
							<input class="form-control" type="text" />
						</div>
						<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
							<label>Concernant votre logement, vous êtes :</label>
							<select class="form-control">
								<option>Choice</option>
								<option>Propriétaire</option>
								<option>Locataire</option>
								<option>Hébergé à titre gratuit</option>
								<option>Logé par nécessité absolue de service</option>
							</select>
						</div>
					</div>
				</form>
			</div>
			<div class="FourthdWrapper">
				<form action="" class="EtudeoNeuf_form">
					<h3>COMPOSITION DU PATRIMOINE</h3>
					<h4>ACTIF</h4>
					<table width="100%" border="0" cellspacing="10" cellpadding="0">
						<tr>
							<th width="18%">IMMOBILIER</th>
							<th width="18%">Valeur achat</th>
							<th width="18%">Depuis le</th>
							<th width="18%">Lieu</th>
							<th width="28%">Remarques</th>
						</tr>
						<tr>
							<td>Rés. Principale</td>
							<td class="EuroSemb"><span>€</span><input type="text" /></td>
							<td><input type="text" placeholder="dd/mm/yyyy" id="emeDate" /></td>
							<td><input type="text" placeholder="City" /></td>
							<td><textarea name="" cols="" rows=""> </textarea></td>
						</tr>
						<tr>
							<td>Rés. Secondaire</td>
							<td class="EuroSemb"><span>€</span><input type="text" /></td>
							<td><input type="text" placeholder="dd/mm/yyyy" id="emeDate" /></td>
							<td><input type="text" placeholder="City" /></td>
							<td><textarea name="" cols="" rows=""> </textarea></td>
						</tr>
						<tr>
							<td>Locatif</td>
							<td class="EuroSemb"><span>€</span><input type="text" /></td>
							<td><input type="text" placeholder="dd/mm/yyyy" id="emeDate" /></td>
							<td><input type="text" placeholder="City" /></td>
							<td><textarea name="" cols="" rows=""> </textarea></td>
						</tr>
						<tr>
							<td>Autres</td>
							<td class="EuroSemb"><span>€</span><input type="text" /></td>
							<td><input type="text" placeholder="dd/mm/yyyy" id="emeDate" /></td>
							<td><input type="text" placeholder="City" /></td>
							<td><textarea name="" cols="" rows=""> </textarea></td>
						</tr>
						<tr>
							<th width="18%">VALEURS MOBILIERES</th>
							<th width="18%">Vous</th>
							<th width="18%">Votre conjoint</th>
							<th width="18%">Depuis le</th>
							<th width="28%">Remarques</th>
						</tr>
						<tr>
							<td>Actions/obligations</td>
							<td class="EuroSemb"><span>€</span><input type="text" /></td>
							<td class="EuroSemb"><span>€</span><input type="text" /></td>
							<td><input type="text" placeholder="dd/mm/yyyy" id="emeDate" /></td>
							<td><textarea name="" cols="" rows=""> </textarea></td>
						</tr>
						<tr>
							<td>SICAV / FCP</td>
							<td class="EuroSemb"><span>€</span><input type="text" /></td>
							<td class="EuroSemb"><span>€</span><input type="text" /></td>
							<td><input type="text" placeholder="dd/mm/yyyy" id="emeDate" /></td>
							<td><textarea name="" cols="" rows=""> </textarea></td>
						</tr>
						<tr>
							<td>Assurance vie</td>
							<td class="EuroSemb"><span>€</span><input type="text" /></td>
							<td class="EuroSemb"><span>€</span><input type="text" /></td>
							<td><input type="text" placeholder="dd/mm/yyyy" id="emeDate" /></td>
							<td><textarea name="" cols="" rows=""> </textarea></td>
						</tr>
						<tr>
							<th width="18%">EPARGNE</th>
							<th width="18%">Vous</th>
							<th width="18%">Votre conjoint</th>
							<th width="18%">Depuis le</th>
							<th width="28%">Remarques</th>
						</tr>
						<tr>
							<td>Livret d’épargne</td>
							<td class="EuroSemb"><span>€</span><input type="text" /></td>
							<td class="EuroSemb"><span>€</span><input type="text" /></td>
							<td><input type="text" placeholder="dd/mm/yyyy" id="emeDate" /></td>
							<td><textarea name="" cols="" rows=""> </textarea></td>
						</tr>
						<tr>
							<td>CODEVI</td>
							<td class="EuroSemb"><span>€</span><input type="text" /></td>
							<td class="EuroSemb"><span>€</span><input type="text" /></td>
							<td><input type="text" placeholder="dd/mm/yyyy" id="emeDate" /></td>
							<td><textarea name="" cols="" rows=""> </textarea></td>
						</tr>
						<tr>
							<td>PEL</td>
							<td class="EuroSemb"><span>€</span><input type="text" /></td>
							<td class="EuroSemb"><span>€</span><input type="text" /></td>
							<td><input type="text" placeholder="dd/mm/yyyy" id="emeDate" /></td>
							<td><textarea name="" cols="" rows=""> </textarea></td>
						</tr>
						<tr>
							<td>CEL</td>
							<td class="EuroSemb"><span>€</span><input type="text" /></td>
							<td class="EuroSemb"><span>€</span><input type="text" /></td>
							<td><input type="text" placeholder="dd/mm/yyyy" id="emeDate" /></td>
							<td><textarea name="" cols="" rows=""> </textarea></td>
						</tr>
						<tr>
							<td>Autres</td>
							<td class="EuroSemb"><span>€</span><input type="text" /></td>
							<td class="EuroSemb"><span>€</span><input type="text" /></td>
							<td><input type="text" placeholder="dd/mm/yyyy" id="emeDate" /></td>
							<td><textarea name="" cols="" rows=""> </textarea></td>
						</tr>
					</table>					
					
				</form>
			</div>
			<div class="PassifdWrapper">
				<form action="" class="EtudeoNeuf_form">
					<h4>PASSIF</h4>
					<table width="100%" border="0" cellspacing="10" cellpadding="0">
						<tr>
							<th width="16%">CHARGES/PRETS</th>
							<th width="14%">Type de prêt (%)</th>
							<th width="14%">Taux</th>
							<th width="14%">Montant emprunté</th>
							<th width="14%">Capital restant du</th>
							<th width="14%">Fin du prêt</th>
							<th width="14%">Rbrst/mois</th>
						</tr>
						<tr>
							<td>Rés. Principale</td>
							<td><input type="text" /></td>
							<td class="EuroSembPrs"><input type="text" /><b>%</b></td>
							<td class="EuroSemb"><span>€</span><input type="text" /></td>
							<td class="EuroSemb"><span>€</span><input type="text" /></td>
							<td><input type="text" placeholder="dd/mm/yyyy" id="emeDate" /></td>
							<td class="EuroSemb"><span>€</span><input type="text" /></td>
						</tr>
						<tr>
							<td>Rés. Secondaire</td>
							<td><input type="text" /></td>
							<td class="EuroSembPrs"><input type="text" /><b>%</b></td>
							<td class="EuroSemb"><span>€</span><input type="text" /></td>
							<td class="EuroSemb"><span>€</span><input type="text" /></td>
							<td><input type="text" placeholder="dd/mm/yyyy" id="emeDate" /></td>
							<td class="EuroSemb"><span>€</span><input type="text" /></td>
						</tr>
						<tr>
							<td>Crédit 1</td>
							<td><input type="text" /></td>
							<td class="EuroSembPrs"><input type="text" /><b>%</b></td>
							<td class="EuroSemb"><span>€</span><input type="text" /></td>
							<td class="EuroSemb"><span>€</span><input type="text" /></td>
							<td><input type="text" placeholder="dd/mm/yyyy" id="emeDate" /></td>
							<td class="EuroSemb"><span>€</span><input type="text" /></td>
						</tr>
						<tr>
							<td>Crédit 2</td>
							<td><input type="text" /></td>
							<td class="EuroSembPrs"><input type="text" /><b>%</b></td>
							<td class="EuroSemb"><span>€</span><input type="text" /></td>
							<td class="EuroSemb"><span>€</span><input type="text" /></td>
							<td><input type="text" placeholder="dd/mm/yyyy" id="emeDate" /></td>
							<td class="EuroSemb"><span>€</span><input type="text" /></td>
						</tr>
						<tr>
							<td>Crédit 3</td>
							<td><input type="text" /></td>
							<td class="EuroSembPrs"><input type="text" /><b>%</b></td>
							<td class="EuroSemb"><span>€</span><input type="text" /></td>
							<td class="EuroSemb"><span>€</span><input type="text" /></td>
							<td><input type="text" placeholder="dd/mm/yyyy" id="emeDate" /></td>
							<td class="EuroSemb"><span>€</span><input type="text" /></td>
						</tr>
						<tr>
							<td>Autres</td>
							<td><input type="text" /></td>
							<td class="EuroSembPrs"><input type="text" /><b>%</b></td>
							<td class="EuroSemb"><span>€</span><input type="text" /></td>
							<td class="EuroSemb"><span>€</span><input type="text" /></td>
							<td><input type="text" placeholder="dd/mm/yyyy" id="emeDate" /></td>
							<td class="EuroSemb"><span>€</span><input type="text" /></td>
						</tr>
						<tr>
							<td colspan="6" align="center" style="font-waight:700;">TOTAL CHARGES</td>
							<td class="EuroSemb"><span>€</span><input type="text" /></td>
						</tr>
					</table>
					<div  class="BottomQues">
					<p>D’où un endettement actuel de <input type="text" /><span>%</span> </p>
					<p>Soit une capacité d’investissement actuelle de <input type="text" /><span>%</span>  soit, en euros <input type="text" /><span>€</span></p>
					</div>
				</form>
			</div>
		</aside>
	</div>
</div>
    <link href="css/jquery-ui.css" rel="stylesheet" />
    <script type="text/javascript" src="js/datepicker.js"></script>
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.8.1/jquery-ui.min.js"></script>
<script>
    function dateCheck(that) {
        if (that.value == "pacs") {
            //alert("check");
            document.getElementById("depuisle").style.display = "block";
        } else {
            document.getElementById("depuisle").style.display = "none";
        }
        if (that.value == "mariage") {
            //alert("check");
            document.getElementById("chbox").style.display = "block";
        } else {
            //document.getElementById("chbox").style.display = "none";
        }
        if (that.value == "chackfld") {
            //alert("check");
            document.getElementById("lacommunaute").style.display = "block";
        } else {
            //document.getElementById("lacommunaute").style.display = "none";
        }
        if (that.value == "celibataire") {
            //alert("check");
            document.getElementById("chbox").style.display = "none";
        } else {
        }
        if (that.value == "celibataire") {
            //alert("check");
            document.getElementById("lacommunaute").style.display = "none";
        } else {
        }
        if (that.value == "unionlibre") {
            //alert("check");
            document.getElementById("chbox").style.display = "none";
        } else {
        }
        if (that.value == "unionlibre") {
            //alert("check");
            document.getElementById("lacommunaute").style.display = "none";
        } else {
        }
		
    };
	///Montant Yes
    function valueCheck(that) {       
		
		if (that.value == "yes") {
            document.getElementById("MontantYes").style.display = "block";
        } else {
            document.getElementById("MontantYes").style.display = "none";
        }
		
	/* jQuery('select').click(function(){
		if (that.value == "yes") {
            jQuery('#choice1').addClass('col-lg-3');
        } else {
            jQuery('#choice1').removeClass('col-lg-3');
        }		
	}); */
    };
	///Montant No
    function dataCheck(that) { 
		if (that.value == "yes") {
            document.getElementById("MontantNo").style.display = "block";
        } else {
            document.getElementById("MontantNo").style.display = "none";
        }
	/* jQuery('select').click(function(){
		if (that.value == "yes") {
            jQuery('#choice2').addClass('col-lg-3');
        } else {
            jQuery('#choice2').removeClass('col-lg-3');
        }		
	}); */
    };

/// date

	$('input[id$=tbDate]').datepicker({
		dateFormat: 'dd-mm-yy'
	});	
	$('input[id$=emeDate]').datepicker({
		dateFormat: 'dd-mm-yy'
	});	
	$('input[id$=pacsDate]').datepicker({
		dateFormat: 'dd-mm-yy'
	});	
	$('input[id$=mariDate]').datepicker({
		dateFormat: 'dd-mm-yy'
	});

</script>