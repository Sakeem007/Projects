<div class="LatestSale">
	<div class="UnbanimoTxtbox">
		<h5>Découvrez les dernières ventes réalisées autour d'un référent (code postal, ville, adresse...)</h5>
		<input type="search" placeholder="Ex : '10 rue du Château', 'Paris 15', '69002...' " /><button type="button">Découvrir</button>
		<p>Valeurs foncières mises à disposition par ETALAB</p>
	</div>
</div>	