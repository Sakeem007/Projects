<?php include('header.php');?>
	
	<!-- Being: offrimo box -->
	<article class="offrimoBox">
		<div class="container">	
			<nav class="nav nav-tab">
				<ul>
					<li class="active"><a href="#Diffusimo" data-toggle="tab">Diffusimo<small>"Performance & tracking"</small></a></li>
				</ul>
			</nav>
			<div class="tab-content">
				<div id="Diffusimo" class="item tab-pane fade in active">
					<div class="row">
						<div class="tab-content">
							<div id="SolusoftDiffusimo" class="item tab-pane fade in active">
								<div class="row">
									<?php include('solusoft-diffusimo.php');?>
								</div>
							</div>
							<!--<div id="DiffusimoFairerapport" class="item tab-pane fade">
								<div class="row">
									<?php //include('offrimo-diffusimo-fairerapport.php');?>
								</div>
							</div>-->				
						</div>
					</div>
				</div>
			</div>
			
		</div>
	</article>
	<!-- End: offrimo box -->

<?php include('footer.php');?>
<?php include('modal.php');?>