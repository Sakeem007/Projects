<div class="formGrid">
	<div class="tableColum col-xs-12 col-sm-6 col-md-6 col-lg-6">
		<div class="profile">
			<div class="img" style="background-image: url(images/pro1.png);">
				<div class="overlay">
					<div class="overlay__text">
					  <input type="image" src="images/upload.png" width="30px"/>
					  <input type="file" style="display: none;" />
					  <div>Upload Image</div>
					</div>
				</div>
			</div>
			
			<div class="text">
				<h5>Philippe Soulie</h5>
				<small>Home Conseiller</small>
			</div>
		</div>
		<div class="form">
			<div class="title">Mes Informations :</div>
			<form action="#" method="post">
				<div class="form-group">
					<label>Identifiant connexion :</label>
					<div class="input-field">
						<input type="text" name="" value=""/>
					</div>
				</div>
				<div class="form-group">
					<label>Mot de passe :</label>
					<div class="input-field">
						<input type="text" name="" value=""/>
					</div>
				</div>
				<div class="form-group">
					<label>Titre :</label>
					<div class="input-field">
						<input type="text" name="" value=""/>
					</div>
				</div>
				<div class="form-group">
					<label>Nom :</label>
					<div class="input-field">
						<input type="text" name="" value=""/>
					</div>
				</div>
				<div class="form-group">
					<label>Prenom :</label>
					<div class="input-field">
						<input type="text" name="" value=""/>
					</div>
				</div>
				<div class="form-group">
					<label>Email :</label>
					<div class="input-field">
						<input type="email" name="" value=""/>
					</div>
				</div>
				<div class="form-group">
					<label>N<sup>o</sup> Portable :</label>
					<div class="input-field">
						<input type="text" name="" value=""/>
					</div>
				</div>
				<div class="form-group">
					<label>N<sup>o</sup> Fixe :</label>
					<div class="input-field">
						<input type="text" name="" value=""/>
					</div>
				</div>
				<div class="form-group">
					<label>Adresse :</label>
					<div class="input-field">
						<input type="text" name="" value=""/>
					</div>
				</div>
				<div class="photo-group">
					<ul>
						<li>Photo utilisees :</li>
						<li>
							<div class="img" style="background-image: url(images/pro1.png);">
								<div class="overlay">
									<div class="overlay__text">
									  <input type="image" src="images/upload.png" width="20px"/>
									  <input type="file" style="display: none;" />
									  <div>Upload Image</div>
									</div>
								</div>
							</div>
							Espace Home Conseiller
						</li>
						<li>
							<div class="img" style="background-image: url(images/pro1.png);">
								<div class="overlay">
									<div class="overlay__text">
									  <input type="image" src="images/upload.png" width="20px"/>
									  <input type="file" style="display: none;" />
									  <div>Upload Image</div>
									</div>
								</div>
							</div>
							Carte Visite
						</li>
						<li>
							<div class="img" style="background-image: url(images/pro1.png);">
								<div class="overlay">
									<div class="overlay__text">
									  <input type="image" src="images/upload.png" width="20px"/>
									  <input type="file" style="display: none;" />
									  <div>Upload Image</div>
									</div>
								</div>
							</div>
							Signature mail
						</li>
					</ul>
				</div>
				<div class="form-group">
					<input type="submit" value="Sauvegarder" class="submit"/>
				</div>
			</form>
		</div>
	</div>
	<div class="tableColum col-xs-12 col-sm-6 col-md-6 col-lg-6">
		<div class="profile">
			<div class="img" style="background-image: url(images/pro2.png);">
				<div class="overlay">
					<div class="overlay__text">
					  <input type="image" src="images/upload.png" width="30px"/>
					  <input type="file" style="display: none;" />
					  <div>Upload Image</div>
					</div>
				</div>
			</div>
			<div class="text">
				<h5>Votre Agence</h5>
				<small>Home Conseiller</small>
			</div>
		</div>
		<div class="form">
			<div class="title">Mes agence :</div>
			<form action="#" method="post">
				<div class="form-group">
					<label>Nom de I’agence :</label>
					<div class="input-field">
						<input type="text" name="" value="L'IMMOBILIER" disabled=""/>
					</div>
				</div>
				<div class="form-group">
					<label>Tel :</label>
					<div class="input-field">
						<input type="text" name="" value="0457 430 050" disabled=""/>
					</div>
				</div>
				<div class="form-group">
					<label>E-mail :</label>
					<div class="input-field">
						<input type="text" name="" value="administratif@limmobilier.net" disabled=""/>
					</div>
				</div>
				<div class="form-group">
					<label>Adresse :</label>
					<div class="input-field">
						<input type="text" name="" value="2avenue du Lac 74140 DOUVAINE" disabled=""/>
					</div>
				</div>
				<div class="form-group">
					<label>Site web :</label>
					<div class="input-field">
						<input type="text" name="" value="www.limmobilier.net" disabled=""/>
					</div>
				</div>
				<div class="form-group">
					<label>Description :</label>
					<div class="input-field">
						<textarea type="text" value="" disabled=""></textarea>
					</div>
				</div>
				<div class="form-meter">
					<label>Metiers :</label>
					<div class="meter-field">
						<ul>
							<li><label><input type="checkbox" checked="" disabled=""/><span></span> Transaction</label></li>
							<li><label><input type="checkbox" checked="" disabled=""/><span></span> Location Saisonniere</label></li>
							<li><label><input type="checkbox" disabled=""/><span></span> Gestion</label></li>
							<li><label><input type="checkbox" checked="" disabled=""/><span></span> Le Neuf</label></li>
							<li><label><input type="checkbox" disabled=""/><span></span> Syndic</label></li>
							<li><label><input type="checkbox" disabled=""/><span></span> Commerces & Enterprises</label></li>
						</ul>
					</div>
				</div>
			</form>
		</div>
	</div>
	<div class="tableColum col-xs-12 col-sm-12 col-md-12 col-lg-12">
		<div class="packList">
			<div class="title">Mon Pack :</div>
			<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
				<div class="pack">
					<label>Options incluses dans votre contrat :</label>
					<ul>
						<li><a href="#">Formations</a></li>
						<li><a href="#">Acces Interface</a></li>
						<li><a href="#">Acces logiciel</a></li>
						<li><a href="#">Acces Documents</a></li>
						<li><a href="#">Diffusion illimitee sur limmobilier.net</a></li>
						<li><a href="#">Diffusion illimitee sur les sites partenaires</a></li>
					</ul>
				</div>
			</div>
			<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
				<div class="pack">
					
					<label>Options Back Office :</label>					
					
					<div class="pack">
						<label>Call center :</label>
						<ul>
							<li><a href="#">Script S1 (Pages blanches)</a></li>
							<li><a href="#">Script S2 (Petites annonces)</a></li>
							<li><a href="#">Script S3 (Suivi clients)</a></li>
						</ul>
					</div>
					<div class="pack">
						<label>Marketing :</label>
						<ul>
							<li><a href="#">Impression cartes de visite supplementaires</a></li>
							<li><a href="#">Impression Journal MONIMO</a></li>
							<li><a href="#">Impression documents sur mesure (flyers, mailing,..)</a></li>
						</ul>
					</div>
					<div class="pack">
						<label>Reporting :</label>
						<ul>
							<li><a href="#">Suivi activite</a></li>
							<li><a href="#">Suivi portefeuille</a></li>
							<li><a href="#">Suivi dossiers de vente</a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>