	<!-- Being: offrimo box -->
	<article class="offrimoBox">
		<div class="container">
			<nav class="nav nav-tab">
				<ul>
					<li class="active"><a href="#MenDelegations" data-toggle="tab">Men Délégations</a></li>
					<li><a href="#MesInvitations" data-toggle="tab">Mes Invitations</a></li>
				</ul>
			</nav>
			<div class="tab-content">
				<div id="MenDelegations" class="item tab-pane fade in active">
					<div class="row">
						<nav class="nav nav-tab">
							<ul>
								<li class="active"><a href="#CurrentDelegation" data-toggle="tab">Délégation en Cours</a></li>
								<li><a href="#DelegationAccepted" data-toggle="tab">Délégation acceptée</a></li>
								<li><a href="#DelegationRecorded" data-toggle="tab">Délégation actée</a></li>
							</ul>
						</nav>
						<div class="tab-content">
							<div id="CurrentDelegation" class="item tab-pane fade in active">
								<div class="row">
									<?php include('men-current-delegation.php');?>
								</div>
							</div>
							<div id="DelegationAccepted" class="item tab-pane fade">
								<div class="row">
									<?php include('men-delegation-accepted.php');?>
								</div>
							</div>	
							<div id="DelegationRecorded" class="item tab-pane fade">
								<div class="row">
									<?php include('men-delegation-recorded.php');?>
								</div>
							</div>				
						</div>
					</div>
				</div>
				<div id="MesInvitations" class="item tab-pane fade">
					<div class="row">
						<?php include('mes-invitations.php');?>
					</div>
				</div>				
			</div>
			
		</div>
	</article>
	<!-- End: offrimo box -->
