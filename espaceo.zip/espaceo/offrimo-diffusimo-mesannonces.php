<div class="banners" style="background-image: url(images/research-motor-img.png);">
	<div class="Banners_TxT">	
		<h2>Diffusimo</h2>
		<h5>
		<p>"Je veux consulter mes requêtes
			<select>
				<option>Vente</option>
				<option>Location</option>
			</select>qui sont
			<select>
				<option>Online</option>
				<option>Offline</option>
			</select>
		</p>
		<p>pour mes  
			<select>
				<option>Maison</option>
				<option>Appartement</option>
				<option>Terrain</option>
			</select>situées Code
			<select>
				<option>Postal</option>
				<option>Ville</option>
			</select>
		"</p>
	</div>
</div>
<div class="offrimo">
	<div class="filter diffusimo">
		<form action="#" method="post">
			<ul>
				<li>Filtre :</li>
				<li>
					<select>
						<option>par support</option>
					</select>
				</li>
				<li>
					<input type="date" placeholder="Date parution" />
				</li>
				<li>
					<select>
						<option>Trie par prix</option>
					</select>
				</li>
				<li>
					<select>
						<option>Par agent</option>
					</select>
				</li>
				<li>
					<input type="text" />
				</li>
				<li class="btns">
					<button class="submit" type="submit"></button>            
				</li>
				<li class="btns">
					<a class="resetlast" href="#"></a> 
				</li>
			</ul>
		</form>
	</div>
	<div class="listing">
		<form action="#" method="post">
			<ul>
				<li> Listing des requêtes:</li>
				<li><span>25</span></li>
				<li>
					<select>
						<option>Affichage</option>
						<option>List</option>
						<option>Mosaic</option>
					</select>
				</li>
				<li>
					<select>
						<option>10 biens</option>
						<option>20</option>
						<option>30</option>
					</select>
				</li>
			</ul>
		</form>
	</div>
	<div class="Diffusimo_containtWrapper">
		<div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
			<div class="Alertimo_repBox">
				<div class="Alertimo_repBox_header">
					<div class="diffHeader_left">
						<i class="fa fa-building"></i>
						<h4>Appartement
						<span>74360 Bonnes</span>
						</h4>
					</div>
					<div class="diffHeader_right">Il y a 6jrs</div>	
					<div class="clearfix"></div>
				</div>
				<div class="Diffusimo_repBox_body">
					<div id="DiffusimoAppartement" class="carousel slide" data-ride="carousel">
						<div class="carousel-inner">
							<div class="plus_cont">
							<i class="fa fa-plus"></i>
							<div class="txt_cont">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,
							</div>
							</div>
							<div class="item active" style="background:url(images/offrimo1.png)"></div>
							<div class="item" style="background:url(images/offrimo2.png)"></div>
						</div>
						<!-- Left and right controls -->
						<a class="left carousel-control" href="#DiffusimoAppartement" data-slide="prev"> 
							<span class="glyphicon glyphicon-chevron-left"></span>  <span class="sr-only">Previous</span> 
						</a>
						<a class="right carousel-control" href="#DiffusimoAppartement" data-slide="next"> 
							<span class="glyphicon glyphicon-chevron-right"></span>  <span class="sr-only">Next</span> 
						</a>
					</div>
					<div class="diff_tags">
						<div class="diff_tags_left"><span>65m²</span><span>3P</span></div>
						<div class="diff_tags_right">283 000euros
                           <span>4 183euros/m²</span></div>
					</div>
				</div>
				<div class="Diffusimo_repBox_footer">
					<ul>
						<li>
							<select>
								<option>Voir l'offre</option>
								<option>Le boncoin</option>
								<option>Seloger</option>
								<option>Logicimmo</option>
							</select>
						</li>
						<li><img src="images/rankimo.png"/> 3/12</li>
						<li><i class="fa fa-eye"></i> 15</li>
					</ul></div>
				<div class="clr"></div>
			</div>
		</div>
		<div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
			<div class="Alertimo_repBox">
				<div class="Alertimo_repBox_header">
					<div class="diffHeader_left">
						<i class="fa fa-home"></i>
						<h4>Maison
						<span>74360 Bonnes</span>
						</h4>
					</div>
					<div class="diffHeader_right">Il y a 6jrs</div>	
					<div class="clearfix"></div>
				</div>
				<div class="Diffusimo_repBox_body">
					<div id="MaisonAppartement" class="carousel slide" data-ride="carousel">
						<div class="carousel-inner">
							<div class="plus_cont">
							<i class="fa fa-plus"></i>
							<div class="txt_cont">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,
							</div>
							</div>
							<div class="item active" style="background:url(images/offrimo1.png)"></div>
							<div class="item" style="background:url(images/offrimo2.png)"></div>
						</div>
						<!-- Left and right controls -->
						<a class="left carousel-control" href="#MaisonAppartement" data-slide="prev"> 
							<span class="glyphicon glyphicon-chevron-left"></span>  <span class="sr-only">Previous</span> 
						</a>
						<a class="right carousel-control" href="#MaisonAppartement" data-slide="next"> 
							<span class="glyphicon glyphicon-chevron-right"></span>  <span class="sr-only">Next</span> 
						</a>
					</div>
					<div class="diff_tags">
						<div class="diff_tags_left"><span>65m²</span><span>3P</span></div>
						<div class="diff_tags_right">283 000euros
                           <span>4 183euros/m²</span></div>
					</div>
				</div>
				<div class="Diffusimo_repBox_footer">
					<ul>
						<li>
							<select>
								<option>Voir l'offre</option>
								<option>Le boncoin</option>
								<option>Seloger</option>
								<option>Logicimmo</option>
							</select>
						</li>
						<li><img src="images/rankimo.png"/> 3/12</li>
						<li><i class="fa fa-eye"></i> 15</li>
					</ul></div>
				<div class="clr"></div>
			</div>
		</div>
		<div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
			<div class="Alertimo_repBox">
				<div class="Alertimo_repBox_header">
					<div class="diffHeader_left">
						<i class="fa fa-home"></i>
						<h4>Terrain
						<span>74360 Bonnes</span>
						</h4>
					</div>
					<div class="diffHeader_right">Il y a 6jrs</div>	
					<div class="clearfix"></div>
				</div>
				<div class="Diffusimo_repBox_body">
					<div id="TerrainAppartement" class="carousel slide" data-ride="carousel">
						<div class="carousel-inner">
							<div class="plus_cont">
							<i class="fa fa-plus"></i>
							<!--<i class="fa fa-close"></i>-->
							<div class="txt_cont">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,
							</div>
							</div>
							<div class="item active" style="background:url(images/offrimo1.png)"></div>
							<div class="item" style="background:url(images/offrimo2.png)"></div>
						</div>
						<!-- Left and right controls -->
						<a class="left carousel-control" href="#TerrainAppartement" data-slide="prev"> 
							<span class="glyphicon glyphicon-chevron-left"></span>  <span class="sr-only">Previous</span> 
						</a>
						<a class="right carousel-control" href="#TerrainAppartement" data-slide="next"> 
							<span class="glyphicon glyphicon-chevron-right"></span>  <span class="sr-only">Next</span> 
						</a>
					</div>
					<div class="diff_tags">
						<div class="diff_tags_left"><span>65m²</span><span>3P</span></div>
						<div class="diff_tags_right">283 000euros
                           <span>4 183euros/m²</span></div>
					</div>
				</div>
				<div class="Diffusimo_repBox_footer">
					<ul>
						<li>
							<select>
								<option>Voir l'offre</option>
								<option>Le boncoin</option>
								<option>Seloger</option>
								<option>Logicimmo</option>
							</select>
						</li>
						<li><img src="images/rankimo.png"/> 3/12</li>
						<li><i class="fa fa-eye"></i> 15</li>
					</ul></div>
				<div class="clr"></div>
			</div>
		</div>
		<div class="clr"></div>
		<div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
			<div class="Alertimo_repBox">
				<div class="Alertimo_repBox_header">
					<div class="diffHeader_left">
						<i class="fa fa-building"></i>
						<h4>Appartement
						<span>74360 Bonnes</span>
						</h4>
					</div>
					<div class="diffHeader_right">Il y a 6jrs</div>	
					<div class="clearfix"></div>
				</div>
				<div class="Diffusimo_repBox_body">
					<div id="DiffusimoAppartement1" class="carousel slide" data-ride="carousel">
						<div class="carousel-inner">
							<div class="plus_cont">
							<i class="fa fa-plus"></i>
							<div class="txt_cont">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,
							</div>
							</div>
							<div class="item active" style="background:url(images/offrimo1.png)"></div>
							<div class="item" style="background:url(images/offrimo2.png)"></div>
						</div>
						<!-- Left and right controls -->
						<a class="left carousel-control" href="#DiffusimoAppartement1" data-slide="prev"> 
							<span class="glyphicon glyphicon-chevron-left"></span>  <span class="sr-only">Previous</span> 
						</a>
						<a class="right carousel-control" href="#DiffusimoAppartement1" data-slide="next"> 
							<span class="glyphicon glyphicon-chevron-right"></span>  <span class="sr-only">Next</span> 
						</a>
					</div>
					<div class="diff_tags">
						<div class="diff_tags_left"><span>65m²</span><span>3P</span></div>
						<div class="diff_tags_right">283 000euros
                           <span>4 183euros/m²</span></div>
					</div>
				</div>
				<div class="Diffusimo_repBox_footer">
					<ul>
						<li>
							<select>
								<option>Voir l'offre</option>
								<option>Le boncoin</option>
								<option>Seloger</option>
								<option>Logicimmo</option>
							</select>
						</li>
						<li><img src="images/rankimo.png"/> 3/12</li>
						<li><i class="fa fa-eye"></i> 15</li>
					</ul></div>
				<div class="clr"></div>
			</div>
		</div>
		<div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
			<div class="Alertimo_repBox">
				<div class="Alertimo_repBox_header">
					<div class="diffHeader_left">
						<i class="fa fa-home"></i>
						<h4>Maison
						<span>74360 Bonnes</span>
						</h4>
					</div>
					<div class="diffHeader_right">Il y a 6jrs</div>	
					<div class="clearfix"></div>
				</div>
				<div class="Diffusimo_repBox_body">
					<div id="MaisonAppartement1" class="carousel slide" data-ride="carousel">
						<div class="carousel-inner">
							<div class="plus_cont">
							<i class="fa fa-plus"></i>
							<div class="txt_cont">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,
							</div>
							</div>
							<div class="item active" style="background:url(images/offrimo1.png)"></div>
							<div class="item" style="background:url(images/offrimo2.png)"></div>
						</div>
						<!-- Left and right controls -->
						<a class="left carousel-control" href="#MaisonAppartement1" data-slide="prev"> 
							<span class="glyphicon glyphicon-chevron-left"></span>  <span class="sr-only">Previous</span> 
						</a>
						<a class="right carousel-control" href="#MaisonAppartement1" data-slide="next"> 
							<span class="glyphicon glyphicon-chevron-right"></span>  <span class="sr-only">Next</span> 
						</a>
					</div>
					<div class="diff_tags">
						<div class="diff_tags_left"><span>65m²</span><span>3P</span></div>
						<div class="diff_tags_right">283 000euros
                           <span>4 183euros/m²</span></div>
					</div>
				</div>
				<div class="Diffusimo_repBox_footer">
					<ul>
						<li>
							<select>
								<option>Voir l'offre</option>
								<option>Le boncoin</option>
								<option>Seloger</option>
								<option>Logicimmo</option>
							</select>
						</li>
						<li><img src="images/rankimo.png"/> 3/12</li>
						<li><i class="fa fa-eye"></i> 15</li>
					</ul></div>
				<div class="clr"></div>
			</div>
		</div>
		<div class="col-xs-12 col-sm-6 col-md-4 col-lg-4">
			<div class="Alertimo_repBox">
				<div class="Alertimo_repBox_header">
					<div class="diffHeader_left">
						<i class="fa fa-home"></i>
						<h4>Terrain
						<span>74360 Bonnes</span>
						</h4>
					</div>
					<div class="diffHeader_right">Il y a 6jrs</div>	
					<div class="clearfix"></div>
				</div>
				<div class="Diffusimo_repBox_body">
					<div id="TerrainAppartement1" class="carousel slide" data-ride="carousel">
						<div class="carousel-inner">
							<div class="plus_cont">
							<i class="fa fa-plus"></i>
							<!--<i class="fa fa-close"></i>-->
							<div class="txt_cont">Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s,
							</div>
							</div>
							<div class="item active" style="background:url(images/offrimo1.png)"></div>
							<div class="item" style="background:url(images/offrimo2.png)"></div>
						</div>
						<!-- Left and right controls -->
						<a class="left carousel-control" href="#TerrainAppartement1" data-slide="prev"> 
							<span class="glyphicon glyphicon-chevron-left"></span>  <span class="sr-only">Previous</span> 
						</a>
						<a class="right carousel-control" href="#TerrainAppartement1" data-slide="next"> 
							<span class="glyphicon glyphicon-chevron-right"></span>  <span class="sr-only">Next</span> 
						</a>
					</div>
					<div class="diff_tags">
						<div class="diff_tags_left"><span>65m²</span><span>3P</span></div>
						<div class="diff_tags_right">283 000euros
                           <span>4 183euros/m²</span></div>
					</div>
				</div>
				<div class="Diffusimo_repBox_footer">
					<ul>
						<li>
							<select>
								<option>Voir l'offre</option>
								<option>Le boncoin</option>
								<option>Seloger</option>
								<option>Logicimmo</option>
							</select>
						</li>
						<li><img src="images/rankimo.png"/> 3/12</li>
						<li><i class="fa fa-eye"></i> 15</li>
					</ul></div>
				<div class="clr"></div>
			</div>
		</div>
		<div class="clr"></div>
	</div>
	<div id="deletConfor" class="modal fade deletConfor" role="dialog">
    <div class="modal-dialog">
		<div class="modal-content">
          <div class="clr"></div>
          <h3>Confirmer la demande de suppression?</h3>
		  <p>Voulez-vous que nous demandions votre confirmation de suppression?</p>
		  <div class="BtnBoxsec">
		  <button type="button" class="btn btn-default">Confirm</button>
		  <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
		  </div>
        </div>
    </div>
</div>
</div>