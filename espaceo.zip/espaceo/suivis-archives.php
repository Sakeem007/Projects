<?php include('header2.php');?>
<div class="container">
	<div class="row">
		<div class="SuivisArchives tab-content">
			<div class="banners" style="background-image: url(images/research-motor-img.png);">
				<div class="Banners_TxT">
					<h2>Suivis Archives</h2>				
					<!--<h5>
					<p class="CallimoTxt">offer's url: <span>http://35.180.116.227/offrimo</span></p>
					<p class="CallimoTxt">'date de la demande : <span>12/04/2019</span>'</p>
					<p class="CallimoTxt">'demande suivi par : <span>Philippe Soulie</span>'</p>
					</h5>-->
				</div>
			</div>
			<div class="CallimoOffers">
				<div class="repter">
					<div class="tablebox">
						<div class="box">
							<div class="img slider_Section">
								<div id="callimooffer1" class="carousel slide" data-ride="carousel">
									<!-- Wrapper for slides -->
									<div class="carousel-inner">
									  <div class="item active" style="background:url(images/offerimg1.jpg);"></div>
									  <div class="item" style="background:url(images/offerimg2.jpg);"></div>							
									  <div class="item" style="background:url(images/offerimg3.jpg);"></div>
									</div>
									<!-- Left and right controls -->
									<a class="left carousel-control" href="#callimooffer1" data-slide="prev">
									  <span class="glyphicon glyphicon-chevron-left"></span>
									  <span class="sr-only">Previous</span>
									</a>
									<a class="right carousel-control" href="#callimooffer1" data-slide="next">
									  <span class="glyphicon glyphicon-chevron-right"></span>
									  <span class="sr-only">Next</span>
									</a>
								</div>					
							</div>
						</div>
						<div class="box">
							<div class="contents callOferTxt">
								<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
							</div>
						</div>
						<div class="box">
							<div class="contents">
								<div class="CallimoTop">
									<p><strong>Offer’s URL:</strong> <span>http://35.180.116.227/offrimo</span></p>
									<p><strong>Date de la demande:</strong> <span>12/04/2019</span></p>
									<p><strong>Demande de suivi par:</strong> <span>Philippe Soulie</span></p>
								</div>
								<div class="CallimoBottom">
									<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
										<h5>Coordonnées :</h5>
										<p><strong>Nom:</strong><span>Philippe Soulie</span></p>
										<p><strong>Tel:</strong><span>0000 000 000</span></p>
										<p><strong>Mail:</strong><span>abc@hotmail.com</span></p>
									</div>	
									<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6 callimoNote">
										<textarea name="" cols="" rows="" placeholder="Note"></textarea>
									</div>						
								</div>						
							</div>
						</div>
						<div class="box ">
							<div class="contents callOferTxt1">
								<label><input type="checkbox"/><span></span> RDV PRIS</label>
								<label><input type="checkbox"/><span></span> RAPPEL</label>
								<label class="archiverRemove"><input type="checkbox"/><span></span> ARCHIVER</label>
							</div>
						</div>
					</div>
				</div>	
				<div class="repter">
					<div class="tablebox">
						<div class="box">
							<div class="img slider_Section">
								  <div id="callimooffer2" class="carousel slide" data-ride="carousel">
									<!-- Wrapper for slides -->
									<div class="carousel-inner">
									  <div class="item active" style="background:url(images/offerimg1.jpg);">
									  </div>
									  <div class="item" style="background:url(images/offerimg2.jpg);">
									  </div>							
									  <div class="item" style="background:url(images/offerimg3.jpg);">
									  </div>
									</div>
									<!-- Left and right controls -->
									<a class="left carousel-control" href="#callimooffer2" data-slide="prev">
									  <span class="glyphicon glyphicon-chevron-left"></span>
									  <span class="sr-only">Previous</span>
									</a>
									<a class="right carousel-control" href="#callimooffer2" data-slide="next">
									  <span class="glyphicon glyphicon-chevron-right"></span>
									  <span class="sr-only">Next</span>
									</a>
								  </div>					
							</div>
						</div>
						<div class="box">
							<div class="contents callOferTxt">
								<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
							</div>
						</div>
						<div class="box">
							<div class="contents">
								<div class="CallimoTop">
									<p><strong>Offer’s URL:</strong> <span>http://35.180.116.227/offrimo</span></p>
									<p><strong>Date de la demande:</strong> <span>12/04/2019</span></p>
									<p><strong>Demande de suivi par:</strong> <span>Philippe Soulie</span></p>
								</div>
								<div class="CallimoBottom">
									<h5>Coordonnées :</h5>
									<p><strong>Nom:</strong><span>Philippe Soulie</span></p>
									<p><strong>Tel:</strong><span>0000 000 000</span></p>
									<p><strong>Mail:</strong><span>abc@hotmail.com</span></p>
								</div>						
							</div>
						</div>
						<div class="box ">
							<div class="contents callOferTxt1">
								<label><input type="checkbox"/><span></span> RDV PRIS</label>
								<label><input type="checkbox"/><span></span> RAPPEL</label>
							</div>
						</div>
					</div>
				</div>
				<div class="repter">
					<div class="tablebox">
						<div class="box">
							<div class="img slider_Section">
								<div id="callimooffer3" class="carousel slide" data-ride="carousel">
									<!-- Wrapper for slides -->
									<div class="carousel-inner">
									  <div class="item active" style="background:url(images/offerimg2.jpg);"></div>
									  <div class="item" style="background:url(images/offerimg3.jpg);"></div>							
									  <div class="item" style="background:url(images/offerimg1.jpg);"></div>
									</div>
									<!-- Left and right controls -->
									<a class="left carousel-control" href="#callimooffer3" data-slide="prev">
									  <span class="glyphicon glyphicon-chevron-left"></span>
									  <span class="sr-only">Previous</span>
									</a>
									<a class="right carousel-control" href="#callimooffer3" data-slide="next">
									  <span class="glyphicon glyphicon-chevron-right"></span>
									  <span class="sr-only">Next</span>
									</a>
								</div>					
							</div>
						</div>
						<div class="box">
							<div class="contents callOferTxt">
								<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
							</div>
						</div>
						<div class="box">
							<div class="contents">
								<div class="CallimoTop">
									<p><strong>Offer’s URL:</strong> <span>http://35.180.116.227/offrimo</span></p>
									<p><strong>Date de la demande:</strong> <span>12/04/2019</span></p>
									<p><strong>Demande de suivi par:</strong> <span>Philippe Soulie</span></p>
								</div>
								<div class="CallimoBottom">
									<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
										<h5>Coordonnées :</h5>
										<p><strong>Nom:</strong><span>Philippe Soulie</span></p>
										<p><strong>Tel:</strong><span>0000 000 000</span></p>
										<p><strong>Mail:</strong><span>abc@hotmail.com</span></p>
									</div>	
									<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6 callimoNote">
										<textarea name="" cols="" rows="" placeholder="Note"></textarea>
									</div>						
								</div>						
							</div>
						</div>
						<div class="box ">
							<div class="contents callOferTxt1">
								<label><input type="checkbox"/><span></span> RDV PRIS</label>
								<label><input type="checkbox"/><span></span> RAPPEL</label>
								<label class="archiverRemove"><input type="checkbox"/><span></span> ARCHIVER</label>
							</div>
						</div>
					</div>
				</div>	
				<div class="repter">
					<div class="tablebox">
						<div class="box">
							<div class="img slider_Section">
								  <div id="callimooffer4" class="carousel slide" data-ride="carousel">
									<!-- Wrapper for slides -->
									<div class="carousel-inner">
									  <div class="item active" style="background:url(images/offerimg1.jpg);">
									  </div>
									  <div class="item" style="background:url(images/offerimg2.jpg);">
									  </div>							
									  <div class="item" style="background:url(images/offerimg3.jpg);">
									  </div>
									</div>
									<!-- Left and right controls -->
									<a class="left carousel-control" href="#callimooffer4" data-slide="prev">
									  <span class="glyphicon glyphicon-chevron-left"></span>
									  <span class="sr-only">Previous</span>
									</a>
									<a class="right carousel-control" href="#callimooffer4" data-slide="next">
									  <span class="glyphicon glyphicon-chevron-right"></span>
									  <span class="sr-only">Next</span>
									</a>
								  </div>					
							</div>
						</div>
						<div class="box">
							<div class="contents callOferTxt">
								<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
							</div>
						</div>
						<div class="box">
							<div class="contents">
								<div class="CallimoTop">
									<p><strong>Offer’s URL:</strong> <span>http://35.180.116.227/offrimo</span></p>
									<p><strong>Date de la demande:</strong> <span>12/04/2019</span></p>
									<p><strong>Demande de suivi par:</strong> <span>Philippe Soulie</span></p>
								</div>
								<div class="CallimoBottom">
									<h5>Coordonnées :</h5>
									<p><strong>Nom:</strong><span>Philippe Soulie</span></p>
									<p><strong>Tel:</strong><span>0000 000 000</span></p>
									<p><strong>Mail:</strong><span>abc@hotmail.com</span></p>
								</div>						
							</div>
						</div>
						<div class="box ">
							<div class="contents callOferTxt1">
								<label><input type="checkbox"/><span></span> RDV PRIS</label>
								<label><input type="checkbox"/><span></span> RAPPEL</label>
							</div>
						</div>
					</div>
				</div>		
				<div class="repter">
					<div class="tablebox">
						<div class="box">
							<div class="img slider_Section">
								<div id="callimooffer5" class="carousel slide" data-ride="carousel">
									<!-- Wrapper for slides -->
									<div class="carousel-inner">
									  <div class="item active" style="background:url(images/offerimg1.jpg);"></div>
									  <div class="item" style="background:url(images/offerimg3.jpg);"></div>							
									  <div class="item" style="background:url(images/offerimg2.jpg);"></div>
									</div>
									<!-- Left and right controls -->
									<a class="left carousel-control" href="#callimooffer5" data-slide="prev">
									  <span class="glyphicon glyphicon-chevron-left"></span>
									  <span class="sr-only">Previous</span>
									</a>
									<a class="right carousel-control" href="#callimooffer5" data-slide="next">
									  <span class="glyphicon glyphicon-chevron-right"></span>
									  <span class="sr-only">Next</span>
									</a>
								</div>					
							</div>
						</div>
						<div class="box">
							<div class="contents callOferTxt">
								<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
							</div>
						</div>
						<div class="box">
							<div class="contents">
								<div class="CallimoTop">
									<p><strong>Offer’s URL:</strong> <span>http://35.180.116.227/offrimo</span></p>
									<p><strong>Date de la demande:</strong> <span>12/04/2019</span></p>
									<p><strong>Demande de suivi par:</strong> <span>Philippe Soulie</span></p>
								</div>
								<div class="CallimoBottom">
									<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
										<h5>Coordonnées :</h5>
										<p><strong>Nom:</strong><span>Philippe Soulie</span></p>
										<p><strong>Tel:</strong><span>0000 000 000</span></p>
										<p><strong>Mail:</strong><span>abc@hotmail.com</span></p>
									</div>	
									<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6 callimoNote">
										<textarea name="" cols="" rows="" placeholder="Note"></textarea>
									</div>						
								</div>						
							</div>
						</div>
						<div class="box ">
							<div class="contents callOferTxt1">
								<label><input type="checkbox"/><span></span> RDV PRIS</label>
								<label><input type="checkbox"/><span></span> RAPPEL</label>
								<label class="archiverRemove"><input type="checkbox"/><span></span> ARCHIVER</label>
							</div>
						</div>
					</div>
				</div>	
				<div class="repter">
					<div class="tablebox">
						<div class="box">
							<div class="img slider_Section">
								  <div id="callimooffer6" class="carousel slide" data-ride="carousel">
									<!-- Wrapper for slides -->
									<div class="carousel-inner">
									  <div class="item active" style="background:url(images/offerimg1.jpg);">
									  </div>
									  <div class="item" style="background:url(images/offerimg2.jpg);">
									  </div>							
									  <div class="item" style="background:url(images/offerimg3.jpg);">
									  </div>
									</div>
									<!-- Left and right controls -->
									<a class="left carousel-control" href="#callimooffer4" data-slide="prev">
									  <span class="glyphicon glyphicon-chevron-left"></span>
									  <span class="sr-only">Previous</span>
									</a>
									<a class="right carousel-control" href="#callimooffer6" data-slide="next">
									  <span class="glyphicon glyphicon-chevron-right"></span>
									  <span class="sr-only">Next</span>
									</a>
								  </div>					
							</div>
						</div>
						<div class="box">
							<div class="contents callOferTxt">
								<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
							</div>
						</div>
						<div class="box">
							<div class="contents">
								<div class="CallimoTop">
									<p><strong>Offer’s URL:</strong> <span>http://35.180.116.227/offrimo</span></p>
									<p><strong>Date de la demande:</strong> <span>12/04/2019</span></p>
									<p><strong>Demande de suivi par:</strong> <span>Philippe Soulie</span></p>
								</div>
								<div class="CallimoBottom">
									<h5>Coordonnées :</h5>
									<p><strong>Nom:</strong><span>Philippe Soulie</span></p>
									<p><strong>Tel:</strong><span>0000 000 000</span></p>
									<p><strong>Mail:</strong><span>abc@hotmail.com</span></p>
								</div>						
							</div>
						</div>
						<div class="box ">
							<div class="contents callOferTxt1">
								<label><input type="checkbox"/><span></span> RDV PRIS</label>
								<label><input type="checkbox"/><span></span> RAPPEL</label>
							</div>
						</div>
					</div>
				</div>
				<div class="repter">
					<div class="tablebox">
						<div class="box">
							<div class="img slider_Section">
								<div id="callimooffer7" class="carousel slide" data-ride="carousel">
									<!-- Wrapper for slides -->
									<div class="carousel-inner">
									  <div class="item active" style="background:url(images/offerimg3.jpg);"></div>
									  <div class="item" style="background:url(images/offerimg2.jpg);"></div>							
									  <div class="item" style="background:url(images/offerimg1.jpg);"></div>
									</div>
									<!-- Left and right controls -->
									<a class="left carousel-control" href="#callimooffer7" data-slide="prev">
									  <span class="glyphicon glyphicon-chevron-left"></span>
									  <span class="sr-only">Previous</span>
									</a>
									<a class="right carousel-control" href="#callimooffer7" data-slide="next">
									  <span class="glyphicon glyphicon-chevron-right"></span>
									  <span class="sr-only">Next</span>
									</a>
								</div>					
							</div>
						</div>
						<div class="box">
							<div class="contents callOferTxt">
								<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
							</div>
						</div>
						<div class="box">
							<div class="contents">
								<div class="CallimoTop">
									<p><strong>Offer’s URL:</strong> <span>http://35.180.116.227/offrimo</span></p>
									<p><strong>Date de la demande:</strong> <span>12/04/2019</span></p>
									<p><strong>Demande de suivi par:</strong> <span>Philippe Soulie</span></p>
								</div>
								<div class="CallimoBottom">
									<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
										<h5>Coordonnées :</h5>
										<p><strong>Nom:</strong><span>Philippe Soulie</span></p>
										<p><strong>Tel:</strong><span>0000 000 000</span></p>
										<p><strong>Mail:</strong><span>abc@hotmail.com</span></p>
									</div>	
									<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6 callimoNote">
										<textarea name="" cols="" rows="" placeholder="Note"></textarea>
									</div>						
								</div>						
							</div>
						</div>
						<div class="box ">
							<div class="contents callOferTxt1">
								<label><input type="checkbox"/><span></span> RDV PRIS</label>
								<label><input type="checkbox"/><span></span> RAPPEL</label>
								<label class="archiverRemove"><input type="checkbox"/><span></span> ARCHIVER</label>
							</div>
						</div>
					</div>
				</div>
				<div class="repter">
					<div class="tablebox">
						<div class="box">
							<div class="img slider_Section">
								  <div id="callimooffer8" class="carousel slide" data-ride="carousel">
									<!-- Wrapper for slides -->
									<div class="carousel-inner">
									  <div class="item active" style="background:url(images/offerimg1.jpg);">
									  </div>
									  <div class="item" style="background:url(images/offerimg2.jpg);">
									  </div>							
									  <div class="item" style="background:url(images/offerimg3.jpg);">
									  </div>
									</div>
									<!-- Left and right controls -->
									<a class="left carousel-control" href="#callimooffer8" data-slide="prev">
									  <span class="glyphicon glyphicon-chevron-left"></span>
									  <span class="sr-only">Previous</span>
									</a>
									<a class="right carousel-control" href="#callimooffer8" data-slide="next">
									  <span class="glyphicon glyphicon-chevron-right"></span>
									  <span class="sr-only">Next</span>
									</a>
								  </div>					
							</div>
						</div>
						<div class="box">
							<div class="contents callOferTxt">
								<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
							</div>
						</div>
						<div class="box">
							<div class="contents">
								<div class="CallimoTop">
									<p><strong>Offer’s URL:</strong> <span>http://35.180.116.227/offrimo</span></p>
									<p><strong>Date de la demande:</strong> <span>12/04/2019</span></p>
									<p><strong>Demande de suivi par:</strong> <span>Philippe Soulie</span></p>
								</div>
								<div class="CallimoBottom">
									<h5>Coordonnées :</h5>
									<p><strong>Nom:</strong><span>Philippe Soulie</span></p>
									<p><strong>Tel:</strong><span>0000 000 000</span></p>
									<p><strong>Mail:</strong><span>abc@hotmail.com</span></p>
								</div>						
							</div>
						</div>
						<div class="box ">
							<div class="contents callOferTxt1">
								<label><input type="checkbox"/><span></span> RDV PRIS</label>
								<label><input type="checkbox"/><span></span> RAPPEL</label>
							</div>
						</div>
					</div>
				</div>
			</div>	
		</div>	
	</div>	
</div>
	
<?php include('footer.php');?>