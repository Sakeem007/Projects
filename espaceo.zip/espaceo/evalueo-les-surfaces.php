<div class="surfaces">
	
	<h5>Le Calcul des Surfaces</h5>
	<div class="row">
		<aside class="item col-xs-12 col-sm-12 col-md-12 col-lg-12">
			<label><input type="checkbox"/><em></em> Je ne calcule pas la surface  pondéréé totale, je la connais, c’est <span class="input-m2"><input type="text"/></span></label>
			<label><input type="checkbox"/><em></em> Je souhaite calculer la surface pondéréé totale</label>
		</aside>
		<aside class="form col-xs-12 col-sm-12 col-md-12 col-lg-12">
			<div class="orangeBorder">
				<div class="head">Les surface intérieures</div>
				<form action="#">
					<label><input type="checkbox"/><em></em> Je connais la surface interiéure totale, c’est <span class="input-m2"><input type="text"/></span></label>
					<label><input type="checkbox"/><em></em> Je souhaite calculer la surface intérieure totale</label>
					<label>Surface Sous-Sol <span class="input-m2"><input type="text"/></span></label>
					<label>Surface RDC <span class="input-m2"><input type="text"/></span></label>
					<label>Surface des étage(s) <span class="input-m2"><input type="text"/></span></label>
				</form>
			</div>
		
			<div class="orangeBorder">
				<div class="head">Les surface intérieures</div>
				<form action="#">
					<label><input type="checkbox"/><em></em> Je connais la surface interiéure totale, c’est <span class="input-m2"><input type="text"/></span></label>
					<label><input type="checkbox"/><em></em> Je souhaite calculer la surface intérieure totale</label>
					<label>Véranda(s) <span class="input-m2"><input type="text"/></span></label>
					<label>Balcon(s) <span class="input-m2"><input type="text"/></span></label>
					<label>Terrasse(s) <span class="input-m2"><input type="text"/></span></label>
					<label>Garage(s) <span class="input-m2"><input type="text"/></span></label>
					<label>Batiment annexe (s) <span class="input-m2"><input type="text"/></span></label>
				</form>
			</div>
		</aside>
		<h6>Le résultat aprés pondération de la surface totale est	<span class="input-m2"><input type="text"/></span></h6>
	</div>
</div>