<div id="Sectorimo" class="item tab-pane fade in active">
	<div class="row">
	<div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 Obj_sectorimo_Wrapper">
		<div class="col-xs-12 col-sm-5 col-md-5 col-lg-5">
			<div class="map-sectorimo">
				<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d11379754.90301434!2d-6.929476864819009!3d45.86609808040356!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd54a02933785731%3A0x6bfd3f96c747d9f7!2sFrance!5e0!3m2!1sen!2sin!4v1534584981505" width="100%" height="464" frameborder="0" style="border:0" allowfullscreen></iframe>			
			</div>
			<div class="col-xs-12 maison-bottom-list">
				<ul class="Obj_sectorimo_map_Box sectorimoActive">
					<li class="green_icon"><a href="#"><i class="green-btn fa fa-circle"></i> Activée(s)</a></li>
					<li class="red_icon"><a href="#"><i class="red-btn fa fa-circle"></i> A activer</a></li>
				</ul>
			</div>
		</div>
		
		<div class="col-xs-12 col-sm-7 col-md-7 col-lg-7 Tableau_bord_right">
		<div class="sliderArrowBox"><a href="#"><i class="fa fa-angle-left"></i></a> Retour Tableau de Board <!--<i class="fa fa-angle-left"></i>--></div>
			
			<ul class="cecterimoRight_Box">
				<li class="">
					<select>
						<option>Paramétrer Une ZAC</option>
						<option>Name</option>
					</select> <span>(un département)</span>
				</li>
				<li class="Stxt_box"><i class="fa fa-map-marker"></i> Ajouter une ZAC:</li>
				<li class=""><input type="text" placeholder="Rhone-Alpes" value=""/><i class="fa fa-times"></i><i class="fa fa-edit"></i>
				</li>
				<li class=""><input type="text" value=""/><i class="fa fa-plus"></i><a class="resetlast" href="#"></a><button class="ValiderBtn">Valider</button></li>
				<li class="Stxt_box"><i class="fa fa-user"></i> Associer un Leader:</li>
				<li class=""><input type="text" placeholder="Rhone-Alpes" value=""/> <input type="text" placeholder="Philipper Soulie" value=""/><i class="fa fa-edit"></i></li>
				<li class=""><input type="text" value=""/><i class="fa fa-plus"></i><a class="resetlast" href="#"></a><button class="ValiderBtn">Valider</button></li>
				<li class="Stxt_box1">ZAC(s) activée(s): 1</li>
				<li class="Stxt_box">ZAC(s) à activer: 12</li>

			</ul>
		</div>
	</div>

	</div>
</div>