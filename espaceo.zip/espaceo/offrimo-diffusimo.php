<div class="banners" style="background-image: url(images/bg-4.jpg);">
	<h2>Diffusimo</h2>
	<p>"J'optimise et je suis mes annonces diffusées sur le web"</p>
	<h5>Je veux consulter mes annonces diffusées par 
	<select>
		<option>catégories</option>
	</select> suivant le 
	<select>
		<option>type</option>
	</select> ayant  
	<select>
		<option>un style</option>
	</select>  avec les 
	<select>
		<option>caractéristiques</option>
	</select> et bénéficiant des 
	<select>
		<option>plus</option>
	</select></h5>
	<a href="#" class="whiteBtn">Lancer mon listing</a>
	<a href="#" class="whiteBtn">Lancer listing team</a>
</div>
<div class="offrimo">
	<div class="filter diffusimo">
		<form action="#" method="post">
			<ul>
				<li>Filtre :</li>
				<li>
					<select>
						<option>Par agent</option>
						<option>Par agent</option>
					</select>
				</li>
				<li>
					<select>
						<option>Item like eye</option>
						<option>Item like eye</option>
					</select>
				</li>
				<li>
					<select>
						<option>Contacts</option>
						<option>Contacts</option>
					</select>
				</li>
				<li>
					<select>
						<option>Taux visibilite</option>
						<option>Taux visibilite</option>
					</select>
				</li>
				<li>
					<select>
						<option>Prix</option>
						<option>Prix</option>
					</select>
				</li>
				<li>
					<select>
						<option>Signes</option>
						<option>Signes</option>
					</select>
				</li>
				<li><button type="submit">Lancer filter</button></li>
				<li>
					<div class="search">
						<input type="text" value="Mots clefs" class="searchInput"/>
						<input type="submit" value="" class="searchBtn"/>
					</div>
				</li>
			</ul>
		</form>
	</div>
	<div class="listing">
		<form action="#" method="post">
			<ul>
				<li>Biens diffuses</li>
				<li><input type="text" value="31"/></li>
			</ul>
		</form>
	</div>
	<div class="repter">
		<div class="diffusimo" id="diffusimo_togg_show">
			<div class="box">
				<div class="slider">
					<div id="owl-slider1" class="slider owl-carousel">
						<div class="img" style="background-image: url(images/offrimo1.png)">
							<span class="locBtn">Douvaine</span>
						</div>
						<div class="img" style="background-image: url(images/offrimo1.png)">
							<span class="locBtn">Douvaine</span>
						</div>
						<div class="img" style="background-image: url(images/offrimo1.png)">
							<span class="locBtn">Douvaine</span>
						</div>
					</div>
				</div>
			</div>
			<div class="box">
				<div class="headerTop">Généralités</div>
				<div class="contents">
					<label><i class="fa fa-eye"></i> : 37</label>
					<label>Contacts : 3</label>
					<label>Tx visibilité : 8%</label>
					<label>N° mandat : 214</label>
					<div class="showDiff">
						<label>Réf:132</label>
						<label>HC: P.Soulié</label>
						<label>Prix: 480 000 euros</label>
					</div>
				</div>
			</div>
			<div class="box">
				<div class="headerTop">Catégorie</div>
				<div class="contents">
					<label><input type="checkbox"/><span></span> Prestige</label>
					<label><input type="checkbox"/><span></span> Classique</label>
					<label><input type="checkbox"/><span></span> Neuf</label>
					<div class="showDiff">
						<label></label>
					</div>
				</div>
			</div>
			<div class="box">
				<div class="headerTop">Type</div>
				<div class="contents">
					<label><input type="checkbox"/><span></span> Maison</label>
					<label><input type="checkbox"/><span></span> Maison de ville</label>
					<label><input type="checkbox"/><span></span> Appt</label>
					<label><input type="checkbox"/><span></span> Terrain</label>
					<div class="showDiff">
						<label><input type="checkbox"/><span></span> Immeuble</label>
					</div>
				</div>
			</div>
			<div class="box">
				<div class="headerTop">Style architectural</div>
				<div class="contents">
					<label><input type="checkbox"/><span></span> Traditionnel</label>
					<label><input type="checkbox"/><span></span> Contemporain</label>
					<label><input type="checkbox"/><span></span> Ossature Bois</label>
					<label><input type="checkbox"/><span></span> Vielles Pierres</label>
					<div class="showDiff">
						<label></label>
					</div>
				</div>
			</div>
			<div class="box">
				<div class="headerTop">Caractéristiques</div>
				<div class="contents">
					<label><input type="checkbox"/><span></span> PP</label>
					<label><input type="checkbox"/><span></span> Atique</label>
					<label><input type="checkbox"/><span></span> RDJ</label>
					<label><input type="checkbox"/><span></span> RDC</label>
					<div class="showDiff">
						<label><input type="checkbox"/><span></span> Duplex</label>
						<label><input type="checkbox"/><span></span> A rénover </label>
						<label><input type="checkbox"/><span></span> DP possible</label>
					</div>
				</div>
			</div>
			<div class="box">
				<div class="headerTop">Les plus</div>
				<div class="contents">
					<label><input type="checkbox"/><span></span> Piscine</label>
					<label><input type="checkbox"/><span></span> Vue Lac</label>
					<label><input type="checkbox"/><span></span> Vue Montagnes</label>
					<label><input type="checkbox"/><span></span> Pieds dans l'eau</label>
					<div class="showDiff">
						<label><input type="checkbox"/><span></span> Cheminée</label>
						<label><input type="checkbox"/><span></span> Garage</label>
						<label><input type="checkbox"/><span></span> Cave</label>
						<label><input type="checkbox"/><span></span> SPA</label>
						<label><input type="checkbox"/><span></span> Home cinéma</label>
					</div>
				</div>
			</div>
			<div class="box">
				<div class="headerTop">Les signes</div>
				<div class="contents">
					<label><input type="checkbox"/><span></span> Coup coeur</label>
					<label><input type="checkbox"/><span></span> Vendu</label>
					<label><input type="checkbox"/><span></span> Exclusivité</label>
					<label><input type="checkbox"/><span></span> Nouveauté</label>
					<div class="showDiff">
						<label><input type="checkbox"/><span></span> Prix evalueo</label>
						<label><input type="checkbox"/><span></span> Optimeo</label>
					</div>
				</div>
			</div>
			<a href="javascript:void(0);" id="all_Diff_check_open"></a>
		</div>
	</div>
</div>