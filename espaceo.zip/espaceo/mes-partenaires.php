<div class="CallimoDashboardBox MesPartenair">
	<div class="tableColum col-xs-12 col-sm-12 col-md-12 col-lg-12">
		<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6">
			<div class="row MesPartenersLeft">
				<input type="" placeholder="Recherche..." />
			</div>
		</div>
		<div class="col-xs-12 col-sm-6 col-md-6 col-lg-6"><!-- #apporteur-Ajouter-List -->
			<div class="row MesPartenersRight"><a href="javacript:void(0)" data-toggle="modal" data-backdrop="true"><i class="fa fa-plus"></i> Ajouter un Partenaire</a></div>
		</div>
		<div class="clearfix"></div>
		<div class="MesDetailsList">
		<table width="100%" border="0" cellpadding="10">
		  <tr>
			<th align="center" valign="middle">Agence </th>
			<th align="center" valign="middle">Ville</th>
			<th align="center" valign="middle">Contact</th>
			<th align="center" valign="middle">Telephone</th>
			<th align="center" valign="middle">Mail</th>
			<th align="center" valign="middle">Nombre interimo<br /> diffusés</th>
			<th align="center" valign="middle">Délegations en<br /> cours avec ce<br /> partenaire</th>
			<th align="center" valign="middle">Interimo actés</th>
		  </tr>
		  <tr>
			<td align="center" valign="middle">Century 21</td>
			<td align="center" valign="middle">Toulouse</td>
			<td align="center" valign="middle">Natacha</td>
			<td align="center" valign="middle">06..</td>
			<td align="center" valign="middle">abc@gmail.com</td>
			<td align="center" valign="middle">20</td>
			<td align="center" valign="middle">2</td>
			<td align="center" valign="middle">4</td>
		  </tr>
		  <tr>
			<td align="center" valign="middle">Century 21</td>
			<td align="center" valign="middle">Toulouse</td>
			<td align="center" valign="middle">Natacha</td>
			<td align="center" valign="middle">06..</td>
			<td align="center" valign="middle">abc@gmail.com</td>
			<td align="center" valign="middle">20</td>
			<td align="center" valign="middle">2</td>
			<td align="center" valign="middle">4</td>
		  </tr>
		  <tr>
			<td align="center" valign="middle">Century 21</td>
			<td align="center" valign="middle">Toulouse</td>
			<td align="center" valign="middle">Natacha</td>
			<td align="center" valign="middle">06..</td>
			<td align="center" valign="middle">abc@gmail.com</td>
			<td align="center" valign="middle">20</td>
			<td align="center" valign="middle">2</td>
			<td align="center" valign="middle">4</td>
		  </tr>
		</table>
		</div>
	</div>
</div>

