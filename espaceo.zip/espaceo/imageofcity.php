<?php
$format = 'json';
$location = 'Douvaine%2074140%20France';
$key = 'AIzaSyAJavS77dchhzdJSxEOmvEEG9D-SJxsHe0';
$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => "https://maps.googleapis.com/maps/api/place/findplacefromtext/json?input=".$location."&inputtype=textquery&fields=photos%2Cformatted_address%2Cname%2Crating%2Copening_hours%2Cgeometry&key=AIzaSyAJavS77dchhzdJSxEOmvEEG9D-SJxsHe0",
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => "",
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 30,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => "GET",
  CURLOPT_HTTPHEADER => array(
    "cache-control: no-cache",
    "postman-token: fa2bb91b-591e-004c-e9d0-cff2dc9c12ef"
  ),
));

$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
  echo "cURL Error #:" . $err;
} else {
  $response;
}


$output = json_decode($response, true);
//echo "<pre>";
$referencecode=$output['candidates'][0]['photos'][0]['photo_reference'];
?>

<img src="<?php echo 'https://maps.googleapis.com/maps/api/place/photo?maxwidth=400&photoreference='.$referencecode.'&key=AIzaSyAJavS77dchhzdJSxEOmvEEG9D-SJxsHe0'; ?>" >