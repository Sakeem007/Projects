<div class="tableLay">
	<div class="tableCell">
		<div class="heading">L'offer des biens comparables:</div>
		<div class="text">
			<ul>
				<li>Offer des biens comparables PAP : <strong>52 biens</strong></li>
				<li>Offer des biens comparables PRO : <strong>89 biens</strong></li>
				<li>Prix moyen des biens comparables PRO : <strong>245 500 biens</strong></li>
				<li>Delai moyen de mise en ligne des biens : <strong>30 jours</strong></li>
				<li>depuis 01/01/2017 nombre de biens comparable mise en vente : <strong>1800 biens</strong></li>
				<li>En moyenne mensuelle, il y a <strong>165 biens</strong> comparables mise en vente</li>
			</ul>
		</div>
		<div class="analyseBtn">
			<a href="#" class="">Nous conseillons EVALUEO pour determiner le juste prix</a>
		</div>
	</div>
	<div class="tableCell">
		<div class="heading">L'offer des biens comparables:</div>
		<div class="text">
			<ul>
				<li>Nombre de biens comparables :</li>
				<li>Meilleur prix du biens comparable:</li>
				<li>Votre bien serait 18/89 biens comparables</li>
				<li>Le prix de votre bien serait de:
					<ul>
						<li>+23% superieur a la moyenne des biens comparables soit +12500 &euro;</li>
						<li>+23% superieur a la moyenne des biens comparables soit +18200 &euro;</li>
					</ul>
				</li>
			</ul>
		</div>
		<div class="analyseBtn">
			<a href="#" class="">Deposer votre annonce gratuitement sur pourquoipasla.com</a>
		</div>
	</div>
</div>
<div class="comparimoAnalyseBtn">
	<div class="analyseBtn">
		<a href="#" class="">Nous conseillons EVALUEO pour determiner le juste prix</a>
	</div>
	<div class="analyseBtn">
		<a href="#" class="">Deposer votre annonce gratuitement sur pourquoipasla.com</a>
	</div>
</div>