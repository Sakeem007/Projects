<div class="max-content">
	<div class="row">
		<div class="yellowCont">
			<aside class="leftCol col-xs-12 col-sm-12 col-md-12 col-lg-7">			
				<div class="heading">
					<h5>Les 2 Paramètres :</h5>
					Valeur du loyer et taux de rendement 
				</div>
				<div class="heading">
					<h5>Valeur du loyer</h5>
				</div>
				<div class="yellowBorder">
					<h6> La valeur par dèfaut</h6>
					
					<div class="checkBoxes">
						<label>Soit un loyer mensuel</label>
						<label><input type="checkbox"/><em></em> Je prends cette variable</label>
						<label><input type="checkbox"/><em></em> Je pondère cette valeur</label>
						<label><input type="checkbox"/><em></em> Je connais la valeur du terrain</label>
					</div>
					<div class="formRight">
						<div class="price">
							<div class="euro"><input type="text" value=""/><span>&euro;/<small>m<sup>2</sup></small></span></div>
						</div>
						<div class="price">
							<div class="euro"><input type="text" value=""/><span>&euro;/<small>mois</small></span></div>
						</div>
						<div class="ponderation">
							<ul>
								<li class="active"></li>
								<li></li>
								<li></li>
							</ul>
						</div>
						<div class="price">
							<div class="euro"> <input type="text" value=""/><span>&euro;</span></div>
						</div>
					</div>
				</div>
				<div class="heading">
					<h5>Taux de rendement</h5>
				</div>
				<div class="yellowBorder">
					<h6>La taux de rendement par dèfaut est</h6>
					<div class="checkBoxes">						
						<label><input type="checkbox"/><em></em> Je prends cette variable</label>
						<label><input type="checkbox"/><em></em> Je pondère cette valeur</label>
						<label><input type="checkbox"/><em></em> Je souhaite utiliser ce taux</label>
					</div>
					<div class="formRight">
						<div class="price">
							<div class="percent"> <input type="text" value=""/><span>%</span></div>
						</div>
						<div class="ponderation">
							<ul>
								<li class="active"></li>
								<li></li>
								<li></li>
							</ul>
						</div>
						<div class="price">
							<div class="percent"> <input type="text" value=""/><span>%</span></div>
						</div>
					</div>
				</div>
			</aside>
			<aside class="rightCol col-xs-12 col-sm-12 col-md-12 col-lg-5">
				<div class="heading">
					<h5> Simulation en temps rèel de la valeur par capitalisation<h5>
				</div>				
				<div class="textBoxes">
					<h6>Valeur du bien " Suivant les valeurs par défaut" : 455000 &euro;</h6>
				
					<h6>Valeur du bien " Suivant les valeurs pondérées" : 455000 &euro;</h6>
				</div>
			</aside>			
		</div>
	</div>
</div>