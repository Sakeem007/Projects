<div class="evalueo">	
	<div class="row">
		<aside class="item col-xs-12 col-sm-12 col-md-12 col-lg-12">
			<div class="filter">
				<form action="#" method="post">
					<ul>
						<li>Filtre :</li>
						<li><select>
							<option>Type</option>
							<option>Type</option>
							<option>Type</option>
						</select></li>
						<li><select>
							<option>Ville</option>
							<option>Ville</option>
							<option>Ville</option>
						</select></li>
						<li><select>
							<option>Pieus</option>
							<option>Pieus</option>
							<option>Pieus</option>
						</select></li>
						<li><select>
							<option>Euipe</option>
							<option>Euipe</option>
							<option>Euipe</option>
						</select></li>
						<li><input type="text" value="Mof clegr"/></li>
						<li class="btns"><button type="submit" class="submit"></button></li>
					</ul>
				</form>
			</div>
			<div class="onglet">
				<div class="img"><img src="images/map4.jpg"/></div>
				<div class="text">
					<span class="dots3" data-toggle="tab" data-target="#Le_Bien"></span>
					<p>Maison <a href="javascript:void(0);" class="myBtn">nouveau prix</a></p>
					<h6>41 Avenue du Lac, 74140 Douvaine</h6>
					<span class="value">150 m<sup>2</sup></span>
					<span class="value">5 pieces</span>
				</div>
			</div>
			<div class="onglet">
				<div class="img"><img src="images/map3.jpg"/></div>
				<div class="text">
					<span class="dots3" data-toggle="tab" data-target="#Le_Bien"></span>
					<p>Maison <a href="javascript:void(0);" class="myBtn">nouveau prix</a></p>
					<h6>3 Rue des Bolliets, 74140 Douvaine</h6>
					<span class="value">140 m<sup>2</sup></span>
					<span class="value">4 pieces</span>
				</div>
			</div>
			<div class="onglet">
				<div class="img"><img src="images/map4.jpg"/></div>
				<div class="text">
					<span class="dots3" data-toggle="tab" data-target="#Le_Bien"></span>
					<p>Maison <a href="javascript:void(0);" class="myBtn">nouveau prix</a></p>
					<h6>41 Avenue du Lac, 74140 Douvaine</h6>
					<span class="value">150 m<sup>2</sup></span>
					<span class="value">5 pieces</span>
				</div>
			</div>
			<div class="onglet">
				<div class="img"><img src="images/map3.jpg"/></div>
				<div class="text">
					<span class="dots3" data-toggle="tab" data-target="#Le_Bien"></span>
					<p>Maison <a href="javascript:void(0);" class="myBtn">nouveau prix</a></p>
					<h6>90 Rue de la Gare, 74500 Amphion les Bains</h6>
					<span class="value">110 m<sup>2</sup></span>
					<span class="value">5 pieces</span>
				</div>
			</div>
		</aside>
	</div>
</div>