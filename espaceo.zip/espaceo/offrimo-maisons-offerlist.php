<?php include('header.php');?>
<div class="comparatorWrapper">
	<div class="container">
		<div class="row">
			<div class="tab-content">
				<h3>Comparez tous vos biens en un seul coup d’oeil !</h3>	
				<div class="table-responsive">
				  <table class="table table-sm">
					<thead>
					  <tr>
						<th scope="row">Libellé/Biens <br>Localisation</th>
						<td> 
							<div class="comparator-property-image"> 
								<a href="#" class="comparator-remove bg-danger" ><span class="fa fa-times"></span></a>
								<div class="properties-content-img"><img src="images/offerimg1.jpg"></div>
							</div>
							Ballaison <a class="btn btn-primary see-property-btn" role="button" href="#">Voir la ville</a>
						</td>
						<td>
							<div class="comparator-property-image"> 
								<a href="#" class="comparator-remove bg-danger" ><span class="fa fa-times"></span></a>
								<div class="properties-content-img"><img src="images/offerimg2.jpg"></div>
						    </div>
							Veigy-Foncenex <a class="btn btn-primary see-property-btn" role="button" href="#">Voir la ville</a>
						</td>
						<td>
							<div class="comparator-property-image"> 
								<a href="#" class="comparator-remove bg-danger" ><span class="fa fa-times"></span></a>
								<div class="properties-content-img"><img src="images/offerimg3.jpg"></div>
						    </div>
							Veigy-Foncenex <a class="btn btn-primary see-property-btn" role="button" href="#">Voir la ville</a>
						</td>						
					  </tr>
					  <tr>
						<th scope="row">Type(s) de bien</th>
						<td> Maison <a class="btn btn-warning" role="button" href="#offrimoCityList" data-toggle="modal" data-backdrop="true">Voir l'annonce</a></td>
						<td> Maison de village <a class="btn btn-warning" role="button" href="#offrimoCityList" data-toggle="modal" data-backdrop="true">Voir l'annonce</a></td>
						<td> Maison de village <a class="btn btn-warning" role="button" href="#offrimoCityList" data-toggle="modal" data-backdrop="true">Voir l'annonce</a></td>
					  </tr>					  
					</thead>
					<tbody>
						<tr>
							<th scope="row">Prix annoncé<br>Rank prix</th>
							<td> 580000 € <span>82/3</span></td>
							<td> 610000 € <span>83/3</span></td>
							<td> 900000 € <span>81/3</span></td>
						</tr>
						<tr>
							<th scope="row">Surface habitable <br>Rank Surface</th>
							<td>160 m² <span>2/3</span></td>
							<td>180 m² <span>1/3</span></td>
							<td>140 m² <span>3/3</span></td>
						</tr>
						<tr>
							<th scope="row">Nombre de pièces<br>Rank Pièce(s)</th>
							<td>5 <span>2/3</span> </td>
							<td>6 <span>1/3</span> </td>
							<td>4 <span>3/3</span></td>
						</tr>
						<tr>
							<th scope="row">Nombre de Chambre(s)<br>Rank chambre(s)</th>
							<td>4 <span>2/3</span> </td>
							<td>5 <span>1/3</span> </td>
							<td>3 <span>3/3</span></td>
						</tr>
						<tr>
							<th scope="row">DPE</th>
							<td>5 <span>2/3</span> </td>
							<td>6 <span>1/3</span> </td>
							<td>4 <span>3/3</span></td>
						</tr>
						<tr>
							<th scope="row">GPS</th>
							<td>4 <span>2/3</span> </td>
							<td>5 <span>1/3</span> </td>
							<td>3 <span>3/3</span></td>
						</tr>
							<th id="ComepareShow" scope="row"><i class="fa fa-plus"></i> de critères <i class="fa fa-angle-down"></i></th>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
							<td>&nbsp;</td>
						</tr>
					</tbody>
					<tbody class="ComepareProperties" style="display:none;">						
					  <tr>
						<th scope="row">Surface terrain</th>
						<td> 1101  m² </td>
						<td> 76  m² </td>
						<td> - </td>						
					  </tr>
						<tr>
							<th scope="row">Garage</th>
							<td><i class="fa fa-check text-success"></i></td>
							<td><i class="fa fa-times text-danger"></i></td>
							<td><i class="fa fa-times text-danger"></i></td>
						</tr>
						<tr>
							<th scope="row">Jardin</th>
							<td><i class="fa fa-check text-success"></i></td>
							<td><i class="fa fa-times text-danger"></i></td>
							<td><i class="fa fa-times text-danger"></i></td>
						</tr>
						<tr>
							<th scope="row">Balcon</th>
							<td><i class="fa fa-check text-success"></i></td>
							<td><i class="fa fa-times text-danger"></i></td>
							<td><i class="fa fa-times text-danger"></i></td>
						</tr>
						<tr>
							<th scope="row">Terrasse</th>
							<td><i class="fa fa-check text-success"></i></td>
							<td><i class="fa fa-times text-danger"></i></td>
							<td><i class="fa fa-times text-danger"></i></td>
						</tr>
						<tr>
							<th scope="row">Sous-sol</th>
							<td><i class="fa fa-check text-success"></i></td>
							<td><i class="fa fa-times text-danger"></i></td>
							<td><i class="fa fa-times text-danger"></i></td>
						</tr>
						<tr>
							<th scope="row">Avec stationnement</th>
							<td><i class="fa fa-check text-success"></i></td>
							<td><i class="fa fa-times text-danger"></i></td>
							<td><i class="fa fa-times text-danger"></i></td>
						</tr>
						<tr>
							<th scope="row">Fibre optique</th>
							<td><i class="fa fa-check text-success"></i></td>
							<td><i class="fa fa-times text-danger"></i></td>
							<td><i class="fa fa-times text-danger"></i></td>
						</tr>
						<tr>
							<th scope="row">Fibre optique</th>
							<td><i class="fa fa-check text-success"></i></td>
							<td><i class="fa fa-times text-danger"></i></td>
							<td><i class="fa fa-times text-danger"></i></td>
						</tr>
						<tr>
							<th scope="row">Piscine</th>
							<td><i class="fa fa-check text-success"></i></td>
							<td><i class="fa fa-times text-danger"></i></td>
							<td><i class="fa fa-times text-danger"></i></td>
						</tr>
						<tr>
							<th scope="row">Double vitrage</th>
							<td><i class="fa fa-check text-success"></i></td>
							<td><i class="fa fa-times text-danger"></i></td>
							<td><i class="fa fa-times text-danger"></i></td>
						</tr>
						<tr>
							<th scope="row">Volets manuels</th>
							<td><i class="fa fa-check text-success"></i></td>
							<td><i class="fa fa-times text-danger"></i></td>
							<td><i class="fa fa-times text-danger"></i></td>
						</tr>
						<tr>
							<th scope="row">WC indépendant</th>
							<td><i class="fa fa-check text-success"></i></td>
							<td><i class="fa fa-times text-danger"></i></td>
							<td><i class="fa fa-check text-success"></i></td>
						</tr>
						<tr>
							<th scope="row">Disponible immédiatement</th>
							<td><i class="fa fa-check text-success"></i></td>
							<td><i class="fa fa-check text-success"></i></td>
							<td><i class="fa fa-check text-success"></i></td>
						</tr>
						<tr>
							<th scope="row">Cuisine équipée</th>
							<td><i class="fa fa-check text-success"></i></td>
							<td><i class="fa fa-times text-danger"></i></td>
							<td><i class="fa fa-times text-danger"></i></td>
						</tr>
						<tr>
							<th scope="row">Raccordé à l'eau et l'électricité</th>
							<td><i class="fa fa-check text-success"></i></td>
							<td><i class="fa fa-times text-danger"></i></td>
							<td><i class="fa fa-times text-danger"></i></td>
						</tr>
						<tr>
							<th scope="row">Ascenseur</th>
							<td><i class="fa fa-times text-danger"></i></td>
							<td><i class="fa fa-times text-danger"></i></td>
							<td><i class="fa fa-check text-success"></i></td>
						</tr>
						<tr>
							<th scope="row">Copropriétés</th>
							<td><i class="fa fa-times text-danger"></i></td>
							<td><i class="fa fa-times text-danger"></i></td>
							<td><i class="fa fa-check text-success"></i></td>
						</tr>
						<tr>
							<th scope="row">Porte blindé</th>
							<td><i class="fa fa-times text-danger"></i></td>
							<td><i class="fa fa-times text-danger"></i></td>
							<td><i class="fa fa-check text-success"></i></td>
						</tr>
						<tr>
							<th scope="row">Volets électriques</th>
							<td><i class="fa fa-times text-danger"></i></td>
							<td><i class="fa fa-times text-danger"></i></td>
							<td><i class="fa fa-check text-success"></i></td>
						</tr>
						<tr>
							<th scope="row">Cheminée</th>
							<td><i class="fa fa-times text-danger"></i></td>
							<td><i class="fa fa-times text-danger"></i></td>
							<td><i class="fa fa-times text-danger"></i></td>
						</tr>
					</tbody>
					<tbody>
					  <tr>
						<th scope="row">Rank Moyen</th>
						<td>2/3</td>
						<td>1/3</td>
						<td>3/3</td>
					  </tr>
					</tbody>

					</tbody>
				  </table>
				</div>
			</div>				
		</div>			
	</div>			
</div>
<!-- Modal suivi > Annonce -->
<div id="offrimoCityList" class="modal fade" role="dialog">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-body">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<iframe id="webviewiframe" src="https://www.leboncoin.fr/ventes_immobilieres/1529859683.htm/" seamless="" width="100%" height="400"></iframe>
			</div>
		</div>
	</div>
</div>	

<?php include('footer.php');?>
<?php include('modal.php');?>