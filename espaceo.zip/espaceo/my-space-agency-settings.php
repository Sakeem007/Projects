<div class="formGrid">
	<div class="tableColum">
		<div class="profile">
			<div class="img" style="background-image: url(images/camraicon.jpg);">
				<div class="overlay">
					<div class="overlay__text">
						<div class="upload-btn-wrapper">
						  <button class="btn"><img src="images/upload.png" width="30px" /></button>
						  <input type="file" name="myfile" />
						</div>
					 
					  <div>Upload Image</div>
					</div>
				</div>
			</div>	
			<div class="text">
				<h5>Agency name</h5>
				<small>City</small>			</div>
		</div>
		<div class="MySpaceSettings">
			<div class="title">Mon Agence:</div>
			<form action="#" method="post">
				<div class="form-group">
					<label>Nom :</label>
					<div class="input-field">
						<input type="text" name="" value=""/>
					</div>
				</div>
				<div class="form-group">
					<label>Tel  :</label>
					<div class="input-field">
						<input type="text" name="" value=""/>
					</div>
				</div>
				<div class="form-group">
					<label>Mail :</label>
					<div class="input-field">
						<input type="text" name="" value=""/>
					</div>				</div>
				<div class="form-group">
					<label>Adresse :</label>
					<div class="input-field">
						<input type="text" name="" value=""/>
					</div>
				</div>
				<div class="form-group">
					<label>Site web :</label>
					<div class="input-field">
						<input type="text" name="" value=""/>
					</div>
				</div>
				<div class="form-group">
					<label>Description :</label>
					<div class="input-field">
						<textarea name="" cols="" rows="4"></textarea>
					</div>
				</div>
				<div class="form-group">
					<input type="button" value="Modifier Paramètres" class="submit"/>
				</div>
			</form>
		</div>
	</div></div>